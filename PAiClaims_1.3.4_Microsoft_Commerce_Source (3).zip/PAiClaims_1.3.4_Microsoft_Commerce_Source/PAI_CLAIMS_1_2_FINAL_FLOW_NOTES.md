# PAi Claims 1.2.0 — Photo → PSi → Carrier → Parliament → Paid Flow

This build completes the estimating/claim-map flow defined for PAi Claims.

## Locked workflow

1. **Photos start the map.** PAi vision creates atomic propositions for damage, cause, location, extent, repair operation, quantity, materials, labor, equipment/access, disposal, permit allowance, tax allowance, O&P allowance, mobilization, protection/cleanup, price, and the reason for each price.
2. **Nothing required is blank.** Every cost component has a numeric rough value and explicit reason. Photo/LLM-created values start `SPECULATIVE`.
3. **The initial estimate is preserved.** Each photo pass writes an `initial_photo` PSi snapshot. Later passes never overwrite it.
4. **Regional Pass 2.** PSi searches the authorized Lowe's store feed/partner catalog by product ID or material description. It uses the job store/ZIP. If no direct material observation is available, it first uses a supplied Xactimate basis when possible; otherwise it retains a complete one-bracket model value.
5. **Regional factors stay explicit.** Material and labor regional-difference percentages are stored separately and appear in the reason for the adjusted amount.
6. **Labor rule is directional.** When the carrier/Xactimate estimate supplies worker-hours and labor rate, PSi calculates `hours × rate` and uses `MAX(PSi regional labor, Xactimate-supported labor)`. A lower carrier labor basis never reduces the existing PSi labor amount.
7. **All non-material costs remain visible.** Equipment/access, disposal, permits, tax, O&P, mobilization, protection/cleanup remain separate bracketed cost propositions rather than being hidden inside labor.
8. **5% high-side estimate allowance is explicit.** Default contingency is 5% and is shown as its own cost component/reason. It is configurable and never silently buried in line prices.
9. **Carrier/Xactimate is a new evidence path, not a replacement.** Carrier values are stored unchanged as competing/corroborating nodes. Matching facts may move one step; unrelated facts do not move.
10. **Carrier arrival automatically re-runs Pass 2.** Existing local-material observations are retained and supplied Xactimate labor/material/equipment/tax/O&P components are used where actually present.
11. **The Claim Map is the atomic graph.** Every proposition and meaningful relationship has its own bracket, provenance root, timestamp, reason, and promotion/correction history.
12. **Parliament reads the graph.** It receives the atomic map and locked PSi/carrier totals. It is instructed not to invent facts, prices, laws, or silently promote propositions.
13. **Actual payment is recorded as evidence.** Any received payment is a validated monetary event. Only a payment explicitly marked final for a selected repair item promotes that linked monetary proposition to the final validated state. Partial or claim-level payments do not validate unrelated items.

## Lowe's connector

The desktop bridge now supports:

- authorized store-price CSV import,
- exact product ID lookup,
- description search against the imported store feed,
- optional authorized partner product endpoint,
- optional authorized partner search endpoint using a user-supplied URL template,
- store ID + job ZIP,
- source hash/timestamp/provenance.

No Lowe's endpoint is invented or scraped. Partner URL templates and credentials must come from authorized Lowe's access.

## Xactimate use

Carrier/Xactimate data is user-supplied/imported and preserved unchanged. When present, PSi can consume:

- carrier quantity/unit price/RCV/ACV,
- material amount,
- worker-hours,
- labor rate/labor amount,
- equipment amount,
- tax,
- O&P.

Where Xactimate exposes a related pricing basis but no direct local material observation exists, PSi may create an `EXPLAINED` Xactimate-derived value. Model-only fallback remains `SPECULATIVE`.

## Epistemic behavior

- AI/photo/model inference → `SPECULATIVE`
- independent/documented corroboration → `EXPLAINED`
- multiple independent/direct support paths or final linked monetary proof → `VALIDATED`
- contradiction → `CONTRADICTED`

A corroborated damage fact does not validate quantity, price, labor, cause, permit, O&P, or any other proposition automatically.

## Safety corrections in 1.2.0

- Removed the no-AI hard-coded claim findings that previously returned unsupported `VALIDATED` roof conclusions.
- Trade count no longer automatically establishes O&P entitlement. Explicit O&P stays a source-traced allowance; coverage/entitlement remains a separate policy/rule/evidence question.
- Removed the hard-coded $12,500 ALE calculation; ALE now uses documented receipt/evidence amounts.

## Verification performed in the build container

- `npm run lint` — PASS
- `npm run test:psi` — **16/16 PASS**
- `node --check electron/main.cjs` — PASS
- `node --check electron/preload.cjs` — PASS

The tests cover photo-pass completeness, explicit price reasons, regional/local material pricing, Xactimate-derived fallback, labor MAX rule in both directions, 5% contingency, initial-estimate preservation, atomic graph construction, carrier counter preservation, proposition-specific evidence promotion, partial payment behavior, and final linked payment promotion.

### Build-environment note

The final Vite/electron-builder package was not produced in the Linux inspection container because the available dependency tree was copied from Windows and contains Windows-native Rollup/esbuild binaries. TypeScript and domain tests pass. On the target Windows machine, run `RUN_PSI_DEV.ps1`; it installs native dependencies locally if needed, runs tests/lint, and launches the app. Then run `BUILD_PSI_STORE.ps1` for the Store package.
