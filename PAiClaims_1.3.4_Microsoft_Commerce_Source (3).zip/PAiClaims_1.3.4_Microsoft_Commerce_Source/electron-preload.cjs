// Legacy preload kept for compatibility. The canonical preload bridge lives in
// electron/preload.cjs.
require('./electron/preload.cjs');
