using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows.Forms;
using Windows.Services.Store;

namespace PAiClaimsStoreBridge
{
    [ComImport]
    [Guid("3E68D4BD-7135-4D10-8018-9FB6D9F33FA1")]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    internal interface IInitializeWithWindow
    {
        void Initialize(IntPtr hwnd);
    }

    internal static class Program
    {
        [STAThread]
        private static int Main(string[] args)
        {
            Dictionary<string, string> options = ParseArgs(args);
            string command = options.ContainsKey("command") ? options["command"] : "state";

            if (command == "self-test")
            {
                Write(new Dictionary<string, object> {
                    { "ok", true },
                    { "bridge", "PAiClaims.StoreBridge" },
                    { "version", "1.3.4" },
                    { "runtime", Environment.Version.ToString() }
                });
                return 0;
            }

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            using (StoreRunnerForm runner = new StoreRunnerForm(options))
            {
                Application.Run(runner);
                return runner.ExitCode;
            }
        }

        internal static Dictionary<string, string> ParseArgs(string[] args)
        {
            Dictionary<string, string> result = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            for (int i = 0; i < args.Length; i++)
            {
                string arg = args[i] ?? "";
                if (!arg.StartsWith("--")) continue;
                string key = arg.Substring(2);
                string value = "true";
                if (i + 1 < args.Length && !(args[i + 1] ?? "").StartsWith("--")) value = args[++i];
                result[key] = value;
            }
            return result;
        }

        internal static string Require(Dictionary<string, string> options, string name)
        {
            string value;
            if (!options.TryGetValue(name, out value) || String.IsNullOrWhiteSpace(value))
                throw new ArgumentException("Missing --" + name + " argument.");
            return value;
        }

        internal static void Write(object value)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            Console.WriteLine(new JavaScriptSerializer().Serialize(value));
        }
    }

    internal sealed class StoreRunnerForm : Form
    {
        private static readonly string[] ProductKinds = new[] { "Durable", "Consumable", "UnmanagedConsumable" };
        private readonly Dictionary<string, string> _options;
        private bool _started;
        public int ExitCode { get; private set; }

        public StoreRunnerForm(Dictionary<string, string> options)
        {
            _options = options;
            ExitCode = 1;
            ShowInTaskbar = false;
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.Manual;
            Size = new Size(2, 2);
            Location = new Point(Screen.PrimaryScreen.WorkingArea.Left + (Screen.PrimaryScreen.WorkingArea.Width / 2),
                                 Screen.PrimaryScreen.WorkingArea.Top + (Screen.PrimaryScreen.WorkingArea.Height / 2));
            Opacity = 0.01;
            Text = "PAi Claims Microsoft Store";
        }

        protected override async void OnShown(EventArgs e)
        {
            base.OnShown(e);
            if (_started) return;
            _started = true;

            try
            {
                StoreContext context = StoreContext.GetDefault();
                if (context == null) throw new InvalidOperationException("Microsoft Store context is unavailable.");
                ((IInitializeWithWindow)(object)context).Initialize(Handle);

                string command = _options.ContainsKey("command") ? _options["command"] : "state";
                Dictionary<string, object> payload;
                if (command == "state")
                    payload = await GetStateAsync(context);
                else if (command == "purchase")
                    payload = await PurchaseAsync(context, Program.Require(_options, "product"));
                else if (command == "consume")
                {
                    string productId = Program.Require(_options, "product");
                    Guid trackingId = Guid.Parse(Program.Require(_options, "tracking"));
                    uint quantity = _options.ContainsKey("quantity") ? UInt32.Parse(_options["quantity"]) : 1U;
                    payload = await ConsumeAsync(context, productId, quantity, trackingId);
                }
                else
                    throw new InvalidOperationException("Unknown command: " + command);

                Program.Write(payload);
                ExitCode = payload.ContainsKey("ok") && Object.Equals(payload["ok"], true) ? 0 : 1;
            }
            catch (Exception ex)
            {
                Program.Write(new Dictionary<string, object> {
                    { "ok", false },
                    { "available", false },
                    { "error", ex.Message ?? ex.GetType().Name },
                    { "hresult", "0x" + ex.HResult.ToString("X8") },
                    { "type", ex.GetType().FullName }
                });
                ExitCode = 1;
            }
            finally
            {
                BeginInvoke((Action)(() => Close()));
            }
        }

        private async Task<Dictionary<string, object>> GetStateAsync(StoreContext context)
        {
            Dictionary<string, ProductInfo> products = await LoadProductsAsync(context);
            StoreAppLicense appLicense = await context.GetAppLicenseAsync();

            List<Dictionary<string, object>> licenses = new List<Dictionary<string, object>>();
            if (appLicense != null && appLicense.AddOnLicenses != null)
            {
                foreach (KeyValuePair<string, StoreLicense> item in appLicense.AddOnLicenses)
                {
                    StoreLicense license = item.Value;
                    string token = Safe(license.InAppOfferToken);
                    string storeId = ProductIdFromSkuStoreId(Safe(license.SkuStoreId));
                    ProductInfo catalogProduct;
                    if (products.TryGetValue(token, out catalogProduct) && !String.IsNullOrWhiteSpace(catalogProduct.StoreId))
                        storeId = catalogProduct.StoreId;

                    licenses.Add(new Dictionary<string, object> {
                        { "productId", token },
                        { "storeId", storeId },
                        // AddOnLicenses contains only currently-valid entitlements.
                        { "active", true },
                        { "expirationUtc", Iso(license.ExpirationDate) }
                    });

                    if (!String.IsNullOrWhiteSpace(token) && !products.ContainsKey(token))
                    {
                        products[token] = new ProductInfo {
                            ProductId = token,
                            StoreId = storeId,
                            Kind = "Durable",
                            Title = token,
                            FormattedPrice = "",
                            InCollection = true
                        };
                    }
                }
            }

            List<Dictionary<string, object>> productRows = new List<Dictionary<string, object>>();
            foreach (ProductInfo p in products.Values.OrderBy(x => x.ProductId, StringComparer.OrdinalIgnoreCase))
            {
                uint balance = 0;
                string balanceStatus = "";
                if (String.Equals(p.Kind, "Consumable", StringComparison.OrdinalIgnoreCase) && !String.IsNullOrWhiteSpace(p.StoreId))
                {
                    StoreConsumableResult result = await context.GetConsumableBalanceRemainingAsync(p.StoreId);
                    if (result != null)
                    {
                        balance = result.BalanceRemaining;
                        balanceStatus = result.Status.ToString();
                    }
                }

                productRows.Add(new Dictionary<string, object> {
                    { "productId", p.ProductId },
                    { "storeId", p.StoreId },
                    { "kind", p.Kind },
                    { "title", p.Title },
                    { "formattedPrice", p.FormattedPrice },
                    { "inUserCollection", p.InCollection },
                    { "balance", balance },
                    { "balanceStatus", balanceStatus }
                });
            }

            return new Dictionary<string, object> {
                { "ok", true },
                { "available", true },
                { "timestampUtc", DateTimeOffset.UtcNow.ToString("o") },
                { "products", productRows },
                { "licenses", licenses }
            };
        }

        private async Task<Dictionary<string, object>> PurchaseAsync(StoreContext context, string productId)
        {
            Dictionary<string, ProductInfo> products = await LoadProductsAsync(context);
            ProductInfo product;
            if (!products.TryGetValue(productId, out product) || String.IsNullOrWhiteSpace(product.StoreId))
            {
                StoreAppLicense appLicense = await context.GetAppLicenseAsync();
                if (appLicense != null && appLicense.AddOnLicenses != null)
                {
                    foreach (StoreLicense addOn in appLicense.AddOnLicenses.Values)
                    {
                        if (String.Equals(Safe(addOn.InAppOfferToken), productId, StringComparison.OrdinalIgnoreCase))
                        {
                            return new Dictionary<string, object> {
                                { "ok", true },
                                { "productId", productId },
                                { "status", "AlreadyPurchased" },
                                { "alreadyOwned", true }
                            };
                        }
                    }
                }
                throw new InvalidOperationException("Microsoft Store add-on '" + productId + "' was not found. Confirm the add-on is published and set to Available for purchase from within the parent product.");
            }

            StorePurchaseResult result = await context.RequestPurchaseAsync(product.StoreId);
            string status = result == null ? "Unknown" : result.Status.ToString();
            string extended = result == null || result.ExtendedError == null ? "" : "0x" + result.ExtendedError.HResult.ToString("X8");
            bool success = status == "Succeeded" || status == "AlreadyPurchased";
            return new Dictionary<string, object> {
                { "ok", success },
                { "productId", productId },
                { "storeId", product.StoreId },
                { "status", status },
                { "extendedError", extended }
            };
        }

        private async Task<Dictionary<string, object>> ConsumeAsync(StoreContext context, string productId, uint quantity, Guid trackingId)
        {
            Dictionary<string, ProductInfo> products = await LoadProductsAsync(context);
            ProductInfo product;
            if (!products.TryGetValue(productId, out product) || String.IsNullOrWhiteSpace(product.StoreId))
                throw new InvalidOperationException("Microsoft Store consumable '" + productId + "' was not found.");
            if (!String.Equals(product.Kind, "Consumable", StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("The selected Microsoft Store add-on is not a Store-managed consumable.");

            StoreConsumableResult result = await context.ReportConsumableFulfillmentAsync(product.StoreId, quantity, trackingId);
            string status = result == null ? "Unknown" : result.Status.ToString();
            string extended = result == null || result.ExtendedError == null ? "" : "0x" + result.ExtendedError.HResult.ToString("X8");
            bool success = status == "Succeeded";
            return new Dictionary<string, object> {
                { "ok", success },
                { "productId", productId },
                { "storeId", product.StoreId },
                { "status", status },
                { "balanceRemaining", result == null ? 0 : result.BalanceRemaining },
                { "trackingId", trackingId.ToString() },
                { "extendedError", extended }
            };
        }

        private async Task<Dictionary<string, ProductInfo>> LoadProductsAsync(StoreContext context)
        {
            Dictionary<string, ProductInfo> output = new Dictionary<string, ProductInfo>(StringComparer.OrdinalIgnoreCase);
            StoreProductQueryResult associated = await context.GetAssociatedStoreProductsAsync(ProductKinds);
            MergeProducts(output, associated);
            StoreProductQueryResult owned = await context.GetUserCollectionAsync(ProductKinds);
            MergeProducts(output, owned);
            return output;
        }

        private static void MergeProducts(Dictionary<string, ProductInfo> output, StoreProductQueryResult query)
        {
            if (query == null || query.Products == null) return;
            foreach (KeyValuePair<string, StoreProduct> item in query.Products)
            {
                StoreProduct product = item.Value;
                string token = Safe(product.InAppOfferToken);
                if (String.IsNullOrWhiteSpace(token)) continue;
                ProductInfo existing;
                output.TryGetValue(token, out existing);
                output[token] = new ProductInfo {
                    ProductId = token,
                    StoreId = Safe(product.StoreId),
                    Kind = Safe(product.ProductKind),
                    Title = Safe(product.Title),
                    FormattedPrice = product.Price == null ? "" : Safe(product.Price.FormattedPrice),
                    InCollection = product.IsInUserCollection || (existing != null && existing.InCollection)
                };
            }
        }

        private static string ProductIdFromSkuStoreId(string skuStoreId)
        {
            if (String.IsNullOrWhiteSpace(skuStoreId)) return "";
            int slash = skuStoreId.IndexOf('/');
            return slash > 0 ? skuStoreId.Substring(0, slash) : skuStoreId;
        }

        private static string Safe(string value) { return value ?? ""; }
        private static string Iso(DateTimeOffset value) { return value.ToUniversalTime().ToString("o"); }

        private sealed class ProductInfo
        {
            public string ProductId;
            public string StoreId;
            public string Kind;
            public string Title;
            public string FormattedPrice;
            public bool InCollection;
        }
    }
}
