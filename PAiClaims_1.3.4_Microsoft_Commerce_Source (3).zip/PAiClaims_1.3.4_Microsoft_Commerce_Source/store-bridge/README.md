# PAi Claims Microsoft Store bridge

`PAiClaims.StoreBridge.exe` is a tiny Windows-only helper used by the Electron
main process to call `Windows.Services.Store.StoreContext`.

It does four things only:

1. discovers PAi Claims add-ons and their Store IDs by matching Partner Center
   Product IDs (`InAppOfferToken`),
2. reads durable/subscription licenses and Store-managed consumable balances,
3. opens the Microsoft purchase UI for a selected add-on, and
4. reports one additional-case consumable as fulfilled after PAi Claims binds
   that credit to a workspace.

The helper is compiled by `Build-StoreBridge.ps1` before the APPX build. It must
run from the installed PAi Claims package so Windows gives it the PAi Claims
package identity. It is not expected to work when double-clicked from an
unpackaged source folder.

No Microsoft Store IDs are hard-coded. The bridge discovers them from the
published add-ons and matches these Partner Center Product IDs:

- `pai-claims-first-case`
- `pai-claims-single-case`
- `pai-claims-annual`
