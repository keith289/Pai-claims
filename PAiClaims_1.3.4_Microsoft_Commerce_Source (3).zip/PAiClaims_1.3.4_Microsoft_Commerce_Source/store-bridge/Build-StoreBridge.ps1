$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

$source = Join-Path $PSScriptRoot "Program.cs"
$outDir = Join-Path $PSScriptRoot "bin"
$outExe = Join-Path $outDir "PAiClaims.StoreBridge.exe"
New-Item -ItemType Directory -Force $outDir | Out-Null

$cscCandidates = @(
    "$env:WINDIR\Microsoft.NET\Framework64\v4.0.30319\csc.exe",
    "$env:WINDIR\Microsoft.NET\Framework\v4.0.30319\csc.exe"
) | Where-Object { Test-Path $_ }
if (-not $cscCandidates) { throw "C# compiler not found. Windows .NET Framework 4.x is required." }
$csc = $cscCandidates[0]

$windowsKit = "${env:ProgramFiles(x86)}\Windows Kits\10\UnionMetadata"
# Only the versioned Windows.winmd carries Windows.Services.Store. The
# unversioned UnionMetadata\Facade\Windows.WinMD is a projection stub, and it
# sorts ABOVE the version folders alphabetically ("F" > "1"), so a plain
# descending sort on FullName always picked the wrong one. Exclude the facades
# and order by SDK version.
$winmd = Get-ChildItem $windowsKit -Filter Windows.winmd -Recurse -ErrorAction SilentlyContinue |
    Where-Object { $_.DirectoryName -notmatch '\\Facade$' -and $_.Directory.Name -match '^\d+\.\d+\.\d+' } |
    Sort-Object { [version]$_.Directory.Name } -Descending |
    Select-Object -First 1 -ExpandProperty FullName
if (-not $winmd) { throw "Windows.winmd not found. Install the Windows 10/11 SDK (the same SDK used to build the APPX)." }

$refRoot = "${env:ProgramFiles(x86)}\Reference Assemblies\Microsoft\Framework\.NETFramework"
$winRuntime = Get-ChildItem $refRoot -Filter System.Runtime.WindowsRuntime.dll -Recurse -ErrorAction SilentlyContinue |
    Sort-Object FullName -Descending | Select-Object -First 1 -ExpandProperty FullName
if (-not $winRuntime) {
    $fallback = "$env:WINDIR\Microsoft.NET\Framework64\v4.0.30319\System.Runtime.WindowsRuntime.dll"
    if (Test-Path $fallback) { $winRuntime = $fallback }
}
if (-not $winRuntime) { throw "System.Runtime.WindowsRuntime.dll not found. Install .NET Framework 4.8 Developer Pack." }

$webExtensions = "$env:WINDIR\Microsoft.NET\Framework64\v4.0.30319\System.Web.Extensions.dll"
if (-not (Test-Path $webExtensions)) { $webExtensions = "$env:WINDIR\Microsoft.NET\Framework\v4.0.30319\System.Web.Extensions.dll" }
if (-not (Test-Path $webExtensions)) { throw "System.Web.Extensions.dll not found." }

Write-Host "Building Microsoft Store commerce bridge..." -ForegroundColor Cyan
Write-Host "  C# compiler : $csc"
Write-Host "  Windows SDK : $winmd"

# The versioned Windows.winmd surfaces types from System.Runtime, which the old
# projection facade hid. csc needs the .NET Framework facade assemblies on the
# reference list or every WinRT attribute fails to resolve. Version folders
# differ between machines (v4.8 vs v4.8.1), so discover rather than hardcode.
$facadeDir = Get-ChildItem $refRoot -Directory -ErrorAction SilentlyContinue |
    Where-Object { Test-Path (Join-Path $_.FullName 'Facades\System.Runtime.dll') } |
    Sort-Object Name -Descending | Select-Object -First 1
if (-not $facadeDir) { throw "No .NETFramework Facades folder with System.Runtime.dll found under $refRoot." }
$facades = Get-ChildItem (Join-Path $facadeDir.FullName 'Facades') -Filter *.dll |
    ForEach-Object { "/reference:$($_.FullName)" }
Write-Host "  Facades     : $($facadeDir.Name) ($($facades.Count) assemblies)"


& $csc /nologo /target:exe /platform:x64 /optimize+ /out:$outExe /reference:$winmd /reference:$winRuntime $facades /reference:$webExtensions /reference:System.Windows.Forms.dll /reference:System.Drawing.dll $source
if ($LASTEXITCODE -ne 0 -or -not (Test-Path $outExe)) { throw "Store bridge compilation failed." }

& $outExe --command self-test
if ($LASTEXITCODE -ne 0) { throw "Store bridge self-test failed." }
Write-Host "Store bridge ready: $outExe" -ForegroundColor Green
