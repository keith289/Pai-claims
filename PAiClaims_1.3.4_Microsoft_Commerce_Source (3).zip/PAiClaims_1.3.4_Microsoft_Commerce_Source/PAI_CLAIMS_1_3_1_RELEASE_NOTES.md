# PAi Claims 1.3.1 — Release Notes

## Microsoft Store commerce

- Added Microsoft Store purchase flow for the existing Partner Center add-ons:
  - `pai-claims-first-case`
  - `pai-claims-single-case`
  - `pai-claims-annual`
- Added runtime discovery of Microsoft-generated Store IDs through Partner Center Product IDs; no generated Store ID is hard-coded.
- Added an alias for the already-submitted first-case Partner Center identifier `daa1e8b9-d3d8-4d66-aaae-4fdc5fcedd53`, so the existing add-on does not need to be recreated.
- Added Store-managed consumable balance/fulfillment for additional case credits.
- Added annual subscription license/expiration synchronization.
- Added persisted fulfillment tracking IDs so a consumable retry does not invent a second fulfillment transaction.
- Added persisted pending-first-case state so an interrupted first-case Store purchase can resume safely.
- Treats the Durable first-case license as an account-level "intro already purchased" marker on later installations, preventing a simple reinstall from producing another introductory case.
- Preserved PAi purchase codes as a collapsed support/recovery path instead of the normal sales flow.

## Existing PAi Claims behavior preserved

- Existing estimator and evidence-graph behavior is unchanged.
- Case workspaces remain user-owned folders.
- Per-case unlocks remain tied to the selected workspace.
- Annual-expired workspaces remain readable rather than locking the user out of their files.
- The introductory first case still carries the one-time PAi Legal/shared-workspace bonus.

## Maintenance/security

- External renderer-created popups remain blocked; external navigation is restricted to HTTPS.
- Dispute Letter Studio printing no longer depends on a blocked popup window. Printing now uses an internal temporary print frame.

## Verification

The source test suite contains 31 automated tests in this build:

- 18 estimator/evidence-domain tests
- 13 commerce tests, including the submitted first-case GUID alias and Microsoft Store ledger/entitlement cases

Run `VERIFY_FINAL_FLOW.ps1` on the Windows build machine before packaging.
