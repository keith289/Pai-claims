# Packaging PAi Claims for the Microsoft Store (MSIX)

## Identity — must match Partner Center exactly

| Field | Value | Set in |
|---|---|---|
| Package/Identity/Name | `PAiLuton.PAiClaims` | `electron-builder.yml` → `appx.identityName` |
| Package/Identity/Publisher | `CN=D7A83BB4-9693-4195-82DE-2A76C46F6F0F` | `appx.publisher` |
| Package/Properties/PublisherDisplayName | `PAi Luton` | `appx.publisherDisplayName` |
| Package Family Name | `PAiLuton.PAiClaims_tkjdczdb08j36` | derived by Windows — not set by hand |
| Store ID | `9P255VXPD5B4` | Partner Center only |

The PFN suffix `tkjdczdb08j36` is a hash of the Publisher string. **If your built
package's PFN doesn't end in that suffix, the Publisher string is wrong** — check
it before uploading rather than after a rejection. Verify with:

```powershell
Get-AppxPackage -Name PAiLuton.PAiClaims | Select-Object PackageFamilyName
```

## Architecture

MSIX cannot host a Node process on its own, so the app ships as an Electron
shell that runs the existing Express server on a loopback port and loads it in
a window. The React frontend and `server.ts` are unchanged apart from two
edits noted below.

```
electron/main.js     shell: boots dist/server.cjs, owns folder picker + settings
electron/preload.js  contextIsolated bridge (window.paiDesktop)
dist/                vite build output + esbuild-bundled server.cjs
```

## Build

```bash
npm install
npm run electron:dev     # dev: vite + electron
npm run build:msix       # release/PAiClaims-1.3.4-x64.appx
```

Requires Windows with the Windows SDK for `makeappx`/`signtool`. Store
submissions are signed by Microsoft during ingestion, so do **not** sign the
Store build yourself.

### Sideload testing

Store identity can't be installed locally without a matching certificate. Use:

```bash
npm run build:sideload   # rebuilds with publisher CN=PAiLutonDev
```

Then create a self-signed cert with that exact subject, sign the package, trust
the cert in `Local Machine\Trusted People`, and enable Developer Mode. The
sideload build is for testing only — never submit it.

## Required assets

electron-builder reads these from `build/`. The Store rejects packages with
missing or incorrectly sized tiles:

| File | Size |
|---|---|
| `build/appx/Square44x44Logo.png` | 44×44 |
| `build/appx/Square150x150Logo.png` | 150×150 |
| `build/appx/Wide310x150Logo.png` | 310×150 |
| `build/appx/StoreLogo.png` | 50×50 |
| `build/appx/SplashScreen.png` | 620×300 |
| `build/icon.ico` | multi-size, 256×256 included |

Scaled variants (`.scale-200` etc.) are optional but improve rendering on
high-DPI displays.

## Two changes made to `server.ts`

1. `PORT` now reads `process.env.PORT` (the shell picks a free port; two
   installs or a dev server on 3000 would otherwise collide).
2. The listener binds `127.0.0.1` instead of `0.0.0.0`. **This was exposing
   claim data to every device on the local network.** Set `HOST` explicitly if
   you ever need to serve it deliberately.

## Things that will fail Store certification if left as-is

**The Gemini key must not be in the package.** `.env.example` expects AI Studio
to inject `GEMINI_API_KEY` at runtime; there is no AI Studio in a shipped MSIX.
The shell reads the key from `%LOCALAPPDATA%\PAi Claims\settings.json`, written
by the user through a settings screen. A key bundled into the MSIX is
extractable by anyone who downloads it. The server already degrades to
deterministic fallback mode without a key, which is the correct default.

**Privacy disclosure is mandatory.** The app handles personal and financial
claim information. Partner Center requires a privacy policy. Hosted AI is
optional and remains disabled until the user explicitly consents in AI Setup;
the same screen lets the user revoke consent and remove saved provider keys.

**Age rating and category.** This handles insurance and financial records —
expect the questionnaire to ask about data collection.

## Claim storage on any drive

MSIX apps are sandboxed, but a folder chosen through the system picker is
granted to the app. `claim:chooseLocation` opens that picker, so users can
build claims on `D:\`, an external drive, or a network share without the
`broadFileSystemAccess` restricted capability — which requires separate Store
approval and is commonly refused on a first submission. Avoid it.

Recent locations are remembered in user settings so the second claim is faster.

## Version numbers

MSIX requires a 4-part version and the Store requires the **revision to be 0**.
`buildVersion: '1.3.4.0'` in `electron-builder.yml` handles this. Bump the
first three parts in `package.json`; leave the fourth at 0.


## Microsoft Store commerce bridge (1.3.1)

Run `BUILD_PSI_STORE.ps1`; it compiles the Windows.Services.Store helper before packaging. See `PAiClaims_1.3.1_MICROSOFT_COMMERCE.md`.
