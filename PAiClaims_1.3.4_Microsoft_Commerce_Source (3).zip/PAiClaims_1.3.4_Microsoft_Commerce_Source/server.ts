import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import {
  generate as aiGenerate,
  activeConfig as aiActiveConfig,
  isConfigured as aiIsConfigured,
  testConnection as aiTestConnection,
  PROVIDERS as AI_PROVIDERS,
  AINotConfigured,
} from './src/ai/providers';
import * as llama from './src/ai/llamacpp';
import { ensureCompletePhotoEstimate, inventoryTotals } from './src/domain/claimEstimateFlow';
import { buildClaimGraph, graphStats } from './src/domain/claimGraph';
import os from 'os';
import dotenv from 'dotenv';

dotenv.config();

// Port and host are supplied by the desktop shell, which picks a free
// loopback port. Falls back to 3000 for plain `npm run dev`.
const PORT = Number(process.env.PORT) || 3000;
// Bind loopback by default: claim data must not be reachable from the local
// network. Set HOST explicitly to serve it deliberately.
const HOST = process.env.HOST || '127.0.0.1';

// AI access goes through the provider layer. Which backend is used is a user
// setting, not a build-time decision.
function aiConfigured(): boolean {
  return aiIsConfigured();
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '20mb' }));

  // API Routes
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'ok',
      engine: 'PAi Claim Epistemic Recovery Engine v2.0',
      geminiConfigured: aiConfigured(),
      aiProvider: aiActiveConfig().id,
      aiConfigured: aiConfigured(),
    });
  });


  // Photo-first damage analysis. Every proposition and dollar starts at the
  // lowest one-bracket state. The response is normalized so no required cost
  // category is left blank.
  app.post('/api/analyze-damage-photos', async (req, res) => {
    try {
      const { claim, photos } = req.body as {
        claim: any;
        photos: Array<{ evidenceId: string; dataUrl: string; filename?: string }>;
      };
      if (!claim || !Array.isArray(photos) || !photos.length) {
        return res.status(400).json({ error: 'Claim and at least one photo are required.' });
      }
      if (!aiConfigured()) {
        return res.status(503).json({ error: 'Configure local or API AI to analyze damage photos.' });
      }

      const system = `You are PAi Claims PASS-1 property-damage vision estimator.
Analyze the supplied user photos and build a COMPLETE rough repair estimate from pictures forward.

ABSOLUTE RULES:
1. Every proposition starts SPECULATIVE. Never self-promote.
2. Every repair operation must have a rough price AND a reason. Nothing needed for a complete rough estimate may be blank.
3. For every operation, itemize these cost classes even when they are only provisional: material, labor, equipment/access, debris/disposal, permit allowance, tax allowance, overhead/profit allowance, mobilization/delivery, protection/cleanup.
4. Give a numeric amount for every class. If exact data is unavailable, speculate reasonably and explain the assumption. The brackets make clear it is not set in stone.
5. Also provide quantity, unit, laborHours, material search terms, cause, extent, location, and visible access/logistics.
6. Do not claim an insurer owes anything and do not claim a legal/code rule is proven from a photo.
7. Use USD.
8. The sum of costComponents should be close to valuation.amount.

Return strict JSON:
{
 "photoSummaries":[{"photoIndex":0,"category":"Roof & Slopes","caption":"...","damageTags":["..."]}],
 "items":[{
   "id":"damage-...",
   "statement":"...",
   "component":"...",
   "location":"...",
   "damageType":"...",
   "likelyCause":"...",
   "extent":"...",
   "photoEvidenceIds":["..."],
   "imageRegions":[{"evidenceId":"...","label":"...","x":0.1,"y":0.1,"width":0.2,"height":0.2}],
   "damageBracket":"SPECULATIVE",
   "repairOperations":[{
     "id":"repair-...",
     "trade":"Roofing",
     "description":"...",
     "quantity":1,
     "unit":"EA",
     "materialSearchTerms":["..."],
     "laborHours":1,
     "equipmentAndDisposal":100,
     "costComponents":[
       {"id":"...","kind":"material","label":"Materials","amount":100,"reason":"...","bracket":"SPECULATIVE","sourceMethod":"photo_ai"},
       {"id":"...","kind":"labor","label":"Labor","amount":100,"reason":"...","bracket":"SPECULATIVE","sourceMethod":"photo_ai","workerHours":2},
       {"id":"...","kind":"equipment","label":"Equipment / access","amount":50,"reason":"...","bracket":"SPECULATIVE","sourceMethod":"photo_ai"},
       {"id":"...","kind":"disposal","label":"Debris / disposal","amount":50,"reason":"...","bracket":"SPECULATIVE","sourceMethod":"photo_ai"},
       {"id":"...","kind":"permit","label":"Permit allowance","amount":25,"reason":"...","bracket":"SPECULATIVE","sourceMethod":"photo_ai"},
       {"id":"...","kind":"tax","label":"Tax allowance","amount":25,"reason":"...","bracket":"SPECULATIVE","sourceMethod":"photo_ai"},
       {"id":"...","kind":"overhead_profit","label":"Overhead & profit allowance","amount":50,"reason":"...","bracket":"SPECULATIVE","sourceMethod":"photo_ai"},
       {"id":"...","kind":"mobilization","label":"Mobilization / delivery","amount":25,"reason":"...","bracket":"SPECULATIVE","sourceMethod":"photo_ai"},
       {"id":"...","kind":"protection","label":"Protection / cleanup","amount":25,"reason":"...","bracket":"SPECULATIVE","sourceMethod":"photo_ai"}
     ]
   }],
   "valuation":{"amount":450,"currency":"USD","assumptions":["..."],"bracket":"SPECULATIVE","pricedAt":"ISO","pricingBasis":"..."}
 }]
}`;

      const prompt = `Claim context is context, not proof:
claim=${claim.claimNumber || ''}
peril=${claim.peril || ''}
property=${claim.propertyAddress || ''}
state=${claim.jurisdictionState || ''}
dateOfLoss=${claim.dateOfLoss || ''}

Photo evidence IDs in order: ${photos.map((p) => p.evidenceId).join(', ')}.
Build the complete one-bracket initial estimate.`;
      const answer = await aiGenerate({
        prompt,
        system,
        json: true,
        temperature: 0.15,
        maxTokens: 7000,
        images: photos.slice(0, 12).map((p) => ({ dataUrl: p.dataUrl, label: p.filename })),
      });
      let parsed: any;
      try { parsed = JSON.parse(answer.text); }
      catch { return res.status(502).json({ error: 'Vision AI returned invalid JSON.' }); }

      const now = new Date().toISOString();
      const rawItems = Array.isArray(parsed.items) ? parsed.items.map((item: any, index: number) => ({
        ...item,
        id: item.id || `damage-${Date.now()}-${index}`,
        statement: item.statement || `Possible damage to ${item.component || 'property component'}`,
        component: item.component || 'Unknown component',
        location: item.location || 'Location inferred from photo context',
        damageType: item.damageType || 'Visible damage',
        likelyCause: item.likelyCause || 'Cause requires corroboration',
        extent: item.extent || 'Extent requires measurement',
        photoEvidenceIds: Array.isArray(item.photoEvidenceIds) && item.photoEvidenceIds.length ? item.photoEvidenceIds : [photos[0].evidenceId],
        imageRegions: Array.isArray(item.imageRegions) ? item.imageRegions : [],
        damageBracket: 'SPECULATIVE',
        repairOperations: Array.isArray(item.repairOperations) ? item.repairOperations.map((op: any, opIndex: number) => ({
          ...op,
          id: op.id || `repair-${index}-${opIndex}`,
          trade: op.trade || 'General',
          description: op.description || 'Provisional repair operation',
          quantity: Math.max(0.01, Number(op.quantity) || 1),
          unit: op.unit || 'EA',
          materialSearchTerms: Array.isArray(op.materialSearchTerms) ? op.materialSearchTerms : [item.component || 'repair material'],
          laborHours: Math.max(0.25, Number(op.laborHours) || 0.25),
          equipmentAndDisposal: Math.max(0, Number(op.equipmentAndDisposal) || 0),
          costComponents: Array.isArray(op.costComponents) ? op.costComponents.map((c: any, cIndex: number) => ({
            ...c,
            id: c.id || `cost-${index}-${opIndex}-${c.kind || cIndex}`,
            amount: Math.max(0.01, Number(c.amount) || 0.01),
            reason: c.reason || 'Provisional photo-analysis allowance; stronger source not yet available.',
            bracket: 'SPECULATIVE',
            sourceMethod: 'photo_ai',
            sourceEvidenceIds: Array.isArray(c.sourceEvidenceIds) ? c.sourceEvidenceIds : item.photoEvidenceIds,
          })) : [],
        })) : [],
        valuation: {
          amount: Math.max(50, Number(item.valuation?.amount) || 1000),
          currency: 'USD',
          assumptions: Array.isArray(item.valuation?.assumptions) ? item.valuation.assumptions : ['Photo-analysis rough estimate; stronger evidence not yet available.'],
          bracket: 'SPECULATIVE',
          pricedAt: now,
          pricingBasis: item.valuation?.pricingBasis || 'Photo-analysis rough price. Every included amount is one-bracket provisional.',
        },
      })) : [];
      const items = ensureCompletePhotoEstimate(rawItems, now);
      res.json({ photoSummaries: Array.isArray(parsed.photoSummaries) ? parsed.photoSummaries : [], items, provider: answer.provider, model: answer.model });
    } catch (err: any) {
      console.error('Error in analyze-damage-photos:', err);
      res.status(500).json({ error: err?.message || 'Photo analysis failed.' });
    }
  });

  // Last-resort price completion. This endpoint is deliberately speculative:
  // it exists so an estimate is never blank. Stronger retailer/Xactimate/
  // invoice evidence supersedes it later.
  app.post('/api/speculate-price', async (req, res) => {
    try {
      const { description, quantity, unit, zipCode, state, carrierItems, roughAmount } = req.body || {};
      const carrier = Array.isArray(carrierItems) ? carrierItems : [];
      if (!aiConfigured()) {
        const fallback = Math.max(1, Number(roughAmount) || Math.max(25, Number(quantity || 1) * 50));
        return res.json({
          amount: Math.round(fallback * 100) / 100,
          unitPrice: Number(quantity) > 0 ? Math.round((fallback / Number(quantity)) * 100) / 100 : fallback,
          reason: 'AI is not configured. Retaining the existing one-bracket rough amount so the estimate is complete.',
          bracket: 'SPECULATIVE',
          sourceMethod: 'llm_fallback',
        });
      }
      const answer = await aiGenerate({
        json: true,
        temperature: 0.2,
        maxTokens: 1200,
        system: `You complete missing construction prices for PAi Claims. Never leave a required amount blank.
If supplied carrier/Xactimate items provide a related pricing basis, extrapolate from those first.
Otherwise make a reasonable current-market rough estimate for the stated region.
This is speculative unless it is directly derived from supplied Xactimate numbers.
Return JSON only: {"amount":123.45,"unitPrice":12.34,"reason":"...","bracket":"SPECULATIVE|EXPLAINED","sourceMethod":"llm_fallback|xactimate_derived"}.`,
        prompt: `Item: ${description}
Quantity: ${quantity} ${unit}
ZIP: ${zipCode || ''}
State: ${state || ''}
Existing rough amount: ${roughAmount || 0}
Supplied carrier/Xactimate items:
${carrier.slice(0, 40).map((i: any) => `${i.xactCode || ''} ${i.description || ''} qty=${i.carrierQuantity || 0} unit=${i.unit || ''} unitPrice=${i.carrierUnitPrice || 0} material=${i.materialAmount || 0} laborHours=${i.workerHours || 0} laborRate=${i.laborRate || 0}`).join('\n')}`,
      });
      const parsed = JSON.parse(answer.text);
      const amount = Math.max(0.01, Number(parsed.amount) || Number(roughAmount) || 1);
      res.json({
        amount: Math.round(amount * 100) / 100,
        unitPrice: Math.max(0.01, Number(parsed.unitPrice) || (Number(quantity) > 0 ? amount / Number(quantity) : amount)),
        reason: parsed.reason || 'LLM rough price used because stronger direct pricing was unavailable.',
        bracket: parsed.bracket === 'EXPLAINED' ? 'EXPLAINED' : 'SPECULATIVE',
        sourceMethod: parsed.sourceMethod === 'xactimate_derived' ? 'xactimate_derived' : 'llm_fallback',
      });
    } catch (err: any) {
      res.status(500).json({ error: err?.message || 'Could not complete rough price.' });
    }
  });

  // 1. Comprehensive Claim Audit & Strategy Generation. This route reads the
  // live graph; it does not manufacture a parallel set of hard-coded facts.
  app.post('/api/analyze-claim', async (req, res) => {
    try {
      const { claim } = req.body;
      if (!claim) return res.status(400).json({ error: 'Claim payload is required' });

      const graph = claim.claimGraph || buildClaimGraph(claim);
      const stats = graphStats(graph);
      const totals = inventoryTotals(claim.damageInventory || []);
      const psi = totals.pass2 || totals.initial || Number(claim.auditedTrueValuation?.contractorRCV || 0);
      const carrier = Number(claim.carrierAudit?.carrierXactimateTotal || claim.carrierOffer?.initialOfferRCV || 0);
      const gap = psi - carrier;
      const findings = graph.nodes
        .filter((n: any) => ['damage','repair_operation','quantity','price','reason','carrier_position','payment'].includes(n.kind))
        .slice(0, 80)
        .map((n: any) => ({ id: n.id, statement: n.statement, bracket: n.bracket, reason: n.reason, amount: n.amount ?? null }));

      if (!aiConfigured()) {
        return res.json({
          auditSummary: `Source-traced claim map: ${stats.nodeCount} atomic propositions and ${stats.edgeCount} relationships. Initial PSi $${totals.initial.toLocaleString()}, current PSi $${psi.toLocaleString()}, carrier/Xactimate $${carrier.toLocaleString()}, comparison difference $${gap.toLocaleString()}.`,
          bracketFindings: findings.slice(0, 30),
          graphStats: stats,
          note: 'No AI provider is configured. This response contains only values already present in the claim graph; it does not create legal conclusions or new prices.',
        });
      }

      const prompt = `You are the PAi Claims analysis layer. Read the supplied atomic claim graph and explain it without changing any deterministic or source-traced value.

CLAIM: ${claim.claimNumber}
PROPERTY: ${claim.propertyAddress}
PERIL: ${claim.peril}
INITIAL PSI: $${totals.initial}
CURRENT PSI: $${psi}
CARRIER/XACTIMATE: $${carrier}
DIFFERENCE: $${gap}
GRAPH COUNTS: ${JSON.stringify(stats.counts)}

ATOMIC FINDINGS:
${JSON.stringify(findings, null, 2)}

RULES:
- Preserve every bracket exactly; do not promote a proposition.
- Do not invent measurements, prices, statutes, policy requirements, code requirements, or amounts owed.
- A carrier agreement supports only the proposition it actually addresses.
- Payment validates only linked monetary propositions when recorded as final; it does not validate unrelated damage/scope.
- Clearly distinguish provisional [[SPECULATIVE]], corroborated {[EXPLAINED]}, proven [[[VALIDATED]]], and contradicted facts.
- Discuss a dollar difference as an estimate/claim difference, not automatically an amount legally owed.

Return a concise structured forensic claim analysis with: current record, strongest supported items, unresolved/speculative items, carrier-vs-PSi differences, and next evidence that would materially strengthen the record.`;

      const response = await aiGenerate({ prompt });
      res.json({ analysisText: response.text, graphStats: stats });
    } catch (err: any) {
      console.error('Error in analyze-claim:', err);
      res.status(500).json({ error: err.message || 'Failed to analyze claim' });
    }
  });

  // 2. Parliament reads the live atomic bracket map. No chamber is allowed to
  // invent or silently promote a number.
  app.post('/api/parliament-projection', async (req, res) => {
    try {
      const { claim, perspective } = req.body;
      if (!claim || !perspective) return res.status(400).json({ error: 'Claim and perspective are required' });

      const graph = claim.claimGraph || buildClaimGraph(claim);
      const stats = graphStats(graph);
      const totals = inventoryTotals(claim.damageInventory || []);
      const carrierTotal = Number(claim.carrierAudit?.carrierXactimateTotal || claim.carrierOffer?.initialOfferRCV || 0);
      const currentPsi = totals.pass2 || totals.initial || Number(claim.auditedTrueValuation?.contractorRCV || 0);
      const gap = Math.max(0, currentPsi - carrierTotal);
      const provisional = graph.nodes.filter((n: any) => n.bracket === 'SPECULATIVE').slice(0, 20);
      const corroborated = graph.nodes.filter((n: any) => n.bracket === 'EXPLAINED').slice(0, 20);
      const proven = graph.nodes.filter((n: any) => n.bracket === 'VALIDATED').slice(0, 20);

      const titles: Record<string, string> = {
        advocate: 'Policyholder Evidence Advocate',
        opposition: 'Carrier Challenge Chamber',
        precedent: 'Policy & Authority Chamber',
        forecaster: 'Deterministic Valuation Chamber',
        recorder: 'Audit & Provenance Recorder',
        settlement: 'Settlement Readiness Chamber',
      };

      if (!aiConfigured()) {
        return res.json({
          perspective,
          title: titles[perspective] || 'Parliament Chamber',
          coreFindingBracket: stats.counts.VALIDATED > 0 ? 'EXPLAINED' : 'SPECULATIVE',
          structuralForecast: `Parliament is reading ${stats.nodeCount} atomic propositions and ${stats.edgeCount} relationships. Current PSi estimate is $${currentPsi.toLocaleString()} versus carrier/Xactimate $${carrierTotal.toLocaleString()}, a documented comparison gap of $${gap.toLocaleString()}. ${stats.counts.SPECULATIVE} nodes remain provisional, ${stats.counts.EXPLAINED} are corroborated, and ${stats.counts.VALIDATED} are proven.`,
          keyLeveragePoints: [
            `Initial photo estimate remains preserved at $${totals.initial.toLocaleString()}.`,
            `Regional Pass 2 is ${totals.pass2 ? `$${totals.pass2.toLocaleString()} including $${totals.contingency.toLocaleString()} explicit contingency` : 'not yet completed'}.`,
            'Carrier/Xactimate evidence promotes only propositions it independently addresses; differing values remain competing nodes.',
          ],
          vulnerabilities: provisional.slice(0, 2).map((n: any) => `Still provisional: ${n.statement}`),
          recommendedAction: provisional.length ? 'Add the next independent evidence source to the highest-value provisional propositions.' : 'Review corroborated/proven propositions before drafting the demand.',
          confidenceScore: stats.counts.VALIDATED ? 85 : 65,
          matterWeight_k66: Math.min(100, graph.nodes.filter((n: any) => n.channel === 'matter_k66').length * 3),
          relationWeight_k90: Math.min(100, graph.nodes.filter((n: any) => n.channel === 'relation_k90').length * 3),
          chronologyWeight_k120: Math.min(100, graph.nodes.filter((n: any) => n.channel === 'chronology_k120').length * 5),
        });
      }

      const graphDigest = graph.nodes.slice(0, 120).map((n: any) =>
        `[${n.bracket}] ${n.kind}: ${n.statement}${typeof n.amount === 'number' ? ` = $${n.amount}` : ''} | reason=${n.reason}`
      ).join('\n');

      const prompt = `You are the ${String(perspective).toUpperCase()} chamber in PAi Claims Parliament.
You MUST reason only from the supplied atomic bracket graph. Do not invent facts, law, prices, deadlines, probabilities, or entitlement. One confirmed subclaim never validates another.

Current locked values:
Initial photo PSi: $${totals.initial}
Regional Pass-2 PSi: $${totals.pass2}
Pass-2 base: $${totals.pass2Base}
Explicit contingency: $${totals.contingency}
Carrier/Xactimate total: $${carrierTotal}
Comparison gap: $${gap}

Graph counts:
SPECULATIVE=${stats.counts.SPECULATIVE}
EXPLAINED=${stats.counts.EXPLAINED}
VALIDATED=${stats.counts.VALIDATED}
CONTRADICTED=${stats.counts.CONTRADICTED}

Atomic graph:
${graphDigest}

Return JSON:
{
"title":"...",
"coreFindingBracket":"SPECULATIVE|EXPLAINED|VALIDATED|CONTRADICTED",
"structuralForecast":"...",
"keyLeveragePoints":["..."],
"vulnerabilities":["..."],
"recommendedAction":"...",
"confidenceScore":0,
"matterWeight_k66":0,
"relationWeight_k90":0,
"chronologyWeight_k120":0
}`;
      const response = await aiGenerate({ prompt, json: true, temperature: 0.15, maxTokens: 2500 });
      res.json(JSON.parse(response.text || '{}'));
    } catch (err: any) {
      console.error('Error in parliament-projection:', err);
      res.status(500).json({ error: err.message || 'Failed to generate parliament projection' });
    }
  });

  // 3. Legal Dispute & Demand Letters Generator
  app.post('/api/generate-legal-letter', async (req, res) => {
    try {
      const { claim, letterType, additionalNotes } = req.body;
      if (!claim || !letterType) {
        return res.status(400).json({ error: 'Claim and letterType are required' });
      }

      const prompt = `You are a licensed insurance claim attorney and certified public adjuster generating a formal, legally binding, highly persuasive insurance claim document.

DOCUMENT TYPE: ${letterType}
(Options: 'pre_settlement_demand' = Formal Pre-Settlement Supplemental Demand Package;
          'denial_rebuttal' = Formal Rebuttal to Carrier Claim Denial / Lowball;
          'appraisal_demand' = Formal Invocation of Policy Appraisal Clause & Umpire Demand;
          'doi_complaint' = Department of Insurance Formal Unfair Claims Practice Complaint;
          'sworn_proof_of_loss' = Sworn Statement in Proof of Loss Package)

CLAIM DETAILS:
- Policyholder: ${claim.policyholderName}
- Property Address: ${claim.propertyAddress}
- Insurer: ${claim.carrierName}
- Claim Number: ${claim.claimNumber}
- Policy Number: ${claim.policyNumber}
- Date of Loss: ${claim.dateOfLoss}
- Peril: ${claim.peril}
- Assigned Adjuster: ${claim.assignedAdjuster || 'Claims Department'}
- Carrier Offer to Date: $${claim.carrierOffer?.netCarrierCheckIssued} (Gross RCV: $${claim.carrierOffer?.initialOfferRCV})
- Audited True Market Scope: $${claim.auditedTrueValuation?.trueGrossRecovery}
- Total Supplemental Recovery Gap Owed: $${claim.auditedTrueValuation?.totalRecoveryGap}
- General Contractor Overhead & Profit (10/10) Owed: $${claim.auditedTrueValuation?.eligibleOverheadAndProfit}
- Ordinance & Law Code Compliance Owed: $${claim.auditedTrueValuation?.eligibleCodeUpgrades}

DISPUTED LINE ITEMS & TENSIONS:
${claim.tensions?.map((t: any) => `- Tension: ${t.title} | Carrier: ${t.carrierPosition} vs Proof: ${t.policyholderEvidence}`).join('\n')}

ADDITIONAL CUSTOM INSTRUCTIONS: ${additionalNotes || 'None'}

Draft a complete, formal, professional, dated, formatted letter ready to print or email to the insurance carrier's claims executive. Include formal legal statutory citations (e.g. prompt payment deadlines, matching statutes, burden of proof on exclusions, bad faith notices, Trinidad v. Florida Peninsula / relevant state precedent). Use clear headers, itemized damage schedules, and strict 10 to 14 day response deadlines.`;

      const response = await aiGenerate({
        prompt,
      });

      res.json({
        letterContent: response.text,
      });
    } catch (err: any) {
      console.error('Error in generate-legal-letter:', err);
      res.status(500).json({ error: err.message || 'Failed to generate legal letter' });
    }
  });

  // 4. Interactive Claim Advisor Chat
  app.post('/api/chat-advisor', async (req, res) => {
    try {
      const { claim, messages, userQuery } = req.body;

      const contextPrompt = `You are PAi Claim Advisor, an expert insurance claim handler, coverage attorney, and recovery strategist.
Current Active Case:
- Claim #${claim?.claimNumber} (${claim?.policyholderName})
- Carrier: ${claim?.carrierName}
- Policy Limits: Dwelling $${claim?.policyLimits?.dwelling_covA}, O&L $${claim?.policyLimits?.ordinanceAndLaw_amount}
- Initial Check: $${claim?.carrierOffer?.netCarrierCheckIssued} vs True Audited Valuation: $${claim?.auditedTrueValuation?.trueGrossRecovery} (Gap: $${claim?.auditedTrueValuation?.totalRecoveryGap})
- Key Issues: Overhead & Profit 10/10, Code Upgrades, Spot Repair vs Replacement, Excessive Depreciation.

Answer the user's question directly with strategic advice, exact policy citations, negotiating scripts, or step-by-step actions to maximize payout recovery.
Highlight validated facts using [[[VALIDATED]]] brackets and flag uncorroborated adjuster excuses with [{UNVERIFIED}] or [[SPECULATIVE]]. Keep answers highly structured and immediately actionable.`;

      const promptContents = [
        contextPrompt,
        ...(messages || []).map((m: any) => `${m.role.toUpperCase()}: ${m.content}`),
        `USER: ${userQuery}`,
      ].join('\n\n');

      const response = await aiGenerate({
        prompt: promptContents,
      });

      res.json({
        response: response.text,
      });
    } catch (err: any) {
      console.error('Error in chat-advisor:', err);
      res.status(500).json({ error: err.message || 'Chat advisor error' });
    }
  });

  // 5. Forensic Xactimate Estimate Itemizer & Scope Optimizer

  /**
   * Word-for-word re-read of already-ingested text.
   *
   * The model is given the extracted text and asked to return it verbatim. It
   * is explicitly not asked to interpret, correct or tidy anything: its value
   * here is as an independent reader whose mistakes are uncorrelated with
   * Tesseract's, so agreement between them is evidence and disagreement is a
   * flag. Any "improvement" it made would destroy exactly that property.
   */
  app.post('/api/verify-transcript', async (req, res) => {
    try {
      const { pages } = req.body as {
        pages: Array<{ page: number; text: string; source?: string; confidence?: number | null }>;
      };
      if (!Array.isArray(pages) || pages.length === 0) {
        return res.status(400).json({ error: 'pages are required' });
      }
      if (!aiConfigured()) {
        // No model: the ingested readings still reconcile against each other.
        return res.json({ verified: false, reason: 'No AI provider configured.', pages: [] });
      }

      const system = [
        'You transcribe. You do not interpret, summarise, correct, complete or reformat.',
        'You are shown text extracted from a document page by OCR or a PDF text layer.',
        'Return the same text, word for word, exactly as you read it.',
        'Do NOT fix spelling. Do NOT expand abbreviations. Do NOT normalise numbers or currency.',
        'Do NOT add words that are not there. Do NOT remove words that are.',
        'If a passage is unreadable or garbled, reproduce it as it appears rather than guessing.',
        'Return ONLY JSON: {"pages":[{"page":number,"text":"string"}]}',
      ].join(' ');

      const prompt = `Reproduce each page's text verbatim.

${pages
        .map((p) => `<<<PAGE ${p.page}>>>\n${p.text}`)
        .join('\n\n')}`;

      const answer = await aiGenerate({
        prompt,
        system,
        json: true,
        // Deterministic: this is a reading task, not a generative one.
        temperature: 0,
        maxTokens: 8000,
      });

      let parsed: any;
      try {
        parsed = JSON.parse(answer.text);
      } catch {
        return res.status(502).json({ error: 'The model did not return usable JSON.' });
      }
      const out = Array.isArray(parsed?.pages) ? parsed.pages : [];
      res.json({
        verified: true,
        pages: out.map((p: any) => ({
          page: Number(p.page),
          source: 'vision-model',
          text: String(p.text ?? ''),
          confidence: null,
        })),
      });
    } catch (error: any) {
      if (error instanceof AINotConfigured) {
        return res.json({ verified: false, reason: error.message, pages: [] });
      }
      res.status(500).json({ error: error?.message || 'Transcript verification failed' });
    }
  });

  /**
   * Transcribe document images the text pipeline could not read.
   *
   * The result is shown to the user and confirmed before any figure may use
   * it. Nothing here is treated as read until that happens.
   */
  app.post('/api/transcribe-images', async (req, res) => {
    try {
      const { images } = req.body as {
        images: Array<{ page: number; dataUrl: string; filename?: string }>;
      };
      if (!Array.isArray(images) || images.length === 0) {
        return res.status(400).json({ error: 'images are required' });
      }
      if (!aiConfigured()) {
        return res.json({ transcribed: false, reason: 'No AI provider configured.', pages: [] });
      }

      const system = [
        'You transcribe document images. You do not interpret or summarise.',
        'Reproduce every visible character: headings, labels, numbers, currency symbols, dates, form numbers.',
        'Preserve the reading order and keep each labelled value next to its label.',
        'Where text is illegible, write [illegible] in its place rather than guessing.',
        'Never infer a value that is not printed. Never complete a partially visible number.',
        'Return ONLY JSON: {"pages":[{"page":number,"text":"string","illegibleCount":number}]}',
      ].join(' ');

      const answer = await aiGenerate({
        prompt: `Transcribe these ${images.length} document image(s) verbatim. Pages in order: ${images
          .map((i) => i.page)
          .join(', ')}.`,
        system,
        json: true,
        temperature: 0,
        maxTokens: 8000,
        images: images.slice(0, 12).map((i) => ({
          dataUrl: i.dataUrl,
          label: i.filename || `page ${i.page}`,
        })),
      });

      let parsed: any;
      try {
        parsed = JSON.parse(answer.text);
      } catch {
        return res.status(502).json({ error: 'The model did not return usable JSON.' });
      }
      const out = Array.isArray(parsed?.pages) ? parsed.pages : [];
      res.json({
        transcribed: true,
        // Requires a person to confirm it before the estimation flow may run.
        requiresUserVerification: true,
        pages: out.map((p: any) => ({
          page: Number(p.page),
          source: 'vision-model',
          text: String(p.text ?? ''),
          illegibleCount: Number(p.illegibleCount ?? 0),
          confidence: null,
        })),
      });
    } catch (error: any) {
      if (error instanceof AINotConfigured) {
        return res.json({ transcribed: false, reason: error.message, pages: [] });
      }
      res.status(500).json({ error: error?.message || 'Image transcription failed' });
    }
  });

  app.post('/api/audit-xactimate', async (req, res) => {
    try {
      const { rawText, claimDetails, manualItems } = req.body;
      if (!rawText && (!manualItems || manualItems.length === 0)) {
        return res.status(400).json({ error: 'Xactimate text content or items are required' });
      }

      if (!aiConfigured()) {
        const imported = Array.isArray(manualItems) ? manualItems.map((item: any, index: number) => ({
          ...item,
          id: item.id || `carrier-${Date.now()}-${index}`,
          carrierQuantity: Number(item.carrierQuantity || 0),
          carrierUnitPrice: Number(item.carrierUnitPrice || 0),
          carrierTotal: Number(item.carrierTotal || item.carrierRCV || 0),
          contractorQuantity: Number(item.contractorQuantity ?? item.carrierQuantity ?? 0),
          contractorUnitPrice: Number(item.contractorUnitPrice ?? item.carrierUnitPrice ?? 0),
          contractorTotal: Number(item.contractorTotal ?? item.carrierTotal ?? item.carrierRCV ?? 0),
          gapAmount: Number(item.gapAmount || 0),
          status: item.status || 'carrier_imported',
          reason: item.reason || 'Imported carrier/Xactimate value; unchanged. AI audit is not configured.',
          selected: Boolean(item.selected ?? true),
          epistemicBracket: 'EXPLAINED',
        })) : [];
        const carrierTotal = imported.reduce((sum: number, item: any) => sum + Number(item.carrierTotal || 0), 0);
        return res.json({
          carrierName: claimDetails?.carrierName || 'Carrier',
          claimNumber: claimDetails?.claimNumber || 'CLM-PENDING',
          carrierXactimateTotal: carrierTotal,
          optimizedContractorTotal: carrierTotal,
          totalOmittedValue: 0,
          omittedCount: 0,
          multiTradeGCOPQualified: false,
          gcopValue: 0,
          codeUpgradesTotal: 0,
          identifiedTrades: [...new Set(imported.map((item: any) => item.tradeCategory || item.category).filter(Boolean))],
          auditScore: 0,
          summaryNotes: imported.length
            ? 'Carrier/Xactimate values imported unchanged. Configure AI to identify possible omissions; PSi can still compare quantities, labor hours/rates, and prices deterministically.'
            : 'No AI is configured and no structured carrier line items were supplied. Paste/import structured line items to compare them without AI.',
          rebuttalArguments: [],
          items: imported,
        });
      }

      const prompt = `You are a certified master Xactimate estimator, forensic construction auditor, and property insurance public adjuster.
Analyze the following insurance carrier's Xactimate estimate text, line items, and claim metadata:

CLAIM CONTEXT:
- Policyholder: ${claimDetails?.policyholderName || 'Insured'}
- Carrier: ${claimDetails?.carrierName || 'Carrier'}
- Peril: ${claimDetails?.peril || 'Wind / Water / Storm'}
- Property: ${claimDetails?.propertyAddress || 'Residential Structure'}

CARRIER XACTIMATE INPUT:
${rawText || JSON.stringify(manualItems)}

FORENSIC AUDIT DIRECTIVES:
1. Parse every item in the carrier estimate.
2. Identify what the carrier adjuster OMITTED or SHORTED compared to standard industry Xactimate best practices, manufacturer specs (GAF, Owens Corning, CertainTeed, IICRC S500), building codes (IRC, IBC, FBC, Miami-Dade HVHZ), and state matching statutes.
3. Check for standard omitted items:
   - Roofing: RFG STARTER (universal starter), RFG DRIP (drip edge IRC R905.2.8.5), RFG IWS (ice & water shield ASTM D1970), RFG STEEP (pitch surcharge 7/12+), RFG 2STORY (two-story access), RFG RIDGC (high-profile ridge cap), RFG PIPE (plumbing pipe jacks), RFG FLASH / STEP (step flashing), DMO DUMP (dumpster & haul-off), geometric waste factor (10-15% on hip/valley roofs vs 0% carrier).
   - Water/Plumbing: WTR GRM (antimicrobial), WTR DTRP (daily moisture logging site visit), CON ROOM / MANIP (content manipulation / moving furniture), PNT MASK (zip-wall containment & floor protection), DRY TEXT (texture match).
   - Finishes: PNT S (stain blocking primer sealer), continuous wall/ceiling painting to natural breaks under matching statutes.
   - Overhead & Profit: 10% Overhead + 10% Profit (O&P 10/10) when 3+ trades are involved (Trinidad v. Florida Peninsula).
   - Ordinance & Law: Municipal permit fees (FEE PERMIT), engineering / OSHA safety harness tie-offs.
4. Preserve every carrier value exactly as supplied. Extract worker-hours, labor rate, labor amount, material amount, equipment, tax and O&P whenever the source exposes them.
5. Any proposed omission or benchmark that is not directly in the carrier file must remain SPECULATIVE or EXPLAINED; never mark an AI-created proposition VALIDATED.
6. Do not assert that an item is legally owed. Identify the source/basis and let the claim graph/Parliament evaluate it.

Return ONLY a valid JSON object strictly matching this schema:
{
  "carrierName": "string",
  "claimNumber": "string",
  "carrierXactimateTotal": number,
  "optimizedContractorTotal": number,
  "totalOmittedValue": number,
  "omittedCount": number,
  "multiTradeGCOPQualified": boolean,
  "gcopValue": number,
  "codeUpgradesTotal": number,
  "identifiedTrades": ["string"],
  "auditScore": number (0 to 100 severity of lowball),
  "summaryNotes": "string (clear forensic summary explaining adjuster omissions)",
  "rebuttalArguments": ["string (3-5 razor-sharp legal and code arguments to present to adjuster)"],
  "items": [
    {
      "id": "string",
      "xactCode": "string (e.g. RFG STARTER, RFG DRIP, RFG IWS, DRY TEXT, O&P 10/10, etc.)",
      "category": "string",
      "description": "string",
      "unit": "string (LF, SQ, EA, SF, HR, %, DA)",
      "carrierQuantity": number,
      "carrierUnitPrice": number,
      "carrierTotal": number,
      "contractorQuantity": number,
      "contractorUnitPrice": number,
      "contractorTotal": number,
      "gapAmount": number,
      "status": "completely_missing" | "shorted_quantity" | "lowballed_pricing" | "unjustified_depreciation" | "omitted_code_upgrade" | "omitted_gcop",
      "reason": "string (why carrier omitted it and why contractor is entitled to it)",
      "codeCitation": "string (e.g. IRC R905.2.8.5, ASTM D1970, Trinidad v. FL Peninsula, GAF Spec Sec 4.2)",
      "tradeCategory": "Roofing" | "Drywall & Ceiling" | "Water Mitigation" | "Paint & Finishes" | "Flooring" | "HVAC & Electrical" | "General Contractor O&P (10/10)" | "Code Upgrades & Permits" | "Contents & Protection",
      "selected": true,
      "epistemicBracket": "SPECULATIVE" | "EXPLAINED" | "CONTRADICTED",
      "originalPage": number,
      "workerHours": number,
      "laborRate": number,
      "laborAmount": number,
      "materialAmount": number,
      "equipmentAmount": number,
      "tax": number,
      "overheadAndProfit": number
    }
  ]
}`;

      const response = await aiGenerate({
        prompt,
        json: true,
      });

      const parsed = JSON.parse(response.text?.trim() || '{}');
      res.json(parsed);
    } catch (err: any) {
      console.error('Error in audit-xactimate:', err);
      res.status(500).json({ error: err.message || 'Failed to audit Xactimate estimate' });
    }
  });

  // 6. Case Completeness & Missing Evidence / Photo Audit
  app.post('/api/audit-case-completeness', async (req, res) => {
    try {
      const { claim, evidenceList, photoList, userResponses } = req.body;
      if (!claim) {
        return res.status(400).json({ error: 'Claim payload is required' });
      }

      const docs = evidenceList || claim.evidence || [];
      const photos = photoList || claim.photos || [];

      // Check if GEMINI_API_KEY is available
      if (!aiConfigured()) {
        const docTypes = new Set(docs.map((d: any) => d.type));
        const photoCategories = new Set(photos.map((p: any) => p.category));

        const hasPolicy = docTypes.has('policy_dec');
        const hasPE = docTypes.has('engineer_report');
        const hasEstimate = docTypes.has('contractor_estimate');
        const hasWeather = docTypes.has('weather_data');
        const hasDenial = docTypes.has('denial_letter');
        const hasPhotoLog = docTypes.has('photo_log') || photos.length > 0;
        const hasAtticPhotos = photoCategories.has('Attic & Sheathing');
        const hasWaterMitLogs = docTypes.has('receipts_ale') || docTypes.has('proof_of_loss');

        const pillars = [
          {
            name: 'Photographic Proof & Macro Test Squares',
            status: photos.length >= 6 && hasAtticPhotos ? 'complete' : photos.length > 0 ? 'partial' : 'missing',
            score: photos.length >= 6 && hasAtticPhotos ? 92 : photos.length > 0 ? 60 : 25,
            description: 'Comprehensive high-resolution photographic evidence showing damage overviews, 10x10 test squares, chalked impacts, moisture readings, and structural underside.',
            presentItems: photos.map((p: any) => `${p.title} (${p.category})`),
            missingItems: [
              ...(!hasAtticPhotos ? ['Attic interior decking & rafter underside inspection photos to prove moisture seepage'] : []),
              ...(photos.length < 5 ? ['10x10 Test Square macro closeups with chalk circle impact count and pitch gauge'] : []),
            ],
          },
          {
            name: 'Policy Contract & Declarations Endorsements',
            status: hasPolicy ? 'complete' : 'missing',
            score: hasPolicy ? 95 : 10,
            description: 'Certified policy declarations, endorsement schedules (Ordinance & Law, Matching Riders, Mold sublimits), and deductible provisions.',
            presentItems: hasPolicy ? ['Certified Policy Declarations with HO-04-77 Ordinance & Law rider'] : [],
            missingItems: hasPolicy ? [] : ['Certified Dec Page with full policy endorsement jacket'],
          },
          {
            name: 'Independent Forensic Engineering (PE) Causation',
            status: hasPE ? 'complete' : 'missing',
            score: hasPE ? 90 : 30,
            description: 'Licensed Professional Engineer (PE) causation report establishing direct physical loss vs carrier wear-and-tear / age assertions.',
            presentItems: hasPE ? ['Independent PE Structural Engineering Report'] : [],
            missingItems: hasPE ? [] : ['Independent Professional Engineer (PE) causation and uplift failure analysis'],
          },
          {
            name: 'Certified Doppler Radar & NOAA Meteorological Data',
            status: hasWeather ? 'complete' : 'missing',
            score: hasWeather ? 100 : 20,
            description: 'Official NOAA / NWS Doppler radar storm track verification proving hail size and peak wind gusts at exact property coordinates on date of loss.',
            presentItems: hasWeather ? ['NOAA NWS Station Doppler Radar & Wind Log'] : [],
            missingItems: hasWeather ? [] : ['Certified NOAA Doppler Hail Swath / Wind Velocity data at parcel coordinates'],
          },
          {
            name: 'Contractor Benchmark & Itemized Scope (Xactimate)',
            status: hasEstimate ? 'complete' : 'missing',
            score: hasEstimate ? 95 : 15,
            description: 'Licensed General Contractor itemized Xactimate estimate with manufacturer specifications, geometric waste, and 10/10 O&P.',
            presentItems: hasEstimate ? ['Comprehensive Itemized Contractor Estimate with 10/10 O&P'] : [],
            missingItems: hasEstimate ? [] : ['Detailed line-item contractor scope of repair benchmarked to local price lists'],
          },
          {
            name: 'Municipal Building Code & 25% Replacement Mandates',
            status: 'partial',
            score: 65,
            description: 'Local municipal authority building codes requiring secondary water barriers, drip edge, starter strip, or 100% replacement under 25% rules.',
            presentItems: ['Florida Building Code §1511.1 / IRC R905.2.8.5 references'],
            missingItems: ['Formal building department letter or municipality code officer compliance notice'],
          },
          {
            name: 'Mitigation Logs & Living Expenses (ALE) Documentation',
            status: hasWaterMitLogs ? 'complete' : 'partial',
            score: hasWaterMitLogs ? 85 : 50,
            description: 'IICRC S500 daily psychrometric drying logs, moisture maps, emergency tarping invoices, and temporary housing receipts.',
            presentItems: hasWaterMitLogs ? ['Proof of Loss & Emergency ALE Records'] : [],
            missingItems: hasWaterMitLogs ? [] : ['Daily psychrometric moisture logs and emergency mitigation receipts'],
          },
        ];

        const avgScore = Math.round(pillars.reduce((acc, p) => acc + p.score, 0) / pillars.length);

        return res.json({
          overallScore: avgScore,
          completenessStatus: avgScore >= 85 ? 'BULLETPROOF' : avgScore >= 70 ? 'READY_FOR_DEMAND' : avgScore >= 50 ? 'MODERATE_GAPS' : 'CRITICAL_GAPS',
          readinessForAppraisalOrDemand: Math.min(100, Math.round(avgScore * 1.1)),
          totalDocumentsLoaded: docs.length,
          totalPhotosLoaded: photos.length,
          pillars,
          missingChecklist: [
            {
              id: 'gap-01',
              category: 'Photographic Proof',
              itemTitle: 'Attic Underside & Roof Decking Intrusion Photos',
              urgency: 'critical',
              whyNeeded: 'Insurance field adjusters routinely claim interior water leaks are pre-existing or caused by maintenance. Photos of the underside of roof sheathing showing wet rafters and daylight gaps prove direct storm penetration.',
              carrierTrapToAvoid: 'Carrier will assert "interior leak caused by deferred roof maintenance" without attic decking proof.',
              suggestedAction: 'Take 4-6 wide and closeup photos inside attic looking up at the roof deck above water damaged rooms.',
              questionPrompt: 'Do you have photos of the attic space and underside of the roof decking above the damaged rooms?',
              quickAnswers: ['Yes, I have them ready to upload', 'No, need contractor to take them', 'Not applicable (no attic access)'],
              actionType: 'upload_photo',
              isResolved: hasAtticPhotos,
            },
            {
              id: 'gap-02',
              category: 'Code & Ordinance (Law)',
              itemTitle: 'Local Municipality Code Enforcement 25% Rule Notice',
              urgency: 'high',
              whyNeeded: 'When roof damage exceeds 25%, municipal building codes (IRC / FBC) forbid spot repairs and mandate 100% full replacement. A formal code memo unlocks Ordinance & Law coverage.',
              carrierTrapToAvoid: 'Carrier will attempt to pay for a 20-shingle spot patch instead of the $35k+ full roof replacement.',
              suggestedAction: 'Obtain written statement or bulletin from city/county building official regarding code compliance on reroofs.',
              questionPrompt: 'Did the local building department or inspector confirm that the roof damage triggers the mandatory 25% full replacement code?',
              quickAnswers: ['Yes, building department confirmed', 'Need to request formal code letter', 'Contractor cited the code in estimate'],
              actionType: 'upload_doc',
              isResolved: false,
            },
            {
              id: 'gap-03',
              category: 'Photographic Proof',
              itemTitle: '10x10 Test Square Chalk Count Photos with Pitch Gauge',
              urgency: 'high',
              whyNeeded: 'Standard forensic roofing methodology requires chalking all hail/wind impacts inside a 10x10 square per slope. Over 8-10 hits qualifies the entire slope for full replacement.',
              carrierTrapToAvoid: 'Adjuster will claim hits are "foot traffic", "mechanical damage", or "blistering" unless chalked with a pitch gauge and ruler.',
              suggestedAction: 'Upload high-resolution test square photos with macro ruler showing circular bruise fractures.',
              questionPrompt: 'Are there chalked 10x10 test square photos with a macro scale showing bruised asphalt shingle mats?',
              quickAnswers: ['Yes, included in contractor photo report', 'Only general photos taken so far', 'Need to schedule roof reinspection'],
              actionType: 'upload_photo',
              isResolved: photos.length >= 4,
            },
            {
              id: 'gap-04',
              category: 'Policy & Endorsements',
              itemTitle: 'Carrier Complete Claim File & Adjuster Log Notes Request',
              urgency: 'medium',
              whyNeeded: 'Under state unfair claims settlement practices, policyholders have the right to request the carrier adjuster field notes, engineer raw photo logs, and Xactimate ESX files.',
              carrierTrapToAvoid: 'Carriers hide internal adjuster estimates that were higher before supervisor cuts.',
              suggestedAction: 'Generate a formal statutory Request for Complete Claim File and Adjuster Log Notes.',
              questionPrompt: 'Have you requested the carrier complete claim file, internal adjuster field notes, and original photo log?',
              quickAnswers: ['Request already sent to carrier', 'No, need to generate formal demand', 'Carrier provided partial estimate only'],
              actionType: 'generate_letter',
              isResolved: false,
            },
          ],
          proactiveQuestions: [
            {
              id: 'q-attic',
              question: 'Did your contractor inspect the attic space directly beneath the roof damage?',
              context: 'Attic photos showing daylight or moisture staining on plywood decking provide undeniable physical proof of storm penetration that destroys carrier "wear-and-tear" defenses.',
              pillar: 'Photographic Proof',
              impactOnSettlement: 'High (+15% leverage against carrier maintenance denials)',
              options: [
                { label: 'Yes - I have attic moisture & decking photos', value: 'yes_have_photos', suggestedDocOrPhoto: 'Upload Attic Photos' },
                { label: 'No - Only inspected exterior roof', value: 'no_exterior_only', triggersRecommendation: 'Schedule immediate attic photographic inspection' },
                { label: 'Contractor documented in written report only', value: 'in_report_only', triggersRecommendation: 'Extract photos from contractor report' },
              ],
            },
            {
              id: 'q-code-letter',
              question: 'Has a permit been pulled or has the municipal building department issued a code determination?',
              context: 'Insurance carriers often dispute Ordinance & Law coverage until an official municipal code officer or permit inspection confirms that existing non-conforming components (drip edge, underlayment, decking thickness) must be brought to current code.',
              pillar: 'Code & Ordinance (Law)',
              impactOnSettlement: 'Critical (Unlocks $14k - $30k+ in Ordinance & Law coverage)',
              options: [
                { label: 'Permit application submitted with code upgrade requirements', value: 'permit_submitted' },
                { label: 'City building code official confirmed 25% rule verbally', value: 'verbal_code' },
                { label: 'No permit pulled yet - need code citation letter', value: 'no_permit_yet', triggersRecommendation: 'Generate Municipal Code Upgrade Demand Notice' },
              ],
            },
            {
              id: 'q-discontinued',
              question: 'Is the damaged exterior or interior material discontinued (e.g. shingle, siding, tile, flooring)?',
              context: 'Under state matching statutes, if a discontinued material cannot be matched in size, color, and quality, the insurer must replace the entire continuous slope, elevation, or contiguous floor area.',
              pillar: 'Contractor Benchmark',
              impactOnSettlement: 'Massive (+40% to +100% total claim valuation)',
              options: [
                { label: 'Yes - Verified discontinued by ITEL or manufacturer', value: 'itel_confirmed' },
                { label: 'Likely discontinued (installed >7 years ago)', value: 'likely_discontinued', triggersRecommendation: 'Submit sample to ITEL for certified lab match report' },
                { label: 'Standard modern material still available', value: 'standard_available' },
              ],
            },
          ],
          expertRecommendations: [
            'Immediately upload attic underside photos to close the carrier wear-and-tear loophole.',
            'Issue a formal statutory request for the carrier internal adjuster notes and engineer raw metadata photos.',
            'Submit shingle/flooring sample to ITEL for certified laboratory confirmation of material discontinuance to trigger 100% uniform matching coverage.',
            'Attach municipal building code citations for drip edge (IRC R905.2.8.5) and secondary water barrier to secure full Ordinance & Law recovery.',
          ],
        });
      }

      const prompt = `You are a world-class forensic insurance coverage attorney, public adjuster strategist, and building forensic auditor.
Analyze the loaded case files and photos for an insurance claim to perform a deep Case Completeness & Missing Evidence Forensic Audit.

CLAIM DETAILS:
- Policyholder: ${claim.policyholderName}
- Claim Number: ${claim.claimNumber}
- Peril: ${claim.peril}
- Policy Type: ${claim.policyType}
- Property: ${claim.propertyAddress}
- Carrier: ${claim.carrierName}
- Carrier Initial Check: $${claim.carrierOffer?.netCarrierCheckIssued} (Gross RCV: $${claim.carrierOffer?.initialOfferRCV})
- Contractor Audited Valuation: $${claim.auditedTrueValuation?.trueGrossRecovery}
- Recovery Gap: $${claim.auditedTrueValuation?.totalRecoveryGap}

CURRENT LOADED DOCUMENTS (${docs.length}):
${docs.map((d: any) => `- [${d.type.toUpperCase()}] "${d.title}" (Source: ${d.source}, Date: ${d.date}, Excerpt: "${d.excerpt?.substring(0, 150)}")`).join('\n')}

CURRENT LOADED PHOTOS (${photos.length}):
${photos.map((p: any) => `- [PHOTO: ${p.category}] "${p.title}" (Tags: ${p.damageTags?.join(', ')}, Caption: "${p.caption}")`).join('\n')}

USER RESPONSES TO PREVIOUS QUESTIONS:
${JSON.stringify(userResponses || {})}

YOUR TASK:
1. Conduct an audit across the 7 Evidentiary Pillars:
   Pillar 1: Photographic Proof & Macro Test Squares
   Pillar 2: Policy Contract & Declarations Endorsements
   Pillar 3: Independent Forensic Engineering (PE) Causation
   Pillar 4: Certified Doppler Radar & NOAA Meteorological Data
   Pillar 5: Contractor Benchmark & Itemized Scope (Xactimate)
   Pillar 6: Municipal Building Code & 25% Replacement Mandates
   Pillar 7: Mitigation Logs & Living Expenses (ALE) Documentation

2. Identify EXACTLY what evidence, documents, photos, angles, lab reports, or code letters are MISSING from this case.
3. Formulate targeted forensic questions to actively ASK THE USER if they have specific evidence or if certain field conditions exist.
4. Calculate an accurate Case Completeness Score (0-100) and readiness status.

Return ONLY valid JSON matching this schema:
{
  "overallScore": number (0 to 100),
  "completenessStatus": "CRITICAL_GAPS" | "MODERATE_GAPS" | "READY_FOR_DEMAND" | "BULLETPROOF",
  "readinessForAppraisalOrDemand": number (0 to 100),
  "totalDocumentsLoaded": number,
  "totalPhotosLoaded": number,
  "pillars": [
    {
      "name": "string",
      "status": "complete" | "partial" | "missing",
      "score": number (0 to 100),
      "description": "string",
      "presentItems": ["string"],
      "missingItems": ["string"]
    }
  ],
  "missingChecklist": [
    {
      "id": "string",
      "category": "Photographic Proof" | "Policy & Endorsements" | "Engineering & Causation" | "Weather & NOAA Data" | "Contractor Benchmark / Xactimate" | "Code & Ordinance (Law)" | "Mitigation & Living Expenses (ALE)",
      "itemTitle": "string",
      "urgency": "critical" | "high" | "medium",
      "whyNeeded": "string (forensic justification why this item wins the claim)",
      "carrierTrapToAvoid": "string (what the adjuster will say or deny if this item is absent)",
      "suggestedAction": "string (specific action to obtain or upload)",
      "questionPrompt": "string (clear, direct question to ask the user if they have this or can get it)",
      "quickAnswers": ["string (3 actionable choices)"],
      "actionType": "upload_doc" | "upload_photo" | "generate_letter" | "confirm_fact",
      "isResolved": boolean
    }
  ],
  "proactiveQuestions": [
    {
      "id": "string",
      "question": "string",
      "context": "string",
      "pillar": "string",
      "impactOnSettlement": "string",
      "options": [
        {
          "label": "string",
          "value": "string",
          "triggersRecommendation": "string (optional)",
          "suggestedDocOrPhoto": "string (optional)"
        }
      ]
    }
  ],
  "expertRecommendations": ["string"]
}`;

      const response = await aiGenerate({
        prompt,
        json: true,
      });

      const parsed = JSON.parse(response.text?.trim() || '{}');
      res.json(parsed);
    } catch (err: any) {
      console.error('Error in audit-case-completeness:', err);
      res.status(500).json({ error: err.message || 'Failed to audit case completeness' });
    }
  });

  // --- AI provider configuration -------------------------------------
  // Lists what is available and what is active. Never returns a key.
  app.get('/api/ai/providers', (_req, res) => {
    const cfg = aiActiveConfig();
    res.json({
      providers: AI_PROVIDERS,
      active: { id: cfg.id, model: cfg.model || null, baseUrl: cfg.baseUrl || null },
      configured: aiIsConfigured(),
    });
  });

  // Apply configuration to the running server process. Electron also persists
  // the same choice in %LOCALAPPDATA%. This route is required in electron:dev,
  // where the UI shell and Express server are separate processes.
  app.post('/api/ai/config', (req, res) => {
    const { provider, apiKey, model, baseUrl } = req.body || {};
    const allowed = new Set(AI_PROVIDERS.map((p) => p.id));
    if (!provider || !allowed.has(provider)) {
      return res.status(400).json({ ok: false, error: 'Unknown AI provider.' });
    }
    process.env.AI_PROVIDER = provider;
    process.env.AI_MODEL = model || '';
    if (provider === 'local') {
      process.env.AI_BASE_URL = '';
    } else {
      process.env.AI_BASE_URL = baseUrl || '';
    }
    const keyEnv: Record<string, string> = {
      gemini: 'GEMINI_API_KEY',
      anthropic: 'ANTHROPIC_API_KEY',
      openai: 'OPENAI_API_KEY',
      'openai-compatible': 'AI_API_KEY',
    };
    const envName = keyEnv[provider];
    if (envName && apiKey !== undefined) process.env[envName] = String(apiKey || '');
    return res.json({ ok: true, provider });
  });

  // Verifies a provider before the user relies on it. The desktop shell has
  // already written the key to env; this only exercises it.
  app.post('/api/ai/test', async (_req, res) => {
    const result = await aiTestConnection(aiActiveConfig());
    res.status(result.ok ? 200 : 400).json(result);
  });

  // --- Private AI runtime (llama.cpp, bundled) -------------------------
  app.get('/api/ai/local/status', async (_req, res) => {
    res.json(await llama.status());
  });

  app.get('/api/ai/local/recommend', (_req, res) => {
    const ramGB = Math.round(os.totalmem() / 1024 ** 3);
    res.json({ ...llama.recommend(ramGB), platform: process.platform, cpus: os.cpus().length });
  });

  // Streams download progress as server-sent events. Model files are large,
  // so the user sees real byte counts rather than a spinner.
  app.post('/api/ai/local/download', async (req, res) => {
    res.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      Connection: 'keep-alive',
    });
    const send = (o: any) => res.write(`data: ${JSON.stringify(o)}\n\n`);
    let aborted = false;
    req.on('aborted', () => { aborted = true; });
    res.on('close', () => {
      if (!res.writableEnded) aborted = true;
    });
    try {
      for await (const p of llama.download(req.body?.model)) {
        if (aborted) break;
        send(p);
        if (p.done) break;
      }
    } catch (err: any) {
      send({ status: 'error', error: err?.message || String(err), done: true });
    }
    res.end();
  });

  app.post('/api/ai/local/start', async (req, res) => {
    const { modelPath, contextTokens, gpuLayers } = req.body || {};
    const result = await llama.start({
      modelPath,
      port: Number(process.env.LLAMA_PORT) || 8080,
      contextTokens,
      gpuLayers,
    });
    if (result.ok) process.env.LLAMA_BASE_URL = result.baseUrl as string;
    res.status(result.ok ? 200 : 400).json(result);
  });

  app.post('/api/ai/local/stop', async (_req, res) => {
    await llama.stop();
    delete process.env.LLAMA_BASE_URL;
    res.json({ ok: true });
  });

  app.delete('/api/ai/local/model', (req, res) => {
    try {
      res.json(llama.removeModel(req.body?.file));
    } catch (err: any) {
      res.status(400).json({ error: err?.message || String(err) });
    }
  });

  // UI serving MUST come after every /api route. In production the SPA
  // wildcard would otherwise return index.html for GET /api/ai/local/status,
  // which made the local installer appear to lock up.
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = process.env.PAI_DIST_DIR || path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, HOST, () => {
    console.log(`PAi Claim Server running on http://${HOST}:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
});
