$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

Write-Host "PAi Claims 1.3.1 — Microsoft Commerce Verification" -ForegroundColor Cyan

if (-not (Test-Path ".\node_modules")) {
    Write-Host "Installing Windows-native dependencies..." -ForegroundColor Cyan
    npm install
}

Write-Host "1/5 Microsoft Store bridge compile/self-test" -ForegroundColor Cyan
& .\store-bridge\Build-StoreBridge.ps1

Write-Host "2/5 Domain and commerce tests" -ForegroundColor Cyan
npm test

Write-Host "3/5 TypeScript check" -ForegroundColor Cyan
npm run lint

Write-Host "4/5 Electron bridge syntax" -ForegroundColor Cyan
node --check .\electron\main.cjs
node --check .\electron\preload.cjs
node --check .\electron\commerce.cjs
node --check .\electron\microsoft-store.cjs
node --check .\electron\store-bridge.cjs

Write-Host "5/5 Version/package checks" -ForegroundColor Cyan
$pkg = Get-Content .\package.json -Raw | ConvertFrom-Json
if ($pkg.version -ne "1.3.1") { throw "package.json version must be 1.3.1" }
$builder = Get-Content .\electron-builder.yml -Raw
if ($builder -notmatch 'buildVersion:\s*1\.3\.1\.0') { throw "electron-builder.yml buildVersion must be 1.3.1.0" }
if ($builder -notmatch 'PAiClaims\.StoreBridge\.exe') { throw "Store bridge is not included in electron-builder.yml" }

Write-Host "Verification complete — source checks passed." -ForegroundColor Green
Write-Host "Use .\BUILD_PSI_STORE.ps1 to create release\PAiClaims-1.3.1-x64.appx." -ForegroundColor Green
Write-Host "Real Microsoft purchases must be tested from the installed packaged/Store build." -ForegroundColor Yellow
