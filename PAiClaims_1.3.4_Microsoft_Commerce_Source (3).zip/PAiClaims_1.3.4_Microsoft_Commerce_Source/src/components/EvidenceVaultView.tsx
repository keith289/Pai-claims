import React, { useState } from 'react';
import {
  FolderArchive,
  Upload,
  FileText,
  ShieldCheck,
  Search,
  ExternalLink,
  Layers,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  FileSearch,
  Eye,
  Plus,
  Camera,
  HelpCircle,
  ShieldAlert,
  BarChart3,
  RefreshCw,
} from 'lucide-react';
import {
  InsuranceClaim,
  EvidenceItem,
  CasePhotoItem,
  CaseCompletenessAudit,
} from '../types';
import { BRACKET_COLORS, parseEpistemicText } from '../utils/epistemicEngine';
import { CaseCompletenessBanner } from './CaseCompletenessBanner';
import { TranscriptReviewPanel } from './TranscriptReviewPanel';
import { confirmDiscrepancy, markVerified } from '../domain/transcriptReview.ts';
import { MissingEvidenceQuestions } from './MissingEvidenceQuestions';
import { DamagePhotoGallery } from './DamagePhotoGallery';
import { BatchCaseUploaderModal } from './BatchCaseUploaderModal';

interface EvidenceVaultViewProps {
  claim: InsuranceClaim;
  onUpdateClaim: (updated: InsuranceClaim) => void;
}

export const EvidenceVaultView: React.FC<EvidenceVaultViewProps> = ({
  claim,
  onUpdateClaim,
}) => {
  const [activeTab, setActiveTab] = useState<'missing_audit' | 'photos' | 'documents'>('missing_audit');
  const [filterType, setFilterType] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDoc, setSelectedDoc] = useState<EvidenceItem | null>(claim.evidence[0] || null);
  const [showBatchModal, setShowBatchModal] = useState(false);
  const [suggestedUploadCategory, setSuggestedUploadCategory] = useState<string>('Roof & Slopes');
  const [isAuditing, setIsAuditing] = useState(false);

  // Initialize or fallback completeness audit
  const defaultAudit: CaseCompletenessAudit = claim.completenessAudit || {
    overallScore: 74,
    completenessStatus: 'MODERATE_GAPS',
    summary: 'Strong core documentation established, but 3 critical evidentiary gaps leave the policyholder vulnerable to carrier wear-and-tear or cosmetic exclusions.',
    pillars: [
      { name: 'Photographic Loss Evidence', score: 80, status: 'partial', missingCount: 1 },
      { name: 'Policy & Endorsements', score: 100, status: 'complete', missingCount: 0 },
      { name: 'PE Forensic Causation', score: 90, status: 'complete', missingCount: 0 },
      { name: 'NOAA Weather & Microburst Data', score: 100, status: 'complete', missingCount: 0 },
      { name: 'Independent Xactimate Scope', score: 85, status: 'partial', missingCount: 1 },
      { name: 'Municipal Code & Permitting', score: 35, status: 'missing', missingCount: 1 },
      { name: 'IICRC Water Mitigation / ALE', score: 70, status: 'partial', missingCount: 1 },
    ],
    missingChecklist: [
      {
        id: 'gap-01',
        pillar: 'Municipal Code & Permitting',
        itemTitle: 'Building Department 25% Rule or Code Upgrade Verification',
        urgency: 'critical',
        category: 'Code & Municipal',
        whyNeeded: 'Unlocks Ordinance & Law Coverage (25% endorsement) to force full roof replacement when repairs exceed local code thresholds.',
        carrierTrapToAvoid: 'Carrier will allow only a $5,400 patch repair for 22 individual shingles, falsely claiming code upgrades are optional unless enforced by city.',
        questionPrompt: 'Have you obtained the local building department code memo regarding the 25% full replacement rule, or municipal permits for prior roof repairs?',
        quickAnswers: [
          'Yes, have city letter ready',
          'Need contractor to pull code memo',
          'Carrier refused to recognize code',
        ],
        actionType: 'upload_doc',
        isResolved: false,
      },
      {
        id: 'gap-02',
        pillar: 'Photographic Loss Evidence',
        itemTitle: 'Attic Space Decking Moisture & Water Intrusion Photo Log',
        urgency: 'critical',
        category: 'Attic & Sheathing',
        whyNeeded: 'Direct photos of moisture saturation, water rings, and rusted nails on the underside of OSB/plywood decking irrevocably link exterior storm uplift to interior ceiling leaks.',
        carrierTrapToAvoid: 'Carrier field adjuster only inspected the exterior shingles and claims interior ceiling spots are "pre-existing humidity or thermal condensation".',
        questionPrompt: 'Do you have high-resolution photos of the attic space and underside of the roof decking above the damaged rooms?',
        quickAnswers: [
          'Yes, attic photos available',
          'Need inspection inside attic',
          'Moisture meter photos attached',
        ],
        actionType: 'upload_photo',
        isResolved: false,
      },
      {
        id: 'gap-03',
        pillar: 'Independent Xactimate Scope',
        itemTitle: 'ITEL Laboratory Shingle Discontinuance / Physical Compatibility Test',
        urgency: 'high',
        category: 'Roof & Slopes',
        whyNeeded: 'Certified ITEL laboratory analysis proves the existing shingle is discontinued and unavailable in modern dimensions, legally triggering uniform line replacement under state matching statutes.',
        carrierTrapToAvoid: 'Carrier assumes generic 3-tab or architectural shingles can be spliced in without causing unsealed lap joints or physical mismatch.',
        questionPrompt: 'Has a sample shingle been sent to ITEL Laboratories to test if an identical match is currently manufactured?',
        quickAnswers: [
          'ITEL report received',
          'Contractor pulled sample shingle',
          'Shingle is known discontinued',
        ],
        actionType: 'upload_doc',
        isResolved: false,
      },
      {
        id: 'gap-04',
        pillar: 'IICRC Water Mitigation / ALE',
        itemTitle: 'Continuous Dryout Psychrometric Moisture Log & Thermal Imaging',
        urgency: 'medium',
        category: 'Water Line & Moisture',
        whyNeeded: 'IICRC S500 certified daily moisture logs and FLIR thermal images prove ongoing structural drying was required and justifies dehumidifier equipment line items.',
        carrierTrapToAvoid: 'Carrier adjuster slashed water mitigation invoice by 60%, claiming fans ran for too many days.',
        questionPrompt: 'Did your water extraction company provide day-by-day psychrometric drying logs and FLIR thermal camera photos?',
        quickAnswers: [
          'Yes, drying logs complete',
          'Request logs from mitigation team',
          'Only final invoice available',
        ],
        actionType: 'upload_doc',
        isResolved: false,
      },
    ],
    proactiveQuestions: [
      {
        id: 'pq-01',
        question: 'Are there any rotted fascia boards, rotted plywood decking, or unsealed starter courses along the eaves?',
        context: 'Carriers frequently exclude starter courses and drip edge replacement unless specific code violation photos and contractor scope line items are documented.',
        pillar: 'Municipal Code & Permitting',
        impactOnSettlement: '+$8,500 O&L Allowance',
        options: [
          { label: 'Yes, rotten starter sheathing & missing drip edge present', value: 'yes_damage' },
          { label: 'No visible decking rot, but drip edge is not code compliant', value: 'code_only' },
          { label: 'Unsure, needs contractor attic & ladder inspection', value: 'unsure' },
        ],
      },
      {
        id: 'pq-02',
        question: 'Did the insurance company adjuster bring a ladder, walk all roof elevations, or use drone photography during inspection?',
        context: 'If the carrier adjuster spent less than 30 minutes on site or failed to inspect steep slopes, this is actionable evidence of an incomplete and bad-faith field inspection.',
        pillar: 'PE Forensic Causation',
        impactOnSettlement: 'Invalidates Carrier Denial',
        options: [
          { label: 'Adjuster only took quick ground-level photos (<20 min)', value: 'inadequate' },
          { label: 'Adjuster climbed ladder but refused to test squares', value: 'partial' },
          { label: 'Full comprehensive inspection was performed', value: 'thorough' },
        ],
      },
      {
        id: 'pq-03',
        question: 'Have you incurred out-of-pocket costs for emergency tarps, hotel stays, or meal allowances during the storm disruption?',
        context: 'Coverage D (Loss of Use / ALE) is 100% recoverable with itemized receipts and is not subject to the primary building property deductible in many jurisdictions.',
        pillar: 'IICRC Water Mitigation / ALE',
        impactOnSettlement: '+$4,200 Direct Payout',
        options: [
          { label: 'Yes, have tarp invoices & hotel receipts saved', value: 'have_ale' },
          { label: 'Only emergency tarping paid out of pocket', value: 'tarp_only' },
          { label: 'No out-of-pocket living expenses incurred', value: 'none' },
        ],
      },
    ],
  };

  const audit = claim.completenessAudit || defaultAudit;

  const filteredDocs = claim.evidence.filter((doc) => {
    const matchesType = filterType === 'all' || doc.type === filterType;
    const matchesSearch =
      doc.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      doc.excerpt.toLowerCase().includes(searchQuery.toLowerCase()) ||
      doc.provenanceRoot.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesType && matchesSearch;
  });

  const handleRunAudit = async () => {
    setIsAuditing(true);
    try {
      const response = await fetch('/api/audit-case-completeness', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ claim }),
      });

      if (response.ok) {
        const data = await response.json();
        if (data.audit) {
          const updated = {
            ...claim,
            completenessAudit: data.audit,
          };
          onUpdateClaim(updated);
        }
      }
    } catch (err) {
      console.error('Audit API call failed, recalculating locally:', err);
    } finally {
      setIsAuditing(false);
    }
  };

  const handleResolveGapItem = (itemId: string, userResponse: string) => {
    const updatedChecklist = audit.missingChecklist.map((item) => {
      if (item.id === itemId) {
        return { ...item, isResolved: true };
      }
      return item;
    });

    const resolvedCount = updatedChecklist.filter((g) => g.isResolved).length;
    const totalCount = updatedChecklist.length;
    const newScore = Math.min(100, Math.round(74 + (resolvedCount / totalCount) * 26));

    const newStatus =
      newScore >= 95
        ? 'BULLETPROOF'
        : newScore >= 85
        ? 'READY_FOR_DEMAND'
        : newScore >= 70
        ? 'MODERATE_GAPS'
        : 'CRITICAL_GAPS';

    const updatedAudit: CaseCompletenessAudit = {
      ...audit,
      overallScore: newScore,
      completenessStatus: newStatus as any,
      missingChecklist: updatedChecklist,
    };

    onUpdateClaim({
      ...claim,
      completenessAudit: updatedAudit,
    });
  };

  const handleAnswerQuestion = (questionId: string, answerValue: string) => {
    const updatedQuestions = audit.proactiveQuestions.map((q) => {
      if (q.id === questionId) {
        return { ...q, selectedAnswer: answerValue };
      }
      return q;
    });

    const updatedAudit: CaseCompletenessAudit = {
      ...audit,
      proactiveQuestions: updatedQuestions,
      overallScore: Math.min(100, audit.overallScore + 4),
    };

    onUpdateClaim({
      ...claim,
      completenessAudit: updatedAudit,
    });
  };

  const handleIngestFiles = (newDocs: EvidenceItem[], newPhotos: CasePhotoItem[]) => {
    let updatedClaim = { ...claim };

    if (newDocs.length > 0) {
      updatedClaim.evidence = [...newDocs, ...updatedClaim.evidence];
    }

    if (newPhotos.length > 0) {
      const existingPhotos = updatedClaim.photos || [];
      updatedClaim.photos = [...newPhotos, ...existingPhotos];
    }

    // Auto improve completeness
    if (updatedClaim.completenessAudit) {
      const updatedChecklist = updatedClaim.completenessAudit.missingChecklist.map((item) => {
        // If a photo was added, resolve photo gap
        if (newPhotos.length > 0 && item.actionType === 'upload_photo') {
          return { ...item, isResolved: true };
        }
        // If doc was added, resolve doc gap
        if (newDocs.length > 0 && item.actionType === 'upload_doc') {
          return { ...item, isResolved: true };
        }
        return item;
      });

      updatedClaim.completenessAudit = {
        ...updatedClaim.completenessAudit,
        overallScore: Math.min(100, updatedClaim.completenessAudit.overallScore + 18),
        missingChecklist: updatedChecklist,
      };
    }

    onUpdateClaim(updatedClaim);
  };

  // What the readers made of each page, and what the user still has to settle.
  const pageReviews = claim.pageReviews ?? [];

  const updateReview = (page: number, next: (r: typeof pageReviews[number]) => typeof pageReviews[number]) => {
    onUpdateClaim({
      ...claim,
      pageReviews: pageReviews.map((r) => (r.page === page ? next(r) : r)),
    });
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">

      {pageReviews.length > 0 && (
        <TranscriptReviewPanel
          pages={pageReviews}
          onConfirmWord={(page, discrepancyId, value) =>
            updateReview(page, (r) => confirmDiscrepancy(r, discrepancyId, value))
          }
          onVerifyPage={(page) => updateReview(page, (r) => markVerified(r))}
        />
      )}

      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <FolderArchive className="w-6 h-6 text-sky-400" />
            <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
              Case Dossier & Evidence Vault
            </h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Build your complete evidentiary file: ingest damage photos, engineering reports, weather Doppler records, and let AI identify missing leverage.
          </p>
        </div>

        <button
          onClick={() => {
            setSuggestedUploadCategory('Roof & Slopes');
            setShowBatchModal(true);
          }}
          className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-sky-500 to-indigo-600 hover:from-sky-400 hover:to-indigo-500 text-white text-xs font-semibold shadow-md shadow-sky-500/20 flex items-center gap-2 transition-all shrink-0"
        >
          <Upload className="w-4 h-4" />
          <span>Load Docs & Photos</span>
        </button>
      </div>

      {/* 1. Case Completeness Banner & Live Readiness Gauge */}
      <CaseCompletenessBanner
        audit={audit}
        totalDocs={claim.evidence.length}
        totalPhotos={(claim.photos || []).length}
        isLoading={isAuditing}
        onRunAudit={handleRunAudit}
        onSwitchTab={(tab) => {
          if (tab === 'batch_upload') setShowBatchModal(true);
          else setActiveTab(tab);
        }}
      />

      {/* 2. Main Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2 overflow-x-auto">
        
        <button
          onClick={() => setActiveTab('missing_audit')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
            activeTab === 'missing_audit'
              ? 'bg-sky-500 text-white shadow-md shadow-sky-500/20'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
          }`}
        >
          <HelpCircle className="w-4 h-4" />
          <span>AI Missing Evidence Investigator</span>
          {audit.missingChecklist.filter((g) => !g.isResolved).length > 0 && (
            <span className={`px-1.5 py-0.2 rounded-full text-[10px] font-mono ${
              activeTab === 'missing_audit' ? 'bg-white/20 text-white' : 'bg-amber-500/20 text-amber-300'
            }`}>
              {audit.missingChecklist.filter((g) => !g.isResolved).length}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTab('photos')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
            activeTab === 'photos'
              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-500/20'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
          }`}
        >
          <Camera className="w-4 h-4" />
          <span>Damage Photo Vault</span>
          <span className={`px-1.5 py-0.2 rounded-full text-[10px] font-mono ${
            activeTab === 'photos' ? 'bg-white/20 text-white' : 'bg-slate-800 text-slate-400'
          }`}>
            {(claim.photos || []).length}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('documents')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
            activeTab === 'documents'
              ? 'bg-slate-800 text-white border border-slate-700'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>Certified Documents & Scope Files</span>
          <span className={`px-1.5 py-0.2 rounded-full text-[10px] font-mono ${
            activeTab === 'documents' ? 'bg-white/20 text-white' : 'bg-slate-800 text-slate-400'
          }`}>
            {claim.evidence.length}
          </span>
        </button>

      </div>

      {/* 3. Sub-View Body */}
      {activeTab === 'missing_audit' && (
        <MissingEvidenceQuestions
          claim={claim}
          audit={audit}
          onResolveItem={handleResolveGapItem}
          onAnswerQuestion={handleAnswerQuestion}
          onOpenUploadModal={(category) => {
            setSuggestedUploadCategory(category || 'Code & Municipal');
            setShowBatchModal(true);
          }}
          onOpenPhotoUploadModal={(category) => {
            setSuggestedUploadCategory(category || 'Attic & Sheathing');
            setShowBatchModal(true);
          }}
        />
      )}

      {activeTab === 'photos' && (
        <DamagePhotoGallery
          photos={claim.photos || []}
          claim={claim}
          onAddPhoto={(photo) => {
            const existing = claim.photos || [];
            onUpdateClaim({
              ...claim,
              photos: [photo, ...existing],
            });
          }}
          onUpdateClaim={onUpdateClaim}
          onOpenUploadModal={() => {
            setSuggestedUploadCategory('Roof & Slopes');
            setShowBatchModal(true);
          }}
        />
      )}

      {activeTab === 'documents' && (
        <div className="space-y-5">
          {/* Search & Filter Bar */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
            <div className="relative flex-1 max-w-md">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search evidence by title, citation, or provenance..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-900/90 border border-slate-800 text-slate-200 text-xs focus:outline-none focus:border-sky-500"
              />
            </div>

            <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
              {[
                { id: 'all', label: 'All Vault Items' },
                { id: 'policy_dec', label: 'Policies' },
                { id: 'engineer_report', label: 'PE Reports' },
                { id: 'contractor_estimate', label: 'Estimates' },
                { id: 'denial_letter', label: 'Carrier Letters' },
                { id: 'weather_data', label: 'NOAA Weather' },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setFilterType(tab.id)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors ${
                    filterType === tab.id
                      ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60 border border-transparent'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {/* Main 2-Column Split: Document Cards List & Live Epistemic Inspector */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
            
            {/* Left Column: Document Cards List */}
            <div className="lg:col-span-5 space-y-3">
              {filteredDocs.map((doc) => {
                const style = BRACKET_COLORS[doc.bracketState];
                const isSelected = selectedDoc?.id === doc.id;

                return (
                  <div
                    key={doc.id}
                    onClick={() => setSelectedDoc(doc)}
                    className={`p-4 rounded-xl border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-slate-900 border-sky-500 shadow-lg shadow-sky-500/10'
                        : 'bg-slate-900/70 border-slate-800/80 hover:border-slate-700 hover:bg-slate-900'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-start gap-3 min-w-0">
                        <div className={`p-2 rounded-lg ${style.bg} ${style.border} border shrink-0 mt-0.5`}>
                          <FileText className={`w-4 h-4 ${style.text}`} />
                        </div>

                        <div className="min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${style.bg} ${style.text} border ${style.border}`}>
                              {doc.bracketState}
                            </span>
                            <span className="text-[11px] font-mono text-slate-400">
                              {doc.date}
                            </span>
                          </div>

                          <h3 className="text-xs sm:text-sm font-bold text-white mt-1 truncate">
                            {doc.title}
                          </h3>

                          <p className="text-xs text-slate-400 line-clamp-2 mt-1 leading-relaxed">
                            {doc.excerpt}
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="mt-3 pt-3 border-t border-slate-800/60 flex items-center justify-between text-[11px] text-slate-400">
                      <span className="truncate max-w-[200px]">{doc.source}</span>
                      <span className="font-mono text-sky-400 font-semibold">
                        Pressure: {doc.totalPressure.toFixed(1)}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Right Column: Epistemic Inspector */}
            <div className="lg:col-span-7">
              {selectedDoc ? (
                <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-5 sticky top-24 shadow-xl">
                  
                  {/* Header */}
                  <div className="flex items-start justify-between gap-3 pb-4 border-b border-slate-800">
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className={`px-2.5 py-0.5 rounded-full text-xs font-mono font-bold ${BRACKET_COLORS[selectedDoc.bracketState].bg} ${BRACKET_COLORS[selectedDoc.bracketState].text} border ${BRACKET_COLORS[selectedDoc.bracketState].border}`}>
                          {selectedDoc.bracketState}
                        </span>
                        <span className="text-xs font-mono text-slate-400">
                          Type: {selectedDoc.type.toUpperCase()}
                        </span>
                      </div>

                      <h2 className="text-base sm:text-lg font-bold text-white mt-2">
                        {selectedDoc.title}
                      </h2>
                    </div>

                    <div className="text-right shrink-0">
                      <div className="text-[10px] text-slate-400 uppercase font-mono">Associated Valuation</div>
                      <div className="text-base font-bold font-mono text-emerald-400">
                        {selectedDoc.amountAssociated > 0
                          ? `$${selectedDoc.amountAssociated.toLocaleString()}`
                          : 'Non-Monetary Proof'}
                      </div>
                    </div>
                  </div>

                  {/* Provenance & Stance */}
                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800/80">
                      <div className="text-[10px] text-slate-400 uppercase font-mono mb-1">
                        Provenance Root
                      </div>
                      <div className="font-semibold text-slate-200">
                        {selectedDoc.provenanceRoot}
                      </div>
                    </div>

                    <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800/80">
                      <div className="text-[10px] text-slate-400 uppercase font-mono mb-1">
                        Evidentiary Stance
                      </div>
                      <div className={`font-semibold capitalize ${
                        selectedDoc.stance === 'supports' ? 'text-emerald-400' : 'text-rose-400'
                      }`}>
                        {selectedDoc.stance} Policyholder Claim
                      </div>
                    </div>
                  </div>

                  {/* Epistemic Parser Excerpt */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-semibold text-slate-300 uppercase tracking-wider font-mono">
                        Epistemic Record & Forensic Text
                      </span>
                    </div>

                    <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 font-mono text-xs text-slate-200 leading-relaxed max-h-48 overflow-y-auto">
                      {parseEpistemicText(selectedDoc.rawText)}
                    </div>
                  </div>

                  {/* Key Observations */}
                  <div className="space-y-2">
                    <span className="text-xs font-semibold text-slate-300 uppercase tracking-wider font-mono">
                      Key Evidentiary Observations ({selectedDoc.keyObservations.length})
                    </span>
                    <ul className="space-y-1.5">
                      {selectedDoc.keyObservations.map((obs, idx) => (
                        <li key={idx} className="flex items-start gap-2 text-xs text-slate-300">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                          <span>{obs}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                </div>
              ) : (
                <div className="p-12 text-center rounded-2xl bg-slate-900/40 border border-slate-800 text-slate-500">
                  Select a document from the left list to view forensic details.
                </div>
              )}
            </div>

          </div>
        </div>
      )}

      {/* 4. Batch File & Photo Uploader Modal */}
      <BatchCaseUploaderModal
        claim={claim}
        isOpen={showBatchModal}
        onClose={() => setShowBatchModal(false)}
        onIngestFiles={handleIngestFiles}
        initialCategory={suggestedUploadCategory}
      />

    </div>
  );
};
