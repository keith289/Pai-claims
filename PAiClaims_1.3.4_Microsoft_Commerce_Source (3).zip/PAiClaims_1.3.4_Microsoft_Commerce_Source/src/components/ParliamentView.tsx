import React, { useState } from 'react';
import {
  Scale,
  Sparkles,
  ShieldCheck,
  AlertTriangle,
  Compass,
  DollarSign,
  FileText,
  TrendingUp,
  RefreshCw,
  CheckCircle2,
  Lock,
} from 'lucide-react';
import { InsuranceClaim, ParliamentPerspective, ParliamentAnalysisResult } from '../types';
import { BRACKET_COLORS } from '../utils/epistemicEngine';

interface ParliamentViewProps {
  claim: InsuranceClaim;
  onNavigateTab: (tab: any) => void;
}

export const ParliamentView: React.FC<ParliamentViewProps> = ({ claim, onNavigateTab }) => {
  const [activePerspective, setActivePerspective] = useState<ParliamentPerspective>('advocate');
  const [loading, setLoading] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<ParliamentAnalysisResult | null>(null);

  const chambers: Array<{
    id: ParliamentPerspective;
    title: string;
    roleDesc: string;
    icon: React.ComponentType<{ className?: string }>;
    accentColor: string;
  }> = [
    {
      id: 'advocate',
      title: 'Policyholder Max-Recovery Advocate',
      roleDesc: 'Aggressive recovery strategy, O&P 10/10 lock-in & code upgrades',
      icon: TrendingUp,
      accentColor: 'text-emerald-400',
    },
    {
      id: 'opposition',
      title: 'Insurer Adjuster / Defense Perspective',
      roleDesc: 'Anticipates wear-and-tear defenses, unit cost counters & scope cuts',
      icon: AlertTriangle,
      accentColor: 'text-rose-400',
    },
    {
      id: 'precedent',
      title: 'Coverage Precedent & Statutory Judge',
      roleDesc: 'Form HO-00-03 interpretation, burden of proof & matching laws',
      icon: Scale,
      accentColor: 'text-sky-400',
    },
    {
      id: 'forecaster',
      title: 'Forensic Payout Forecaster',
      roleDesc: 'Probabilistic settlement recovery matrix & appraisal timing',
      icon: DollarSign,
      accentColor: 'text-amber-400',
    },
    {
      id: 'recorder',
      title: 'Audit & Provenance Recorder',
      roleDesc: 'Deterministic facts, NOAA radar timestamps & PE affidavits',
      icon: ShieldCheck,
      accentColor: 'text-purple-400',
    },
    {
      id: 'settlement',
      title: 'Settlement Strategist',
      roleDesc: 'Leverage points, 60-day CRN bad faith notice & appraisal trigger',
      icon: Compass,
      accentColor: 'text-teal-400',
    },
  ];

  const fetchParliamentAnalysis = async (persp: ParliamentPerspective) => {
    setLoading(true);
    try {
      const res = await fetch('/api/parliament-projection', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          claim,
          perspective: persp,
        }),
      });
      const data = await res.json();
      setAnalysisResult(data);
    } catch (err) {
      console.error('Error in fetchParliamentAnalysis:', err);
    } finally {
      setLoading(false);
    }
  };

  React.useEffect(() => {
    fetchParliamentAnalysis(activePerspective);
  }, [activePerspective, claim.id]);

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Scale className="w-5 h-5 text-sky-400" />
            <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
              Parliament Strategic AI Chamber
            </h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Deterministic multi-perspective structural forecasts. Each chamber simulates a specific legal, forensic, or adjusting viewpoint to anticipate carrier pushback and secure the maximum payout.
          </p>
        </div>

        <button
          onClick={() => fetchParliamentAnalysis(activePerspective)}
          disabled={loading}
          className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold flex items-center gap-2 transition-all disabled:opacity-50"
        >
          <RefreshCw className={`w-3.5 h-3.5 text-sky-400 ${loading ? 'animate-spin' : ''}`} />
          <span>Re-project Chamber</span>
        </button>
      </div>

      {/* Chamber Selector Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {chambers.map((chamber) => {
          const Icon = chamber.icon;
          const isActive = activePerspective === chamber.id;
          return (
            <button
              key={chamber.id}
              onClick={() => setActivePerspective(chamber.id)}
              className={`p-3.5 rounded-xl border text-left transition-all space-y-1.5 ${
                isActive
                  ? 'bg-slate-900 border-sky-500/60 shadow-lg shadow-sky-500/10'
                  : 'bg-slate-900/60 border-slate-800 hover:border-slate-700 hover:bg-slate-900/80'
              }`}
            >
              <div className="flex items-center justify-between">
                <Icon className={`w-4 h-4 ${chamber.accentColor}`} />
                {isActive && (
                  <span className="text-[10px] uppercase font-mono px-1.5 py-0.2 rounded bg-sky-500/20 text-sky-300 border border-sky-500/40">
                    ACTIVE CHAMBER
                  </span>
                )}
              </div>
              <div className="font-bold text-xs text-white">{chamber.title}</div>
              <div className="text-[11px] text-slate-400 line-clamp-1">{chamber.roleDesc}</div>
            </button>
          );
        })}
      </div>

      {/* Chamber Forecast Output Card */}
      {loading ? (
        <div className="p-12 rounded-2xl bg-slate-900/90 border border-slate-800 flex flex-col items-center justify-center space-y-3">
          <RefreshCw className="w-8 h-8 text-sky-400 animate-spin" />
          <span className="text-xs text-slate-300 font-mono">
            Evaluating claim posture & epistemic vectors across {activePerspective.toUpperCase()} chamber...
          </span>
        </div>
      ) : analysisResult ? (
        <div className="rounded-2xl bg-slate-900/95 border border-slate-800 p-6 space-y-6 shadow-2xl">
          
          {/* Output Header */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
            <div>
              <div className="flex items-center gap-2">
                <span
                  className={`px-2.5 py-0.5 rounded text-xs font-mono font-bold ${
                    BRACKET_COLORS[analysisResult.coreFindingBracket || 'VALIDATED'].badgeBg
                  }`}
                >
                  {analysisResult.coreFindingBracket || 'VALIDATED'}
                </span>
                <span className="text-xs text-slate-400 font-mono">
                  Confidence: {analysisResult.confidenceScore || 94}%
                </span>
              </div>
              <h2 className="text-lg font-bold text-white tracking-tight mt-1">
                {analysisResult.title}
              </h2>
            </div>

            <div className="flex items-center gap-3 text-xs font-mono">
              <span className="px-2 py-1 rounded bg-slate-950 border border-slate-800 text-slate-300">
                Matter: {analysisResult.matterWeight_k66 || 45}%
              </span>
              <span className="px-2 py-1 rounded bg-slate-950 border border-slate-800 text-slate-300">
                Relation: {analysisResult.relationWeight_k90 || 35}%
              </span>
              <span className="px-2 py-1 rounded bg-slate-950 border border-slate-800 text-slate-300">
                Chronology: {analysisResult.chronologyWeight_k120 || 20}%
              </span>
            </div>
          </div>

          {/* Structural Forecast Statement */}
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
            <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider font-mono">
              Structural Epistemic Forecast
            </h3>
            <p className="text-sm text-slate-200 leading-relaxed font-sans">
              {analysisResult.structuralForecast}
            </p>
          </div>

          {/* 2-Column: Key Leverage Points & Vulnerabilities */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            
            {/* Key Leverage Points */}
            <div className="p-4 rounded-xl bg-emerald-950/20 border border-emerald-800/30 space-y-3">
              <h3 className="text-xs font-bold text-emerald-300 uppercase tracking-wider font-mono flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                Strategic Leverage Points
              </h3>
              <div className="space-y-2">
                {analysisResult.keyLeveragePoints?.map((pt, idx) => (
                  <div key={idx} className="text-xs text-slate-200 flex items-start gap-2">
                    <span className="text-emerald-400 font-bold">•</span>
                    <span>{pt}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Potential Vulnerabilities to Guard */}
            <div className="p-4 rounded-xl bg-amber-950/20 border border-amber-800/30 space-y-3">
              <h3 className="text-xs font-bold text-amber-300 uppercase tracking-wider font-mono flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                Potential Insurer Counter-Moves
              </h3>
              <div className="space-y-2">
                {analysisResult.vulnerabilities?.map((vuln, idx) => (
                  <div key={idx} className="text-xs text-slate-200 flex items-start gap-2">
                    <span className="text-amber-400 font-bold">•</span>
                    <span>{vuln}</span>
                  </div>
                ))}
              </div>
            </div>

          </div>

          {/* Recommended Tactical Action CTA */}
          <div className="p-4 rounded-xl bg-sky-950/30 border border-sky-800/40 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <span className="text-[10px] font-mono uppercase text-sky-400 font-bold">
                RECOMMENDED IMMEDIATE MOVE
              </span>
              <p className="text-xs text-slate-200 font-medium">
                {analysisResult.recommendedAction}
              </p>
            </div>
            <button
              onClick={() => onNavigateTab('legal_letters')}
              className="px-4 py-2 rounded-xl bg-sky-500 hover:bg-sky-400 text-white text-xs font-bold shadow-md shadow-sky-500/20 whitespace-nowrap transition-all"
            >
              Generate Supporting Letter
            </button>
          </div>

        </div>
      ) : null}

    </div>
  );
};
