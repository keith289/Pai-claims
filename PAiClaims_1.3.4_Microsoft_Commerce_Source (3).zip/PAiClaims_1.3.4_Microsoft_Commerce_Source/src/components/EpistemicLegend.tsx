import React from 'react';
import { BRACKET_COLORS } from '../utils/epistemicEngine';
import { EpistemicBracket } from '../types';

export const EpistemicLegend: React.FC<{ compact?: boolean }> = ({ compact = false }) => {
  const brackets: Array<{ key: EpistemicBracket; syntax: string; description: string }> = [
    { key: 'VALIDATED', syntax: '[[[claim]]]', description: 'Direct evidence with >= 2 independent provenance roots. Support strictly exceeds contradiction.' },
    { key: 'EXPLAINED', syntax: '{[claim]}', description: 'At least one structural / direct evidence root (licensed contractor bid, PE report, NOAA log).' },
    { key: 'SPECULATIVE', syntax: '[[claim]]', description: 'Adjuster opinion, hypothetical pre-existing wear, non-binding initial estimate, grammar break.' },
    { key: 'UNVERIFIED', syntax: '[{claim}]', description: 'Raw assertion without supporting provenance or corroborating documentation.' },
    { key: 'CONTRADICTED', syntax: '[!claim!@]', description: 'Direct factual or legal tension between insurer assertion and validated policyholder proof.' },
  ];

  if (compact) {
    return (
      <div className="flex flex-wrap items-center gap-2 text-xs">
        {brackets.map((b) => {
          const style = BRACKET_COLORS[b.key];
          return (
            <span
              key={b.key}
              className={`px-2 py-0.5 rounded font-mono text-[11px] border ${style.badgeBg}`}
              title={b.description}
            >
              {b.syntax} <span className="opacity-75 font-sans">({b.key})</span>
            </span>
          );
        })}
      </div>
    );
  }

  return (
    <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 text-slate-200">
      <div className="flex items-center justify-between mb-3">
        <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400 font-mono">
          PAi Epistemic Brackets & Trust Legend
        </h4>
        <span className="text-[11px] text-sky-400 font-mono">Klein Epistemology v2</span>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2.5">
        {brackets.map((b) => {
          const style = BRACKET_COLORS[b.key];
          return (
            <div
              key={b.key}
              className={`p-2.5 rounded-lg border ${style.border} ${style.bg} transition-all duration-200`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="font-mono text-xs font-bold text-white tracking-wide">
                  {b.syntax}
                </span>
                <span className={`text-[10px] uppercase font-mono px-1.5 py-0.5 rounded ${style.badgeBg}`}>
                  {b.key}
                </span>
              </div>
              <p className="text-[11px] text-slate-300 leading-tight mt-1">
                {b.description}
              </p>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export const EpistemicBracketBadge: React.FC<{ bracket: EpistemicBracket }> = ({ bracket }) => {
  const style = BRACKET_COLORS[bracket] || BRACKET_COLORS.UNVERIFIED;
  const syntaxMap: Record<EpistemicBracket, string> = {
    VALIDATED: '[[[VALIDATED]]]',
    EXPLAINED: '{[EXPLAINED]}',
    SPECULATIVE: '[[SPECULATIVE]]',
    UNVERIFIED: '[{UNVERIFIED}]',
    CONTRADICTED: '[!CONTRADICTED!]',
  };

  return (
    <span
      className={`px-2 py-0.5 rounded font-mono text-[10px] border font-bold ${style.badgeBg}`}
      title={`Epistemic reliability status: ${bracket}`}
    >
      {syntaxMap[bracket] || syntaxMap.UNVERIFIED}
    </span>
  );
};

