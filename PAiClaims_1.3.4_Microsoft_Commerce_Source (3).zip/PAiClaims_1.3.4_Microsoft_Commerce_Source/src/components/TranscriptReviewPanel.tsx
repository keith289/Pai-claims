import React from 'react';
import { AlertTriangle, Check, Eye, FileWarning, ShieldCheck } from 'lucide-react';
import type {
  ReconciliationResult,
  TranscriptDiscrepancy,
} from '../domain/transcriptReview.ts';
import { assessEstimationReadiness } from '../domain/transcriptReview.ts';

/**
 * Where the user settles what the readers could not.
 *
 * Two jobs, deliberately kept apart. Disputed words are shown with every
 * reading side by side so the user picks one against the document — the
 * software never highlights a "recommended" answer, because a nudge toward
 * one reading is the same as choosing it. Model transcriptions of images are
 * shown whole and confirmed before any figure may use them.
 */

interface Props {
  pages: ReconciliationResult[];
  onConfirmWord: (page: number, discrepancyId: string, value: string) => void;
  onVerifyPage: (page: number) => void;
  onOpenDocument?: (page: number) => void;
}

const SOURCE_LABEL: Record<string, string> = {
  'pdf-text': 'Document text layer',
  'tesseract-ocr': 'OCR',
  'vision-model': 'AI reading',
};

export const TranscriptReviewPanel: React.FC<Props> = ({
  pages,
  onConfirmWord,
  onVerifyPage,
  onOpenDocument,
}) => {
  const readiness = assessEstimationReadiness(pages);
  const awaiting = pages.filter((p) => p.requiresUserVerification);
  const disputed = pages.filter((p) => p.unresolved.length > 0);

  if (readiness.ready) {
    return (
      <div className="rounded-xl border border-emerald-600/40 bg-emerald-950/20 p-4">
        <div className="flex items-center gap-3">
          <ShieldCheck className="h-5 w-5 text-emerald-400" />
          <div className="text-sm">
            <div className="font-semibold text-emerald-200">
              Every page reads consistently.
            </div>
            <div className="text-xs text-emerald-100/70">
              {pages.length} page{pages.length === 1 ? '' : 's'} checked across{' '}
              {[...new Set(pages.flatMap((p) => p.sources))]
                .map((s) => SOURCE_LABEL[s as string] ?? String(s))
                .join(', ')}
              . Estimation can proceed.
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="rounded-xl border border-amber-600/40 bg-amber-950/25 p-4">
        <div className="flex items-start gap-3">
          <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-amber-400" />
          <div className="space-y-1.5 text-sm">
            <div className="font-semibold text-amber-200">
              Estimation is paused until the document is confirmed.
            </div>
            {readiness.reasons.map((reason, i) => (
              <p key={i} className="text-xs text-amber-100/80">
                {reason}
              </p>
            ))}
          </div>
        </div>
      </div>

      {disputed.map((page) => (
        <div key={`d-${page.page}`} className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-mono font-bold uppercase text-slate-400">
              Page {page.page} — {page.unresolved.length} word
              {page.unresolved.length === 1 ? '' : 's'} to confirm
            </span>
            {onOpenDocument && (
              <button
                onClick={() => onOpenDocument(page.page)}
                className="text-xs text-sky-400 hover:text-sky-300"
              >
                Open page {page.page}
              </button>
            )}
          </div>

          {page.unresolved.map((d: TranscriptDiscrepancy) => (
            <div
              key={d.id}
              className="rounded-lg border border-rose-500/40 bg-rose-950/20 p-3 space-y-2"
            >
              {d.numeric && (
                <div className="flex items-center gap-1.5 text-[11px] font-semibold text-rose-300">
                  <FileWarning className="h-3.5 w-3.5" />
                  This value contains digits
                </div>
              )}

              <div className="rounded bg-slate-950/70 px-3 py-2 font-mono text-xs text-slate-300">
                {d.context}
              </div>

              <div className="text-xs text-slate-400">{d.reason}</div>

              <div className="space-y-1.5">
                {d.readings.map((r, i) => (
                  <div key={i} className="flex items-center gap-2">
                    <button
                      onClick={() => onConfirmWord(page.page, d.id, r.value)}
                      className="flex items-center gap-1.5 rounded-md border border-slate-700 bg-slate-900 px-3 py-1.5 text-xs font-mono font-semibold text-slate-100 hover:border-emerald-500/60 hover:bg-emerald-500/10"
                    >
                      <Check className="h-3.5 w-3.5 text-emerald-400" />
                      {r.value || <span className="italic text-slate-500">(nothing)</span>}
                    </button>
                    <span className="text-[11px] text-slate-500">
                      {SOURCE_LABEL[r.source] ?? r.source}
                      {typeof r.confidence === 'number' &&
                        ` · ${(r.confidence * 100).toFixed(0)}% confidence`}
                    </span>
                  </div>
                ))}
              </div>

              <div className="text-[11px] text-amber-200">{d.userAction}</div>
            </div>
          ))}
        </div>
      ))}

      {awaiting.map((page) => (
        <div
          key={`v-${page.page}`}
          className="rounded-lg border border-sky-500/40 bg-sky-950/20 p-3 space-y-2"
        >
          <div className="flex items-center gap-2">
            <Eye className="h-4 w-4 text-sky-400" />
            <span className="text-sm font-semibold text-sky-100">
              Page {page.page} was transcribed from an image
            </span>
          </div>
          <p className="text-xs text-slate-400">
            No text could be extracted from this page, so a model read it. Nothing
            here has been checked against the document. Read it through before it
            is used in any figure — particularly the numbers.
          </p>
          <pre className="max-h-64 overflow-auto whitespace-pre-wrap rounded bg-slate-950/70 p-3 font-mono text-xs text-slate-300">
            {page.text || '(the model returned nothing for this page)'}
          </pre>
          <div className="flex items-center gap-2">
            <button
              onClick={() => onVerifyPage(page.page)}
              className="rounded-md border border-emerald-500/50 px-3 py-1.5 text-xs font-semibold text-emerald-200 hover:bg-emerald-500/10"
            >
              This matches the document
            </button>
            {onOpenDocument && (
              <button
                onClick={() => onOpenDocument(page.page)}
                className="rounded-md border border-slate-700 px-3 py-1.5 text-xs text-slate-300 hover:bg-slate-800"
              >
                Open the original
              </button>
            )}
          </div>
        </div>
      ))}
    </div>
  );
};
