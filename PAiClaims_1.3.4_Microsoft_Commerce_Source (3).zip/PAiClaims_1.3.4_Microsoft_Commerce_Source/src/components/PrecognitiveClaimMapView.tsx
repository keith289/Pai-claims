import React, { useMemo, useState } from 'react';
import { Activity, GitFork, History, Link2, ShieldCheck, WalletCards } from 'lucide-react';
import type { ClaimGraphNode, EpistemicBracket, InsuranceClaim, RPMChannel } from '../types';
import { BRACKET_COLORS, wrapBracket } from '../utils/epistemicEngine';
import { buildClaimGraph, graphStats } from '../domain/claimGraph';

interface PrecognitiveClaimMapViewProps {
  claim: InsuranceClaim;
}

type Zoom = 1 | 2 | 3;

const CHANNELS: Array<{ key: RPMChannel; label: string; short: string; description: string }> = [
  { key: 'matter_k66', label: 'Matter & Repair', short: 'A · k66', description: 'Damage, scope, quantities and reconstruction cost' },
  { key: 'relation_k90', label: 'Relation & Support', short: 'B · k90', description: 'Reasons, cause, policy, carrier positions and authority' },
  { key: 'chronology_k120', label: 'Chronology & Payment', short: 'C · k120', description: 'Audit history, offers, approvals and actual payment' },
];

const stageLabel: Record<EpistemicBracket, string> = {
  UNVERIFIED: 'RAW',
  SPECULATIVE: 'PROVISIONAL',
  EXPLAINED: 'CORROBORATED',
  VALIDATED: 'PROVEN',
  CONTRADICTED: 'CONTRADICTED',
};

const visibleAtZoom = (node: ClaimGraphNode, zoom: Zoom) => {
  if (zoom === 3) return true;
  if (zoom === 2) return !['location', 'other'].includes(node.kind);
  return ['damage', 'price', 'carrier_position', 'payment', 'policy', 'authority', 'timeline'].includes(node.kind);
};

const amountText = (node: ClaimGraphNode) => typeof node.amount === 'number' ? `$${node.amount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : null;

export const PrecognitiveClaimMapView: React.FC<PrecognitiveClaimMapViewProps> = ({ claim }) => {
  const [zoomLevel, setZoomLevel] = useState<Zoom>(2);
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);

  const graph = useMemo(() => claim.claimGraph || buildClaimGraph(claim, claim.auditTrail[0]?.timestamp || claim.dateReported || claim.dateOfLoss), [claim]);
  const stats = useMemo(() => graphStats(graph), [graph]);
  const selectedNode = graph.nodes.find((node) => node.id === selectedNodeId) || null;
  const selectedEdges = selectedNode ? graph.edges.filter((edge) => edge.fromNodeId === selectedNode.id || edge.toNodeId === selectedNode.id) : [];

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      <section className="rounded-2xl border border-sky-500/30 bg-gradient-to-br from-slate-900 via-[#0d1626] to-slate-950 p-5 sm:p-6">
        <div className="flex flex-col xl:flex-row xl:items-end justify-between gap-5">
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-sky-400">
              <GitFork className="w-5 h-5" />
              <span className="text-[11px] font-mono uppercase tracking-[0.2em]">Live bracket graph</span>
            </div>
            <h1 className="text-2xl font-bold text-white">Precognitive Claim Map</h1>
            <p className="text-sm text-slate-300 max-w-3xl leading-relaxed">
              The map is built from the claim's atomic propositions. Damage, quantities, prices, reasons, labor, equipment, carrier positions and payments mature independently as new evidence arrives.
            </p>
          </div>
          <div className="flex items-center gap-1 p-1 rounded-xl bg-slate-950/80 border border-slate-800 text-xs font-mono">
            {([1, 2, 3] as Zoom[]).map((level) => (
              <button key={level} onClick={() => setZoomLevel(level)} className={`px-3 py-2 rounded-lg transition ${zoomLevel === level ? 'bg-sky-500 text-white font-bold' : 'text-slate-400 hover:text-white'}`}>
                {level === 1 ? 'L1 Case' : level === 2 ? 'L2 Claims' : 'L3 Atoms'}
              </button>
            ))}
          </div>
        </div>
      </section>

      <section className="grid grid-cols-2 md:grid-cols-5 gap-3">
        {[
          ['Nodes', stats.nodeCount, 'text-white'],
          ['Provisional', stats.counts.SPECULATIVE, 'text-purple-300'],
          ['Corroborated', stats.counts.EXPLAINED, 'text-amber-300'],
          ['Proven', stats.counts.VALIDATED, 'text-emerald-300'],
          ['Contradicted', stats.counts.CONTRADICTED, 'text-rose-300'],
        ].map(([label, value, color]) => (
          <div key={String(label)} className="rounded-xl border border-slate-800 bg-slate-900/70 p-3">
            <div className="text-[10px] uppercase tracking-wider text-slate-500">{label}</div>
            <div className={`text-xl font-semibold tabular-nums mt-1 ${color}`}>{value}</div>
          </div>
        ))}
      </section>

      <div className="grid grid-cols-1 xl:grid-cols-[1fr_22rem] gap-5">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {CHANNELS.map((channel) => {
            const channelNodes = graph.nodes.filter((node) => node.channel === channel.key && visibleAtZoom(node, zoomLevel));
            return (
              <section key={channel.key} className="rounded-2xl border border-slate-800 bg-slate-900/70 overflow-hidden min-h-[28rem]">
                <header className="p-4 border-b border-slate-800 bg-slate-950/50">
                  <div className="flex items-center justify-between gap-3">
                    <div>
                      <div className="text-xs font-bold text-white uppercase tracking-wider">{channel.label}</div>
                      <div className="text-[10px] text-slate-500 mt-1">{channel.description}</div>
                    </div>
                    <span className="text-[10px] font-mono rounded-md border border-slate-700 px-2 py-1 text-sky-300">{channel.short}</span>
                  </div>
                </header>
                <div className="p-3 space-y-2 max-h-[60rem] overflow-auto">
                  {channelNodes.length === 0 && <div className="p-6 text-center text-xs text-slate-500">No live propositions in this channel yet.</div>}
                  {channelNodes.map((node) => {
                    const style = BRACKET_COLORS[node.bracket];
                    const selected = selectedNodeId === node.id;
                    return (
                      <button
                        type="button"
                        key={node.id}
                        onClick={() => setSelectedNodeId(node.id)}
                        className={`w-full text-left rounded-xl border p-3 transition ${selected ? 'border-sky-400 bg-slate-950 shadow-lg shadow-sky-950/30' : `${style.border} bg-slate-950/70 hover:bg-slate-950`}`}
                      >
                        <div className="flex items-start justify-between gap-2">
                          <span className={`px-1.5 py-0.5 rounded text-[9px] font-mono font-bold ${style.badgeBg}`}>{stageLabel[node.bracket]}</span>
                          {amountText(node) && <span className="text-xs font-mono font-bold text-white">{amountText(node)}</span>}
                        </div>
                        <div className={`mt-2 text-xs leading-relaxed ${style.text}`}>{wrapBracket(node.statement, node.bracket)}</div>
                        <div className="mt-2 pt-2 border-t border-slate-900 flex items-center justify-between gap-2 text-[9px] text-slate-500 font-mono">
                          <span>{node.kind.replaceAll('_', ' ')}</span>
                          <span>{node.provenanceRoots.length} root{node.provenanceRoots.length === 1 ? '' : 's'}</span>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </section>
            );
          })}
        </div>

        <aside className="rounded-2xl border border-slate-800 bg-slate-900/80 h-fit xl:sticky xl:top-4 overflow-hidden">
          {!selectedNode ? (
            <div className="p-7 text-center">
              <Activity className="w-8 h-8 text-slate-600 mx-auto mb-3" />
              <div className="text-sm font-semibold text-white">Select a proposition</div>
              <p className="text-xs text-slate-500 mt-2 leading-relaxed">Every node carries its own bracket, reason, provenance and promotion history.</p>
            </div>
          ) : (
            <div>
              <div className="p-4 border-b border-slate-800">
                <div className="flex items-center justify-between gap-2">
                  <span className={`px-2 py-1 rounded text-[10px] font-mono font-bold ${BRACKET_COLORS[selectedNode.bracket].badgeBg}`}>{stageLabel[selectedNode.bracket]}</span>
                  {amountText(selectedNode) && <span className="font-mono font-bold text-white">{amountText(selectedNode)}</span>}
                </div>
                <h2 className="text-sm font-semibold text-white mt-3 leading-relaxed">{selectedNode.statement}</h2>
              </div>

              <div className="p-4 space-y-5 text-xs">
                <div>
                  <div className="flex items-center gap-2 text-slate-300 font-semibold"><ShieldCheck className="w-3.5 h-3.5 text-amber-400" /> Bracketed reason</div>
                  <div className="mt-2 rounded-lg border border-slate-800 bg-slate-950/60 p-3 text-slate-400 leading-relaxed">{wrapBracket(selectedNode.reason, selectedNode.bracket)}</div>
                </div>

                <div>
                  <div className="flex items-center gap-2 text-slate-300 font-semibold"><Link2 className="w-3.5 h-3.5 text-sky-400" /> Provenance</div>
                  <div className="mt-2 space-y-1 text-[11px] text-slate-500">
                    {selectedNode.provenanceRoots.length ? selectedNode.provenanceRoots.map((root) => <div key={root}>• {root}</div>) : <div>• Provisional/model source only</div>}
                    {selectedNode.sourceEvidenceIds.map((id) => <div key={id} className="font-mono">evidence: {id}</div>)}
                  </div>
                </div>

                <div>
                  <div className="flex items-center gap-2 text-slate-300 font-semibold"><GitFork className="w-3.5 h-3.5 text-purple-400" /> Relationships</div>
                  <div className="mt-2 space-y-1.5">
                    {selectedEdges.length === 0 && <div className="text-slate-500">No mapped edges yet.</div>}
                    {selectedEdges.slice(0, 12).map((edge) => {
                      const otherId = edge.fromNodeId === selectedNode.id ? edge.toNodeId : edge.fromNodeId;
                      const other = graph.nodes.find((node) => node.id === otherId);
                      return <button key={edge.id} onClick={() => setSelectedNodeId(otherId)} className="w-full text-left rounded-lg border border-slate-800 bg-slate-950/50 p-2 hover:border-slate-700"><div className="text-[9px] uppercase tracking-wider text-sky-400">{edge.kind.replaceAll('_', ' ')}</div><div className="text-[11px] text-slate-400 mt-1 line-clamp-2">{other?.statement || otherId}</div></button>;
                    })}
                  </div>
                </div>

                <div>
                  <div className="flex items-center gap-2 text-slate-300 font-semibold"><History className="w-3.5 h-3.5 text-emerald-400" /> Promotion history</div>
                  <div className="mt-2 space-y-2">
                    {[...selectedNode.history].reverse().map((event) => (
                      <div key={event.id} className="rounded-lg border border-slate-800 bg-slate-950/50 p-2.5">
                        <div className="flex items-center justify-between gap-2"><span className="text-[10px] uppercase tracking-wider text-slate-300">{event.action}</span><span className="text-[9px] font-mono text-slate-600">{event.at?.slice(0, 10)}</span></div>
                        <div className="text-[11px] text-slate-500 mt-1 leading-relaxed">{event.reason}</div>
                        {event.fromBracket && <div className="text-[9px] font-mono text-slate-600 mt-1">{event.fromBracket} → {event.toBracket}</div>}
                      </div>
                    ))}
                  </div>
                </div>

                {selectedNode.kind === 'payment' && <div className="rounded-xl border border-emerald-700/40 bg-emerald-950/20 p-3 flex gap-2"><WalletCards className="w-4 h-4 text-emerald-400 shrink-0" /><div className="text-[11px] text-emerald-200">Actual payment is a direct monetary event. It validates the payment proposition itself; it does not silently validate unrelated scope facts.</div></div>}
              </div>
            </div>
          )}
        </aside>
      </div>
    </div>
  );
};
