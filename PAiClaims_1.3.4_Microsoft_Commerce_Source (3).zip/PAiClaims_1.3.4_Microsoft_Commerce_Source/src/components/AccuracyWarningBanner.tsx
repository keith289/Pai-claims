import React from 'react';
import { AlertTriangle } from 'lucide-react';
import type { InsuranceClaim } from '../types';
import { assessCompleteness } from '../domain/policyRecord.ts';

/**
 * Persistent accuracy warning.
 *
 * Shows on every tab for as long as the case is missing information that the
 * numbers depend on. It does not block anything — it states plainly which
 * inputs were never supplied and what that costs the figures on screen.
 *
 * This must stay visible rather than being dismissible: a user who dismissed
 * it on day one would otherwise export a demand figure weeks later with no
 * indication that it rests on unsupplied inputs.
 */

interface Props {
  claim: InsuranceClaim | null;
  onSupplyPolicy?: () => void;
  /** Called when the user confirms one of the candidate values against the document. */
  onResolveConflict?: (conflictId: string, value: string) => void;
}

const LABELS: Record<string, string> = {
  dwelling_covA: 'Coverage A dwelling limit',
  otherStructures_covB: 'Coverage B other structures',
  personalProperty_covC: 'Coverage C personal property',
  lossOfUse_covD: 'Coverage D loss of use',
  ordinanceAndLaw_percent: 'ordinance & law percentage',
  ordinanceAndLaw_amount: 'ordinance & law allowance',
  moldRemediationLimit: 'mold remediation limit',
  debrisRemovalPercent: 'debris removal allowance',
  deductible: 'deductible',
  deductibleType: 'deductible basis (flat or percentage)',
  settlementBasis: 'settlement basis (RCV or ACV)',
  policyPeriodStart: 'policy period start',
  policyPeriodEnd: 'policy period end',
  suitLimitationMonths: 'suit limitation period',
  proofOfLossDays: 'proof of loss deadline',
};

export const AccuracyWarningBanner: React.FC<Props> = ({
  claim,
  onSupplyPolicy,
  onResolveConflict,
}) => {
  if (!claim) return null;

  const intakeGaps = claim.intakeGaps ?? [];
  const policy = claim.policyRecord ? assessCompleteness(claim.policyRecord) : null;
  const unreadTerms = policy?.unreadTerms ?? [];
  const missingForms = policy?.missingForms ?? [];
  const conflicts = policy?.conflicts ?? [];
  const unresolved = policy?.unresolvedConflicts ?? [];

  if (
    intakeGaps.length === 0 &&
    unreadTerms.length === 0 &&
    missingForms.length === 0 &&
    conflicts.length === 0
  ) {
    return null;
  }

  const termList = unreadTerms.map((t) => LABELS[t] ?? t);

  return (
    <div className="mb-5 rounded-xl border border-amber-500/40 bg-amber-950/30 p-4">
      <div className="flex items-start gap-3">
        <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-amber-400" />
        <div className="space-y-2 text-sm">
          <p className="font-semibold text-amber-200">
            Figures on this case are affected by missing information.
          </p>

          {intakeGaps.length > 0 && (
            <p className="text-amber-100/80">
              <span className="font-medium">Not entered at intake:</span>{' '}
              {intakeGaps.join(', ')}. Any total that depends on these is
              incomplete rather than low.
            </p>
          )}

          {termList.length > 0 && (
            <p className="text-amber-100/80">
              <span className="font-medium">Not read from a policy document:</span>{' '}
              {termList.join(', ')}. Coverage boundary checks against these terms
              cannot be run, and the recovery gap is uncapped where a limit would
              normally apply.
            </p>
          )}

          {missingForms.length > 0 && (
            <p className="text-amber-100/80">
              <span className="font-medium">
                Listed on the declarations page but not supplied:
              </span>{' '}
              {missingForms.join(', ')}. The governing language in these forms is
              unread.
            </p>
          )}

          {unresolved.length > 0 && (
            <div className="space-y-2 pt-1">
              <p className="text-rose-200 font-medium">
                {unresolved.length === 1
                  ? 'A value was read two different ways and the document does not settle which is right.'
                  : `${unresolved.length} values were read two different ways and the document does not settle which is right.`}
              </p>
              {unresolved.map((c) => (
                <div
                  key={c.id}
                  className="rounded-lg border border-rose-500/40 bg-rose-950/25 p-3 space-y-1.5"
                >
                  <div className="text-sm font-semibold text-rose-100">
                    {c.label}
                    {c.page != null && (
                      <span className="text-rose-300/70 font-normal"> — page {c.page}</span>
                    )}
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {c.candidates.map((cand, i) => (
                      <span
                        key={i}
                        className="rounded-md border border-slate-700 bg-slate-950/70 px-2 py-1 text-xs text-slate-200"
                      >
                        <span className="font-mono font-semibold">{cand.value}</span>
                        <span className="text-slate-500"> · {cand.method}</span>
                        {typeof cand.confidence === 'number' && (
                          <span className="text-slate-500">
                            {' '}
                            {(cand.confidence * 100).toFixed(0)}%
                          </span>
                        )}
                      </span>
                    ))}
                  </div>
                  <div className="text-xs text-slate-400">{c.reason}</div>
                  <div className="text-xs text-amber-200">{c.userAction}</div>
                  {onResolveConflict && (
                    <div className="flex flex-wrap gap-2 pt-1">
                      {c.candidates.map((cand, i) => (
                        <button
                          key={i}
                          onClick={() => onResolveConflict(c.id, cand.value)}
                          className="rounded-md border border-emerald-500/50 px-2.5 py-1 text-xs font-semibold text-emerald-200 hover:bg-emerald-500/10"
                        >
                          Confirm {cand.value}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}

          {conflicts.length > unresolved.length && (
            <p className="text-rose-200">
              <span className="font-medium">Conflicting values also recorded for:</span>{' '}
              {conflicts
                .filter((c) => !unresolved.some((u) => (u.term ?? u.label) === c))
                .map((c) => LABELS[c] ?? c)
                .join(', ')}
              .
            </p>
          )}

          {onSupplyPolicy && (
            <button
              onClick={onSupplyPolicy}
              className="mt-1 rounded-lg border border-amber-500/50 px-3 py-1.5 text-xs font-semibold text-amber-200 hover:bg-amber-500/10"
            >
              Supply the missing information
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
