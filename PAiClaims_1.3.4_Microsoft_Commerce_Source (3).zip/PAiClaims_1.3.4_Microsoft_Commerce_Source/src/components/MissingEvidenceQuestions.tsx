import React, { useState } from 'react';
import {
  HelpCircle,
  AlertTriangle,
  CheckCircle2,
  Upload,
  Camera,
  FileText,
  ShieldAlert,
  ArrowRight,
  Sparkles,
  Info,
  Layers,
  ChevronDown,
  ChevronUp,
  MessageSquare,
  Scale,
  Plus,
} from 'lucide-react';
import {
  CaseCompletenessAudit,
  MissingEvidenceChecklistItem,
  ProactiveQuestionItem,
  InsuranceClaim,
} from '../types';

interface MissingEvidenceQuestionsProps {
  claim: InsuranceClaim;
  audit: CaseCompletenessAudit | null;
  onResolveItem: (itemId: string, userResponse: string) => void;
  onAnswerQuestion: (questionId: string, answerValue: string) => void;
  onOpenUploadModal: (suggestedType?: string) => void;
  onOpenPhotoUploadModal: (suggestedCategory?: string) => void;
}

export const MissingEvidenceQuestions: React.FC<MissingEvidenceQuestionsProps> = ({
  claim,
  audit,
  onResolveItem,
  onAnswerQuestion,
  onOpenUploadModal,
  onOpenPhotoUploadModal,
}) => {
  const [selectedPillar, setSelectedPillar] = useState<string>('all');
  const [expandedGapId, setExpandedGapId] = useState<string | null>(
    audit?.missingChecklist?.[0]?.id || null
  );

  const pillars = audit?.pillars || [];
  const missingChecklist = audit?.missingChecklist || [];
  const proactiveQuestions = audit?.proactiveQuestions || [];

  const filteredChecklist = missingChecklist.filter((item) => {
    if (selectedPillar === 'all') return true;
    return item.category.toLowerCase().includes(selectedPillar.toLowerCase());
  });

  const getUrgencyBadge = (urgency: MissingEvidenceChecklistItem['urgency']) => {
    switch (urgency) {
      case 'critical':
        return 'bg-rose-500/20 text-rose-300 border-rose-500/40';
      case 'high':
        return 'bg-amber-500/20 text-amber-300 border-amber-500/40';
      case 'medium':
      default:
        return 'bg-sky-500/20 text-sky-300 border-sky-500/40';
    }
  };

  return (
    <div className="space-y-6">
      
      {/* 1. Evidentiary Pillars Grid */}
      <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-5 space-y-4 shadow-lg">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-sky-400" />
            <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
              7 Core Evidentiary Pillars
            </h3>
          </div>
          <span className="text-xs text-slate-400 font-mono">
            Click pillar to filter missing items
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {pillars.map((pillar) => {
            const isSelected = selectedPillar === pillar.name;
            const isComplete = pillar.status === 'complete';
            const isPartial = pillar.status === 'partial';

            return (
              <button
                key={pillar.name}
                onClick={() => setSelectedPillar(isSelected ? 'all' : pillar.name)}
                className={`p-3 rounded-xl border text-left transition-all ${
                  isSelected
                    ? 'bg-sky-500/15 border-sky-500/50 shadow-md shadow-sky-500/10'
                    : 'bg-slate-950/60 border-slate-800/80 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between gap-1 mb-1.5">
                  <span
                    className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                      isComplete
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                        : isPartial
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                        : 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                    }`}
                  >
                    {isComplete ? '100% Solid' : isPartial ? 'Partial Proof' : 'Missing Proof'}
                  </span>
                  <span className="text-xs font-mono font-bold text-white">
                    {pillar.score}%
                  </span>
                </div>

                <div className="text-xs font-semibold text-slate-200 line-clamp-1">
                  {pillar.name}
                </div>

                {/* Mini progress bar */}
                <div className="w-full h-1.5 bg-slate-800 rounded-full mt-2 overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-500 ${
                      isComplete
                        ? 'bg-emerald-400'
                        : isPartial
                        ? 'bg-amber-400'
                        : 'bg-rose-500'
                    }`}
                    style={{ width: `${pillar.score}%` }}
                  />
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* 2. Interactive AI Investigator: "Ask If Anything Is Missing" Questions */}
      {proactiveQuestions.length > 0 && (
        <div className="rounded-2xl bg-gradient-to-br from-indigo-950/40 via-slate-900 to-slate-900 border border-indigo-500/30 p-5 space-y-4 shadow-xl relative overflow-hidden">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-indigo-500/20 border border-indigo-500/40 text-indigo-300">
              <MessageSquare className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white tracking-tight flex items-center gap-2">
                <span>AI Case Investigator: Direct Inquiries</span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-mono bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                  Live Strategy Audit
                </span>
              </h3>
              <p className="text-xs text-slate-300/80 mt-0.5">
                Answer these questions to automatically update your case strength and discover missing claim leverage:
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-1">
            {proactiveQuestions.map((q) => (
              <div
                key={q.id}
                className="p-4 rounded-xl bg-slate-950/80 border border-indigo-500/20 flex flex-col justify-between space-y-3"
              >
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between text-[10px] font-mono">
                    <span className="text-indigo-300 font-semibold uppercase">{q.pillar}</span>
                    <span className="text-emerald-400 font-bold">{q.impactOnSettlement}</span>
                  </div>
                  <h4 className="text-xs font-bold text-white leading-snug">
                    {q.question}
                  </h4>
                  <p className="text-[11px] text-slate-400 line-clamp-3">
                    {q.context}
                  </p>
                </div>

                <div className="space-y-1.5 pt-2 border-t border-slate-800/80">
                  {q.options.map((opt) => {
                    const isSelected = q.selectedAnswer === opt.value;
                    return (
                      <button
                        key={opt.value}
                        onClick={() => onAnswerQuestion(q.id, opt.value)}
                        className={`w-full text-left px-2.5 py-2 rounded-lg text-xs transition-all flex items-center justify-between gap-2 ${
                          isSelected
                            ? 'bg-indigo-500/30 text-indigo-100 border border-indigo-400 font-semibold shadow-sm'
                            : 'bg-slate-900/90 text-slate-300 hover:bg-slate-800 hover:text-white border border-slate-800'
                        }`}
                      >
                        <span className="text-[11px] leading-tight line-clamp-2">{opt.label}</span>
                        {isSelected && <CheckCircle2 className="w-3.5 h-3.5 text-indigo-400 shrink-0" />}
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 3. Detailed Missing Items Forensic Checklist */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-amber-400" />
            <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
              Missing Proof & Forensic Vulnerability Checklist ({filteredChecklist.length})
            </h3>
          </div>
          {selectedPillar !== 'all' && (
            <button
              onClick={() => setSelectedPillar('all')}
              className="text-xs text-sky-400 hover:underline font-mono"
            >
              Reset Filter
            </button>
          )}
        </div>

        <div className="space-y-3">
          {filteredChecklist.map((gap) => {
            const isExpanded = expandedGapId === gap.id;
            const isResolved = gap.isResolved;

            return (
              <div
                key={gap.id}
                className={`rounded-xl border transition-all overflow-hidden ${
                  isResolved
                    ? 'bg-slate-950/50 border-emerald-500/30 opacity-75'
                    : isExpanded
                    ? 'bg-slate-900 border-sky-500/60 shadow-lg shadow-sky-500/10'
                    : 'bg-slate-900/70 border-slate-800 hover:border-slate-700'
                }`}
              >
                {/* Item Row Header */}
                <div
                  onClick={() => setExpandedGapId(isExpanded ? null : gap.id)}
                  className="p-4 cursor-pointer flex items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div
                      className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 ${
                        isResolved
                          ? 'bg-emerald-500/20 text-emerald-400'
                          : gap.urgency === 'critical'
                          ? 'bg-rose-500/20 text-rose-400'
                          : 'bg-amber-500/20 text-amber-400'
                      }`}
                    >
                      {isResolved ? (
                        <CheckCircle2 className="w-4 h-4" />
                      ) : (
                        <AlertTriangle className="w-4 h-4" />
                      )}
                    </div>

                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold border ${getUrgencyBadge(
                            gap.urgency
                          )}`}
                        >
                          {gap.urgency.toUpperCase()}
                        </span>
                        <span className="text-[11px] font-mono text-slate-400">
                          {gap.category}
                        </span>
                        {isResolved && (
                          <span className="text-[11px] font-semibold text-emerald-400 flex items-center gap-1">
                            • Proof Attached / Resolved
                          </span>
                        )}
                      </div>
                      <h4 className="text-xs sm:text-sm font-bold text-white truncate mt-0.5">
                        {gap.itemTitle}
                      </h4>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    {isExpanded ? (
                      <ChevronUp className="w-4 h-4 text-slate-400" />
                    ) : (
                      <ChevronDown className="w-4 h-4 text-slate-400" />
                    )}
                  </div>
                </div>

                {/* Expanded Inspection & Action Pane */}
                {isExpanded && (
                  <div className="px-4 pb-4 pt-1 border-t border-slate-800/80 space-y-4 bg-slate-950/40">
                    
                    {/* The Prompt Question Asked to the User */}
                    <div className="p-3.5 rounded-xl bg-sky-950/30 border border-sky-500/30 flex items-start gap-3">
                      <HelpCircle className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
                      <div className="space-y-1">
                        <div className="text-[10px] uppercase font-mono font-bold text-sky-300">
                          Forensic Auditor Inquiry
                        </div>
                        <div className="text-xs font-semibold text-slate-100">
                          {gap.questionPrompt}
                        </div>
                      </div>
                    </div>

                    {/* Forensic Details Grid */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                      <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
                        <div className="text-[10px] uppercase font-mono font-bold text-emerald-400 flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3" />
                          <span>Why This Item Wins The Claim</span>
                        </div>
                        <p className="text-slate-300 text-[11px] leading-relaxed">
                          {gap.whyNeeded}
                        </p>
                      </div>

                      <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
                        <div className="text-[10px] uppercase font-mono font-bold text-rose-400 flex items-center gap-1">
                          <ShieldAlert className="w-3 h-3" />
                          <span>Carrier Defense / Trap To Avoid</span>
                        </div>
                        <p className="text-slate-300 text-[11px] leading-relaxed">
                          {gap.carrierTrapToAvoid}
                        </p>
                      </div>
                    </div>

                    {/* Quick Answers & Action Buttons */}
                    <div className="pt-2 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                      <div className="flex items-center gap-2 flex-wrap">
                        {gap.quickAnswers.map((ans, idx) => (
                          <button
                            key={idx}
                            onClick={() => onResolveItem(gap.id, ans)}
                            className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-700 transition-colors"
                          >
                            {ans}
                          </button>
                        ))}
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        {gap.actionType === 'upload_photo' && (
                          <button
                            onClick={() => onOpenPhotoUploadModal(gap.category)}
                            className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center gap-1.5 shadow-sm transition-all"
                          >
                            <Camera className="w-3.5 h-3.5" />
                            <span>Upload Damage Photo</span>
                          </button>
                        )}

                        {gap.actionType === 'upload_doc' && (
                          <button
                            onClick={() => onOpenUploadModal(gap.category)}
                            className="px-3 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold flex items-center gap-1.5 shadow-sm transition-all"
                          >
                            <FileText className="w-3.5 h-3.5" />
                            <span>Upload Document</span>
                          </button>
                        )}

                        {!isResolved && (
                          <button
                            onClick={() => onResolveItem(gap.id, 'Manually Verified by User')}
                            className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-emerald-400 text-xs font-semibold border border-slate-700 transition-all flex items-center gap-1"
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>Mark Resolved</span>
                          </button>
                        )}
                      </div>
                    </div>

                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

    </div>
  );
};
