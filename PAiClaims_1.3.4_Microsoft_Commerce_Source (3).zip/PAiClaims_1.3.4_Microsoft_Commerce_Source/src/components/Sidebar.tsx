import React from 'react';
import {
  LayoutDashboard,
  FileSearch,
  FolderArchive,
  GitFork,
  DollarSign,
  Scale,
  FileText,
  Clock,
  ChevronRight,
  TrendingUp,
  AlertTriangle,
  Cpu,
  Calculator,
} from 'lucide-react';
import { InsuranceClaim, TabType } from '../types';
export type { TabType };

interface SidebarProps {
  activeTab: TabType;
  onTabChange: (tab: TabType) => void;
  activeClaim: InsuranceClaim;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onTabChange,
  activeClaim,
}) => {
  const menuItems: Array<{
    id: TabType;
    label: string;
    description: string;
    icon: React.ComponentType<{ className?: string }>;
    badge?: string;
    badgeColor?: string;
  }> = [
    {
      id: 'dashboard',
      label: 'Claim Dashboard',
      description: 'Recovery gap, telemetry & health',
      icon: LayoutDashboard,
    },
    {
      id: 'psi_estimator',
      label: 'PSi Estimators',
      description: 'Deterministic local reconstruction cost',
      icon: Calculator,
      badge: 'AI OFF',
      badgeColor: 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30',
    },
    {
      id: 'xactimate_optimizer',
      label: 'Xactimate Itemizer',
      description: 'Carrier scope audit & missing items',
      icon: FileSearch,
      badge: 'AI Itemizer',
      badgeColor: 'bg-sky-500/20 text-sky-300 border border-sky-500/40',
    },
    {
      id: 'payout_optimizer',
      label: 'Max Payout Optimizer',
      description: 'Line items, O&P 10/10 & Code rules',
      icon: DollarSign,
      badge: `+$${((activeClaim.auditedTrueValuation?.totalRecoveryGap || 0) / 1000).toFixed(0)}k`,
      badgeColor: 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40',
    },
    {
      id: 'evidence',
      label: 'Evidence Vault & Photos',
      description: 'Docs, photos & AI gap investigator',
      icon: FolderArchive,
      badge: `${(activeClaim.evidence?.length || 0) + (activeClaim.photos?.length || 0)} loaded`,
      badgeColor: 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/40',
    },
    {
      id: 'precognitive_map',
      label: 'Precognitive Claim Map',
      description: 'Klein A/B/C transition topology',
      icon: GitFork,
    },
    {
      id: 'parliament',
      label: 'Parliament Strategy AI',
      description: '6 Deterministic claim projections',
      icon: Scale,
    },
    {
      id: 'legal_letters',
      label: 'Dispute Letters Studio',
      description: 'Demand, Rebuttal & Appraisal',
      icon: FileText,
    },
    {
      id: 'timeline',
      label: 'Statutory Deadlines',
      description: 'Prompt pay & Bad faith countdowns',
      icon: Clock,
      badge: `${activeClaim.statutoryDeadlines?.filter((d) => d.status === 'critical_pending').length || 0} urgent`,
    },
    {
      id: 'ai_setup',
      label: 'AI Setup',
      description: 'Private on-device model or API key',
      icon: Cpu,
    },
  ];

  return (
    <aside className="w-full lg:w-64 bg-[#0a0d14] border-r border-slate-800/80 flex flex-col shrink-0 p-3">
      {/* Active Claim Snapshot Card */}
      <div className="p-3 mb-3 rounded-xl bg-slate-900/80 border border-slate-800 text-xs space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-[10px] uppercase font-mono text-slate-400">Carrier Target</span>
          <span className="px-1.5 py-0.5 rounded text-[10px] font-mono bg-rose-950/60 text-rose-300 border border-rose-800/60">
            {activeClaim.status.replace('_', ' ').toUpperCase()}
          </span>
        </div>
        <div>
          <div className="text-slate-200 font-semibold truncate">{activeClaim.carrierName}</div>
          <div className="text-[11px] text-slate-400 font-mono">Claim #{activeClaim.claimNumber}</div>
        </div>
        <div className="pt-2 border-t border-slate-800 flex items-center justify-between">
          <div>
            <div className="text-[10px] text-slate-400">Recovery Gap</div>
            <div className="text-sm font-bold text-emerald-400 font-mono">
              +${(activeClaim.auditedTrueValuation?.totalRecoveryGap || 0).toLocaleString()}
            </div>
          </div>
          <div className="text-right">
            <div className="text-[10px] text-slate-400">Initial Paid</div>
            <div className="text-xs font-semibold text-slate-300 font-mono">
              ${(activeClaim.carrierOffer?.netCarrierCheckIssued || 0).toLocaleString()}
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Menu */}
      <nav className="space-y-1 flex-1">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onTabChange(item.id)}
              className={`w-full text-left px-3 py-2.5 rounded-xl text-xs transition-all flex items-center justify-between group ${
                isActive
                  ? 'bg-sky-500/15 text-white border border-sky-500/40 shadow-sm shadow-sky-500/10 font-medium'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60 border border-transparent'
              }`}
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <Icon
                  className={`w-4 h-4 shrink-0 transition-colors ${
                    isActive ? 'text-sky-400' : 'text-slate-500 group-hover:text-slate-300'
                  }`}
                />
                <div className="truncate">
                  <div className={`truncate ${isActive ? 'text-white font-semibold' : 'text-slate-200'}`}>
                    {item.label}
                  </div>
                  <div className="text-[10px] text-slate-500 truncate hidden xl:block">
                    {item.description}
                  </div>
                </div>
              </div>

              {item.badge ? (
                <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded ${item.badgeColor}`}>
                  {item.badge}
                </span>
              ) : (
                <ChevronRight
                  className={`w-3.5 h-3.5 opacity-0 group-hover:opacity-100 transition-opacity ${
                    isActive ? 'opacity-100 text-sky-400' : 'text-slate-600'
                  }`}
                />
              )}
            </button>
          );
        })}
      </nav>

      {/* Epistemic Trust Lock Status */}
      <div className="mt-auto pt-3 border-t border-slate-800/80">
        <div className="p-2.5 rounded-lg bg-emerald-950/20 border border-emerald-800/30 text-[11px] text-emerald-200/90 flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-emerald-400 shrink-0" />
          <div className="truncate">
            <span className="font-semibold">Trust Lock:</span> Validated Mass (5 Roots)
          </div>
        </div>
      </div>
    </aside>
  );
};
