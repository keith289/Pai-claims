import React, { useState } from 'react';
import {
  FileSearch,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  TrendingUp,
  Shield,
  FileSpreadsheet,
  UploadCloud,
  Sparkles,
  RefreshCw,
  Plus,
  Trash2,
  Copy,
  Check,
  Download,
  PhoneCall,
  Scale,
  Building,
  Info,
  ChevronDown,
  ChevronUp,
  Layers,
  Wrench,
  HelpCircle,
  ExternalLink,
} from 'lucide-react';
import { InsuranceClaim, XactimateAuditResult, XactimateLineItem } from '../types';
import { SAMPLE_XACTIMATE_ESTIMATES } from '../data/sampleXactimateEstimates';
import { EpistemicBracketBadge } from './EpistemicLegend';
import { applyCarrierToClaimGraph, buildClaimGraph } from '../domain/claimGraph';
import { applyRegionalPass2, inventoryTotals } from '../domain/claimEstimateFlow';

interface XactimateOptimizerViewProps {
  claim: InsuranceClaim;
  onUpdateClaim: (updated: InsuranceClaim) => void;
  onNavigateTab: (tab: any) => void;
}

export const XactimateOptimizerView: React.FC<XactimateOptimizerViewProps> = ({
  claim,
  onUpdateClaim,
  onNavigateTab,
}) => {
  // Active Estimate Preset or Raw Text State
  const [selectedPresetKey, setSelectedPresetKey] = useState<string>('state_farm_roof_lowball');
  const [rawText, setRawText] = useState<string>(
    SAMPLE_XACTIMATE_ESTIMATES.state_farm_roof_lowball.rawText
  );
  const [isAuditing, setIsAuditing] = useState<boolean>(false);
  const [auditResult, setAuditResult] = useState<XactimateAuditResult>(
    SAMPLE_XACTIMATE_ESTIMATES.state_farm_roof_lowball.auditResult
  );
  const [items, setItems] = useState<XactimateLineItem[]>(
    SAMPLE_XACTIMATE_ESTIMATES.state_farm_roof_lowball.auditResult.items
  );

  // Filters
  const [selectedTrade, setSelectedTrade] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [expandedItemId, setExpandedItemId] = useState<string | null>(items[0]?.id || null);

  // Modals & Panels
  const [showScriptModal, setShowScriptModal] = useState<boolean>(false);
  const [showExportModal, setShowExportModal] = useState<boolean>(false);
  const [showAddItemModal, setShowAddItemModal] = useState<boolean>(false);
  const [copiedState, setCopiedState] = useState<boolean>(false);
  const [appliedSuccess, setAppliedSuccess] = useState<boolean>(false);

  // Manual Add Item Form State
  const [newItemCode, setNewItemCode] = useState<string>('');
  const [newItemDesc, setNewItemDesc] = useState<string>('');
  const [newItemCategory, setNewItemCategory] = useState<string>('Roofing');
  const [newItemUnit, setNewItemUnit] = useState<string>('SQ');
  const [newItemQty, setNewItemQty] = useState<number>(1);
  const [newItemPrice, setNewItemPrice] = useState<number>(150);
  const [newItemReason, setNewItemReason] = useState<string>('');
  const [newItemCodeCitation, setNewItemCodeCitation] = useState<string>('');

  // Handle Preset Selection
  const handleSelectPreset = (key: string) => {
    setSelectedPresetKey(key);
    const preset = SAMPLE_XACTIMATE_ESTIMATES[key];
    if (preset) {
      setRawText(preset.rawText);
      setAuditResult(preset.auditResult);
      setItems(preset.auditResult.items);
      setExpandedItemId(preset.auditResult.items[0]?.id || null);
    }
  };

  // Run AI Audit on Xactimate Text
  const handleRunAudit = async () => {
    setIsAuditing(true);
    try {
      const res = await fetch('/api/audit-xactimate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          rawText,
          claimDetails: claim,
          manualItems: items,
        }),
      });

      if (res.ok) {
        const data: XactimateAuditResult = await res.json();
        setAuditResult(data);
        setItems(data.items || []);
        if (data.items?.length > 0) {
          setExpandedItemId(data.items[0].id);
        }
      } else {
        console.error('Audit API error, using sample fallback');
      }
    } catch (err) {
      console.error('Error running Xactimate audit:', err);
    } finally {
      setIsAuditing(false);
    }
  };

  // Toggle selection of an individual line item
  const handleToggleItem = (id: string) => {
    setItems((prev) =>
      prev.map((item) =>
        item.id === id ? { ...item, selected: !item.selected } : item
      )
    );
  };

  // Toggle Select All
  const handleToggleAll = (select: boolean) => {
    setItems((prev) => prev.map((item) => ({ ...item, selected: select })));
  };

  // Calculate live selected metrics
  const selectedItems = items.filter((i) => i.selected);
  const totalSelectedLift = selectedItems.reduce((sum, i) => sum + i.gapAmount, 0);
  const totalCarrierAllowed = selectedItems.reduce((sum, i) => sum + i.carrierTotal, 0);
  const totalContractorBenchmark = selectedItems.reduce((sum, i) => sum + i.contractorTotal, 0);
  const selectedCodeUpgrades = selectedItems
    .filter((i) => i.status === 'omitted_code_upgrade')
    .reduce((sum, i) => sum + i.gapAmount, 0);
  const selectedGCOP = selectedItems
    .filter((i) => i.status === 'omitted_gcop')
    .reduce((sum, i) => sum + i.gapAmount, 0);

  // Filter items
  const filteredItems = items.filter((item) => {
    const matchesTrade =
      selectedTrade === 'all' ||
      item.tradeCategory.toLowerCase() === selectedTrade.toLowerCase() ||
      item.category.toLowerCase() === selectedTrade.toLowerCase();
    const matchesStatus =
      selectedStatus === 'all' || item.status === selectedStatus;
    const matchesSearch =
      searchQuery === '' ||
      item.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.xactCode.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.reason.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesTrade && matchesStatus && matchesSearch;
  });

  // Import the carrier/Xactimate counter as a new evidence path. It never
  // overwrites the original PSi estimate and it promotes only propositions it
  // actually corroborates.
  const handleApplyToClaim = () => {
    const now = new Date().toISOString();
    const existingCarrierEvidence = claim.evidence.find((e) => e.type === 'carrier_estimate' && e.provenanceRoot?.includes(claim.carrierName));
    const evidenceId = existingCarrierEvidence?.id || `ev-carrier-xact-${Date.now()}`;
    const hash = Array.from(rawText as string).reduce<number>((acc: number, ch: string) => ((acc * 31 + ch.charCodeAt(0)) >>> 0), 2166136261).toString(16);
    const carrierEvidence = existingCarrierEvidence || {
      id: evidenceId,
      title: `${claim.carrierName} Xactimate / carrier estimate`,
      type: 'carrier_estimate' as const,
      filename: `${claim.claimNumber}-carrier-estimate.txt`,
      date: now,
      source: claim.carrierName,
      provenanceRoot: `${claim.carrierName}:carrier-estimate`,
      evidenceLevel: 'structural' as const,
      stance: 'context' as const,
      bracketState: 'EXPLAINED' as const,
      contentHash: hash,
      excerpt: 'Carrier estimate imported unchanged for comparison against the locked initial PSi estimate.',
      rawText,
      amountAssociated: auditResult.carrierXactimateTotal,
      floatPoints: Math.max(1, items.length),
      mixPoints: Math.max(0, Math.floor(items.length / 2)),
      stirPoints: 0,
      totalPressure: Math.max(1, items.length),
      keyObservations: items.slice(0, 20).map((item) => `${item.xactCode}: ${item.carrierQuantity} ${item.unit} @ $${item.carrierUnitPrice}`),
    };

    const updatedLineItems = [...(claim.lineItems || [])];
    items.forEach((item) => {
      const existingIndex = updatedLineItems.findIndex((li) => li.description.includes(item.xactCode) || li.description === item.description);
      const line = {
        id: existingIndex >= 0 ? updatedLineItems[existingIndex].id : `li-xact-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        category: (item.tradeCategory === 'General Contractor O&P (10/10)' ? 'General Conditions / O&P' : item.tradeCategory === 'Code Upgrades & Permits' ? 'Ordinance & Law' : item.tradeCategory) as any,
        description: `[${item.xactCode}] ${item.description}`,
        unit: item.unit,
        quantity: item.contractorQuantity || item.carrierQuantity,
        carrierAllowedACV: item.carrierACV ?? (item.carrierTotal * 0.8),
        carrierAllowedRCV: item.carrierRCV ?? item.carrierTotal,
        contractorBenchmarkRCV: existingIndex >= 0 ? updatedLineItems[existingIndex].contractorBenchmarkRCV : item.contractorTotal,
        depreciationWithheld: item.depreciation || 0,
        isRecoverableDepreciation: Boolean(item.depreciation),
        overheadProfitApplies: false,
        codeUpgradeRequired: item.status === 'omitted_code_upgrade',
        disputeReason: item.reason || 'Carrier line imported unchanged for comparison.',
        policyEndorsementRef: item.codeCitation,
        status: item.status === 'completely_missing' ? 'omitted_by_carrier' as const : (item.gapAmount > 0 ? 'underpaid' as const : 'valid_carrier_allowance' as const),
      };
      if (existingIndex >= 0) updatedLineItems[existingIndex] = { ...updatedLineItems[existingIndex], ...line };
      else updatedLineItems.push(line);
    });

    let updatedClaim: InsuranceClaim = {
      ...claim,
      evidence: existingCarrierEvidence ? claim.evidence : [carrierEvidence, ...claim.evidence],
      carrierAudit: { ...auditResult, items },
      lineItems: updatedLineItems,
      auditTrail: [
        {
          id: `at-xact-${Date.now()}`,
          timestamp: now,
          action: 'Carrier/Xactimate counter imported',
          impact: `${items.length} carrier line(s) preserved unchanged. The counter adds one corroborating pass; it does not replace the initial PSi estimate.`,
          bracketStatus: 'EXPLAINED',
        },
        ...(claim.auditTrail || []),
      ],
    };
    // Carrier arrival is the next estimating pass. Re-run the existing photo
    // inventory through Pass 2 using any stored Lowe's/local material sources
    // plus the supplied Xactimate worker-hours/rates. The original photo and
    // regional snapshots remain preserved; this creates a new comparison pass.
    if ((updatedClaim.damageInventory || []).length) {
      const refinedInventory = applyRegionalPass2(updatedClaim.damageInventory || [], {
        materialSources: claim.pricingModel?.latestMaterialSources || [],
        carrierItems: items,
        regionalMaterialDifferencePct: claim.pricingModel?.regionalMaterialDifferencePct || 0,
        regionalLaborDifferencePct: claim.pricingModel?.regionalLaborDifferencePct || 0,
        contingencyPct: claim.pricingModel?.contingencyPct ?? 5,
        at: now,
      });
      const totals = inventoryTotals(refinedInventory);
      const priorSnapshot = claim.pricingModel?.estimateSnapshots?.[0];
      const carrierComparedSnapshot = {
        id: `psi-carrier-compared-${Date.now()}`,
        trade: priorSnapshot?.trade || ('Roofing' as const),
        createdAt: now,
        status: 'SUPPORTED' as const,
        measuredQuantity: priorSnapshot?.measuredQuantity || 0,
        measuredUnit: priorSnapshot?.measuredUnit || 'claim',
        materialSubtotal: (claim.pricingModel?.latestMaterialSources || []).reduce((sum, source) => sum + Number(source.sellingPrice || 0) * Number(source.purchaseUnits || 0), 0),
        contractorAdjustmentPercent: null,
        contractorAdjustmentAmount: 0,
        materialTax: 0,
        documentedTradeCost: totals.pass2,
        damageEvidenceIds: [...new Set(refinedInventory.flatMap((entry) => entry.photoEvidenceIds || []))],
        materialSources: claim.pricingModel?.latestMaterialSources || [],
        contractorObservationIds: claim.pricingModel?.contractorRateObservations?.map((entry) => entry.id) || [],
        stage: 'carrier_compared' as const,
        bracket: 'EXPLAINED' as const,
        baseCost: totals.pass2Base,
        contingencyPct: claim.pricingModel?.contingencyPct ?? 5,
        contingencyAmount: totals.contingency,
        reason: 'Carrier/Xactimate counter added as an independent corroborating pass. Materials retain current local sources where available; missing material prices are Xactimate-derived or remain explicitly speculative. Labor uses MAX(PSi regional labor, supplied Xactimate worker-hours × rate).',
      };

      updatedClaim = {
        ...updatedClaim,
        damageInventory: refinedInventory,
        pricingModel: {
          lowesStoreId: claim.pricingModel?.lowesStoreId,
          zipCode: claim.pricingModel?.zipCode,
          contractorRateObservations: claim.pricingModel?.contractorRateObservations || [],
          estimateSnapshots: [carrierComparedSnapshot, ...(claim.pricingModel?.estimateSnapshots || [])].slice(0, 100),
          latestMaterialSources: claim.pricingModel?.latestMaterialSources || [],
          regionalMaterialDifferencePct: claim.pricingModel?.regionalMaterialDifferencePct || 0,
          regionalLaborDifferencePct: claim.pricingModel?.regionalLaborDifferencePct || 0,
          contingencyPct: claim.pricingModel?.contingencyPct ?? 5,
        },
        auditedTrueValuation: {
          ...claim.auditedTrueValuation,
          contractorRCV: totals.pass2,
        },
      };
    }

    const baseGraph = buildClaimGraph(updatedClaim, now);
    updatedClaim.claimGraph = applyCarrierToClaimGraph(baseGraph, updatedClaim.damageInventory || [], items, evidenceId, updatedClaim.evidence, now);
    onUpdateClaim(updatedClaim);
    setAppliedSuccess(true);
    setTimeout(() => setAppliedSuccess(false), 4000);
  };

  // Add Custom Item to list
  const handleAddCustomItem = () => {
    if (!newItemDesc || !newItemCode) return;
    const total = newItemQty * newItemPrice;
    const created: XactimateLineItem = {
      id: `xact-custom-${Date.now()}`,
      xactCode: newItemCode.toUpperCase(),
      category: newItemCategory,
      description: newItemDesc,
      unit: newItemUnit,
      carrierQuantity: 0,
      carrierUnitPrice: 0,
      carrierTotal: 0,
      contractorQuantity: newItemQty,
      contractorUnitPrice: newItemPrice,
      contractorTotal: total,
      gapAmount: total,
      status: 'completely_missing',
      reason: newItemReason || 'Identified during forensic physical damage inspection.',
      codeCitation: newItemCodeCitation || 'Standard Building Code & Manufacturer Specs',
      tradeCategory: newItemCategory as any,
      selected: true,
      epistemicBracket: 'SPECULATIVE',
    };

    setItems([created, ...items]);
    setShowAddItemModal(false);
    setNewItemCode('');
    setNewItemDesc('');
    setNewItemReason('');
    setNewItemCodeCitation('');
  };

  // Handle File Upload Simulation
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const text = event.target?.result as string;
        setRawText(
          text ||
            `EXTRACTED XACTIMATE TEXT FROM ${file.name}\n\nCarrier: ${claim.carrierName}\nClaim: ${claim.claimNumber}\nParsed items: RFG 220, RFG FELT, DRY 1/2, PNT P.\nAdjuster notes: Spot repair approved. No GCO&P.`
        );
      };
      reader.readAsText(file);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Top Header Banner */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 p-6 rounded-2xl bg-gradient-to-r from-sky-950/40 via-slate-900 to-indigo-950/30 border border-sky-800/40 shadow-xl relative overflow-hidden">
        <div className="space-y-2 relative z-10">
          <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-full text-xs font-mono bg-sky-500/10 text-sky-400 border border-sky-500/30">
            <FileSearch className="w-3.5 h-3.5" />
            <span>Forensic Xactimate Scope & Omission Itemizer</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white flex items-center gap-3">
            Xactimate Estimate Auditor
          </h1>
          <p className="text-sm text-slate-400 max-w-3xl">
            Audit carrier Xactimate estimates against manufacturer specifications (GAF, Owens Corning), building code mandates (IRC R905, FBC), and multi-trade GCO&P rules to uncover every missing line item and maximize claim payout.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 relative z-10">
          <button
            onClick={() => setShowScriptModal(true)}
            className="px-3.5 py-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-medium flex items-center gap-2 transition-all shadow-sm"
          >
            <PhoneCall className="w-3.5 h-3.5 text-amber-400" />
            <span>Adjuster Phone Script</span>
          </button>
          <button
            onClick={() => setShowExportModal(true)}
            className="px-3.5 py-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-medium flex items-center gap-2 transition-all shadow-sm"
          >
            <Download className="w-3.5 h-3.5 text-sky-400" />
            <span>Export Itemized Sheet</span>
          </button>
          <button
            onClick={() => setShowAddItemModal(true)}
            className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white border border-slate-600 text-xs font-medium flex items-center gap-2 transition-all shadow-sm"
          >
            <Plus className="w-3.5 h-3.5 text-emerald-400" />
            <span>Add Missing Code</span>
          </button>
        </div>
      </div>

      {/* Financial Valuation Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Recovery Gap Lift */}
        <div className="p-5 rounded-2xl bg-gradient-to-br from-emerald-950/40 via-slate-900 to-slate-900 border border-emerald-500/30 relative overflow-hidden">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span className="font-mono uppercase text-emerald-400 font-bold">Total Recovery Lift</span>
            <TrendingUp className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl sm:text-3xl font-bold font-mono text-emerald-400">
            +${totalSelectedLift.toLocaleString()}
          </div>
          <div className="text-xs text-slate-400 mt-2 flex items-center gap-1.5">
            <span className="text-emerald-300 font-semibold">{selectedItems.length} missing items</span>
            <span>selected for supplement</span>
          </div>
        </div>

        {/* Carrier Initial vs Benchmark Total */}
        <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 relative">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span className="font-mono uppercase">Optimized Benchmark Scope</span>
            <Scale className="w-4 h-4 text-sky-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-white">
            ${totalContractorBenchmark.toLocaleString()}
          </div>
          <div className="text-xs text-slate-400 mt-2">
            Carrier allowed only <span className="text-rose-400 font-mono font-medium">${totalCarrierAllowed.toLocaleString()}</span>
          </div>
        </div>

        {/* General Contractor Overhead & Profit 10/10 */}
        <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 relative">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span className="font-mono uppercase">GCO&P 10/10 Qualified</span>
            <Building className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-purple-300">
            ${selectedGCOP.toLocaleString()}
          </div>
          <div className="text-xs text-slate-400 mt-2 flex items-center gap-1">
            <span className="px-1.5 py-0.5 rounded bg-purple-950/60 text-purple-300 text-[10px] font-mono border border-purple-800/60">
              {auditResult.identifiedTrades.length} Trades Required
            </span>
            <span className="truncate">Trinidad v. FL</span>
          </div>
        </div>

        {/* Mandatory Building Code Upgrades */}
        <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 relative">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span className="font-mono uppercase">Code Compliance & Law</span>
            <Shield className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-amber-300">
            ${selectedCodeUpgrades.toLocaleString()}
          </div>
          <div className="text-xs text-slate-400 mt-2">
            IRC R905 Drip Edge, Valleys & Permits
          </div>
        </div>

      </div>

      {/* Ingestion & Preset Analysis Studio */}
      <div className="p-6 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <FileSpreadsheet className="w-4 h-4 text-sky-400" />
              <span>Carrier Estimate Source & AI Parser</span>
            </h3>
            <p className="text-xs text-slate-400">
              Select a carrier estimate preset, paste raw Xactimate text from your PDF, or upload a claim file to run the AI forensic audit.
            </p>
          </div>

          {/* Quick Presets */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400 font-medium">Load Preset:</span>
            <select
              value={selectedPresetKey}
              onChange={(e) => handleSelectPreset(e.target.value)}
              className="px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-xs text-slate-200 focus:outline-none focus:border-sky-500"
            >
              <option value="state_farm_roof_lowball">State Farm - Roof Lowball (Missing Starter, Drip, O&P)</option>
              <option value="allstate_pipe_burst_water">Allstate - Pipe Burst Water Loss (Missing Drying, Manip)</option>
            </select>
          </div>
        </div>

        {/* Input Controls */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          
          {/* Raw Text Box */}
          <div className="lg:col-span-2 space-y-2">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>Paste Raw Xactimate Text / Line Items:</span>
              <label className="cursor-pointer text-sky-400 hover:text-sky-300 flex items-center gap-1 font-medium">
                <UploadCloud className="w-3.5 h-3.5" />
                <span>Upload PDF/TXT</span>
                <input
                  type="file"
                  accept=".txt,.pdf,.csv"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>
            </div>
            <textarea
              rows={4}
              value={rawText}
              onChange={(e) => setRawText(e.target.value)}
              placeholder="Paste line items, carrier summary, or Xactimate estimate text here..."
              className="w-full p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs font-mono text-slate-200 focus:outline-none focus:border-sky-500 placeholder:text-slate-600 resize-none"
            />
          </div>

          {/* Audit Action Box */}
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800/80 flex flex-col justify-between space-y-3">
            <div>
              <div className="text-xs font-bold text-slate-200 flex items-center gap-1.5 mb-1">
                <Sparkles className="w-4 h-4 text-sky-400" />
                <span>AI Forensic Scope Audit</span>
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                Gemini AI parses code-by-code against IRC building codes, manufacturer specs, and case law precedent.
              </p>
            </div>

            <button
              onClick={handleRunAudit}
              disabled={isAuditing}
              className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 hover:to-blue-500 text-white font-semibold text-xs flex items-center justify-center gap-2 shadow-lg shadow-sky-500/20 transition-all disabled:opacity-50"
            >
              {isAuditing ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>Auditing Scope & Codes...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Run Forensic Scope Audit</span>
                </>
              )}
            </button>
          </div>

        </div>

        {/* Audit Executive Summary Card */}
        {auditResult && (
          <div className="p-4 rounded-xl bg-slate-950/80 border border-sky-900/40 text-xs space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-sky-300 flex items-center gap-2">
                <Info className="w-4 h-4 text-sky-400" />
                <span>Audit Findings for {auditResult.carrierName} ({auditResult.claimNumber})</span>
              </span>
              <span className="px-2 py-0.5 rounded text-[11px] font-mono bg-rose-950 text-rose-300 border border-rose-800">
                Lowball Severity Score: {auditResult.auditScore}/100
              </span>
            </div>
            <p className="text-slate-300 leading-relaxed">{auditResult.summaryNotes}</p>
            
            {/* Identified Multi-Trades */}
            <div className="pt-2 border-t border-slate-800 flex flex-wrap items-center gap-2">
              <span className="text-[11px] text-slate-400 font-mono">Identified Trades:</span>
              {auditResult.identifiedTrades?.map((trade, idx) => (
                <span
                  key={idx}
                  className="px-2 py-0.5 rounded-md text-[10px] font-mono bg-slate-900 text-slate-300 border border-slate-700"
                >
                  {trade}
                </span>
              ))}
            </div>
          </div>
        )}

      </div>

      {/* Applied Success Toast */}
      {appliedSuccess && (
        <div className="p-4 rounded-xl bg-emerald-950/90 border border-emerald-500 text-emerald-200 text-xs flex items-center justify-between animate-fade-in shadow-xl">
          <div className="flex items-center gap-2.5">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            <div>
              <span className="font-bold">Successfully Applied to Claim Valuation!</span>
              <div className="text-[11px] text-emerald-300/80">
                Injected {selectedItems.length} missing items (+${totalSelectedLift.toLocaleString()}) into active claim records.
              </div>
            </div>
          </div>
          <button
            onClick={() => onNavigateTab('payout_optimizer')}
            className="px-3 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold transition-colors"
          >
            View Optimizer
          </button>
        </div>
      )}

      {/* Missing Line-Items Breakdown & Optimizer Table */}
      <div className="rounded-2xl bg-slate-900/90 border border-slate-800 overflow-hidden shadow-xl">
        
        {/* Table Controls & Filters */}
        <div className="p-5 border-b border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-950/40">
          
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => handleToggleAll(true)}
              className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] font-medium transition-colors"
            >
              Select All ({items.length})
            </button>
            <button
              onClick={() => handleToggleAll(false)}
              className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] font-medium transition-colors"
            >
              Deselect All
            </button>

            {/* Filter by Trade */}
            <select
              value={selectedTrade}
              onChange={(e) => setSelectedTrade(e.target.value)}
              className="px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-slate-200 focus:outline-none focus:border-sky-500"
            >
              <option value="all">All Trade Categories</option>
              <option value="Roofing">Roofing</option>
              <option value="Drywall & Ceiling">Drywall & Ceiling</option>
              <option value="Water Mitigation">Water Mitigation</option>
              <option value="Paint & Finishes">Paint & Finishes</option>
              <option value="Flooring">Flooring</option>
              <option value="General Contractor O&P (10/10)">General Contractor O&P</option>
              <option value="Code Upgrades & Permits">Code Upgrades & Permits</option>
              <option value="Contents & Protection">Contents & Protection</option>
            </select>

            {/* Filter by Status */}
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-slate-200 focus:outline-none focus:border-sky-500"
            >
              <option value="all">All Discrepancy Types</option>
              <option value="completely_missing">Completely Missing</option>
              <option value="omitted_code_upgrade">Omitted Code Upgrade</option>
              <option value="shorted_quantity">Shorted Quantity / Waste</option>
              <option value="omitted_gcop">Omitted GCO&P (10/10)</option>
            </select>
          </div>

          {/* 1-Click Apply Button */}
          <button
            onClick={handleApplyToClaim}
            disabled={selectedItems.length === 0}
            className="px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold flex items-center justify-center gap-2 shadow-md shadow-emerald-500/20 transition-all disabled:opacity-40"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>Apply Selected ({selectedItems.length}) to Claim (+${totalSelectedLift.toLocaleString()})</span>
          </button>

        </div>

        {/* Table View */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-950/70 text-slate-400 font-mono uppercase text-[11px]">
                <th className="py-3 px-4 w-12 text-center">Include</th>
                <th className="py-3 px-3">Xactimate Code</th>
                <th className="py-3 px-3">Scope Description & Justification</th>
                <th className="py-3 px-3 text-right">Carrier Allowed</th>
                <th className="py-3 px-3 text-right">Benchmark True Scope</th>
                <th className="py-3 px-3 text-right font-bold text-emerald-400">Recovery Lift</th>
                <th className="py-3 px-4 text-center">Epistemic Bracket</th>
                <th className="py-3 px-3 text-center">Inspect</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredItems.map((item) => {
                const isExpanded = expandedItemId === item.id;
                return (
                  <React.Fragment key={item.id}>
                    <tr
                      className={`hover:bg-slate-800/40 transition-colors ${
                        item.selected ? 'bg-slate-900/40' : 'opacity-60 bg-slate-950/20'
                      }`}
                    >
                      {/* Checkbox */}
                      <td className="py-3 px-4 text-center">
                        <input
                          type="checkbox"
                          checked={item.selected}
                          onChange={() => handleToggleItem(item.id)}
                          className="w-4 h-4 rounded border-slate-700 bg-slate-950 text-sky-500 focus:ring-sky-500 cursor-pointer"
                        />
                      </td>

                      {/* Code & Category */}
                      <td className="py-3 px-3">
                        <span className="px-2 py-1 rounded bg-sky-950/80 text-sky-300 font-mono text-[11px] font-bold border border-sky-800/60 block w-fit">
                          {item.xactCode}
                        </span>
                        <span className="text-[10px] text-slate-500 block mt-0.5">
                          {item.tradeCategory}
                        </span>
                      </td>

                      {/* Description & Status Badge */}
                      <td className="py-3 px-3 max-w-md">
                        <div className="font-semibold text-slate-200 flex items-center gap-2">
                          <span>{item.description}</span>
                          {item.status === 'completely_missing' && (
                            <span className="px-1.5 py-0.5 rounded text-[9px] font-mono bg-rose-950/80 text-rose-300 border border-rose-800/60">
                              OMITTED
                            </span>
                          )}
                          {item.status === 'omitted_code_upgrade' && (
                            <span className="px-1.5 py-0.5 rounded text-[9px] font-mono bg-amber-950/80 text-amber-300 border border-amber-800/60">
                              CODE MANDATE
                            </span>
                          )}
                          {item.status === 'omitted_gcop' && (
                            <span className="px-1.5 py-0.5 rounded text-[9px] font-mono bg-purple-950/80 text-purple-300 border border-purple-800/60">
                              GCO&P 10/10
                            </span>
                          )}
                          {item.status === 'shorted_quantity' && (
                            <span className="px-1.5 py-0.5 rounded text-[9px] font-mono bg-orange-950/80 text-orange-300 border border-orange-800/60">
                              SHORTED QTY
                            </span>
                          )}
                        </div>
                        <div className="text-[11px] text-slate-400 mt-0.5 line-clamp-1">
                          {item.reason}
                        </div>
                      </td>

                      {/* Carrier Allowed */}
                      <td className="py-3 px-3 text-right font-mono">
                        {item.carrierTotal > 0 ? (
                          <>
                            <div className="text-slate-300">${item.carrierTotal.toLocaleString()}</div>
                            <div className="text-[10px] text-slate-500">
                              {item.carrierQuantity} {item.unit} @ ${item.carrierUnitPrice}
                            </div>
                          </>
                        ) : (
                          <span className="text-rose-400/80 font-mono text-[11px]">$0.00 (Omitted)</span>
                        )}
                      </td>

                      {/* Benchmark True Scope */}
                      <td className="py-3 px-3 text-right font-mono">
                        <div className="text-slate-100 font-semibold">
                          ${item.contractorTotal.toLocaleString()}
                        </div>
                        <div className="text-[10px] text-slate-400">
                          {item.contractorQuantity} {item.unit} @ ${item.contractorUnitPrice}
                        </div>
                      </td>

                      {/* Recovery Lift */}
                      <td className="py-3 px-3 text-right font-mono font-bold text-emerald-400 text-sm">
                        +${item.gapAmount.toLocaleString()}
                      </td>

                      {/* Epistemic Bracket */}
                      <td className="py-3 px-4 text-center">
                        <EpistemicBracketBadge bracket={item.epistemicBracket} />
                      </td>

                      {/* Expand Button */}
                      <td className="py-3 px-3 text-center">
                        <button
                          onClick={() => setExpandedItemId(isExpanded ? null : item.id)}
                          className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
                        >
                          {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                        </button>
                      </td>
                    </tr>

                    {/* Expandable Inspector Detail Drawer */}
                    {isExpanded && (
                      <tr className="bg-slate-950/80 border-b border-slate-800">
                        <td colSpan={8} className="p-4 sm:p-5 space-y-3">
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                            
                            {/* Forensic Reason & Omission Analysis */}
                            <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 space-y-1.5">
                              <span className="text-[10px] uppercase font-mono text-sky-400 font-bold block">
                                Adjuster Omission Forensic Analysis
                              </span>
                              <p className="text-slate-300 leading-relaxed">{item.reason}</p>
                            </div>

                            {/* Statutory & Code Citation */}
                            <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 space-y-1.5">
                              <span className="text-[10px] uppercase font-mono text-amber-400 font-bold block flex items-center gap-1.5">
                                <Shield className="w-3.5 h-3.5" />
                                <span>Code Mandate & Legal Precedent</span>
                              </span>
                              <p className="text-slate-200 font-mono text-[11px] font-semibold">
                                {item.codeCitation || 'IRC Standard / Manufacturer Specification'}
                              </p>
                              <p className="text-[11px] text-slate-400">
                                This requirement cannot be waived by the insurance carrier under standard policy replacement cost terms.
                              </p>
                            </div>

                          </div>
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Empty state if filtered */}
        {filteredItems.length === 0 && (
          <div className="p-12 text-center text-slate-500 text-xs">
            No line items match the selected filter criteria.
          </div>
        )}

      </div>

      {/* Adjuster Phone Negotiation Script Modal */}
      {showScriptModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-2xl rounded-2xl bg-slate-900 border border-slate-700 shadow-2xl p-6 space-y-4 max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <PhoneCall className="w-5 h-5 text-amber-400" />
                <h3 className="text-base font-bold text-white">Adjuster Phone Negotiation Talking Points</h3>
              </div>
              <button
                onClick={() => setShowScriptModal(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-slate-400">
              Use these strict, legally grounded rebuttal scripts when discussing the Xactimate scope with the carrier adjuster or claims manager.
            </p>

            <div className="space-y-3">
              {auditResult.rebuttalArguments?.map((arg, idx) => (
                <div
                  key={idx}
                  className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-200 space-y-1"
                >
                  <span className="text-[10px] font-mono uppercase text-sky-400 font-bold block">
                    Talking Point #{idx + 1}
                  </span>
                  <p className="leading-relaxed">{arg}</p>
                </div>
              ))}
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-slate-800">
              <button
                onClick={() => {
                  navigator.clipboard.writeText(auditResult.rebuttalArguments.join('\n\n'));
                  setCopiedState(true);
                  setTimeout(() => setCopiedState(false), 2000);
                }}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium flex items-center gap-2"
              >
                {copiedState ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedState ? 'Copied to Clipboard' : 'Copy All Talking Points'}</span>
              </button>
              <button
                onClick={() => setShowScriptModal(false)}
                className="px-4 py-2 rounded-xl bg-sky-500 hover:bg-sky-400 text-white text-xs font-bold"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Export Itemized Sheet Modal */}
      {showExportModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-2xl rounded-2xl bg-slate-900 border border-slate-700 shadow-2xl p-6 space-y-4 max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Download className="w-5 h-5 text-sky-400" />
                <h3 className="text-base font-bold text-white">Itemized Supplemental Demand Sheet</h3>
              </div>
              <button
                onClick={() => setShowExportModal(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 font-mono text-xs text-slate-300 space-y-2 whitespace-pre-wrap max-h-96 overflow-y-auto">
{`FORENSIC XACTIMATE SUPPLEMENTAL DEMAND BREAKDOWN
Claim #: ${claim.claimNumber}
Carrier: ${claim.carrierName}
Policyholder: ${claim.policyholderName}
Date: ${new Date().toLocaleDateString()}

============================================================
ITEMIZED SCOPE OMISSIONS & RECOVERY LIFT SCHEDULE:
============================================================
${selectedItems
  .map(
    (item, i) =>
      `${i + 1}. [${item.xactCode}] ${item.description}\n` +
      `   Unit: ${item.contractorQuantity} ${item.unit} @ $${item.contractorUnitPrice.toFixed(2)} = $${item.contractorTotal.toFixed(2)}\n` +
      `   Carrier Allowed: $${item.carrierTotal.toFixed(2)} | Supplemental Gap: +$${item.gapAmount.toFixed(2)}\n` +
      `   Authority/Code: ${item.codeCitation || 'Manufacturer Specs & Building Code'}\n` +
      `   Justification: ${item.reason}\n`
  )
  .join('\n')}

============================================================
FINANCIAL SUMMARY:
- Carrier Allowed Scope: $${totalCarrierAllowed.toLocaleString()}
- Total Omitted Scope Supplemental Demand: +$${totalSelectedLift.toLocaleString()}
- Total Audited Replacement Cost Value (RCV): $${totalContractorBenchmark.toLocaleString()}
============================================================`}
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
              <button
                onClick={() => {
                  const text = `FORENSIC XACTIMATE SUPPLEMENTAL DEMAND\nClaim #: ${claim.claimNumber}\nCarrier: ${claim.carrierName}\n\n` +
                    selectedItems.map(i => `${i.xactCode}: ${i.description} - $${i.contractorTotal.toFixed(2)} (${i.reason})`).join('\n');
                  navigator.clipboard.writeText(text);
                  setCopiedState(true);
                  setTimeout(() => setCopiedState(false), 2000);
                }}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium flex items-center gap-2"
              >
                {copiedState ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedState ? 'Copied' : 'Copy Text'}</span>
              </button>
              <button
                onClick={() => {
                  window.print();
                }}
                className="px-4 py-2 rounded-xl bg-sky-500 hover:bg-sky-400 text-white text-xs font-bold"
              >
                Print / Save PDF
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add Custom Missing Code Modal */}
      {showAddItemModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-lg rounded-2xl bg-slate-900 border border-slate-700 shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Plus className="w-5 h-5 text-emerald-400" />
                <h3 className="text-base font-bold text-white">Add Custom Xactimate Code</h3>
              </div>
              <button
                onClick={() => setShowAddItemModal(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 mb-1">Xactimate Code</label>
                  <input
                    type="text"
                    placeholder="e.g. RFG DRIP, WTR GRM"
                    value={newItemCode}
                    onChange={(e) => setNewItemCode(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white font-mono uppercase focus:outline-none focus:border-sky-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">Trade Category</label>
                  <select
                    value={newItemCategory}
                    onChange={(e) => setNewItemCategory(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-sky-500"
                  >
                    <option value="Roofing">Roofing</option>
                    <option value="Drywall & Ceiling">Drywall & Ceiling</option>
                    <option value="Water Mitigation">Water Mitigation</option>
                    <option value="Paint & Finishes">Paint & Finishes</option>
                    <option value="Flooring">Flooring</option>
                    <option value="Code Upgrades & Permits">Code Upgrades & Permits</option>
                    <option value="General Contractor O&P (10/10)">General Contractor O&P</option>
                    <option value="Contents & Protection">Contents & Protection</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Scope Description</label>
                <input
                  type="text"
                  placeholder="e.g. Drip edge flashing at eaves and rakes"
                  value={newItemDesc}
                  onChange={(e) => setNewItemDesc(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-sky-500"
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-400 mb-1">Unit (SQ, LF, SF, EA)</label>
                  <input
                    type="text"
                    value={newItemUnit}
                    onChange={(e) => setNewItemUnit(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white font-mono focus:outline-none focus:border-sky-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">Quantity</label>
                  <input
                    type="number"
                    value={newItemQty}
                    onChange={(e) => setNewItemQty(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white font-mono focus:outline-none focus:border-sky-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">Unit Price ($)</label>
                  <input
                    type="number"
                    value={newItemPrice}
                    onChange={(e) => setNewItemPrice(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white font-mono focus:outline-none focus:border-sky-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Omission Reason & Defense</label>
                <input
                  type="text"
                  placeholder="e.g. Omitted by adjuster during inspection; required by manufacturer"
                  value={newItemReason}
                  onChange={(e) => setNewItemReason(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-sky-500"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Building Code / Case Law Citation</label>
                <input
                  type="text"
                  placeholder="e.g. IRC R905.2.8.5; FBC 1507"
                  value={newItemCodeCitation}
                  onChange={(e) => setNewItemCodeCitation(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-white font-mono focus:outline-none focus:border-sky-500"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
              <button
                onClick={() => setShowAddItemModal(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium"
              >
                Cancel
              </button>
              <button
                onClick={handleAddCustomItem}
                className="px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold"
              >
                Add Line Item
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
