import React, { useState } from 'react';
import {
  DollarSign,
  Plus,
  Trash2,
  CheckCircle2,
  AlertCircle,
  TrendingUp,
  ShieldCheck,
  Hammer,
  FileSpreadsheet,
  FileSearch,
  Info,
  Scale,
  Sparkles,
} from 'lucide-react';
import { InsuranceClaim, LineItemDispute, MonetaryTruth, PsiEstimateSnapshot } from '../types';
import { auditOverheadAndProfit } from '../utils/epistemicEngine';
import { applyPaymentToClaimGraph, buildClaimGraph } from '../domain/claimGraph';

interface PayoutOptimizerViewProps {
  claim: InsuranceClaim;
  onUpdateClaim: (updated: InsuranceClaim) => void;
  onNavigateTab: (tab: any) => void;
}

export const PayoutOptimizerView: React.FC<PayoutOptimizerViewProps> = ({
  claim,
  onUpdateClaim,
  onNavigateTab,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [showAddModal, setShowAddModal] = useState(false);
  const [paymentAmount, setPaymentAmount] = useState<number>(0);
  const [paymentEvidenceId, setPaymentEvidenceId] = useState<string>('');
  const [paymentDamageId, setPaymentDamageId] = useState<string>('');
  const [paymentIsFinal, setPaymentIsFinal] = useState<boolean>(true);
  const [paymentMessage, setPaymentMessage] = useState<string>('');

  // New line item state for modal
  const [newLineItem, setNewLineItem] = useState<Partial<LineItemDispute>>({
    category: 'Roofing',
    description: '',
    unit: 'SQ',
    quantity: 1,
    carrierAllowedACV: 0,
    carrierAllowedRCV: 0,
    contractorBenchmarkRCV: 0,
    depreciationWithheld: 0,
    isRecoverableDepreciation: true,
    overheadProfitApplies: true,
    codeUpgradeRequired: false,
    disputeReason: '',
    status: 'omitted_by_carrier',
  });

  const opAudit = auditOverheadAndProfit(claim.lineItems);

  const categories = [
    'All',
    'Roofing',
    'Drywall & Framing',
    'Water Mitigation',
    'Electrical & HVAC',
    'Paint & Finishes',
    'Ordinance & Law',
    'General Conditions / O&P',
  ];

  const filteredLineItems = selectedCategory === 'All'
    ? claim.lineItems
    : claim.lineItems.filter((item) => item.category === selectedCategory);

  // Totals
  const totalCarrierRCV = claim.lineItems.reduce((sum, item) => sum + item.carrierAllowedRCV, 0);
  const totalBenchmarkRCV = claim.lineItems.reduce((sum, item) => sum + item.contractorBenchmarkRCV, 0);
  const directLineItemGap = totalBenchmarkRCV - totalCarrierRCV;

  const handleAddLineItem = () => {
    if (!newLineItem.description || !newLineItem.contractorBenchmarkRCV) return;

    const created: LineItemDispute = {
      id: `li-user-${Date.now()}`,
      category: (newLineItem.category as any) || 'Roofing',
      description: newLineItem.description || 'Custom Disputed Line Item',
      unit: newLineItem.unit || 'EA',
      quantity: Number(newLineItem.quantity) || 1,
      carrierAllowedACV: Number(newLineItem.carrierAllowedACV) || 0,
      carrierAllowedRCV: Number(newLineItem.carrierAllowedRCV) || 0,
      contractorBenchmarkRCV: Number(newLineItem.contractorBenchmarkRCV) || 0,
      depreciationWithheld: Number(newLineItem.depreciationWithheld) || 0,
      isRecoverableDepreciation: Boolean(newLineItem.isRecoverableDepreciation),
      overheadProfitApplies: Boolean(newLineItem.overheadProfitApplies),
      codeUpgradeRequired: Boolean(newLineItem.codeUpgradeRequired),
      disputeReason: newLineItem.disputeReason || 'Omitted from carrier scope during field inspection.',
      status: (newLineItem.status as any) || 'omitted_by_carrier',
    };

    const updatedItems = [...claim.lineItems, created];
    const newOP = auditOverheadAndProfit(updatedItems);
    
    let totalBench = 0;
    let codeUpgrades = 0;
    let recoverableDep = 0;

    updatedItems.forEach((i) => {
      totalBench += i.contractorBenchmarkRCV;
      if (i.codeUpgradeRequired) codeUpgrades += (i.contractorBenchmarkRCV - i.carrierAllowedRCV);
      if (i.isRecoverableDepreciation) recoverableDep += (i.contractorBenchmarkRCV - i.carrierAllowedACV);
    });

    const gross = totalBench + newOP.totalOPAddition + codeUpgrades;
    const net = gross - claim.policyLimits.deductible;
    const gap = Math.max(0, net - claim.carrierOffer.netCarrierCheckIssued);

    const updatedClaim: InsuranceClaim = {
      ...claim,
      lineItems: updatedItems,
      auditedTrueValuation: {
        ...claim.auditedTrueValuation,
        contractorRCV: totalBench,
        eligibleOverheadAndProfit: newOP.totalOPAddition,
        eligibleCodeUpgrades: codeUpgrades,
        trueGrossRecovery: gross,
        netPayoutOwed: net,
        totalRecoveryGap: gap,
      },
    };

    onUpdateClaim(updatedClaim);
    setShowAddModal(false);
    setNewLineItem({
      category: 'Roofing',
      description: '',
      unit: 'SQ',
      quantity: 1,
      carrierAllowedACV: 0,
      carrierAllowedRCV: 0,
      contractorBenchmarkRCV: 0,
      depreciationWithheld: 0,
      isRecoverableDepreciation: true,
      overheadProfitApplies: true,
      codeUpgradeRequired: false,
      disputeReason: '',
      status: 'omitted_by_carrier',
    });
  };

  const handleDeleteLineItem = (id: string) => {
    const updatedItems = claim.lineItems.filter((i) => i.id !== id);
    const newOP = auditOverheadAndProfit(updatedItems);
    
    let totalBench = 0;
    let codeUpgrades = 0;
    updatedItems.forEach((i) => {
      totalBench += i.contractorBenchmarkRCV;
      if (i.codeUpgradeRequired) codeUpgrades += (i.contractorBenchmarkRCV - i.carrierAllowedRCV);
    });

    const gross = totalBench + newOP.totalOPAddition + codeUpgrades;
    const net = gross - claim.policyLimits.deductible;
    const gap = Math.max(0, net - claim.carrierOffer.netCarrierCheckIssued);

    onUpdateClaim({
      ...claim,
      lineItems: updatedItems,
      auditedTrueValuation: {
        ...claim.auditedTrueValuation,
        contractorRCV: totalBench,
        eligibleOverheadAndProfit: newOP.totalOPAddition,
        eligibleCodeUpgrades: codeUpgrades,
        trueGrossRecovery: gross,
        netPayoutOwed: net,
        totalRecoveryGap: gap,
      },
    });
  };


  const receivedPayments = (claim.monetaryTruths || []).filter((truth) => truth.kind === 'received');
  const receivedTotal = receivedPayments.reduce((sum, truth) => sum + Number(truth.amount || 0), 0);

  const handleRecordPayment = () => {
    const amount = Number(paymentAmount || 0);
    if (!(amount > 0)) {
      setPaymentMessage('Enter the payment amount actually received.');
      return;
    }
    if (!paymentEvidenceId) {
      setPaymentMessage('Select the document, receipt, check, or carrier record that proves the payment.');
      return;
    }
    if (paymentIsFinal && !paymentDamageId) {
      setPaymentMessage('Select the repair/damage item this final payment resolves. A whole-claim payment can be recorded, but it cannot silently validate every item.');
      return;
    }

    const now = new Date().toISOString();
    const selectedDamage = (claim.damageInventory || []).find((item) => item.id === paymentDamageId);
    const truth: MonetaryTruth = {
      id: `payment-${Date.now()}`,
      kind: 'received',
      statement: paymentDamageId
        ? `${paymentIsFinal ? 'Final' : 'Partial/interim'} payment received for ${selectedDamage?.component || selectedDamage?.statement || 'linked repair item'}: $${amount.toFixed(2)}`
        : `Claim-level payment received: $${amount.toFixed(2)}`,
      amount,
      bracket: 'VALIDATED',
      evidenceIds: [paymentEvidenceId],
      recordedAt: now,
      damageInventoryId: paymentDamageId || undefined,
      finalForLinkedItem: Boolean(paymentIsFinal && paymentDamageId),
    };

    let updatedClaim: InsuranceClaim = {
      ...claim,
      monetaryTruths: [truth, ...(claim.monetaryTruths || [])],
      auditTrail: [
        {
          id: `audit-payment-${Date.now()}`,
          timestamp: now,
          action: paymentIsFinal ? 'Final payment recorded' : 'Payment received',
          impact: paymentDamageId
            ? `$${amount.toFixed(2)} linked to ${selectedDamage?.component || selectedDamage?.statement || paymentDamageId}. ${paymentIsFinal ? 'Only the linked monetary proposition is promoted to the final validated state.' : 'Payment is preserved as direct evidence but does not close the linked PSi price proposition.'}`
            : `$${amount.toFixed(2)} recorded at claim level. No individual repair proposition was automatically promoted.`,
          bracketStatus: 'VALIDATED',
        },
        ...(claim.auditTrail || []),
      ],
    };

    const baseGraph = updatedClaim.claimGraph || buildClaimGraph(updatedClaim, now);
    updatedClaim.claimGraph = applyPaymentToClaimGraph(baseGraph, truth, updatedClaim.evidence);

    const latest = claim.pricingModel?.estimateSnapshots?.[0];
    if (latest && paymentIsFinal && paymentDamageId) {
      const finalSnapshot: PsiEstimateSnapshot = {
        ...latest,
        id: `psi-final-paid-${Date.now()}`,
        createdAt: now,
        stage: 'final_paid',
        bracket: 'VALIDATED',
        documentedTradeCost: amount,
        reason: `Actual final payment of $${amount.toFixed(2)} recorded for the linked item. The original initial and Pass-2 estimates remain preserved in history.`,
      };
      updatedClaim = {
        ...updatedClaim,
        pricingModel: {
          lowesStoreId: claim.pricingModel?.lowesStoreId,
          zipCode: claim.pricingModel?.zipCode,
          contractorRateObservations: claim.pricingModel?.contractorRateObservations || [],
          estimateSnapshots: [finalSnapshot, ...(claim.pricingModel?.estimateSnapshots || [])].slice(0, 100),
          latestMaterialSources: claim.pricingModel?.latestMaterialSources,
          regionalMaterialDifferencePct: claim.pricingModel?.regionalMaterialDifferencePct,
          regionalLaborDifferencePct: claim.pricingModel?.regionalLaborDifferencePct,
          contingencyPct: claim.pricingModel?.contingencyPct,
        },
      };
    }

    onUpdateClaim(updatedClaim);
    setPaymentAmount(0);
    setPaymentMessage(paymentIsFinal ? 'Final payment recorded and linked monetary proposition promoted.' : 'Payment recorded without closing the linked estimate item.');
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      
      {/* Header & Recovery Math Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <DollarSign className="w-5 h-5 text-emerald-400" />
            <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
              Insurance Payout Recovery Optimizer
            </h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Reconcile carrier estimate line-by-line against the source-traced PSi reconstruction, carrier/Xactimate inputs, bracketed O&P assumptions, and documented code/permit items.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => onNavigateTab('xactimate_optimizer')}
            className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-500 hover:to-indigo-500 text-white text-xs font-semibold shadow-md shadow-sky-500/20 flex items-center gap-1.5 transition-all"
          >
            <FileSearch className="w-4 h-4" />
            <span>Open Xactimate Itemizer</span>
          </button>
          <button
            onClick={() => setShowAddModal(true)}
            className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold border border-slate-700 flex items-center gap-1.5 transition-all"
          >
            <Plus className="w-4 h-4 text-emerald-400" />
            <span>Add Disputed Item</span>
          </button>
        </div>
      </div>

      {/* Final payment / proof stage */}
      <div className="rounded-2xl border border-emerald-500/30 bg-emerald-950/10 p-4 space-y-3">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-2">
          <div>
            <div className="flex items-center gap-2 text-sm font-semibold text-emerald-300">
              <CheckCircle2 className="w-4 h-4" />
              Record Actual Payment
            </div>
            <p className="text-[11px] text-slate-400 mt-1">
              Payment itself is validated evidence. Only a payment marked final for a selected repair item closes that item's monetary proposition; it never validates unrelated damage facts.
            </p>
          </div>
          <div className="text-xs font-mono text-slate-300">
            Received to date: <span className="text-emerald-400 font-bold">${receivedTotal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          <div>
            <label className="block text-[11px] text-slate-400 mb-1">Actual amount received</label>
            <input
              type="number"
              min="0"
              step="0.01"
              value={paymentAmount || ''}
              onChange={(e) => setPaymentAmount(Number(e.target.value))}
              className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 text-xs focus:outline-none focus:border-emerald-500"
              placeholder="0.00"
            />
          </div>
          <div>
            <label className="block text-[11px] text-slate-400 mb-1">Payment proof</label>
            <select
              value={paymentEvidenceId}
              onChange={(e) => setPaymentEvidenceId(e.target.value)}
              className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 text-xs focus:outline-none focus:border-emerald-500"
            >
              <option value="">Select evidence…</option>
              {claim.evidence.map((evidence) => (
                <option key={evidence.id} value={evidence.id}>{evidence.title}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-[11px] text-slate-400 mb-1">Linked repair item</label>
            <select
              value={paymentDamageId}
              onChange={(e) => setPaymentDamageId(e.target.value)}
              className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 text-xs focus:outline-none focus:border-emerald-500"
            >
              <option value="">Claim level only</option>
              {(claim.damageInventory || []).map((item) => (
                <option key={item.id} value={item.id}>{item.component || item.statement}</option>
              ))}
            </select>
          </div>
          <div className="flex flex-col justify-end gap-2">
            <label className="flex items-center gap-2 text-[11px] text-slate-300 cursor-pointer">
              <input type="checkbox" checked={paymentIsFinal} onChange={(e) => setPaymentIsFinal(e.target.checked)} />
              Final payment for linked item
            </label>
            <button
              onClick={handleRecordPayment}
              className="px-3 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold"
            >
              Record Payment
            </button>
          </div>
        </div>
        {paymentMessage && <div className="text-[11px] text-emerald-200/90">{paymentMessage}</div>}
      </div>

      {/* 4 Core Recovery Pillars Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
        
        {/* 1. Direct Line Item Variance */}
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400">Scope Underpayment:</span>
            <span className="font-mono text-emerald-400 font-bold">
              +${directLineItemGap.toLocaleString()}
            </span>
          </div>
          <div className="text-xl font-bold text-white font-mono">
            ${totalBenchmarkRCV.toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-400 flex items-center justify-between">
            <span>Carrier Allowed:</span>
            <span className="font-mono text-slate-300">${totalCarrierRCV.toLocaleString()}</span>
          </div>
        </div>

        {/* 2. Overhead & Profit (10/10) */}
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-sky-500/30 bg-sky-950/10 space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="text-sky-300 font-semibold flex items-center gap-1">
              <Hammer className="w-3.5 h-3.5 text-sky-400" />
              GC O&P (10 & 10):
            </span>
            <span className="font-mono text-sky-300 font-bold">
              +${opAudit.totalOPAddition.toLocaleString()}
            </span>
          </div>
          <div className="text-xl font-bold text-white font-mono">
            {opAudit.qualifiesForOP ? 'DOCUMENTED ALLOWANCE' : 'REQUIRES SUPPORT'}
          </div>
          <div className="text-[11px] text-slate-400 truncate">
            Trade count is context only; O&P remains policy/rule/evidence dependent.
          </div>
        </div>

        {/* 3. Ordinance & Law (Code Upgrades) */}
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-purple-500/30 bg-purple-950/10 space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="text-purple-300 font-semibold flex items-center gap-1">
              <Scale className="w-3.5 h-3.5 text-purple-400" />
              Building Code Upgrades:
            </span>
            <span className="font-mono text-purple-300 font-bold">
              +${(claim.auditedTrueValuation?.eligibleCodeUpgrades || 0).toLocaleString()}
            </span>
          </div>
          <div className="text-xl font-bold text-white font-mono">
            {claim.policyLimits.ordinanceAndLaw_percent}% Policy Rider
          </div>
          <div className="text-[11px] text-slate-400">
            Code/permit amounts remain tied to the applicable jurisdiction and supporting authority.
          </div>
        </div>

        {/* 4. Recoverable Depreciation Clawback */}
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-amber-500/30 bg-amber-950/10 space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="text-amber-300 font-semibold flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
              Withheld Depreciation:
            </span>
            <span className="font-mono text-amber-300 font-bold">
              +${(claim.carrierOffer?.depreciationWithheld || 0).toLocaleString()}
            </span>
          </div>
          <div className="text-xl font-bold text-white font-mono">
            100% Recoverable
          </div>
          <div className="text-[11px] text-slate-400">
            Released upon contractor completion invoice.
          </div>
        </div>

      </div>

      {/* Multi-Trade Overhead & Profit (10/10) Legal Audit Box */}
      <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-sky-500/20 text-sky-400 flex items-center justify-center font-bold text-xs">
              10&10
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">General Contractor Overhead & Profit (GCO&P) Legal Audit</h3>
              <p className="text-xs text-slate-400">
                Insurance law prohibits carriers from withholding 10% Overhead and 10% Profit when multiple trades are reasonably required.
              </p>
            </div>
          </div>
          <span className="text-xs font-mono px-2.5 py-1 rounded-md bg-emerald-950/60 text-emerald-300 border border-emerald-800/60 font-semibold">
            Status: {opAudit.distinctTradeCount} Distinct Trades Identified
          </span>
        </div>

        <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 text-xs text-slate-300 space-y-2">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-slate-400 font-mono">Identified Trades:</span>
            {opAudit.trades.map((t) => (
              <span key={t} className="px-2 py-0.5 rounded bg-slate-800 text-slate-200 font-mono text-[11px]">
                ✓ {t}
              </span>
            ))}
          </div>
          <p className="text-[11px] text-slate-400 leading-relaxed pt-1 border-t border-slate-800/80">
            <span className="font-semibold text-slate-200">Precedent Citation: </span>
            {opAudit.legalJustification} (Citing <em>Trinidad v. Florida Peninsula Ins. Co.</em>, 121 So. 3d 433; holding that an insurer is liable for GCO&P when the insured is reasonably likely to need the services of a general contractor).
          </p>
        </div>
      </div>

      {/* Category Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 border-b border-slate-800">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors ${
              selectedCategory === cat
                ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60 border border-transparent'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Line-Item Discrepancy Table */}
      <div className="rounded-2xl bg-slate-900/90 border border-slate-800 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-950/80 border-b border-slate-800 text-slate-400 font-mono uppercase text-[10px]">
                <th className="py-3 px-4">Trade Category & Description</th>
                <th className="py-3 px-3 text-center">Unit / Qty</th>
                <th className="py-3 px-3 text-right">Carrier Allowed RCV</th>
                <th className="py-3 px-3 text-right">Contractor Benchmark RCV</th>
                <th className="py-3 px-3 text-right text-emerald-400">Recovery Gap</th>
                <th className="py-3 px-3 text-center">Status</th>
                <th className="py-3 px-3 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredLineItems.map((item) => {
                const gap = item.contractorBenchmarkRCV - item.carrierAllowedRCV;
                return (
                  <tr key={item.id} className="hover:bg-slate-800/40 transition-colors group">
                    <td className="py-3 px-4">
                      <div className="font-semibold text-white">{item.description}</div>
                      <div className="text-[11px] text-slate-400 flex items-center gap-2 mt-0.5">
                        <span className="px-1.5 py-0.2 rounded bg-slate-800 text-slate-300 font-mono text-[10px]">
                          {item.category}
                        </span>
                        <span>{item.disputeReason}</span>
                      </div>
                    </td>
                    <td className="py-3 px-3 text-center font-mono text-slate-300">
                      {item.quantity} {item.unit}
                    </td>
                    <td className="py-3 px-3 text-right font-mono text-slate-300">
                      ${item.carrierAllowedRCV.toLocaleString()}
                    </td>
                    <td className="py-3 px-3 text-right font-mono font-bold text-white">
                      ${item.contractorBenchmarkRCV.toLocaleString()}
                    </td>
                    <td className="py-3 px-3 text-right font-mono font-bold text-emerald-400">
                      +${gap.toLocaleString()}
                    </td>
                    <td className="py-3 px-3 text-center">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-mono ${
                          item.status === 'omitted_by_carrier'
                            ? 'bg-rose-950/60 text-rose-300 border border-rose-800/60'
                            : 'bg-amber-950/60 text-amber-300 border border-amber-800/60'
                        }`}
                      >
                        {item.status.replace('_', ' ').toUpperCase()}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-center">
                      <button
                        onClick={() => handleDeleteLineItem(item.id)}
                        className="p-1 text-slate-500 hover:text-rose-400 transition-colors rounded hover:bg-slate-800"
                        title="Delete line item"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Table Footer with Aggregate Recovery */}
        <div className="p-4 bg-slate-950/90 border-t border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
          <div className="text-slate-400">
            Showing {filteredLineItems.length} disputed line items across {opAudit.distinctTradeCount} trades
          </div>
          <div className="flex items-center gap-4 font-mono">
            <div>
              <span className="text-slate-400">Total Benchmark Scope: </span>
              <span className="font-bold text-white">${totalBenchmarkRCV.toLocaleString()}</span>
            </div>
            <div>
              <span className="text-slate-400">Net Item Gap: </span>
              <span className="font-bold text-emerald-400">+${directLineItemGap.toLocaleString()}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Add Line Item Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-lg rounded-2xl bg-slate-900 border border-slate-700 shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-white">Add Disputed Line Item</h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-white text-sm"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 mb-1 font-medium">Trade Category</label>
                <select
                  value={newLineItem.category}
                  onChange={(e) => setNewLineItem({ ...newLineItem, category: e.target.value as any })}
                  className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 focus:outline-none focus:border-sky-500"
                >
                  {categories.filter((c) => c !== 'All').map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-300 mb-1 font-medium">Item Description</label>
                <input
                  type="text"
                  placeholder="e.g. Ice & Water Shield Barrier (Florida Building Code mandate)"
                  value={newLineItem.description}
                  onChange={(e) => setNewLineItem({ ...newLineItem, description: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 focus:outline-none focus:border-sky-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 mb-1 font-medium">Quantity</label>
                  <input
                    type="number"
                    value={newLineItem.quantity}
                    onChange={(e) => setNewLineItem({ ...newLineItem, quantity: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 focus:outline-none focus:border-sky-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 mb-1 font-medium">Unit</label>
                  <input
                    type="text"
                    value={newLineItem.unit}
                    onChange={(e) => setNewLineItem({ ...newLineItem, unit: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 focus:outline-none focus:border-sky-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 mb-1 font-medium">Carrier Allowed RCV ($)</label>
                  <input
                    type="number"
                    value={newLineItem.carrierAllowedRCV}
                    onChange={(e) => setNewLineItem({ ...newLineItem, carrierAllowedRCV: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 focus:outline-none focus:border-sky-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 mb-1 font-medium">Contractor Benchmark RCV ($)</label>
                  <input
                    type="number"
                    value={newLineItem.contractorBenchmarkRCV}
                    onChange={(e) => setNewLineItem({ ...newLineItem, contractorBenchmarkRCV: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 focus:outline-none focus:border-sky-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 mb-1 font-medium">Dispute Reason / Code Reference</label>
                <textarea
                  rows={2}
                  placeholder="e.g. Omitted from initial adjuster scope; required by municipal building code."
                  value={newLineItem.disputeReason}
                  onChange={(e) => setNewLineItem({ ...newLineItem, disputeReason: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 focus:outline-none focus:border-sky-500"
                />
              </div>

              <div className="flex items-center gap-4 pt-1">
                <label className="flex items-center gap-2 cursor-pointer text-slate-300">
                  <input
                    type="checkbox"
                    checked={newLineItem.codeUpgradeRequired}
                    onChange={(e) => setNewLineItem({ ...newLineItem, codeUpgradeRequired: e.target.checked })}
                    className="rounded bg-slate-950 border-slate-700 text-sky-500 focus:ring-0"
                  />
                  <span>Code / permit item</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer text-slate-300">
                  <input
                    type="checkbox"
                    checked={newLineItem.overheadProfitApplies}
                    onChange={(e) => setNewLineItem({ ...newLineItem, overheadProfitApplies: e.target.checked })}
                    className="rounded bg-slate-950 border-slate-700 text-sky-500 focus:ring-0"
                  />
                  <span>Include O&P allowance</span>
                </label>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
              <button
                onClick={() => setShowAddModal(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium"
              >
                Cancel
              </button>
              <button
                onClick={handleAddLineItem}
                className="px-4 py-2 rounded-xl bg-sky-500 hover:bg-sky-400 text-white text-xs font-semibold shadow-md shadow-sky-500/20"
              >
                Save Line Item
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
