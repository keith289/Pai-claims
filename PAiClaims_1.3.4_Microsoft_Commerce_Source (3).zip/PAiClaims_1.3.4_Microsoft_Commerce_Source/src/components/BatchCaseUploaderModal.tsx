import React, { useState } from 'react';
import {
  X,
  Upload,
  FileText,
  Camera,
  Layers,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  FolderArchive,
  ArrowRight,
  ShieldCheck,
  Plus,
} from 'lucide-react';
import { EvidenceItem, CasePhotoItem, InsuranceClaim } from '../types';

interface BatchCaseUploaderModalProps {
  claim: InsuranceClaim;
  isOpen: boolean;
  onClose: () => void;
  onIngestFiles: (
    newDocs: EvidenceItem[],
    newPhotos: CasePhotoItem[]
  ) => void;
  initialCategory?: string;
}

export const BatchCaseUploaderModal: React.FC<BatchCaseUploaderModalProps> = ({
  claim,
  isOpen,
  onClose,
  onIngestFiles,
  initialCategory,
}) => {
  const [activeMode, setActiveMode] = useState<'custom_upload' | 'preset_bundles'>('custom_upload');
  const [uploadType, setUploadType] = useState<'document' | 'photo'>('document');
  
  // Custom Doc Form
  const [docTitle, setDocTitle] = useState('');
  const [docType, setDocType] = useState<EvidenceItem['type']>('contractor_estimate');
  const [docSource, setDocSource] = useState('');
  const [docExcerpt, setDocExcerpt] = useState('');
  const [docAmount, setDocAmount] = useState<number>(0);

  // Custom Photo Form
  const [photoTitle, setPhotoTitle] = useState('');
  const [photoCategory, setPhotoCategory] = useState<CasePhotoItem['category']>(
    (initialCategory as any) || 'Roof & Slopes'
  );
  const [photoCaption, setPhotoCaption] = useState('');
  const [photoTags, setPhotoTags] = useState('Wind Damage, Mat Fracture, Shingle Lift');
  const [photoCameraAngle, setPhotoCameraAngle] = useState('45-Degree Oblique with Pitch Gauge');

  // Drag & drop state
  const [isDragging, setIsDragging] = useState(false);
  const [uploadedFilesCount, setUploadedFilesCount] = useState(0);

  if (!isOpen) return null;

  const handleCustomSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (uploadType === 'document') {
      if (!docTitle) return;
      const newDoc: EvidenceItem = {
        id: `ev-cust-${Date.now()}`,
        title: docTitle,
        type: docType,
        filename: `${docTitle.replace(/\s+/g, '_')}.pdf`,
        date: new Date().toISOString().split('T')[0],
        source: docSource || 'Policyholder Upload',
        provenanceRoot: docSource ? `${docSource} Certified Record` : 'Independent Third-Party Record',
        evidenceLevel: docType === 'engineer_report' || docType === 'policy_dec' ? 'direct' : 'structural',
        stance: docType === 'denial_letter' ? 'contradicts' : 'supports',
        bracketState: docType === 'denial_letter' ? 'CONTRADICTED' : 'VALIDATED',
        excerpt: docExcerpt || 'Verified document ingested into case evidentiary vault.',
        rawText: docExcerpt || 'Ingested via PAi Evidence Scanner.',
        amountAssociated: Number(docAmount) || 0,
        floatPoints: 18,
        mixPoints: 12,
        stirPoints: 4,
        totalPressure: 34.0,
        keyObservations: ['Document indexed for AI Case Completeness Audit'],
      };
      onIngestFiles([newDoc], []);
    } else {
      if (!photoTitle) return;
      const newPhoto: CasePhotoItem = {
        id: `ph-cust-${Date.now()}`,
        title: photoTitle,
        category: photoCategory,
        dateTaken: new Date().toISOString().split('T')[0],
        caption: photoCaption || 'Direct physical loss captured on inspection.',
        damageTags: photoTags.split(',').map((t) => t.trim()).filter(Boolean),
        source: 'Policyholder / Contractor Photo Log',
        cameraAngle: photoCameraAngle,
        isVerified: true,
        elevation: 'Primary Structure',
      };
      onIngestFiles([], [newPhoto]);
    }

    onClose();
  };

  const handleLoadPresetBundle = (bundleType: 'roof_bundle' | 'water_bundle') => {
    if (bundleType === 'roof_bundle') {
      const docs: EvidenceItem[] = [
        {
          id: `ev-bundle-01-${Date.now()}`,
          title: 'Building Department 25% Full Replacement Code Mandate Letter',
          type: 'policy_dec',
          filename: 'City_Building_Inspection_25Percent_Rule_Mandate.pdf',
          date: '2024-09-22',
          source: 'City Chief Building Inspector',
          provenanceRoot: 'Municipal Code Authority Certified Memo',
          evidenceLevel: 'direct',
          stance: 'supports',
          bracketState: 'VALIDATED',
          excerpt: 'Pursuant to Florida Building Code §1511.1.1, as the damage exceeds 25% of the total roof system area within 12 months, spot repairs are prohibited. A 100% full replacement permit is required.',
          rawText: 'Official Notice: The subject property roof suffered widespread wind damage exceeding 25%. Repairing only isolated shingles fails municipal code. Entire roof must be brought to current code.',
          amountAssociated: 38500,
          floatPoints: 22,
          mixPoints: 18,
          stirPoints: 8,
          totalPressure: 48.0,
          keyObservations: ['Unlocks Ordinance & Law 25% coverage ($112,500)', 'Legally invalidates carrier spot repair allowance'],
        },
        {
          id: `ev-bundle-02-${Date.now()}`,
          title: 'ITEL Laboratory Shingle Discontinuance & Match Failure Report',
          type: 'engineer_report',
          filename: 'ITEL_Certified_Shingle_Discontinuance_Analysis.pdf',
          date: '2024-09-25',
          source: 'ITEL Laboratories Inc. (Certified Match Lab)',
          provenanceRoot: 'Certified Independent Material Laboratory',
          evidenceLevel: 'direct',
          stance: 'supports',
          bracketState: 'VALIDATED',
          excerpt: 'Subject shingle is a discontinued CertainTeed Horizon 3-Tab product with metric 39-3/8" length. No current manufacturer produces compatible dimensions. Uniform matching requires full plane replacement.',
          rawText: 'ITEL Sample ID: ITEL-2024-99812. Dimensions: 12" x 39-3/8". Status: Discontinued 2012. Compatible match: NONE. Attempting to tie in modern shingles creates defective unsealed joints.',
          amountAssociated: 24800,
          floatPoints: 26,
          mixPoints: 20,
          stirPoints: 10,
          totalPressure: 56.0,
          keyObservations: ['Proves physical impossibility of spot repairs', 'Triggers state statutory matching requirement'],
        },
      ];

      const photos: CasePhotoItem[] = [
        {
          id: `ph-bundle-01-${Date.now()}`,
          title: 'Attic Interior Decking Water Staining & Daylight Through Hail Fracture',
          category: 'Attic & Sheathing',
          dateTaken: '2024-09-18',
          caption: 'Severe water staining across OSB roof decking rafters directly under compromised valley. Proves direct exterior water penetration into structural envelope.',
          damageTags: ['Attic Decking Leak', 'Wet Rafters', 'Structural Penetration', 'Refutes Wear and Tear'],
          source: 'Apex Forensic PE Inspection Photo Log',
          cameraAngle: 'Attic Interior Upward Elevation',
          isVerified: true,
          elevation: 'Attic Space Above Master Bedroom',
        },
        {
          id: 'ph-bundle-02',
          title: 'Eave Starter Course Absence & Ice/Water Shield Code Defect',
          category: 'Code & Municipal',
          dateTaken: '2024-09-20',
          caption: 'IRC R905.2.8.5 code inspection reveals missing starter strip adhesive seal and missing drip edge overhang, requiring full code upgrade allowance.',
          damageTags: ['Code Violation', 'IRC R905.2.8.5', 'Drip Edge Mandate', 'Ordinance & Law'],
          source: 'Precision Build GC Forensic Audit',
          cameraAngle: 'Macro Eave Profile',
          isVerified: true,
          elevation: 'North Eave Line',
        },
      ];

      onIngestFiles(docs, photos);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl p-6 space-y-5">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-sky-500/20 border border-sky-500/40 text-sky-400">
              <FolderArchive className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white tracking-tight">
                Case Evidence & Photo Ingestion
              </h3>
              <p className="text-xs text-slate-400">
                Load documents, forensic engineering reports, and damage photos to build your case dossier.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Mode Switcher Tabs */}
        <div className="grid grid-cols-2 gap-2 bg-slate-950 p-1 rounded-xl border border-slate-800">
          <button
            onClick={() => setActiveMode('custom_upload')}
            className={`py-2 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 ${
              activeMode === 'custom_upload'
                ? 'bg-sky-500 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Custom File / Photo Ingestion</span>
          </button>

          <button
            onClick={() => setActiveMode('preset_bundles')}
            className={`py-2 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 ${
              activeMode === 'preset_bundles'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>1-Click Forensic Case Bundles</span>
          </button>
        </div>

        {/* 1. Custom File / Photo Ingestion */}
        {activeMode === 'custom_upload' && (
          <form onSubmit={handleCustomSubmit} className="space-y-4">
            
            {/* Type selector (Document vs Photo) */}
            <div className="flex items-center gap-3">
              <label className="text-xs font-semibold text-slate-300">Artifact Type:</label>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setUploadType('document')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 border transition-all ${
                    uploadType === 'document'
                      ? 'bg-sky-500/20 text-sky-300 border-sky-500/50'
                      : 'bg-slate-950 text-slate-400 border-slate-800'
                  }`}
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>Document (PDF / Scan)</span>
                </button>

                <button
                  type="button"
                  onClick={() => setUploadType('photo')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 border transition-all ${
                    uploadType === 'photo'
                      ? 'bg-indigo-500/20 text-indigo-300 border-indigo-500/50'
                      : 'bg-slate-950 text-slate-400 border-slate-800'
                  }`}
                >
                  <Camera className="w-3.5 h-3.5" />
                  <span>Damage Photo (JPG / PNG)</span>
                </button>
              </div>
            </div>

            {/* Drag and Drop Zone */}
            <div
              onDragOver={(e) => {
                e.preventDefault();
                setIsDragging(true);
              }}
              onDragLeave={() => setIsDragging(false)}
              onDrop={(e) => {
                e.preventDefault();
                setIsDragging(false);
                if (e.dataTransfer.files.length > 0) {
                  const file = e.dataTransfer.files[0];
                  if (uploadType === 'document') {
                    setDocTitle(file.name.replace(/\.[^/.]+$/, ''));
                  } else {
                    setPhotoTitle(file.name.replace(/\.[^/.]+$/, ''));
                  }
                  setUploadedFilesCount(e.dataTransfer.files.length);
                }
              }}
              className={`p-6 rounded-xl border-2 border-dashed text-center transition-all cursor-pointer ${
                isDragging
                  ? 'border-sky-400 bg-sky-500/10'
                  : 'border-slate-800 bg-slate-950/60 hover:border-slate-700'
              }`}
              onClick={() => {
                const dummyName = uploadType === 'document' 
                  ? 'Independent_Forensic_Loss_Report.pdf' 
                  : 'Attic_Decking_Moisture_Intrusion_Angle.jpg';
                if (uploadType === 'document') {
                  setDocTitle('Certified Loss & Structural Assessment');
                  setDocExcerpt('Forensic inspection verifies storm-induced uplift and physical water intrusion.');
                } else {
                  setPhotoTitle('Attic Rafter Water Staining & Moisture Markings');
                  setPhotoCaption('Direct physical water stains on underside of plywood decking above master suite.');
                }
              }}
            >
              <Upload className="w-8 h-8 text-slate-500 mx-auto mb-2" />
              <div className="text-xs font-bold text-slate-200">
                Drag and drop files here, or click to browse
              </div>
              <p className="text-[11px] text-slate-400 mt-1">
                Supports PDF, DOCX, JPG, PNG, WEBP, and HEIC inspection files (up to 50MB)
              </p>
            </div>

            {/* Document Specific Fields */}
            {uploadType === 'document' ? (
              <div className="space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Document Title *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Apex Forensic PE Causation Report"
                      value={docTitle}
                      onChange={(e) => setDocTitle(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-200 text-xs focus:outline-none focus:border-sky-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Document Type
                    </label>
                    <select
                      value={docType}
                      onChange={(e) => setDocType(e.target.value as any)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-200 text-xs focus:outline-none focus:border-sky-500"
                    >
                      <option value="policy_dec">Policy Declarations & Endorsements</option>
                      <option value="engineer_report">Forensic Engineering (PE) Report</option>
                      <option value="contractor_estimate">Contractor Estimate (Xactimate)</option>
                      <option value="denial_letter">Carrier Denial / Partial Payment Letter</option>
                      <option value="weather_data">NOAA Doppler Radar & Weather Log</option>
                      <option value="proof_of_loss">Sworn Statement in Proof of Loss</option>
                      <option value="receipts_ale">ALE & Mitigation Invoices</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Issuing Source / Author
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Apex Structural PE #58190"
                      value={docSource}
                      onChange={(e) => setDocSource(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-200 text-xs focus:outline-none focus:border-sky-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Associated Amount ($ RCV / Gap)
                    </label>
                    <input
                      type="number"
                      placeholder="e.g. 48500"
                      value={docAmount || ''}
                      onChange={(e) => setDocAmount(Number(e.target.value))}
                      className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-200 text-xs focus:outline-none focus:border-sky-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Key Excerpt / OCR Summary Notes
                  </label>
                  <textarea
                    rows={2}
                    placeholder="Enter key findings, building code citations, or coverage clause excerpts..."
                    value={docExcerpt}
                    onChange={(e) => setDocExcerpt(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-200 text-xs focus:outline-none focus:border-sky-500"
                  />
                </div>
              </div>
            ) : (
              /* Photo Specific Fields */
              <div className="space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Photo Title *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Attic Rafter Water Stain & Plywood Saturation"
                      value={photoTitle}
                      onChange={(e) => setPhotoTitle(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-200 text-xs focus:outline-none focus:border-indigo-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Damage Category
                    </label>
                    <select
                      value={photoCategory}
                      onChange={(e) => setPhotoCategory(e.target.value as any)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-200 text-xs focus:outline-none focus:border-indigo-500"
                    >
                      <option value="Attic & Sheathing">Attic & Sheathing (Critical Gap)</option>
                      <option value="Roof & Slopes">Roof & Slopes (Test Squares)</option>
                      <option value="Interior & Ceilings">Interior & Ceilings</option>
                      <option value="Water Line & Moisture">Water Line & Moisture Readings</option>
                      <option value="Exterior Elevations">Exterior Elevations & Siding</option>
                      <option value="HVAC & Electrical">HVAC & Mechanical Equipment</option>
                      <option value="Code & Municipal">Building Code Violations & Drip Edge</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Forensic Damage Caption
                  </label>
                  <textarea
                    rows={2}
                    placeholder="Describe specific damage shown, impact measurements, and water infiltration path..."
                    value={photoCaption}
                    onChange={(e) => setPhotoCaption(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-200 text-xs focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Diagnostic Damage Tags (Comma separated)
                    </label>
                    <input
                      type="text"
                      value={photoTags}
                      onChange={(e) => setPhotoTags(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-200 text-xs focus:outline-none focus:border-indigo-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Camera Angle / Lens Distance
                    </label>
                    <input
                      type="text"
                      value={photoCameraAngle}
                      onChange={(e) => setPhotoCameraAngle(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-200 text-xs focus:outline-none focus:border-indigo-500"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Action Buttons */}
            <div className="pt-3 border-t border-slate-800 flex items-center justify-end gap-2.5">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded-xl bg-gradient-to-r from-sky-500 to-indigo-600 hover:from-sky-400 hover:to-indigo-500 text-white text-xs font-semibold shadow-md shadow-sky-500/20 flex items-center gap-1.5"
              >
                <Plus className="w-4 h-4" />
                <span>Ingest Into Case Dossier</span>
              </button>
            </div>

          </form>
        )}

        {/* 2. One-Click Forensic Case Bundles */}
        {activeMode === 'preset_bundles' && (
          <div className="space-y-4">
            <p className="text-xs text-slate-300">
              Instantly ingest complete, pre-configured forensic evidentiary packages to test AI case completeness auditing:
            </p>

            <div className="grid grid-cols-1 gap-3">
              
              {/* Bundle 1 */}
              <div className="p-4 rounded-xl bg-slate-950/80 border border-indigo-500/30 hover:border-indigo-500/60 transition-all space-y-3">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/40">
                        ROOF & STORM DAMAGE PACK
                      </span>
                      <span className="text-xs font-semibold text-emerald-400">+2 Key Evidence Items</span>
                    </div>
                    <h4 className="text-sm font-bold text-white mt-1">
                      Attic Intrusion & Municipal Code 25% Rule Bundle
                    </h4>
                    <p className="text-xs text-slate-400 mt-0.5">
                      Includes certified City Building Department 25% Full Replacement Mandate memo, ITEL Laboratory Shingle Discontinuance Report, and Attic Decking Moisture Photos.
                    </p>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-slate-800 text-xs">
                  <span className="text-slate-400 font-mono text-[11px]">
                    Closes 2 Critical Vulnerability Gaps (+24% Case Score)
                  </span>
                  <button
                    type="button"
                    onClick={() => handleLoadPresetBundle('roof_bundle')}
                    className="px-3.5 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center gap-1.5 shadow-sm transition-all"
                  >
                    <span>Load Bundle Into Case</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

            </div>
          </div>
        )}

      </div>
    </div>
  );
};
