import React from 'react';
import {
  ShieldCheck, Cloud, HardDrive, Check, AlertCircle, Loader2, Trash2,
  Play, Square, KeyRound, ExternalLink, Download,
} from 'lucide-react';

/**
 * AI setup. Two routes, presented as equals:
 *
 *   Private   - llama.cpp runs on this machine, nothing leaves the device.
 *               Costs a model download.
 *   API key   - a hosted provider. Works immediately, no download, but claim
 *               content you submit is sent to that provider.
 *
 * Neither is forced. The app's deterministic features work with no AI at all,
 * and this screen says so rather than blocking the user until they pick.
 */

type ProviderId = 'local' | 'gemini' | 'anthropic' | 'openai' | 'openai-compatible';

interface ProviderInfo {
  id: ProviderId;
  label: string;
  note: string;
  needsKey: boolean;
  defaultModel: string;
  keyUrl?: string;
  sendsDataOffDevice: boolean;
}

interface CatalogOption {
  id: string;
  label: string;
  file: string;
  downloadGB: number;
  minRamGB: number;
  licence: string;
  note: string;
  fits: boolean;
  reason: string;
}

interface Props {
  onDone?: () => void;
  /** True on first run: shows the "skip for now" affordance. */
  firstRun?: boolean;
}

const API = ''; // same-origin: works on dev port and packaged random loopback port

const card = 'rounded-xl border bg-slate-900/90 border-slate-800 text-slate-200';
const label = 'text-xs font-semibold uppercase tracking-wider text-slate-400 font-mono';

export const AISetupView: React.FC<Props> = ({ onDone, firstRun = false }) => {
  const [route, setRoute] = React.useState<'choose' | 'private' | 'api'>(
    firstRun ? 'choose' : 'choose'
  );
  const [providers, setProviders] = React.useState<ProviderInfo[]>([]);
  const [active, setActive] = React.useState<ProviderId>('local');
  const [busy, setBusy] = React.useState<string>('');
  const [message, setMessage] = React.useState<{ ok: boolean; text: string } | null>(null);

  // --- private runtime state
  const [status, setStatus] = React.useState<any>(null);
  const [recommend, setRecommend] = React.useState<any>(null);
  const [progress, setProgress] = React.useState<{ pct: number; text: string } | null>(null);

  // --- api key state
  const [keyProvider, setKeyProvider] = React.useState<ProviderId>('anthropic');
  const [apiKey, setApiKey] = React.useState('');
  const [model, setModel] = React.useState('');
  const [baseUrl, setBaseUrl] = React.useState('');
  const [hasKey, setHasKey] = React.useState<Record<string, boolean>>({});
  const [cloudConsent, setCloudConsent] = React.useState(false);

  const desktop = (window as any).paiDesktop;

  const refresh = React.useCallback(async () => {
    try {
      const [p, s, r] = await Promise.all([
        fetch(API + '/api/ai/providers').then((x) => x.json()),
        fetch(API + '/api/ai/local/status').then((x) => x.json()),
        fetch(API + '/api/ai/local/recommend').then((x) => x.json()),
      ]);
      setProviders(p.providers || []);
      setActive(p.active?.id || 'local');
      setStatus(s);
      setRecommend(r);
      if (desktop?.getAIConfig) {
        const cfg = await desktop.getAIConfig();
        setHasKey(cfg.hasKey || {});
        setCloudConsent(cfg.cloudConsent === true);
      }
    } catch (e: any) {
      setMessage({ ok: false, text: `Could not read AI settings: ${e.message}` });
    }
  }, [desktop]);

  React.useEffect(() => {
    refresh();
  }, [refresh]);

  /* ---------------------------------------------------------- private */

  async function downloadModel(id: string) {
    setBusy('download');
    setProgress({ pct: 0, text: 'Starting download' });
    setMessage(null);
    try {
      const res = await fetch(API + '/api/ai/local/download', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ model: id }),
      });
      const reader = res.body!.getReader();
      const dec = new TextDecoder();
      let buf = '';
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buf += dec.decode(value, { stream: true });
        const lines = buf.split('\n\n');
        buf = lines.pop() || '';
        for (const l of lines) {
          if (!l.startsWith('data: ')) continue;
          const p = JSON.parse(l.slice(6));
          if (p.error) {
            setMessage({ ok: false, text: p.error });
            setProgress(null);
            setBusy('');
            return;
          }
          const gb = p.total ? (p.completed / 1024 ** 3).toFixed(1) : null;
          const totGb = p.total ? (p.total / 1024 ** 3).toFixed(1) : null;
          setProgress({
            pct: p.percent ?? 0,
            text: gb ? `${gb} of ${totGb} GB` : p.status,
          });
          if (p.done) {
            setMessage({ ok: true, text: 'Model installed. Start the runtime to use it.' });
            setProgress(null);
          }
        }
      }
    } catch (e: any) {
      setMessage({ ok: false, text: `Download failed: ${e.message}` });
      setProgress(null);
    }
    setBusy('');
    refresh();
  }

  async function startRuntime(modelPath: string) {
    setBusy('start');
    setMessage({ ok: true, text: 'Loading model. This can take up to a minute.' });
    const r = await fetch(API + '/api/ai/local/start', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ modelPath }),
    }).then((x) => x.json());
    setMessage(
      r.ok
        ? { ok: true, text: 'Running on this device. Nothing is sent to any external service.' }
        : { ok: false, text: r.error || 'Could not start the local runtime.' }
    );
    if (r.ok) {
      await desktop?.setAIConfig?.({ provider: 'local' });
      await fetch(API + '/api/ai/config', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ provider: 'local' }),
      });
    }
    setBusy('');
    refresh();
  }

  async function stopRuntime() {
    setBusy('stop');
    await fetch(API + '/api/ai/local/stop', { method: 'POST' });
    setBusy('');
    setMessage(null);
    refresh();
  }

  async function deleteModel(file: string) {
    setBusy('delete');
    await fetch(API + '/api/ai/local/model', {
      method: 'DELETE',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ file }),
    });
    setBusy('');
    refresh();
  }

  /* -------------------------------------------------------------- api */

  async function saveKey() {
    setBusy('save');
    setMessage(null);
    const cfg = {
      provider: keyProvider,
      apiKey: apiKey || undefined,
      model: model || undefined,
      baseUrl: baseUrl || undefined,
      cloudConsent,
    };
    // Persist in Electron when available, and always apply to the running
    // loopback server. In electron:dev the server is a separate process, so
    // IPC alone cannot update its environment.
    await desktop?.setAIConfig?.(cfg);
    await fetch(API + '/api/ai/config', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(cfg),
    });
    const t = await fetch(API + '/api/ai/test', { method: 'POST' }).then((x) => x.json());
    setMessage(
      t.ok
        ? { ok: true, text: `Connected. ${t.detail}` }
        : { ok: false, text: t.detail || 'Could not reach the provider.' }
    );
    setApiKey('');
    setBusy('');
    refresh();
  }

  async function disableCloudAI() {
    setBusy('disable-cloud');
    setMessage(null);
    await desktop?.setAIConfig?.({ provider: 'local', cloudConsent: false, clearCloudKeys: true });
    await fetch(API + '/api/ai/config', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ provider: 'local', apiKey: '' }),
    });
    setCloudConsent(false);
    setApiKey('');
    setMessage({ ok: true, text: 'Cloud AI is disabled and saved hosted-provider keys were removed.' });
    setBusy('');
    refresh();
  }

  /* ------------------------------------------------------------- ui */

  const cloud = providers.filter((p) => p.id !== 'local');
  const selected = cloud.find((p) => p.id === keyProvider);

  return (
    <div className="p-6 space-y-5 max-w-4xl">
      <div>
        <h2 className="text-xl font-semibold text-slate-100">AI setup</h2>
        <p className="text-sm text-slate-400 mt-1">
          Estimating, quantities, pricing and comparison run without AI. AI only reads
          documents, organises evidence and drafts narrative — it never produces a
          quantity, price or rate.
        </p>
      </div>

      {message && (
        <div
          className={`flex items-start gap-2 p-3 rounded-lg border text-sm ${
            message.ok
              ? 'bg-emerald-950/50 border-emerald-800 text-emerald-200'
              : 'bg-rose-950/50 border-rose-800 text-rose-200'
          }`}
        >
          {message.ok ? (
            <Check className="w-4 h-4 mt-0.5 shrink-0" />
          ) : (
            <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
          )}
          <span>{message.text}</span>
        </div>
      )}

      {/* ---- route chooser ---- */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <button
          onClick={() => setRoute('private')}
          className={`${card} p-5 text-left transition hover:border-sky-700 ${
            route === 'private' ? 'border-sky-600 ring-1 ring-sky-900' : ''
          }`}
        >
          <div className="flex items-center gap-2 mb-2">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            <span className="font-semibold text-slate-100">Private — on this device</span>
          </div>
          <p className="text-sm text-slate-400">
            Runs locally. No claim content leaves this machine, and there is no
            per-use cost. Requires a one-time model download of 2–9 GB.
          </p>
          {status?.running && (
            <span className="inline-flex items-center gap-1 mt-3 text-[11px] font-mono text-emerald-400">
              <Check className="w-3 h-3" /> running
            </span>
          )}
        </button>

        <button
          onClick={() => setRoute('api')}
          className={`${card} p-5 text-left transition hover:border-sky-700 ${
            route === 'api' ? 'border-sky-600 ring-1 ring-sky-900' : ''
          }`}
        >
          <div className="flex items-center gap-2 mb-2">
            <Cloud className="w-5 h-5 text-sky-400" />
            <span className="font-semibold text-slate-100">Use an API key</span>
          </div>
          <p className="text-sm text-slate-400">
            Works straight away with no download, and is faster on modest hardware.
            Claim content you submit is sent to that provider, and you pay them per use.
          </p>
          {active !== 'local' && (
            <span className="inline-flex items-center gap-1 mt-3 text-[11px] font-mono text-sky-400">
              <Check className="w-3 h-3" /> {active} active
            </span>
          )}
        </button>
      </div>

      {/* ---- private ---- */}
      {route === 'private' && (
        <div className={`${card} p-5 space-y-4`}>
          <div className="flex items-center justify-between">
            <h3 className={label}>Local runtime</h3>
            <span className="text-[11px] font-mono text-slate-500">
              {recommend ? `${recommend.totalRamGB} GB RAM · ${recommend.cpus} CPUs` : ''}
            </span>
          </div>

          <p className="text-sm text-slate-400">{status?.nextStep}</p>

          {status?.models?.length > 0 && (
            <div className="space-y-2">
              <h4 className={label}>Installed</h4>
              {status.models.map((m: any) => (
                <div
                  key={m.file}
                  className="flex items-center justify-between p-3 rounded-lg bg-slate-950/60 border border-slate-800"
                >
                  <div className="min-w-0">
                    <div className="text-sm text-slate-200 truncate">{m.label || m.file}</div>
                    <div className="text-[11px] font-mono text-slate-500">
                      {(m.sizeBytes / 1024 ** 3).toFixed(1)} GB
                    </div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    {status.running && status.loadedModel === m.path ? (
                      <button
                        onClick={stopRuntime}
                        disabled={!!busy}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs bg-slate-800 hover:bg-slate-700 text-slate-200"
                      >
                        <Square className="w-3 h-3" /> Stop
                      </button>
                    ) : (
                      <button
                        onClick={() => startRuntime(m.path)}
                        disabled={!!busy}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs bg-emerald-700 hover:bg-emerald-600 text-white disabled:opacity-50"
                      >
                        {busy === 'start' ? (
                          <Loader2 className="w-3 h-3 animate-spin" />
                        ) : (
                          <Play className="w-3 h-3" />
                        )}
                        Start
                      </button>
                    )}
                    <button
                      onClick={() => deleteModel(m.file)}
                      disabled={!!busy || status.running}
                      title={status.running ? 'Stop the runtime first' : 'Delete model'}
                      className="p-1.5 rounded-md text-slate-500 hover:text-rose-400 hover:bg-slate-800 disabled:opacity-40"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {progress && (
            <div className="space-y-1.5">
              <div className="h-2 rounded bg-slate-800 overflow-hidden">
                <div
                  className="h-full bg-sky-500 transition-all"
                  style={{ width: `${progress.pct}%` }}
                />
              </div>
              <div className="flex justify-between text-[11px] font-mono text-slate-400">
                <span>{progress.text}</span>
                <span>{progress.pct}%</span>
              </div>
            </div>
          )}

          <div className="space-y-2">
            <h4 className={label}>Available models</h4>
            {recommend?.options?.map((o: CatalogOption) => {
              const installed = status?.models?.some((m: any) => m.file === o.file);
              return (
                <div
                  key={o.id}
                  className={`p-3 rounded-lg border ${
                    o.fits ? 'bg-slate-950/60 border-slate-800' : 'bg-slate-950/30 border-slate-900'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-slate-200">{o.label}</span>
                        {recommend.recommended === o.id && (
                          <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-emerald-900/60 text-emerald-300 border border-emerald-800">
                            recommended
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-500 mt-1">{o.note}</p>
                      <p className="text-[11px] font-mono text-slate-600 mt-1">
                        {o.downloadGB} GB download · {o.licence}
                      </p>
                      {!o.fits && (
                        <p className="text-[11px] text-amber-500/90 mt-1">{o.reason}</p>
                      )}
                    </div>
                    <button
                      onClick={() => downloadModel(o.id)}
                      disabled={!!busy || installed || !o.fits}
                      className="shrink-0 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs bg-sky-700 hover:bg-sky-600 text-white disabled:opacity-40"
                    >
                      {installed ? (
                        <>
                          <Check className="w-3 h-3" /> Installed
                        </>
                      ) : (
                        <>
                          <Download className="w-3 h-3" /> Download
                        </>
                      )}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ---- api key ---- */}
      {route === 'api' && (
        <div className={`${card} p-5 space-y-4`}>
          <h3 className={label}>Provider</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {cloud.map((p) => (
              <button
                key={p.id}
                onClick={() => setKeyProvider(p.id)}
                className={`p-3 rounded-lg border text-left ${
                  keyProvider === p.id
                    ? 'bg-slate-800 border-sky-700'
                    : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-sm text-slate-200">{p.label}</span>
                  {hasKey[p.id] && <Check className="w-3.5 h-3.5 text-emerald-400" />}
                </div>
                <p className="text-[11px] text-slate-500 mt-1">{p.note}</p>
              </button>
            ))}
          </div>

          <div className="space-y-3">
            <div>
              <label className={label}>API key</label>
              <div className="flex gap-2 mt-1.5">
                <div className="relative flex-1">
                  <KeyRound className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-600" />
                  <input
                    type="password"
                    value={apiKey}
                    onChange={(e) => setApiKey(e.target.value)}
                    placeholder={hasKey[keyProvider] ? 'A key is saved. Enter a new one to replace it.' : 'Paste your key'}
                    className="w-full pl-9 pr-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-sm text-slate-200 placeholder:text-slate-600 focus:outline-none focus:border-sky-700"
                  />
                </div>
                {selected?.keyUrl && (
                  <a
                    href={selected.keyUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs bg-slate-800 hover:bg-slate-700 text-slate-300"
                  >
                    Get a key <ExternalLink className="w-3 h-3" />
                  </a>
                )}
              </div>
              <p className="text-[11px] text-slate-500 mt-1.5">
                Stored on this machine only, never inside the app package.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className={label}>Model (optional)</label>
                <input
                  value={model}
                  onChange={(e) => setModel(e.target.value)}
                  placeholder={selected?.defaultModel || ''}
                  className="w-full mt-1.5 px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-sm text-slate-200 placeholder:text-slate-600 focus:outline-none focus:border-sky-700"
                />
              </div>
              {keyProvider === 'openai-compatible' && (
                <div>
                  <label className={label}>Base URL</label>
                  <input
                    value={baseUrl}
                    onChange={(e) => setBaseUrl(e.target.value)}
                    placeholder="https://api.groq.com/openai/v1"
                    className="w-full mt-1.5 px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-sm text-slate-200 placeholder:text-slate-600 focus:outline-none focus:border-sky-700"
                  />
                </div>
              )}
            </div>

            <label className="flex items-start gap-2 rounded-lg border border-slate-800 bg-slate-950/60 p-3 text-xs text-slate-300">
              <input
                type="checkbox"
                checked={cloudConsent}
                onChange={(e) => setCloudConsent(e.target.checked)}
                className="mt-0.5"
              />
              <span>
                I consent to sending the claim content I submit to the selected hosted AI provider for processing. I can revoke this consent and remove saved provider keys at any time.
              </span>
            </label>

            <div className="flex flex-wrap gap-2">
              <button
                onClick={saveKey}
                disabled={!!busy || !cloudConsent || (!apiKey && !hasKey[keyProvider])}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-lg text-sm bg-sky-700 hover:bg-sky-600 text-white disabled:opacity-40"
              >
                {busy === 'save' ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
                Save and test
              </button>
              {(active !== 'local' || Object.values(hasKey).some(Boolean)) && (
                <button
                  onClick={disableCloudAI}
                  disabled={!!busy}
                  className="px-4 py-2 rounded-lg text-sm bg-slate-800 hover:bg-slate-700 text-slate-300 disabled:opacity-40"
                >
                  Disable cloud AI & remove keys
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {firstRun && (
        <div className="flex items-center justify-between pt-2 border-t border-slate-800">
          <p className="text-xs text-slate-500">
            You can set this up later. Estimating and comparison work without AI.
          </p>
          <button
            onClick={onDone}
            className="px-4 py-2 rounded-lg text-sm bg-slate-800 hover:bg-slate-700 text-slate-200"
          >
            {status?.running || active !== 'local' ? 'Continue to PAi Claims' : 'Skip for now'}
          </button>
        </div>
      )}
    </div>
  );
};

export default AISetupView;
