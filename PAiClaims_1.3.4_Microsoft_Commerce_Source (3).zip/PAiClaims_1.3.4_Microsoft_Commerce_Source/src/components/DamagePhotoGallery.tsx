import React, { useRef, useState } from 'react';
import { Camera, Upload, Search, Plus, Maximize2, Calendar, Loader2, Sparkles, ShieldCheck } from 'lucide-react';
import type { CasePhotoItem, EvidenceItem, InsuranceClaim } from '../types';
import { buildClaimGraph } from '../domain/claimGraph';
import { inventoryTotals } from '../domain/claimEstimateFlow';

interface DamagePhotoGalleryProps {
  photos: CasePhotoItem[];
  claim: InsuranceClaim;
  onAddPhoto: (photo: CasePhotoItem) => void;
  onUpdateClaim?: (claim: InsuranceClaim) => void;
  onOpenUploadModal: () => void;
}

async function sha256(file: File) {
  const digest = await crypto.subtle.digest('SHA-256', await file.arrayBuffer());
  return [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, '0')).join('');
}

function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ''));
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

export const DamagePhotoGallery: React.FC<DamagePhotoGalleryProps> = ({ photos, claim, onAddPhoto, onUpdateClaim, onOpenUploadModal }) => {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [lightboxPhoto, setLightboxPhoto] = useState<CasePhotoItem | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [message, setMessage] = useState('');
  const fileRef = useRef<HTMLInputElement>(null);

  const categories = ['all','Roof & Slopes','Attic & Sheathing','Interior & Ceilings','Water Line & Moisture','Exterior Elevations','HVAC & Electrical','Contents & Personal Property','Code & Municipal'];
  const filteredPhotos = photos.filter((photo) => (selectedCategory === 'all' || photo.category === selectedCategory) && [photo.title, photo.caption, ...photo.damageTags].join(' ').toLowerCase().includes(searchQuery.toLowerCase()));
  const totals = inventoryTotals(claim.damageInventory || []);

  const uploadAndAnalyze = async (files: FileList | null) => {
    if (!files?.length || !onUpdateClaim) return;
    setAnalyzing(true); setMessage('Preparing photos…');
    try {
      const batchPhotos: CasePhotoItem[] = [];
      const batchEvidence: EvidenceItem[] = [];
      const payload: Array<{ evidenceId: string; dataUrl: string; filename: string }> = [];
      for (const file of Array.from(files).slice(0, 12)) {
        const [hash, dataUrl] = await Promise.all([sha256(file), fileToDataUrl(file)]);
        const id = `photo-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
        const evidenceId = `ev-${id}`;
        const photo: CasePhotoItem = {
          id,
          evidenceId,
          contentHash: hash,
          dataUrl,
          url: dataUrl,
          thumbnail: dataUrl,
          title: file.name,
          category: 'Roof & Slopes',
          dateTaken: new Date(file.lastModified || Date.now()).toISOString(),
          caption: 'Uploaded damage photograph awaiting PAi analysis.',
          damageTags: ['unreviewed'],
          source: 'User photo upload',
          isVerified: false,
        };
        const evidence: EvidenceItem = {
          id: evidenceId,
          title: `Damage photo — ${file.name}`,
          type: 'photo_log',
          filename: file.name,
          date: new Date(file.lastModified || Date.now()).toISOString(),
          source: 'User photo upload',
          provenanceRoot: `photo:${hash}`,
          evidenceLevel: 'raw',
          stance: 'context',
          bracketState: 'SPECULATIVE',
          contentHash: hash,
          excerpt: 'Original damage photograph. Interpretations remain speculative until corroborated.',
          rawText: '',
          floatPoints: 1,
          mixPoints: 0,
          stirPoints: 0,
          totalPressure: 1,
          keyObservations: [],
        };
        batchPhotos.push(photo); batchEvidence.push(evidence); payload.push({ evidenceId, dataUrl, filename: file.name });
      }

      const interim: InsuranceClaim = { ...claim, photos: [...batchPhotos, ...(claim.photos || [])], evidence: [...batchEvidence, ...claim.evidence] };
      onUpdateClaim(interim);
      setMessage('PAi is building the one-bracket rough estimate…');
      const response = await fetch('/api/analyze-damage-photos', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ claim: interim, photos: payload }) });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'Photo analysis failed.');

      const summaries = Array.isArray(result.photoSummaries) ? result.photoSummaries : [];
      const enrichedPhotos = batchPhotos.map((photo, index) => {
        const summary = summaries.find((x: any) => Number(x.photoIndex) === index);
        return { ...photo, category: summary?.category || photo.category, caption: summary?.caption || photo.caption, damageTags: Array.isArray(summary?.damageTags) ? summary.damageTags : photo.damageTags } as CasePhotoItem;
      });
      let nextClaim: InsuranceClaim = {
        ...interim,
        photos: [...enrichedPhotos, ...(claim.photos || [])],
        damageInventory: [...(result.items || []), ...(claim.damageInventory || [])],
        pricingModel: { contractorRateObservations: claim.pricingModel?.contractorRateObservations || [], ...(claim.pricingModel || {}), contingencyPct: claim.pricingModel?.contingencyPct ?? 5 },
        auditTrail: [{ id: `audit-photo-${Date.now()}`, timestamp: new Date().toISOString(), action: 'Photo-driven initial PSi estimate created', impact: `${(result.items || []).length} damage item(s) mapped. Every price and reason starts SPECULATIVE.`, bracketStatus: 'SPECULATIVE' }, ...claim.auditTrail],
      };
      const nextTotals = inventoryTotals(nextClaim.damageInventory || []);
      const snapshotAt = new Date().toISOString();
      const initialSnapshot = {
        id: `psi-initial-photo-${Date.now()}`,
        trade: 'Roofing' as const,
        createdAt: snapshotAt,
        status: 'SUPPORTED' as const,
        measuredQuantity: 0,
        measuredUnit: 'photo-map',
        materialSubtotal: 0,
        contractorAdjustmentPercent: null,
        contractorAdjustmentAmount: 0,
        materialTax: 0,
        documentedTradeCost: nextTotals.initial,
        damageEvidenceIds: Array.from(new Set<string>(batchEvidence.map((record) => record.id))),
        materialSources: [],
        contractorObservationIds: [],
        stage: 'initial_photo' as const,
        bracket: 'SPECULATIVE' as const,
        baseCost: nextTotals.initial,
        contingencyPct: 0,
        contingencyAmount: 0,
        reason: 'Locked photo-driven initial estimate. Every item has a rough price and bracketed reason; all values remain provisional until stronger evidence arrives.',
      };
      nextClaim = {
        ...nextClaim,
        pricingModel: {
          ...(nextClaim.pricingModel || {}),
          contractorRateObservations: nextClaim.pricingModel?.contractorRateObservations || [],
          estimateSnapshots: [initialSnapshot, ...(nextClaim.pricingModel?.estimateSnapshots || [])].slice(0, 100),
          contingencyPct: nextClaim.pricingModel?.contingencyPct ?? 5,
        },
      };
      nextClaim.claimGraph = buildClaimGraph(nextClaim);
      onUpdateClaim(nextClaim);
      setMessage(`Initial one-bracket estimate built: $${nextTotals.initial.toLocaleString(undefined,{minimumFractionDigits:2})}. Nothing is treated as set in stone.`);
    } catch (error: any) {
      setMessage(error?.message || 'Could not analyze photos.');
    } finally {
      setAnalyzing(false);
      if (fileRef.current) fileRef.current.value = '';
    }
  };

  return <div className="space-y-5">
    <input ref={fileRef} type="file" accept="image/*" multiple className="hidden" onChange={(e) => uploadAndAnalyze(e.target.files)} />
    <section className="rounded-2xl border border-indigo-500/30 bg-gradient-to-br from-indigo-950/25 via-slate-900 to-slate-950 p-5">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div><div className="flex items-center gap-2 text-indigo-300 text-xs font-mono"><Sparkles className="w-4 h-4"/>PHOTO → MAP → INITIAL ESTIMATE</div><h3 className="text-lg font-bold text-white mt-1">Pictures start the claim map</h3><p className="text-xs text-slate-400 mt-1 max-w-2xl">PAi prices every inferred repair component and writes a reason for it. Every photo-derived proposition starts at the lowest speculative bracket and can only move up when new evidence supports it.</p></div>
        <div className="flex flex-wrap gap-2"><button disabled={analyzing} onClick={() => fileRef.current?.click()} className="px-4 py-2 rounded-xl bg-indigo-600 disabled:opacity-50 text-white text-xs font-bold flex items-center gap-2">{analyzing?<Loader2 className="w-4 h-4 animate-spin"/>:<Upload className="w-4 h-4"/>} Upload & Analyze Photos</button><button onClick={onOpenUploadModal} className="px-4 py-2 rounded-xl border border-slate-700 text-slate-300 text-xs">Document uploader</button></div>
      </div>
      {(totals.initial > 0 || totals.pass2 > 0) && <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mt-4 text-xs"><div className="rounded-lg bg-slate-950/60 p-3"><div className="text-slate-500">Initial [ ]</div><div className="text-white font-mono font-bold">${totals.initial.toLocaleString()}</div></div><div className="rounded-lg bg-slate-950/60 p-3"><div className="text-slate-500">Pass-2 base</div><div className="text-amber-200 font-mono font-bold">${totals.pass2Base.toLocaleString()}</div></div><div className="rounded-lg bg-slate-950/60 p-3"><div className="text-slate-500">Explicit contingency</div><div className="text-amber-200 font-mono font-bold">${totals.contingency.toLocaleString()}</div></div><div className="rounded-lg bg-slate-950/60 p-3"><div className="text-slate-500">Current PSi</div><div className="text-emerald-300 font-mono font-bold">${totals.pass2.toLocaleString()}</div></div></div>}
      {message && <div className="mt-3 text-[11px] text-sky-200">{message}</div>}
    </section>

    <div className="flex flex-col sm:flex-row gap-3 justify-between"><div className="relative flex-1 max-w-md"><Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2"/><input value={searchQuery} onChange={(e)=>setSearchQuery(e.target.value)} placeholder="Search damage photos…" className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs"/></div><div className="flex gap-1 overflow-auto">{categories.map((cat)=><button key={cat} onClick={()=>setSelectedCategory(cat)} className={`px-2.5 py-1.5 rounded-lg text-[10px] whitespace-nowrap ${selectedCategory===cat?'bg-indigo-500/20 text-indigo-200 border border-indigo-500/40':'text-slate-500 border border-transparent'}`}>{cat==='all'?'All':cat}</button>)}</div></div>

    {filteredPhotos.length ? <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">{filteredPhotos.map((photo)=><button key={photo.id} onClick={()=>setLightboxPhoto(photo)} className="text-left overflow-hidden rounded-2xl bg-slate-900 border border-slate-800 hover:border-indigo-500/50"><div className="aspect-video bg-slate-950 relative">{photo.url?<img src={photo.url} alt={photo.title} className="w-full h-full object-cover"/>:<div className="w-full h-full flex items-center justify-center"><Camera className="w-8 h-8 text-slate-600"/></div>}<span className="absolute top-2 left-2 px-2 py-1 rounded bg-purple-950/90 text-purple-200 text-[9px] font-mono border border-purple-600/40">[ SPECULATIVE PHOTO SOURCE ]</span><Maximize2 className="absolute bottom-2 right-2 w-4 h-4 text-white"/></div><div className="p-4"><div className="text-[10px] text-slate-500 flex items-center gap-1"><Calendar className="w-3 h-3"/>{photo.dateTaken?.slice(0,10)}</div><div className="text-sm font-bold text-white mt-1">{photo.title}</div><div className="text-[11px] text-slate-400 mt-1 line-clamp-2">{photo.caption}</div><div className="flex gap-1 flex-wrap mt-2">{photo.damageTags.slice(0,4).map((tag)=><span key={tag} className="px-1.5 py-0.5 rounded bg-slate-950 border border-slate-800 text-[9px] text-slate-400">#{tag}</span>)}</div></div></button>)}</div>:<div className="p-10 text-center border border-dashed border-slate-800 rounded-2xl text-slate-500"><Camera className="w-8 h-8 mx-auto mb-2"/><div className="text-sm">Upload the first damage photos to begin the map.</div></div>}

    {lightboxPhoto && <div className="fixed inset-0 z-50 bg-black/85 p-5 flex items-center justify-center" onClick={()=>setLightboxPhoto(null)}><div className="max-w-5xl max-h-[90vh]" onClick={(e)=>e.stopPropagation()}>{lightboxPhoto.url&&<img src={lightboxPhoto.url} alt={lightboxPhoto.title} className="max-w-full max-h-[75vh] object-contain rounded-xl"/>}<div className="mt-3 rounded-xl bg-slate-900 border border-slate-800 p-4"><div className="flex gap-2 items-center text-purple-300 text-xs"><ShieldCheck className="w-4 h-4"/>Photo observations begin speculative</div><div className="text-white font-bold mt-1">{lightboxPhoto.title}</div><div className="text-slate-400 text-xs mt-1">{lightboxPhoto.caption}</div></div></div></div>}
  </div>;
};
