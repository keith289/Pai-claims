import React from 'react';
import { ShieldCheck, Sparkles, Plus, Download, Bot, Layers, AlertCircle, ChevronDown, CheckCircle2 } from 'lucide-react';
import { InsuranceClaim } from '../types';

interface HeaderProps {
  claims: InsuranceClaim[];
  activeClaim: InsuranceClaim;
  onSelectClaim: (claim: InsuranceClaim) => void;
  onOpenNewClaimModal: () => void;
  onOpenAdvisorChat: () => void;
  onExportBrief: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  claims = [],
  activeClaim,
  onSelectClaim,
  onOpenNewClaimModal,
  onOpenAdvisorChat,
  onExportBrief,
}) => {
  const [dropdownOpen, setDropdownOpen] = React.useState(false);
  const currentClaim = activeClaim || claims[0];

  return (
    <header className="sticky top-0 z-40 bg-[#0c1017]/95 backdrop-blur-md border-b border-slate-800/80 px-4 lg:px-6 py-3">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-3 max-w-7xl mx-auto">
        
        {/* Brand & Active Case Selector */}
        <div className="flex items-center gap-3 w-full md:w-auto justify-between md:justify-start">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-sky-400 to-blue-600 flex items-center justify-center shadow-lg shadow-sky-500/20 text-white font-bold text-base">
              Ψ
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold tracking-tight text-white font-sans text-base">PAi CLAIM</span>
                <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 rounded bg-sky-500/10 text-sky-400 border border-sky-500/30">
                  v2.0 Legal
                </span>
              </div>
              <span className="text-[11px] text-slate-400 hidden sm:inline-block">
                Epistemic Payout Recovery Engine
              </span>
            </div>
          </div>

          <div className="h-6 w-px bg-slate-800 hidden md:block" />

          {/* Active Claim Selector Dropdown */}
          <div className="relative">
            <button
              onClick={() => setDropdownOpen(!dropdownOpen)}
              className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-900/90 border border-slate-700/80 hover:border-slate-600 text-slate-100 text-xs font-medium transition-colors"
            >
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <div className="text-left">
                <div className="font-semibold text-slate-100 truncate max-w-[170px] sm:max-w-[220px]">
                  {currentClaim?.policyholderName || 'Select Claim'}
                </div>
                <div className="text-[10px] text-slate-400 font-mono">
                  {currentClaim?.claimNumber || 'CLM-00000'} • {currentClaim?.peril ? currentClaim.peril.replace('_', ' ').toUpperCase() : 'CLAIM'}
                </div>
              </div>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400 ml-1" />
            </button>

            {dropdownOpen && (
              <div className="absolute left-0 mt-2 w-72 sm:w-80 rounded-xl bg-slate-900 border border-slate-700 shadow-2xl z-50 p-1.5 space-y-1">
                <div className="px-2.5 py-1.5 text-[11px] font-semibold text-slate-400 uppercase tracking-wider font-mono">
                  Active Claim Cases
                </div>
                {claims.map((claim) => (
                  <button
                    key={claim.id}
                    onClick={() => {
                      onSelectClaim(claim);
                      setDropdownOpen(false);
                    }}
                    className={`w-full text-left px-3 py-2 rounded-lg text-xs transition-colors flex items-center justify-between ${
                      claim.id === currentClaim?.id
                        ? 'bg-sky-500/15 text-sky-200 border border-sky-500/30'
                        : 'text-slate-300 hover:bg-slate-800/80'
                    }`}
                  >
                    <div>
                      <div className="font-medium text-white">{claim.policyholderName || 'Policyholder'}</div>
                      <div className="text-[10px] text-slate-400 font-mono">
                        {claim.carrierName} • {claim.claimNumber}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-[11px] font-bold text-emerald-400 font-mono">
                        +${(claim.auditedTrueValuation?.totalRecoveryGap || 0).toLocaleString()}
                      </div>
                      <div className="text-[9px] text-slate-400 uppercase font-mono">Gap</div>
                    </div>
                  </button>
                ))}
                
                <div className="border-t border-slate-800 pt-1 mt-1">
                  <button
                    onClick={() => {
                      setDropdownOpen(false);
                      onOpenNewClaimModal();
                    }}
                    className="w-full flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium text-sky-400 hover:bg-sky-500/10 transition-colors"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    Intake New Claim
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Real-time Telemetry Status & Action Buttons */}
        <div className="flex items-center gap-2.5 w-full md:w-auto justify-end flex-wrap">
          {/* Status Badges */}
          <div className="hidden lg:flex items-center gap-2">
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-slate-900/80 border border-slate-800 text-[11px] text-slate-300 font-mono">
              <Sparkles className="w-3 h-3 text-sky-400" />
              <span>AI Strategist: Ready</span>
            </div>
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-slate-900/80 border border-slate-800 text-[11px] text-slate-300 font-mono">
              <Layers className="w-3 h-3 text-emerald-400" />
              <span>RPM Index: 211.0</span>
            </div>
          </div>

          {/* AI Advisor Trigger */}
          <button
            onClick={onOpenAdvisorChat}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-sky-500/10 hover:bg-sky-500/20 text-sky-400 border border-sky-500/30 text-xs font-medium transition-all shadow-sm shadow-sky-500/10"
          >
            <Bot className="w-3.5 h-3.5" />
            <span>AI Claim Advisor</span>
          </button>

          {/* Export Claim Brief */}
          <button
            onClick={onExportBrief}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-medium transition-colors"
            title="Export Evidence & Valuation Package"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Export Brief</span>
          </button>

          {/* New Claim Button */}
          <button
            onClick={onOpenNewClaimModal}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 hover:to-blue-500 text-white text-xs font-semibold shadow-md shadow-sky-500/20 transition-all"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New Claim</span>
          </button>
        </div>

      </div>
    </header>
  );
};
