import React, { useState } from 'react';
import {
  FileText,
  Send,
  Copy,
  Download,
  Printer,
  Sparkles,
  Check,
  RefreshCw,
  Scale,
  ShieldAlert,
  Gavel,
  BookOpen,
  Edit3,
} from 'lucide-react';
import { InsuranceClaim } from '../types';
import { disputeLetterPrerequisites } from '../domain/policyRecord.ts';

interface DisputeLettersStudioViewProps {
  claim: InsuranceClaim;
}

export const DisputeLettersStudioView: React.FC<DisputeLettersStudioViewProps> = ({ claim }) => {
  const [selectedLetterType, setSelectedLetterType] = useState<string>('pre_settlement_demand');
  const [letterContent, setLetterContent] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);
  const [additionalNotes, setAdditionalNotes] = useState<string>('');

  const letterTemplates = [
    {
      id: 'pre_settlement_demand',
      title: 'Formal Pre-Settlement Supplemental Demand',
      description: 'Demands full $107,730 recovery gap with attached PE engineering affidavit, 4-trade Xactimate estimate, and 10/10 GCO&P justification.',
      icon: Scale,
      urgencyBadge: '14-Day Deadline',
    },
    {
      id: 'denial_rebuttal',
      title: 'Carrier Denial Rebuttal & Bad Faith Notice',
      description: 'Rebuts insurer "wear and tear" or spot-repair defense citing NOAA Doppler data and municipal building code 25% replacement rule.',
      icon: ShieldAlert,
      urgencyBadge: 'Direct Legal Rebuttal',
    },
    {
      id: 'appraisal_demand',
      title: 'Formal Invocation of Policy Appraisal Clause',
      description: 'Formally invokes the policy appraisal clause and names independent competent appraiser to resolve scope & price dispute.',
      icon: Gavel,
      urgencyBadge: 'Binding Mechanism',
    },
    {
      id: 'doi_complaint',
      title: 'Department of Insurance (DOI) Regulatory Complaint',
      description: 'Formal complaint filed with State Insurance Commissioner for unfair claims settlement practices and prompt payment violations.',
      icon: BookOpen,
      urgencyBadge: 'State Regulatory Notice',
    },
    {
      id: 'sworn_proof_of_loss',
      title: 'Sworn Statement in Proof of Loss Package',
      description: 'Notarized formal statement of whole loss and actual cash value satisfying policy condition precedents.',
      icon: FileText,
      urgencyBadge: 'Condition Precedent',
    },
  ];

  // Hard prerequisite gate. An exported letter travels without its brackets,
  // so every figure in it is asserted flat. Nothing is generated until the
  // terms it would quote have actually been read from the policy.
  const prereq = disputeLetterPrerequisites({ ...claim, evidence: claim.evidence });

  const handleGenerateLetter = async () => {
    if (!prereq.satisfied) {
      setLetterContent('');
      return;
    }
    setLoading(true);
    try {
      const res = await fetch('/api/generate-legal-letter', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          claim,
          letterType: selectedLetterType,
          additionalNotes,
        }),
      });
      const data = await res.json();
      setLetterContent(data.letterContent || '');
    } catch (err) {
      console.error('Error generating letter:', err);
    } finally {
      setLoading(false);
    }
  };

  // Initial letter generation on load or type change
  React.useEffect(() => {
    if (!prereq.satisfied) return;
    handleGenerateLetter();
  }, [selectedLetterType, claim.id, prereq.satisfied]);

  const handleCopy = () => {
    navigator.clipboard.writeText(letterContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([letterContent], { type: 'text/markdown;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${claim.claimNumber}_${selectedLetterType}.md`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handlePrint = () => {
    // Electron blocks renderer-created popup windows for safety, so print from a
    // temporary same-document iframe instead of window.open().
    const frame = document.createElement('iframe');
    frame.setAttribute('aria-hidden', 'true');
    frame.style.position = 'fixed';
    frame.style.right = '0';
    frame.style.bottom = '0';
    frame.style.width = '1px';
    frame.style.height = '1px';
    frame.style.border = '0';
    frame.style.opacity = '0';
    document.body.appendChild(frame);

    const doc = frame.contentDocument;
    const printTarget = frame.contentWindow;
    if (!doc || !printTarget) {
      frame.remove();
      return;
    }

    doc.open();
    doc.write(`
      <html>
        <head>
          <title></title>
          <style>
            body { font-family: 'Times New Roman', Times, serif; padding: 40px; line-height: 1.6; color: #111; max-width: 800px; margin: 0 auto; }
            pre { white-space: pre-wrap; overflow-wrap: anywhere; font-family: inherit; }
          </style>
        </head>
        <body><pre id="letter"></pre></body>
      </html>
    `);
    doc.close();
    doc.title = `${claim.claimNumber} - Legal Document`;
    const pre = doc.getElementById('letter');
    if (pre) pre.textContent = letterContent;

    window.setTimeout(() => {
      printTarget.focus();
      printTarget.print();
      window.setTimeout(() => frame.remove(), 1000);
    }, 50);
  };

  // The studio does not open until the prerequisites are met. Showing the
  // templates with a disabled button would still let the user read a demand
  // total that has not earned the right to be quoted.
  if (!prereq.satisfied) {
    return (
      <div className="space-y-6 max-w-3xl mx-auto pb-12">
        <div className="rounded-2xl border border-amber-500/40 bg-amber-950/25 p-6 space-y-4">
          <div className="flex items-center gap-3">
            <ShieldAlert className="w-6 h-6 text-amber-400" />
            <h2 className="text-lg font-bold text-white">
              Dispute letters are unavailable on this case
            </h2>
          </div>
          <p className="text-sm text-amber-100/80">
            A dispute letter quotes coverage terms and a demand figure to the
            carrier, and it is read without any of the qualifications shown
            inside this workspace. It is therefore not generated until the terms
            it would rely on have been read from the policy itself rather than
            entered by hand.
          </p>

          <div className="space-y-2 pt-2">
            <span className="text-[11px] font-mono uppercase text-amber-400 font-bold">
              Outstanding prerequisites
            </span>
            {prereq.blocking.map((p) => (
              <div
                key={p.id}
                className="rounded-lg border border-slate-800 bg-slate-950/60 p-3"
              >
                <div className="text-sm font-semibold text-slate-200">{p.label}</div>
                <div className="text-xs text-slate-400 mt-0.5">{p.why}</div>
              </div>
            ))}
          </div>

          <div className="pt-2 text-xs text-slate-500">
            {prereq.all.length - prereq.blocking.length} of {prereq.all.length}{' '}
            prerequisites met.
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-sky-400" />
            <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
              Dispute & Formal Demand Letters Studio
            </h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Generate legally grounded, citation-backed demand packages, denial rebuttals, and appraisal demands formatted to prompt claim payouts.
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={handleCopy}
            disabled={!letterContent || loading}
            className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-medium flex items-center gap-1.5 transition-colors disabled:opacity-50"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-slate-400" />}
            <span>{copied ? 'Copied to Clipboard' : 'Copy Text'}</span>
          </button>

          <button
            onClick={handleDownload}
            disabled={!letterContent || loading}
            className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-medium flex items-center gap-1.5 transition-colors disabled:opacity-50"
          >
            <Download className="w-3.5 h-3.5 text-slate-400" />
            <span>Download .MD</span>
          </button>

          <button
            onClick={handlePrint}
            disabled={!letterContent || loading}
            className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-medium flex items-center gap-1.5 transition-colors disabled:opacity-50"
          >
            <Printer className="w-3.5 h-3.5 text-slate-400" />
            <span>Print / PDF</span>
          </button>
        </div>
      </div>

      {/* Document Template Selector Tabs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2.5">
        {letterTemplates.map((template) => {
          const Icon = template.icon;
          const isActive = selectedLetterType === template.id;
          return (
            <button
              key={template.id}
              onClick={() => setSelectedLetterType(template.id)}
              className={`p-3 rounded-xl border text-left transition-all space-y-1 ${
                isActive
                  ? 'bg-slate-900 border-sky-500/60 shadow-lg shadow-sky-500/10'
                  : 'bg-slate-900/60 border-slate-800 hover:border-slate-700 hover:bg-slate-900/80'
              }`}
            >
              <div className="flex items-center justify-between">
                <Icon className={`w-4 h-4 ${isActive ? 'text-sky-400' : 'text-slate-400'}`} />
                <span className="text-[9px] font-mono px-1 py-0.2 rounded bg-slate-800 text-slate-300">
                  {template.urgencyBadge}
                </span>
              </div>
              <div className={`font-bold text-xs ${isActive ? 'text-white' : 'text-slate-300'}`}>
                {template.title}
              </div>
            </button>
          );
        })}
      </div>

      {/* Main Letter Editor & Prompt Controls */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        
        {/* Left Column: Live Letter Editor */}
        <div className="lg:col-span-8 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider font-mono">
              Formal Document Output
            </span>
            <span className="text-xs text-slate-500 font-mono">
              Ready for certified mail or email submission
            </span>
          </div>

          <div className="rounded-2xl bg-slate-900/95 border border-slate-800 p-5 shadow-2xl relative min-h-[520px]">
            {loading ? (
              <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm rounded-2xl flex flex-col items-center justify-center space-y-3 z-10">
                <RefreshCw className="w-8 h-8 text-sky-400 animate-spin" />
                <span className="text-xs text-slate-300 font-mono">
                  Drafting statutory citations, line-item itemizations, and legal arguments with Gemini AI...
                </span>
              </div>
            ) : null}

            <textarea
              rows={24}
              value={letterContent}
              onChange={(e) => setLetterContent(e.target.value)}
              className="w-full bg-transparent text-slate-200 text-xs font-mono leading-relaxed focus:outline-none resize-y whitespace-pre-wrap"
              placeholder="Your formal insurance dispute document will appear here..."
            />
          </div>
        </div>

        {/* Right Column: Custom Prompt & Leverage Tweaks */}
        <div className="lg:col-span-4 space-y-4">
          
          <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider font-mono flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-sky-400" />
              Customize & Re-generate Letter
            </h3>
            
            <div>
              <label className="block text-[11px] text-slate-400 mb-1">
                Add Custom Instructions or Evidence Focus:
              </label>
              <textarea
                rows={4}
                value={additionalNotes}
                onChange={(e) => setAdditionalNotes(e.target.value)}
                placeholder="e.g. Explicitly mention that adjuster David Sterling refused to climb the two-story roof, and cite Florida 12% statutory bad-faith interest."
                className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-slate-200 text-xs focus:outline-none focus:border-sky-500 font-sans"
              />
            </div>

            <button
              onClick={handleGenerateLetter}
              disabled={loading}
              className="w-full py-2.5 rounded-xl bg-sky-500 hover:bg-sky-400 text-white text-xs font-semibold shadow-md shadow-sky-500/20 flex items-center justify-center gap-2 transition-all disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
              <span>Regenerate with Updates</span>
            </button>
          </div>

          {/* Statutory Enforcement Badges */}
          <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider font-mono">
              Embedded Legal Citations
            </h3>

            <div className="space-y-2 text-xs">
              <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800/80 text-slate-300">
                <span className="font-semibold text-white block">Trinidad v. Florida Peninsula (121 So. 3d 433)</span>
                <span className="text-[11px] text-slate-400">Mandates 10% Overhead & 10% Profit for multi-trade work.</span>
              </div>

              <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800/80 text-slate-300">
                <span className="font-semibold text-white block">Florida Building Code §706.1.1 (25% Rule)</span>
                <span className="text-[11px] text-slate-400">Forces complete roof replacement when exceeding 25% damaged area.</span>
              </div>

              <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800/80 text-slate-300">
                <span className="font-semibold text-white block">Matching Statute Fla. Stat. §626.9744</span>
                <span className="text-[11px] text-slate-400">Guarantees uniform appearance across adjoining rooms.</span>
              </div>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
