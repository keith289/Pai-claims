import React from 'react';
import {
  ShieldAlert,
  ShieldCheck,
  Sparkles,
  FileText,
  Camera,
  AlertTriangle,
  CheckCircle2,
  RefreshCw,
  HelpCircle,
  ArrowRight,
} from 'lucide-react';
import { CaseCompletenessAudit } from '../types';

interface CaseCompletenessBannerProps {
  audit: CaseCompletenessAudit | null;
  totalDocs: number;
  totalPhotos: number;
  isLoading: boolean;
  onRunAudit: () => void;
  onSwitchTab?: (tab: 'missing_audit' | 'photos' | 'documents' | 'batch_upload') => void;
}

export const CaseCompletenessBanner: React.FC<CaseCompletenessBannerProps> = ({
  audit,
  totalDocs,
  totalPhotos,
  isLoading,
  onRunAudit,
  onSwitchTab,
}) => {
  const score = audit?.overallScore ?? 72;
  const status = audit?.completenessStatus ?? 'MODERATE_GAPS';
  const unresolvedGaps = audit?.missingChecklist.filter((g) => !g.isResolved) || [];
  const criticalGapsCount = unresolvedGaps.filter((g) => g.urgency === 'critical').length;

  const getStatusBadge = () => {
    switch (status) {
      case 'BULLETPROOF':
        return {
          label: 'Bulletproof Evidentiary Record (100% Prepared)',
          color: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40',
          icon: ShieldCheck,
        };
      case 'READY_FOR_DEMAND':
        return {
          label: 'Strong Case (Minor Gaps Remaining)',
          color: 'bg-sky-500/20 text-sky-300 border-sky-500/40',
          icon: CheckCircle2,
        };
      case 'MODERATE_GAPS':
        return {
          label: `${unresolvedGaps.length} Evidentiary Gaps Detected`,
          color: 'bg-amber-500/20 text-amber-300 border-amber-500/40',
          icon: AlertTriangle,
        };
      case 'CRITICAL_GAPS':
      default:
        return {
          label: `${criticalGapsCount} Critical Vulnerabilities - Carrier Exploit Risk`,
          color: 'bg-rose-500/20 text-rose-300 border-rose-500/40',
          icon: ShieldAlert,
        };
    }
  };

  const statusBadge = getStatusBadge();
  const StatusIcon = statusBadge.icon;

  return (
    <div className="rounded-2xl bg-gradient-to-br from-slate-900 via-slate-900/90 to-slate-950 border border-slate-800 p-5 shadow-xl relative overflow-hidden">
      {/* Ambient background glow */}
      <div className="absolute top-0 right-0 -mt-8 -mr-8 w-64 h-64 bg-sky-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-1/3 -mb-8 w-48 h-48 bg-amber-500/5 rounded-full blur-2xl pointer-events-none" />

      <div className="relative z-10 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-5">
        
        {/* Left: Score Gauge & Case State */}
        <div className="flex items-center gap-4">
          {/* Radial score gauge */}
          <div className="relative w-16 h-16 sm:w-20 sm:h-20 shrink-0 flex items-center justify-center">
            <svg className="w-full h-full -rotate-90" viewBox="0 0 36 36">
              <path
                className="text-slate-800"
                strokeWidth="3.5"
                stroke="currentColor"
                fill="none"
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
              />
              <path
                className={
                  score >= 85
                    ? 'text-emerald-500'
                    : score >= 70
                    ? 'text-sky-500'
                    : score >= 50
                    ? 'text-amber-500'
                    : 'text-rose-500'
                }
                strokeDasharray={`${score}, 100`}
                strokeWidth="3.5"
                strokeLinecap="round"
                stroke="currentColor"
                fill="none"
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
              />
            </svg>
            <div className="absolute flex flex-col items-center justify-center text-center">
              <span className="text-base sm:text-xl font-bold font-mono text-white leading-none">
                {score}%
              </span>
              <span className="text-[9px] uppercase tracking-wider text-slate-400 font-semibold mt-0.5">
                Score
              </span>
            </div>
          </div>

          {/* Titles & Status */}
          <div className="space-y-1.5">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-xs font-mono font-semibold uppercase tracking-wider text-sky-400">
                Case Strength & Completeness Audit
              </span>
              <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border flex items-center gap-1 ${statusBadge.color}`}>
                <StatusIcon className="w-3 h-3" />
                <span>{statusBadge.label}</span>
              </span>
            </div>

            <h2 className="text-lg sm:text-xl font-bold text-white tracking-tight">
              {score >= 85
                ? 'Case File is Legally & Forensically Solid'
                : score >= 70
                ? 'Strong Evidentiary Core — 2 Specific Proof Items Recommended'
                : 'Action Required: Key Evidentiary Gaps Detected'}
            </h2>

            <p className="text-xs text-slate-300/90 max-w-2xl">
              {audit?.missingChecklist && audit.missingChecklist.length > 0
                ? `AI Auditor scanned ${totalDocs} documents and ${totalPhotos} damage photos across 7 evidentiary pillars. Review proactive questions below to eliminate carrier denial angles.`
                : `Ingest all policy files, engineer reports, contractor benchmarks, and photo logs to trigger real-time AI gap analysis.`}
            </p>
          </div>
        </div>

        {/* Right: Quick Stats & Audit Action */}
        <div className="flex flex-wrap items-center gap-2.5 sm:gap-3 w-full lg:w-auto justify-start lg:justify-end">
          
          <div className="flex items-center gap-2 bg-slate-950/80 border border-slate-800 px-3 py-2 rounded-xl">
            <FileText className="w-4 h-4 text-sky-400" />
            <div>
              <div className="text-[10px] text-slate-400 leading-none">Docs Loaded</div>
              <div className="text-xs font-bold font-mono text-white mt-0.5">{totalDocs}</div>
            </div>
          </div>

          <div className="flex items-center gap-2 bg-slate-950/80 border border-slate-800 px-3 py-2 rounded-xl">
            <Camera className="w-4 h-4 text-indigo-400" />
            <div>
              <div className="text-[10px] text-slate-400 leading-none">Damage Photos</div>
              <div className="text-xs font-bold font-mono text-white mt-0.5">{totalPhotos}</div>
            </div>
          </div>

          {unresolvedGaps.length > 0 && (
            <button
              onClick={() => onSwitchTab && onSwitchTab('missing_audit')}
              className="flex items-center gap-1.5 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 px-3 py-2 rounded-xl text-amber-300 text-xs font-semibold transition-all"
            >
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>{unresolvedGaps.length} Missing Items</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          )}

          <button
            onClick={onRunAudit}
            disabled={isLoading}
            className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-sky-500 to-indigo-600 hover:from-sky-400 hover:to-indigo-500 text-white text-xs font-semibold shadow-md shadow-sky-500/20 flex items-center gap-2 transition-all disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
            <span>{isLoading ? 'Auditing Case Files...' : 'Re-Scan Case Files'}</span>
          </button>

        </div>

      </div>
    </div>
  );
};
