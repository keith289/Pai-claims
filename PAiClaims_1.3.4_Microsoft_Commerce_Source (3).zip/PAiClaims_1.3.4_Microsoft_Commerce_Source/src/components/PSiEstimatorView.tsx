import React, { useEffect, useMemo, useState } from 'react';
import {
  Calculator,
  CheckCircle2,
  Database,
  FileCheck2,
  Loader2,
  MapPin,
  Plus,
  RefreshCw,
  Save,
  Settings2,
  ShieldCheck,
  Store,
  Trash2,
  TriangleAlert,
} from 'lucide-react';
import type {
  ContractorRateObservation,
  InsuranceClaim,
  LowesMaterialPrice,
  PsiEstimateSnapshot,
} from '../types';
import {
  buildRoofingMaterialTakeoff,
  purchaseUnits,
  type RoofingMeasurements,
} from '../domain/psiEstimator';
import { calculateTradeEstimate, deriveContractorMedian } from '../domain/tradeEstimator';
import { applyRegionalPass2, inventoryTotals } from '../domain/claimEstimateFlow';
import { buildClaimGraph } from '../domain/claimGraph';

interface Props {
  claim: InsuranceClaim;
  onUpdateClaim: (claim: InsuranceClaim) => void;
  onNavigateTab: (tab: any) => void;
}

type MaterialDraft = LowesMaterialPrice & {
  psiCode: string;
  requiredQuantity: number;
  requiredUnit: string;
  formula: string;
  scopeStatus: 'MEASURED' | 'DERIVED' | 'REQUIRES_DATA';
};

const box = 'rounded-xl border border-slate-800 bg-slate-950/70';
const input = 'w-full mt-1 px-2.5 py-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-100 focus:outline-none focus:border-sky-500';

const DEFAULT_MEASUREMENTS: RoofingMeasurements = {
  roofSquares: 0,
  wastePct: 10,
  tearoffLayers: 1,
  eaveLf: 0,
  rakeLf: 0,
  ridgeLf: 0,
  hipLf: 0,
  valleyLf: 0,
  pipeBootCount: 0,
  roofVentCount: 0,
  ridgeVentLf: 0,
  deckReplacementSf: 0,
  iceWaterSf: 0,
  fastenerLbPerSq: 0,
};

function blankMaterial(
  psiCode: string,
  description: string,
  requiredQuantity: number,
  requiredUnit: string,
  formula: string,
  scopeStatus: MaterialDraft['scopeStatus'],
  storeId: string,
  zipCode: string
): MaterialDraft {
  return {
    psiCode,
    description,
    requiredQuantity,
    requiredUnit,
    formula,
    scopeStatus,
    productId: '',
    storeId,
    zipCode,
    sellingPrice: 0,
    fetchedAt: '',
    sourceUrl: '',
    sourceMethod: 'lowes_quote',
    purchaseUnits: 0,
    packageCoverage: requiredUnit === 'EA' ? 1 : 0,
    packageCoverageUnit: requiredUnit,
  };
}

const dollars = (n: number) => `$${(Number.isFinite(n) ? n : 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

export const PSiEstimatorView: React.FC<Props> = ({ claim, onUpdateClaim, onNavigateTab }) => {
  const [measurements, setMeasurements] = useState<RoofingMeasurements>(DEFAULT_MEASUREMENTS);
  const [storeId, setStoreId] = useState(claim.pricingModel?.lowesStoreId || '');
  const [zipCode, setZipCode] = useState(claim.pricingModel?.zipCode || '');
  const [taxRate, setTaxRate] = useState(0);
  const [damageEvidenceId, setDamageEvidenceId] = useState('');
  const [materials, setMaterials] = useState<MaterialDraft[]>([]);
  const [lookupCode, setLookupCode] = useState<string | null>(null);
  const [message, setMessage] = useState('');
  const [showLowes, setShowLowes] = useState(false);
  const [clientId, setClientId] = useState('');
  const [clientSecret, setClientSecret] = useState('');
  const [scope, setScope] = useState('');
  const [tokenUrl, setTokenUrl] = useState('');
  const [productUrlTemplate, setProductUrlTemplate] = useState('');
  const [searchUrlTemplate, setSearchUrlTemplate] = useState('');
  const [hasSecret, setHasSecret] = useState(false);
  const [secretProtected, setSecretProtected] = useState(false);
  const [storeFeedRows, setStoreFeedRows] = useState(0);
  const [observationEvidenceId, setObservationEvidenceId] = useState('');
  const [observationMaterials, setObservationMaterials] = useState(0);
  const [observationContractor, setObservationContractor] = useState(0);
  const [scenarioPercent, setScenarioPercent] = useState<number | undefined>();
  const [regionalMaterialPct, setRegionalMaterialPct] = useState(claim.pricingModel?.regionalMaterialDifferencePct || 0);
  const [regionalLaborPct, setRegionalLaborPct] = useState(claim.pricingModel?.regionalLaborDifferencePct || 0);
  const [contingencyPct, setContingencyPct] = useState(claim.pricingModel?.contingencyPct ?? 5);
  const [runningPass2, setRunningPass2] = useState(false);

  const takeoff = useMemo(() => buildRoofingMaterialTakeoff(measurements), [measurements]);

  useEffect(() => {
    setMaterials((previous) => {
      const old = new Map<string, MaterialDraft>(previous.map((item) => [item.psiCode, item] as [string, MaterialDraft]));
      return takeoff.map((row) => {
        const existing = old.get(row.psiCode);
        const next = existing
          ? {
              ...existing,
              description: row.description,
              requiredQuantity: row.requiredQuantity,
              requiredUnit: row.requiredUnit,
              formula: row.formula,
              scopeStatus: row.status,
              storeId: existing.storeId || storeId,
              zipCode: existing.zipCode || zipCode,
            }
          : blankMaterial(
              row.psiCode,
              row.description,
              row.requiredQuantity,
              row.requiredUnit,
              row.formula,
              row.status,
              storeId,
              zipCode
            );
        const coverage = Number(next.packageCoverage || 0);
        return {
          ...next,
          purchaseUnits: purchaseUnits(row.requiredQuantity, coverage),
        };
      });
    });
  }, [takeoff, storeId, zipCode]);

  useEffect(() => {
    window.paiDesktop?.getLowesConfig()
      .then((config) => {
        setClientId(config.clientId || '');
        setScope(config.scope || '');
        setTokenUrl(config.tokenUrl || '');
        setProductUrlTemplate(config.productUrlTemplate || '');
        setSearchUrlTemplate(config.searchUrlTemplate || '');
        setHasSecret(config.hasSecret);
        setSecretProtected(config.secretProtected);
        setStoreFeedRows(config.storeFeedRows);
      })
      .catch(() => {});
  }, []);

  const observations = claim.pricingModel?.contractorRateObservations || [];
  const median = deriveContractorMedian('Roofing', observations, claim.evidence);
  const photoTotals = inventoryTotals(claim.damageInventory || []);

  const pricedMaterials: LowesMaterialPrice[] = materials
    .filter((item) => item.requiredQuantity > 0)
    .map(({ psiCode: _psiCode, requiredQuantity: _requiredQuantity, requiredUnit: _requiredUnit, formula: _formula, scopeStatus: _scopeStatus, ...item }) => item);

  const result = useMemo(
    () =>
      calculateTradeEstimate({
        trade: 'Roofing',
        measuredQuantity: measurements.roofSquares,
        measuredUnit: 'SQ',
        materials: pricedMaterials,
        observations,
        evidence: claim.evidence,
        taxRate,
        userAdjustmentPercent: scenarioPercent,
      }),
    [measurements.roofSquares, pricedMaterials, observations, claim.evidence, taxRate, scenarioPercent]
  );

  const scopeNeedsData = takeoff.filter((item) => item.status === 'REQUIRES_DATA');
  const supported = result.status === 'SUPPORTED' && scopeNeedsData.length === 0 && Boolean(damageEvidenceId);

  const patchMeasurement = (key: keyof RoofingMeasurements, value: number) => {
    setMeasurements((current) => ({ ...current, [key]: Math.max(0, Number.isFinite(value) ? value : 0) }));
  };

  const updateMaterial = (psiCode: string, patch: Partial<MaterialDraft>) => {
    setMaterials((current) =>
      current.map((item) => {
        if (item.psiCode !== psiCode) return item;
        const next = { ...item, ...patch };
        const coverage = Number(next.packageCoverage || 0);
        return {
          ...next,
          purchaseUnits: purchaseUnits(next.requiredQuantity, coverage),
        };
      })
    );
  };

  const lookupPrice = async (row: MaterialDraft) => {
    if (!window.paiDesktop) {
      setMessage('Lowe\'s local lookup is available in the PAi Claims desktop build.');
      return;
    }
    if (!row.productId || !storeId || !zipCode) {
      setMessage('Enter product ID, store number, and ZIP before pricing.');
      return;
    }
    setLookupCode(row.psiCode);
    setMessage('');
    try {
      const found = await window.paiDesktop.lookupLowesProduct({ productId: row.productId, storeId, zipCode });
      const coverage = Number(found.packageCoverage || row.packageCoverage || 0);
      updateMaterial(row.psiCode, {
        ...found,
        description: row.description,
        storeId,
        zipCode,
        packageCoverage: coverage,
        packageCoverageUnit: found.packageCoverageUnit || row.requiredUnit,
        purchaseUnits: purchaseUnits(row.requiredQuantity, coverage),
      });
      setMessage(`Loaded ${found.sourceMethod.replaceAll('_', ' ')} price for product ${found.productId} at Store #${found.storeId}.`);
    } catch (error: any) {
      setMessage(error?.message || 'Lowe\'s price lookup failed.');
    } finally {
      setLookupCode(null);
    }
  };

  const recordManualQuote = (row: MaterialDraft, sellingPrice: number) => {
    updateMaterial(row.psiCode, {
      sellingPrice,
      storeId,
      zipCode,
      fetchedAt: new Date().toISOString(),
      sourceUrl: 'Attached Lowe\'s quote / user-entered local store price',
      sourceMethod: 'lowes_quote',
    });
  };

  const saveLowesConfig = async () => {
    if (!window.paiDesktop) return;
    try {
      const saved = await window.paiDesktop.setLowesConfig({
        clientId,
        clientSecret: clientSecret || undefined,
        scope,
        tokenUrl,
        productUrlTemplate,
        searchUrlTemplate,
      });
      setHasSecret(saved.hasSecret);
      setSecretProtected(saved.secretProtected);
      setClientSecret('');
      setMessage('Lowe\'s connector settings saved. Secrets are encrypted when Windows secure storage is available.');
    } catch (error: any) {
      setMessage(error?.message || 'Could not save Lowe\'s connector settings.');
    }
  };

  const importStoreFeed = async () => {
    if (!window.paiDesktop) return;
    try {
      const imported = await window.paiDesktop.importLowesStoreFeed();
      if (imported) {
        setStoreFeedRows(imported.rowCount);
        setMessage(`Imported ${imported.rowCount.toLocaleString()} source-traced Lowe's store-price rows. SHA-256 ${imported.hash.slice(0, 12)}…`);
      }
    } catch (error: any) {
      setMessage(error?.message || 'Store-price feed import failed.');
    }
  };

  const addObservation = () => {
    if (!observationEvidenceId || !(observationMaterials > 0) || !(observationContractor >= observationMaterials)) {
      setMessage('A contractor observation needs estimate evidence, local material subtotal, and contractor direct cost.');
      return;
    }
    const observation: ContractorRateObservation = {
      id: `rate-${Date.now()}`,
      trade: 'Roofing',
      lowesMaterialSubtotal: observationMaterials,
      contractorDirectCost: observationContractor,
      evidenceId: observationEvidenceId,
      observedAt: new Date().toISOString(),
    };
    onUpdateClaim({
      ...claim,
      pricingModel: {
        ...(claim.pricingModel || {}),
        lowesStoreId: storeId,
        zipCode,
        contractorRateObservations: [...observations, observation],
        estimateSnapshots: claim.pricingModel?.estimateSnapshots || [],
      },
    });
    setObservationEvidenceId('');
    setObservationMaterials(0);
    setObservationContractor(0);
  };

  const removeObservation = (id: string) => {
    onUpdateClaim({
      ...claim,
      pricingModel: {
        ...(claim.pricingModel || {}),
        lowesStoreId: storeId,
        zipCode,
        contractorRateObservations: observations.filter((item) => item.id !== id),
        estimateSnapshots: claim.pricingModel?.estimateSnapshots || [],
      },
    });
  };


  const runRegionalPass2 = async () => {
    if (!(claim.damageInventory || []).length) {
      setMessage('Upload and analyze damage photos first. Pass 2 refines the one-bracket photo estimate.');
      return;
    }
    setRunningPass2(true);
    setMessage('Running regional Pass 2…');
    try {
      const completed: MaterialDraft[] = [...materials];
      for (let i = 0; i < completed.length; i += 1) {
        const row = completed[i];
        if (!(row.requiredQuantity > 0) || row.sellingPrice > 0) continue;
        let priced: Partial<MaterialDraft> | null = null;

        // Primary path: authorized Lowe's regional lookup / imported store feed.
        if (window.paiDesktop && row.productId && storeId && zipCode) {
          try {
            const found = await window.paiDesktop.lookupLowesProduct({ productId: row.productId, storeId, zipCode });
            const coverage = Number(found.packageCoverage || row.packageCoverage || 0);
            priced = {
              ...found,
              description: row.description,
              storeId,
              zipCode,
              bracket: 'EXPLAINED',
              priceReason: `Current Lowe's regional/store observation for ZIP ${zipCode}.`,
              packageCoverage: coverage || 1,
              packageCoverageUnit: found.packageCoverageUnit || row.requiredUnit,
              purchaseUnits: coverage > 0 ? purchaseUnits(row.requiredQuantity, coverage) : row.requiredQuantity,
            };
          } catch {
            // Continue to description search before using speculative fallback.
          }
        }

        // Photo-first automation does not require the user to know a retailer
        // SKU. Search the authorized store feed/partner catalog by the PSi
        // material description when an exact product ID was not mapped or
        // when the exact lookup failed.
        if (!priced && window.paiDesktop && storeId && zipCode) {
          try {
            const found = await window.paiDesktop.searchLowesProduct({ query: row.description, storeId, zipCode });
            const coverage = Number(found.packageCoverage || row.packageCoverage || 0);
            priced = {
              ...found,
              description: row.description,
              storeId,
              zipCode,
              bracket: 'EXPLAINED',
              priceReason: `Current Lowe's regional/store product matched from "${row.description}" for ZIP ${zipCode}.`,
              packageCoverage: coverage || 1,
              packageCoverageUnit: found.packageCoverageUnit || row.requiredUnit,
              purchaseUnits: coverage > 0 ? purchaseUnits(row.requiredQuantity, coverage) : row.requiredQuantity,
            };
          } catch {
            // Continue to Xactimate-derived / one-bracket speculative fallback.
          }
        }

        // Nothing is left blank. If direct pricing is unavailable, the LLM
        // first extrapolates from the supplied Xactimate estimate when
        // possible, otherwise it returns a one-bracket rough market value.
        if (!priced) {
          const response = await fetch('/api/speculate-price', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              description: row.description,
              quantity: row.requiredQuantity,
              unit: row.requiredUnit,
              zipCode,
              state: claim.jurisdictionState,
              carrierItems: claim.carrierAudit?.items || [],
              roughAmount: Math.max(1, row.requiredQuantity * 50),
            }),
          });
          const fallback = await response.json();
          if (!response.ok) throw new Error(fallback.error || `Could not price ${row.description}`);
          priced = {
            description: row.description,
            productId: row.productId || `PSI-FALLBACK-${row.psiCode}`,
            storeId: storeId || 'regional-fallback',
            zipCode: zipCode || claim.propertyAddress,
            sellingPrice: Number(fallback.unitPrice || fallback.amount || 1),
            fetchedAt: new Date().toISOString(),
            sourceUrl: fallback.sourceMethod === 'xactimate_derived' ? 'Carrier-supplied Xactimate estimate' : 'PAi speculative fallback',
            sourceMethod: fallback.sourceMethod || 'llm_speculation',
            purchaseUnits: row.requiredQuantity,
            packageCoverage: 1,
            packageCoverageUnit: row.requiredUnit,
            bracket: fallback.bracket || 'SPECULATIVE',
            priceReason: fallback.reason,
          };
        }
        completed[i] = { ...row, ...priced } as MaterialDraft;
      }

      setMaterials(completed);
      const sources: LowesMaterialPrice[] = completed
        .filter((row) => row.requiredQuantity > 0 && row.sellingPrice > 0)
        .map(({ psiCode: _code, requiredQuantity: _rq, requiredUnit: _ru, formula: _f, scopeStatus: _ss, ...row }) => row);

      const nextInventory = applyRegionalPass2(claim.damageInventory || [], {
        materialSources: sources,
        carrierItems: claim.carrierAudit?.items || [],
        regionalMaterialDifferencePct: regionalMaterialPct,
        regionalLaborDifferencePct: regionalLaborPct,
        contingencyPct,
      });
      const totals = inventoryTotals(nextInventory);
      const now = new Date().toISOString();
      const snapshot: PsiEstimateSnapshot = {
        id: `psi-pass2-${Date.now()}`,
        trade: 'Roofing',
        createdAt: now,
        status: 'SUPPORTED',
        measuredQuantity: measurements.roofSquares || 0,
        measuredUnit: 'SQ',
        materialSubtotal: sources.reduce((sum, source) => sum + source.sellingPrice * source.purchaseUnits, 0),
        contractorAdjustmentPercent: null,
        contractorAdjustmentAmount: 0,
        materialTax: 0,
        documentedTradeCost: totals.pass2,
        damageEvidenceIds: Array.from(new Set<string>((claim.damageInventory || []).flatMap((item) => (item.photoEvidenceIds || []) as string[]))),
        materialSources: sources,
        contractorObservationIds: [],
        stage: claim.carrierAudit ? 'carrier_compared' : 'regional_pass2',
        bracket: 'EXPLAINED',
        baseCost: totals.pass2Base,
        contingencyPct,
        contingencyAmount: totals.contingency,
        reason: 'Regional Pass 2: Lowe’s/local pricing where available, Xactimate-derived or one-bracket fallback for missing prices, MAX(PSi labor, Xactimate hours × rate), retained photo-derived job costs, explicit contingency.',
      };
      const next: InsuranceClaim = {
        ...claim,
        damageInventory: nextInventory,
        pricingModel: {
          lowesStoreId: storeId,
          zipCode,
          contractorRateObservations: observations,
          estimateSnapshots: [snapshot, ...(claim.pricingModel?.estimateSnapshots || [])].slice(0, 100),
          latestMaterialSources: sources,
          regionalMaterialDifferencePct: regionalMaterialPct,
          regionalLaborDifferencePct: regionalLaborPct,
          contingencyPct,
        },
        auditedTrueValuation: {
          ...claim.auditedTrueValuation,
          contractorRCV: totals.pass2,
          trueGrossRecovery: Math.max(claim.auditedTrueValuation.trueGrossRecovery || 0, totals.pass2),
        },
        auditTrail: [
          {
            id: `audit-pass2-${Date.now()}`,
            timestamp: now,
            action: 'PSi Regional Pass 2 completed',
            impact: `$${totals.pass2.toLocaleString()} current PSi estimate = $${totals.pass2Base.toLocaleString()} base + $${totals.contingency.toLocaleString()} explicit ${contingencyPct}% contingency. Labor uses MAX(PSi, supplied Xactimate hours × rate).`,
            bracketStatus: 'EXPLAINED',
          },
          ...claim.auditTrail,
        ],
      };
      next.claimGraph = buildClaimGraph(next, now);
      onUpdateClaim(next);
      setMessage(`Pass 2 complete: $${totals.pass2.toLocaleString(undefined, { minimumFractionDigits: 2 })}. Every missing price was completed and bracketed; nothing was left blank.`);
    } catch (error: any) {
      setMessage(error?.message || 'Regional Pass 2 failed.');
    } finally {
      setRunningPass2(false);
    }
  };

  const applySupportedEstimate = () => {
    if (!supported || result.contractorAdjustmentPercent === null) return;
    const now = new Date().toISOString();
    const materialsPerSq = result.materialSubtotal / measurements.roofSquares;
    const contractorDeltaPerSq = result.contractorAdjustmentAmount / measurements.roofSquares;
    const lineId = `psi-roof-${Date.now()}`;
    const line = {
      id: lineId,
      category: 'Roofing' as const,
      description: `PSi Roofing — deterministic source-traced reconstruction (${storeId}/${zipCode})`,
      unit: 'SQ',
      quantity: measurements.roofSquares,
      carrierAllowedACV: 0,
      carrierAllowedRCV: 0,
      contractorBenchmarkRCV: result.documentedTradeCost,
      depreciationWithheld: 0,
      isRecoverableDepreciation: false,
      overheadProfitApplies: false,
      codeUpgradeRequired: false,
      disputeReason: `PSi documented repair cost. Materials are local source observations; non-material contractor delta is the median of ${median.independentRoots} independent contractor provenance roots. No AI set the amount.`,
      status: 'omitted_by_carrier' as const,
      psi: {
        materialUnitCost: materialsPerSq,
        laborUnitCost: contractorDeltaPerSq,
        equipmentCost: 0,
        disposalCost: 0,
        taxRate,
        region: `LOWES-${storeId}-${zipCode}`,
        priceDate: now.slice(0, 10),
        pricingSource: `Local Lowe's source observations + ${median.independentRoots}-root contractor direct-cost median`,
        damageEvidenceIds: [damageEvidenceId],
        lowesMaterialSources: result.materialSources,
        contractorAdjustmentPercent: result.contractorAdjustmentPercent,
        contractorAdjustmentBasis: 'claim_median' as const,
        contractorObservationIds: result.observationIds,
      },
    };

    const snapshot: PsiEstimateSnapshot = {
      id: `psi-snapshot-${Date.now()}`,
      trade: 'Roofing',
      createdAt: now,
      status: result.status,
      measuredQuantity: measurements.roofSquares,
      measuredUnit: 'SQ',
      materialSubtotal: result.materialSubtotal,
      contractorAdjustmentPercent: result.contractorAdjustmentPercent,
      contractorAdjustmentAmount: result.contractorAdjustmentAmount,
      materialTax: result.materialTax,
      documentedTradeCost: result.documentedTradeCost,
      damageEvidenceIds: [damageEvidenceId],
      materialSources: result.materialSources,
      contractorObservationIds: result.observationIds,
      measurements: { ...measurements },
    };

    const retained = claim.lineItems.filter((item) => !item.id.startsWith('psi-roof-'));
    const lineItems = [...retained, line];
    const psiTotal = lineItems.filter((item) => item.psi).reduce((sum, item) => sum + item.contractorBenchmarkRCV, 0);
    const existingSnapshots = claim.pricingModel?.estimateSnapshots || [];
    const next: InsuranceClaim = {
      ...claim,
      lineItems,
      pricingModel: {
        ...(claim.pricingModel || {}),
        lowesStoreId: storeId,
        zipCode,
        contractorRateObservations: observations,
        estimateSnapshots: [snapshot, ...existingSnapshots].slice(0, 100),
      },
      auditedTrueValuation: {
        ...claim.auditedTrueValuation,
        contractorRCV: psiTotal,
      },
      auditTrail: [
        {
          id: `audit-psi-${Date.now()}`,
          timestamp: now,
          action: 'Applied supported PSi Roofing estimate',
          impact: `${dollars(result.documentedTradeCost)} documented roofing repair cost. AI: OFF. ${result.materialSources.length} material price sources and ${median.independentRoots} independent contractor roots.`,
          bracketStatus: 'EXPLAINED',
        },
        ...claim.auditTrail,
      ],
    };
    onUpdateClaim(next);
    setMessage('Supported PSi Roofing estimate applied. Carrier values were not overwritten.');
  };

  return (
    <div className="max-w-7xl mx-auto pb-16 space-y-5">
      <section className="rounded-2xl border border-emerald-500/30 bg-gradient-to-br from-slate-900 via-[#0d1820] to-[#08110f] p-5 sm:p-6">
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-5">
          <div className="max-w-3xl">
            <div className="flex items-center gap-2 text-[11px] font-mono uppercase tracking-wider text-emerald-400">
              <ShieldCheck className="w-4 h-4" /> PSi Estimators · AI OFF
            </div>
            <h1 className="text-2xl sm:text-3xl font-semibold text-white mt-2">Evidence-based reconstruction cost</h1>
            <p className="text-sm text-slate-300 mt-2 leading-relaxed">
              PSi calculates physical quantities, package rounding, current local material observations, and an evidence-backed contractor direct-cost delta. It does not decide insurance coverage or what a carrier owes.
            </p>
          </div>
          <div className="text-right shrink-0">
            <div className="text-[10px] uppercase tracking-wider text-slate-500">Documented roofing cost</div>
            <div className="text-4xl font-semibold text-white tabular-nums">{dollars(result.documentedTradeCost)}</div>
            <div className={`text-xs mt-1 ${supported ? 'text-emerald-300' : 'text-amber-300'}`}>
              {supported ? 'SUPPORTED · source-traced' : 'REQUIRES_DATA'}
            </div>
          </div>
        </div>
      </section>

      <div className="grid lg:grid-cols-[340px_1fr] gap-5">
        <div className="space-y-4">
          <section className={`${box} p-4 space-y-3`}>
            <div className="flex items-center gap-2 text-sm font-bold text-white"><Calculator className="w-4 h-4 text-emerald-400" /> Roofing measurements</div>
            <p className="text-[11px] text-slate-500">Enter measured facts. PSi shows every derived formula.</p>
            <div className="grid grid-cols-2 gap-2 text-xs">
              {([
                ['roofSquares', 'Roof SQ'], ['wastePct', 'Waste %'], ['tearoffLayers', 'Tear-off layers'],
                ['eaveLf', 'Eave LF'], ['rakeLf', 'Rake LF'], ['ridgeLf', 'Ridge LF'], ['hipLf', 'Hip LF'],
                ['valleyLf', 'Valley LF'], ['pipeBootCount', 'Pipe boots'], ['roofVentCount', 'Roof vents'],
                ['ridgeVentLf', 'Ridge vent LF'], ['deckReplacementSf', 'Damaged deck SF'], ['iceWaterSf', 'I&W membrane SF'],
                ['fastenerLbPerSq', 'Verified nails LB/SQ'],
              ] as Array<[keyof RoofingMeasurements, string]>).map(([key, label]) => (
                <label key={key}>{label}<input type="number" min="0" step="0.1" className={input} value={measurements[key] || ''} onChange={(e) => patchMeasurement(key, Number(e.target.value))} /></label>
              ))}
            </div>
          </section>

          <section className={`${box} p-4 space-y-3`}>
            <div className="flex items-center gap-2 text-sm font-bold text-white"><MapPin className="w-4 h-4 text-sky-400" /> Local material market</div>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <label>Lowe's store #<input className={input} value={storeId} onChange={(e) => setStoreId(e.target.value.trim())} /></label>
              <label>Job ZIP<input className={input} value={zipCode} onChange={(e) => setZipCode(e.target.value.trim())} /></label>
              <label className="col-span-2">Material tax rate <span className="text-slate-600">(decimal)</span><input type="number" step="0.001" className={input} value={taxRate || ''} onChange={(e) => setTaxRate(Number(e.target.value))} /></label>
            </div>
            <button onClick={() => setShowLowes(!showLowes)} className="w-full px-3 py-2 rounded-lg border border-sky-900 bg-sky-950/20 text-xs text-sky-200 flex items-center justify-center gap-2"><Settings2 className="w-4 h-4" /> Lowe's connector</button>
          </section>

          <section className={`${box} p-4 space-y-3`}>
            <div className="flex items-center justify-between gap-2">
              <div className="text-sm font-bold text-white">Contractor evidence</div>
              <span className={`text-[10px] ${median.status === 'SUPPORTED' ? 'text-emerald-300' : 'text-amber-300'}`}>{median.independentRoots}/3 independent roots</span>
            </div>
            <p className="text-[11px] text-slate-500">PSi uses the median difference between current local materials and contractor direct cost for comparable scope. Repeated copies of one estimate count once.</p>
            <select className={`${input} text-xs`} value={observationEvidenceId} onChange={(e) => setObservationEvidenceId(e.target.value)}>
              <option value="">Contractor estimate evidence…</option>
              {claim.evidence.filter((item) => item.type === 'contractor_estimate').map((item) => <option key={item.id} value={item.id}>{item.title}</option>)}
            </select>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <label>Local materials<input type="number" className={input} value={observationMaterials || ''} onChange={(e) => setObservationMaterials(Number(e.target.value))} /></label>
              <label>Contractor direct cost<input type="number" className={input} value={observationContractor || ''} onChange={(e) => setObservationContractor(Number(e.target.value))} /></label>
            </div>
            <button onClick={addObservation} className="w-full px-3 py-2 rounded-lg bg-indigo-700 text-xs font-bold text-white flex items-center justify-center gap-2"><Plus className="w-4 h-4" /> Add observed estimate</button>
            <div className="flex flex-wrap gap-1.5">
              {observations.filter((item) => item.trade === 'Roofing').map((item) => (
                <span key={item.id} className="px-2 py-1 rounded bg-slate-900 border border-slate-800 text-[10px] text-slate-300">
                  {(((item.contractorDirectCost - item.lowesMaterialSubtotal) / item.lowesMaterialSubtotal) * 100).toFixed(1)}%
                  <button onClick={() => removeObservation(item.id)} className="ml-1 text-rose-300"><Trash2 className="inline w-3 h-3" /></button>
                </span>
              ))}
            </div>
            <label className="text-[11px] text-slate-500">Scenario-only delta %<input type="number" className={input} value={scenarioPercent ?? ''} onChange={(e) => setScenarioPercent(e.target.value === '' ? undefined : Number(e.target.value))} /></label>
          </section>
        </div>

        <div className="space-y-4 min-w-0">
          {showLowes && (
            <section className="rounded-xl border border-sky-900 bg-sky-950/15 p-4 space-y-3">
              <div className="flex items-center justify-between"><div className="font-bold text-sm text-sky-100 flex items-center gap-2"><Database className="w-4 h-4" /> Lowe's price connector</div><span className="text-[10px] text-slate-400">{storeFeedRows.toLocaleString()} feed rows</span></div>
              <p className="text-[11px] text-slate-400">The estimator can use an authorized local store-price CSV immediately. Partner API calls are enabled only when you enter the endpoints supplied with your Lowe's access; PAi does not guess or scrape them.</p>
              <div className="grid md:grid-cols-2 gap-2 text-xs">
                <input className={input} placeholder="Partner client ID" value={clientId} onChange={(e) => setClientId(e.target.value)} />
                <input className={input} type="password" placeholder={hasSecret ? `Secret saved${secretProtected ? ' (encrypted)' : ''}; leave blank` : 'Client secret'} value={clientSecret} onChange={(e) => setClientSecret(e.target.value)} />
                <input className={input} placeholder="OAuth scope (if supplied)" value={scope} onChange={(e) => setScope(e.target.value)} />
                <input className={input} placeholder="OAuth token URL from partner docs" value={tokenUrl} onChange={(e) => setTokenUrl(e.target.value)} />
                <input className={`${input} md:col-span-2`} placeholder="Product URL template, e.g. https://.../{productId}?store={storeId}" value={productUrlTemplate} onChange={(e) => setProductUrlTemplate(e.target.value)} />
                <input className={`${input} md:col-span-2`} placeholder="Optional search URL template from partner docs, e.g. https://...?...q={query}&store={storeId}" value={searchUrlTemplate} onChange={(e) => setSearchUrlTemplate(e.target.value)} />
              </div>
              <div className="flex flex-wrap gap-2">
                <button onClick={saveLowesConfig} className="px-3 py-2 rounded-lg bg-sky-700 text-xs text-white flex items-center gap-2"><Save className="w-4 h-4" /> Save connector</button>
                <button onClick={importStoreFeed} className="px-3 py-2 rounded-lg bg-slate-800 text-xs text-white flex items-center gap-2"><Database className="w-4 h-4" /> Import official store-price CSV</button>
              </div>
            </section>
          )}

          <section className={`${box} p-4 space-y-3`}>
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
              <div>
                <div className="font-bold text-sm text-white">Photo → Regional Pass 2</div>
                <div className="text-[10px] text-slate-500">Initial one-bracket estimate is preserved. Pass 2 replaces/refines materials, tests labor against supplied Xactimate hours × rate, holds higher PSi labor, and adds the explicit contingency.</div>
              </div>
              <button onClick={runRegionalPass2} disabled={runningPass2 || !(claim.damageInventory || []).length} className="h-10 px-4 rounded-lg bg-amber-600 disabled:opacity-40 text-white text-xs font-bold flex items-center justify-center gap-2">{runningPass2 ? <Loader2 className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />} Run Pass 2</button>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
              <div className="rounded-lg bg-slate-950 border border-slate-800 p-3"><div className="text-[9px] uppercase text-slate-500">Initial [ ]</div><div className="text-lg font-mono text-purple-200">{dollars(photoTotals.initial)}</div></div>
              <div className="rounded-lg bg-slate-950 border border-slate-800 p-3"><div className="text-[9px] uppercase text-slate-500">Pass-2 base</div><div className="text-lg font-mono text-amber-200">{dollars(photoTotals.pass2Base)}</div></div>
              <div className="rounded-lg bg-slate-950 border border-slate-800 p-3"><div className="text-[9px] uppercase text-slate-500">Contingency</div><div className="text-lg font-mono text-amber-200">{dollars(photoTotals.contingency)}</div></div>
              <div className="rounded-lg bg-slate-950 border border-slate-800 p-3"><div className="text-[9px] uppercase text-slate-500">Current PSi</div><div className="text-lg font-mono text-emerald-300">{dollars(photoTotals.pass2 || photoTotals.initial)}</div></div>
            </div>
          </section>

          <section className={`${box} overflow-hidden`}>
            <div className="px-4 py-3 border-b border-slate-800 flex items-center justify-between gap-3">
              <div><div className="font-bold text-sm text-white">Deterministic roofing assembly</div><div className="text-[10px] text-slate-500">Quantity → retail package → local source price</div></div>
              <div className="text-right text-[10px] text-slate-500">{takeoff.length} active components</div>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full min-w-[980px] text-xs">
                <thead className="text-[10px] uppercase tracking-wider text-slate-500">
                  <tr className="border-b border-slate-800"><th className="text-left px-3 py-2">PSi component</th><th className="text-right px-3 py-2">Required</th><th className="text-right px-3 py-2">Coverage / pkg</th><th className="text-right px-3 py-2">Buy</th><th className="text-left px-3 py-2">Lowe's product</th><th className="text-right px-3 py-2">Price/pkg</th><th className="text-right px-3 py-2">Extended</th><th className="px-3 py-2"></th></tr>
                </thead>
                <tbody>
                  {materials.map((row) => {
                    const extension = row.sellingPrice * row.purchaseUnits;
                    return <React.Fragment key={row.psiCode}>
                      <tr className="border-b border-slate-800/80 align-top">
                        <td className="px-3 py-2.5"><div className="font-medium text-slate-100">{row.description}</div><div className="text-[9px] font-mono text-emerald-400">{row.psiCode}</div><div className="text-[10px] text-slate-500 mt-1">{row.formula}</div></td>
                        <td className="px-3 py-2.5 text-right tabular-nums"><div className="text-white">{row.requiredQuantity.toFixed(2)} {row.requiredUnit}</div><div className={`text-[9px] ${row.scopeStatus === 'REQUIRES_DATA' ? 'text-amber-300' : 'text-slate-500'}`}>{row.scopeStatus}</div></td>
                        <td className="px-3 py-2"><input type="number" min="0" step="0.01" className="w-24 px-2 py-1.5 text-right rounded bg-slate-900 border border-slate-800" value={row.packageCoverage || ''} onChange={(e) => updateMaterial(row.psiCode, { packageCoverage: Number(e.target.value), packageCoverageUnit: row.requiredUnit })} /><div className="text-[9px] text-slate-600 mt-1">{row.requiredUnit}/package</div></td>
                        <td className="px-3 py-2.5 text-right tabular-nums text-white">{row.purchaseUnits || '—'}</td>
                        <td className="px-3 py-2"><input className="w-36 px-2 py-1.5 rounded bg-slate-900 border border-slate-800" placeholder="Product ID / SKU" value={row.productId} onChange={(e) => updateMaterial(row.psiCode, { productId: e.target.value })} /><div className="text-[9px] text-slate-600 mt-1 truncate max-w-40">{row.sourceMethod.replaceAll('_', ' ')} {row.fetchedAt ? `· ${row.fetchedAt.slice(0, 10)}` : ''}</div></td>
                        <td className="px-3 py-2"><input type="number" min="0" step="0.01" className="w-24 px-2 py-1.5 text-right rounded bg-slate-900 border border-slate-800" value={row.sellingPrice || ''} onChange={(e) => recordManualQuote(row, Number(e.target.value))} />{row.sourceMethod === 'lowes_quote' && row.sellingPrice > 0 && <select className="mt-1 w-28 bg-slate-900 border border-slate-800 rounded text-[9px]" value={row.sourceEvidenceId || ''} onChange={(e) => updateMaterial(row.psiCode, { sourceEvidenceId: e.target.value })}><option value="">Price evidence…</option>{claim.evidence.map((evidence) => <option key={evidence.id} value={evidence.id}>{evidence.title}</option>)}</select>}</td>
                        <td className="px-3 py-2.5 text-right font-semibold text-emerald-300 tabular-nums">{dollars(extension)}</td>
                        <td className="px-3 py-2"><button title="Refresh local price" disabled={lookupCode === row.psiCode || !row.productId || !storeId || !zipCode} onClick={() => lookupPrice(row)} className="h-8 px-2 rounded bg-emerald-700 disabled:opacity-40 text-white flex items-center gap-1">{lookupCode === row.psiCode ? <Loader2 className="w-3 h-3 animate-spin" /> : <RefreshCw className="w-3 h-3" />} Price</button></td>
                      </tr>
                    </React.Fragment>;
                  })}
                </tbody>
              </table>
            </div>
          </section>

          <section className="grid sm:grid-cols-4 gap-3">
            {[['Materials', result.materialSubtotal], ['Contractor delta', result.contractorAdjustmentAmount], ['Material tax', result.materialTax], ['Documented cost', result.documentedTradeCost]].map(([label, value]) => <div key={String(label)} className={`${box} p-3`}><div className="text-[10px] uppercase text-slate-500">{label}</div><div className="text-lg font-semibold text-white mt-1 tabular-nums">{dollars(Number(value))}</div></div>)}
          </section>

          <section className={`${box} p-4 space-y-3`}>
            <div className="grid md:grid-cols-[1fr_auto] gap-3 items-end">
              <label className="text-xs text-slate-300">Damage evidence supporting this roof scope<select className={input} value={damageEvidenceId} onChange={(e) => setDamageEvidenceId(e.target.value)}><option value="">Required before supported estimate…</option>{claim.evidence.map((item) => <option key={item.id} value={item.id}>{item.title}</option>)}</select></label>
              <button onClick={applySupportedEstimate} disabled={!supported} className="h-10 px-4 rounded-lg bg-emerald-600 disabled:opacity-40 text-white text-xs font-bold flex items-center justify-center gap-2"><FileCheck2 className="w-4 h-4" /> Apply supported PSi estimate</button>
            </div>
            {!supported && (
              <div className="rounded-lg border border-amber-900/60 bg-amber-950/20 p-3 text-[11px] text-amber-100 flex gap-2">
                <TriangleAlert className="w-4 h-4 shrink-0 text-amber-400" />
                <div><div className="font-bold">REQUIRES_DATA</div><div>{[
                  ...scopeNeedsData.map((item) => `${item.description}: ${item.formula}`),
                  ...result.missingInputs,
                  ...(damageEvidenceId ? [] : ['damage evidence linked to the measured scope']),
                ].filter((value, index, all) => all.indexOf(value) === index).join('; ')}</div></div>
              </div>
            )}
            {supported && <div className="text-[11px] text-emerald-300 flex items-center gap-2"><CheckCircle2 className="w-4 h-4" /> All calculation inputs are source-traced. This is a documented repair-cost estimate, not a coverage determination.</div>}
            {message && <div className="text-[11px] text-sky-200 border-t border-slate-800 pt-2">{message}</div>}
          </section>

          <div className="flex justify-end"><button onClick={() => onNavigateTab('xactimate_optimizer')} className="px-4 py-2 rounded-lg border border-slate-700 text-xs text-slate-200 flex items-center gap-2"><Store className="w-4 h-4" /> Compare carrier estimate next</button></div>
        </div>
      </div>
    </div>
  );
};
