import React, { useState } from 'react';
import {
  Bot,
  Send,
  X,
  Sparkles,
  RefreshCw,
  User,
  ShieldCheck,
  Zap,
} from 'lucide-react';
import { InsuranceClaim } from '../types';
import { parseEpistemicText, BRACKET_COLORS } from '../utils/epistemicEngine';

interface ClaimAdvisorChatModalProps {
  isOpen: boolean;
  onClose: () => void;
  claim: InsuranceClaim;
}

export const ClaimAdvisorChatModal: React.FC<ClaimAdvisorChatModalProps> = ({
  isOpen,
  onClose,
  claim,
}) => {
  const [messages, setMessages] = useState<Array<{ role: 'user' | 'assistant'; content: string }>>([
    {
      role: 'assistant',
      content: `Hello! I am your PAi Insurance Claim Strategist. I've audited claim #${claim.claimNumber} against ${claim.carrierName}.

Key findings from your case record:
• Total Recovery Gap: [[[+$${(claim.auditedTrueValuation?.totalRecoveryGap || 0).toLocaleString()}]]]
• Qualified General Contractor O&P (10/10): {[+$${(claim.auditedTrueValuation?.eligibleOverheadAndProfit || 0).toLocaleString()}]}
• Withheld Depreciation: [[$${(claim.carrierOffer?.depreciationWithheld || 0).toLocaleString()}]]

How can I help you maximize your claim payout today? Ask me about policy clauses, building codes, adjuster negotiations, or demand tactics!`,
    },
  ]);

  const [inputQuery, setInputQuery] = useState('');
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleSendMessage = async () => {
    if (!inputQuery.trim() || loading) return;

    const userMsg = inputQuery.trim();
    const updatedMessages = [...messages, { role: 'user' as const, content: userMsg }];
    setMessages(updatedMessages);
    setInputQuery('');
    setLoading(true);

    try {
      const res = await fetch('/api/chat-advisor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          claim,
          messages: updatedMessages,
          userQuery: userMsg,
        }),
      });
      const data = await res.json();
      setMessages([
        ...updatedMessages,
        { role: 'assistant', content: data.response || 'No response received.' },
      ]);
    } catch (err) {
      console.error('Chat error:', err);
      setMessages([
        ...updatedMessages,
        { role: 'assistant', content: 'Apologies, I encountered an error. Please try again.' },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const sampleQuestions = [
    'How do I refute the adjuster saying my roof is just old wear and tear?',
    'Explain the 10 & 10 Overhead & Profit rule and why the carrier owes it.',
    'What is the Florida Building Code 25% roof replacement rule?',
    'What should I say if the adjuster asks for recorded statement?',
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex justify-end">
      <div className="w-full max-w-lg bg-[#0a0e17] border-l border-slate-800 h-full flex flex-col shadow-2xl animate-in slide-in-from-right duration-300">
        
        {/* Header */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-900/80">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-sky-500/20 text-sky-400 flex items-center justify-center">
              <Bot className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">PAi Claim Advisor</h3>
              <p className="text-[10px] text-slate-400 font-mono">
                Gemini 3.7 Flash • Active Case #{claim.claimNumber}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Message History */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 text-xs leading-relaxed">
          {messages.map((m, idx) => (
            <div
              key={idx}
              className={`flex gap-2.5 ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {m.role === 'assistant' && (
                <div className="w-6 h-6 rounded-md bg-sky-500/20 text-sky-400 flex items-center justify-center shrink-0 mt-0.5 font-bold text-[10px]">
                  Ψ
                </div>
              )}
              <div
                className={`p-3.5 rounded-2xl max-w-[88%] whitespace-pre-wrap ${
                  m.role === 'user'
                    ? 'bg-sky-600 text-white rounded-tr-none'
                    : 'bg-slate-900 border border-slate-800 text-slate-200 rounded-tl-none font-sans'
                }`}
              >
                {m.content}
              </div>
            </div>
          ))}

          {loading && (
            <div className="flex items-center gap-2 text-xs text-sky-400 font-mono p-3 bg-slate-900/60 rounded-xl border border-slate-800">
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
              <span>Analyzing policy provisions and legal precedent...</span>
            </div>
          )}
        </div>

        {/* Quick Sample Questions */}
        <div className="p-3 border-t border-slate-800/80 bg-slate-950/60 space-y-1.5">
          <div className="text-[10px] text-slate-400 font-mono uppercase">Suggested Prompts:</div>
          <div className="flex flex-wrap gap-1.5">
            {sampleQuestions.map((q, idx) => (
              <button
                key={idx}
                onClick={() => setInputQuery(q)}
                className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 text-[11px] text-slate-300 border border-slate-800 text-left truncate max-w-full transition-colors"
              >
                {q}
              </button>
            ))}
          </div>
        </div>

        {/* Input Bar */}
        <div className="p-3 border-t border-slate-800 bg-slate-900/90 flex items-center gap-2">
          <input
            type="text"
            placeholder="Ask anything about this claim, policy, or negotiation..."
            value={inputQuery}
            onChange={(e) => setInputQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
            className="flex-1 px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-slate-200 text-xs focus:outline-none focus:border-sky-500"
          />
          <button
            onClick={handleSendMessage}
            disabled={!inputQuery.trim() || loading}
            className="p-2.5 rounded-xl bg-sky-500 hover:bg-sky-400 text-white shadow-md shadow-sky-500/20 disabled:opacity-50 transition-all"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>

      </div>
    </div>
  );
};
