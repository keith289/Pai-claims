import React from 'react';
import {
  Clock,
  AlertTriangle,
  CheckCircle2,
  Calendar,
  ShieldAlert,
  Zap,
  Info,
  Scale,
} from 'lucide-react';
import { InsuranceClaim } from '../types';

interface StatutoryTimelineViewProps {
  claim: InsuranceClaim;
  onNavigateTab: (tab: any) => void;
}

export const StatutoryTimelineView: React.FC<StatutoryTimelineViewProps> = ({ claim, onNavigateTab }) => {
  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-sky-400" />
            <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
              Statutory Deadlines & Prompt Pay Timelines
            </h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Track mandatory state insurance commissioner statutory windows, proof of loss deadlines, and bad-faith notice cure clocks running against the carrier.
          </p>
        </div>
      </div>

      {/* Critical Countdown Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {claim.statutoryDeadlines.map((dl) => (
          <div
            key={dl.id}
            className={`p-5 rounded-2xl border space-y-3 transition-all ${
              dl.status === 'critical_pending'
                ? 'bg-amber-950/20 border-amber-500/40 shadow-lg shadow-amber-500/5'
                : dl.status === 'passed'
                ? 'bg-slate-900/60 border-slate-800'
                : 'bg-emerald-950/20 border-emerald-500/40'
            }`}
          >
            <div className="flex items-center justify-between">
              <span
                className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase ${
                  dl.status === 'critical_pending'
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                    : 'bg-slate-800 text-slate-400'
                }`}
              >
                {dl.status.replace('_', ' ')}
              </span>
              <span className="text-xs font-mono font-bold text-white">
                {dl.deadlineDate}
              </span>
            </div>

            <div>
              <h3 className="text-xs font-bold text-white">{dl.title}</h3>
              <div className="text-[10px] font-mono text-sky-400 mt-0.5">
                Statute: {dl.statuteCode}
              </div>
            </div>

            <p className="text-[11px] text-slate-300 leading-relaxed">
              {dl.description}
            </p>

            <div className="p-2.5 rounded-lg bg-slate-950/80 border border-slate-800/80 text-[10px] text-rose-300 font-mono flex items-start gap-1.5">
              <ShieldAlert className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold">Carrier Default Penalty: </span>
                <span>{dl.penaltyForCarrierDefault}</span>
              </div>
            </div>

            {dl.status === 'critical_pending' && (
              <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs font-mono">
                <span className="text-amber-400 font-bold flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 animate-pulse" />
                  {dl.daysRemaining} Days Remaining
                </span>
                <button
                  onClick={() => onNavigateTab('legal_letters')}
                  className="text-sky-400 hover:text-sky-300 text-[11px] font-medium"
                >
                  Prepare Letter →
                </button>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Complete Audit Chronology Log */}
      <div className="p-6 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-4">
        <h3 className="text-base font-bold text-white flex items-center gap-2">
          <Calendar className="w-4 h-4 text-sky-400" />
          <span>Case Epistemic Audit Chronology</span>
        </h3>

        <div className="space-y-3 relative before:absolute before:left-3.5 before:top-3 before:bottom-3 before:w-0.5 before:bg-slate-800">
          {claim.auditTrail.map((audit) => (
            <div key={audit.id} className="relative flex items-start gap-3 pl-8 text-xs">
              <div className="absolute left-2 top-1.5 w-3 h-3 rounded-full bg-sky-500 border-2 border-slate-950 -translate-x-1/2" />
              <div className="flex-1 p-3 rounded-xl bg-slate-950/80 border border-slate-800 space-y-1">
                <div className="flex items-center justify-between font-mono">
                  <span className="font-bold text-white">{audit.action}</span>
                  <span className="text-slate-400 text-[10px]">{audit.timestamp}</span>
                </div>
                <p className="text-slate-300 text-[11px]">{audit.impact}</p>
                <div className="text-[10px] font-mono text-emerald-400 pt-0.5">
                  Bracket Impact: [{audit.bracketStatus}]
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
