import React from 'react';
import {
  TrendingUp,
  AlertTriangle,
  ShieldAlert,
  CheckCircle2,
  FileText,
  DollarSign,
  ArrowUpRight,
  Clock,
  Sparkles,
  Layers,
  FileSpreadsheet,
  FileSearch,
  Hammer,
  Scale,
  Send,
  Zap,
  Camera,
  FolderArchive,
  HelpCircle,
} from 'lucide-react';
import { InsuranceClaim, EpistemicBracket } from '../types';
import { calculateClaimRPM, BRACKET_COLORS } from '../utils/epistemicEngine';
import { EpistemicLegend } from './EpistemicLegend';

interface DashboardViewProps {
  claim: InsuranceClaim;
  onNavigateTab: (tab: any) => void;
  onOpenAdvisorChat: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  claim,
  onNavigateTab,
  onOpenAdvisorChat,
}) => {
  const rpm = calculateClaimRPM(claim.evidence);
  const recoveryGap = claim.auditedTrueValuation?.totalRecoveryGap || 0;
  const initialPaid = claim.carrierOffer?.netCarrierCheckIssued || 0;
  const trueTarget = claim.auditedTrueValuation?.netPayoutOwed || 0;
  const progressPercent = Math.min(100, Math.round((initialPaid / (trueTarget || 1)) * 100));

  // Count brackets across evidence
  const bracketCounts: Record<EpistemicBracket, number> = {
    VALIDATED: claim.evidence.filter((e) => e.bracketState === 'VALIDATED').length,
    EXPLAINED: claim.evidence.filter((e) => e.bracketState === 'EXPLAINED').length,
    SPECULATIVE: claim.evidence.filter((e) => e.bracketState === 'SPECULATIVE').length,
    UNVERIFIED: claim.evidence.filter((e) => e.bracketState === 'UNVERIFIED').length,
    CONTRADICTED: claim.evidence.filter((e) => e.bracketState === 'CONTRADICTED').length,
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      
      {/* Top Hero: Financial Recovery Gap Card */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-slate-900 via-[#0e1626] to-[#0a1220] border border-sky-500/30 p-6 shadow-2xl">
        <div className="absolute -top-24 -right-24 w-96 h-96 bg-sky-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -left-24 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-mono font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center gap-1.5">
                <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
                CLAIM RECOVERY AUDIT ACTIVE
              </span>
              <span className="text-xs text-slate-400 font-mono">
                Policy #{claim.policyNumber}
              </span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
              Total Underpayment Recovery Gap: <span className="text-emerald-400 font-mono">+${recoveryGap.toLocaleString()}</span>
            </h1>
            
            <p className="text-sm text-slate-300 leading-relaxed">
              Carrier issued an initial payment of <span className="font-semibold text-white font-mono">${initialPaid.toLocaleString()}</span>. 
              Forensic audit reveals <span className="font-semibold text-emerald-300 font-mono">${claim.auditedTrueValuation?.trueGrossRecovery.toLocaleString()}</span> in 
              validated damages, multi-trade General Contractor Overhead & Profit (10/10), and mandatory building code upgrades.
            </p>
          </div>

          {/* Action CTAs */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 w-full lg:w-auto shrink-0">
            <button
              onClick={() => onNavigateTab('xactimate_optimizer')}
              className="px-4 py-3 rounded-xl bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-500 hover:to-indigo-500 text-white text-xs font-bold shadow-lg shadow-sky-500/20 flex items-center justify-center gap-2 transition-all"
            >
              <FileSearch className="w-4 h-4" />
              <span>Audit Xactimate Scope</span>
            </button>

            <button
              onClick={() => onNavigateTab('payout_optimizer')}
              className="px-4 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-100 border border-slate-700 text-xs font-semibold flex items-center justify-center gap-2 transition-all"
            >
              <FileSpreadsheet className="w-4 h-4 text-sky-400" />
              <span>Line Items</span>
            </button>

            <button
              onClick={() => onNavigateTab('legal_letters')}
              className="px-4 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-100 border border-slate-700 text-xs font-semibold flex items-center justify-center gap-2 transition-all"
            >
              <Send className="w-4 h-4 text-emerald-400" />
              <span>Demand Letter</span>
            </button>
          </div>
        </div>

        {/* Payout Progress Bar */}
        <div className="mt-6 pt-6 border-t border-slate-800/80 space-y-3">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between text-xs text-slate-300 gap-1 font-mono">
            <div className="flex items-center gap-2">
              <span className="text-slate-400">Carrier Paid:</span>
              <span className="font-bold text-white">${initialPaid.toLocaleString()}</span>
              <span className="text-slate-500">({progressPercent}%)</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-slate-400">True Audited Settlement Target:</span>
              <span className="font-bold text-emerald-400">${trueTarget.toLocaleString()}</span>
            </div>
          </div>

          <div className="w-full h-3 bg-slate-800 rounded-full overflow-hidden p-0.5 border border-slate-700 flex">
            {/* Paid segment */}
            <div
              style={{ width: `${progressPercent}%` }}
              className="h-full bg-sky-500 rounded-full transition-all duration-500"
              title={`Carrier check paid: $${initialPaid.toLocaleString()}`}
            />
            {/* Unpaid recovery gap segment */}
            <div
              style={{ width: `${100 - progressPercent}%` }}
              className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 rounded-full transition-all duration-500 animate-pulse"
              title={`Recovery Gap: +$${recoveryGap.toLocaleString()}`}
            />
          </div>

          {/* Quick Breakdown Badges */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
            <div className="p-2 rounded-lg bg-slate-900/60 border border-slate-800 text-[11px]">
              <span className="text-slate-400 block">GC O&P (10/10):</span>
              <span className="font-bold font-mono text-sky-300">
                +${(claim.auditedTrueValuation?.eligibleOverheadAndProfit || 0).toLocaleString()}
              </span>
            </div>
            <div className="p-2 rounded-lg bg-slate-900/60 border border-slate-800 text-[11px]">
              <span className="text-slate-400 block">Code Upgrades:</span>
              <span className="font-bold font-mono text-purple-300">
                +${(claim.auditedTrueValuation?.eligibleCodeUpgrades || 0).toLocaleString()}
              </span>
            </div>
            <div className="p-2 rounded-lg bg-slate-900/60 border border-slate-800 text-[11px]">
              <span className="text-slate-400 block">Withheld Deprec.:</span>
              <span className="font-bold font-mono text-amber-300">
                +${(claim.carrierOffer?.depreciationWithheld || 0).toLocaleString()}
              </span>
            </div>
            <div className="p-2 rounded-lg bg-slate-900/60 border border-slate-800 text-[11px]">
              <span className="text-slate-400 block">Policy Deductible:</span>
              <span className="font-bold font-mono text-rose-300">
                -${(claim.policyLimits?.deductible || 0).toLocaleString()}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Case Dossier & Missing Evidence Quick Status */}
      <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 border border-indigo-500/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-lg">
        <div className="flex items-center gap-3.5">
          <div className="w-10 h-10 rounded-xl bg-indigo-500/20 border border-indigo-500/40 flex items-center justify-center text-indigo-400 shrink-0">
            <FolderArchive className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-white uppercase tracking-wider font-mono">
                Case Dossier & Evidence Health
              </span>
              <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40">
                {claim.completenessAudit?.overallScore || 74}% Case Readiness
              </span>
            </div>
            <p className="text-xs text-slate-300/80 mt-0.5">
              {claim.evidence.length} documents and {(claim.photos || []).length} damage photos loaded. AI Case Auditor detected missing items.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5 w-full sm:w-auto">
          <button
            onClick={() => onNavigateTab('evidence')}
            className="w-full sm:w-auto px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-md shadow-indigo-500/20 flex items-center justify-center gap-2 transition-all"
          >
            <HelpCircle className="w-4 h-4" />
            <span>Ask If Anything Is Missing</span>
          </button>
        </div>
      </div>

      {/* Epistemic Health & 3-Channel Relational Pressure Gauges */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        
        {/* Klein Transition Channels (Matter, Relation, Chronology) */}
        <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Layers className="w-4 h-4 text-sky-400" />
              <h3 className="text-sm font-bold text-white font-sans">Klein Transition Channels</h3>
            </div>
            <span className="text-[11px] font-mono text-slate-400">Total RPM: {rpm.totalPressure.toFixed(1)}</span>
          </div>

          <div className="space-y-3">
            {/* Matter k66 */}
            <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80 space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-slate-200">Matter & Damage (k66)</span>
                <span className="font-mono text-emerald-400 font-bold">{rpm.channels.matter_k66} pts</span>
              </div>
              <p className="text-[11px] text-slate-400">
                Physical loss, contractor estimates, roof core measurements, Xactimate unit costs.
              </p>
            </div>

            {/* Relation k90 */}
            <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80 space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-slate-200">Relation & Policy (k90)</span>
                <span className="font-mono text-sky-400 font-bold">{rpm.channels.relation_k90} pts</span>
              </div>
              <p className="text-[11px] text-slate-400">
                Form HO-00-03 coverage, Ordinance & Law 25% rider, exclusion burdens on insurer.
              </p>
            </div>

            {/* Chronology k120 */}
            <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80 space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-slate-200">Chronology & Notice (k120)</span>
                <span className="font-mono text-amber-400 font-bold">{rpm.channels.chronology_k120} pts</span>
              </div>
              <p className="text-[11px] text-slate-400">
                NOAA windstorm timestamp, date of loss, 60-day statutory bad faith cure countdown.
              </p>
            </div>
          </div>
        </div>

        {/* Epistemic Evidence Mass Breakdown */}
        <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Scale className="w-4 h-4 text-emerald-400" />
              <h3 className="text-sm font-bold text-white font-sans">Epistemic Evidence Strength</h3>
            </div>
            <span className="text-[11px] font-mono text-emerald-400 font-semibold">94% Validated</span>
          </div>

          <div className="grid grid-cols-2 gap-2.5">
            <div className="p-3 rounded-xl bg-emerald-950/30 border border-emerald-800/40">
              <div className="text-[10px] font-mono text-emerald-300 uppercase">[[[VALIDATED]]]</div>
              <div className="text-xl font-bold text-emerald-200 font-mono mt-1">{bracketCounts.VALIDATED}</div>
              <div className="text-[10px] text-emerald-400/80 mt-0.5">Direct PE / NOAA Proof</div>
            </div>

            <div className="p-3 rounded-xl bg-amber-950/30 border border-amber-800/40">
              <div className="text-[10px] font-mono text-amber-300 uppercase">{'{[EXPLAINED]}'}</div>
              <div className="text-xl font-bold text-amber-200 font-mono mt-1">{bracketCounts.EXPLAINED}</div>
              <div className="text-[10px] text-amber-400/80 mt-0.5">Structural Sub-bids</div>
            </div>

            <div className="p-3 rounded-xl bg-purple-950/30 border border-purple-800/40">
              <div className="text-[10px] font-mono text-purple-300 uppercase">[[SPECULATIVE]]</div>
              <div className="text-xl font-bold text-purple-200 font-mono mt-1">{bracketCounts.SPECULATIVE}</div>
              <div className="text-[10px] text-purple-400/80 mt-0.5">Adjuster Opinions</div>
            </div>

            <div className="p-3 rounded-xl bg-rose-950/30 border border-rose-800/40">
              <div className="text-[10px] font-mono text-rose-300 uppercase">[!CONTRADICTED!]</div>
              <div className="text-xl font-bold text-rose-200 font-mono mt-1">{claim.tensions?.length || 0}</div>
              <div className="text-[10px] text-rose-400/80 mt-0.5">Carrier Lowball Tensions</div>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 text-xs text-slate-300 flex items-center justify-between">
            <span>Independent Provenance Roots:</span>
            <span className="font-mono font-bold text-sky-400">5 Distinct Entities</span>
          </div>
        </div>

        {/* Quick Next Move / Tactical Action Hub */}
        <div className="p-5 rounded-2xl bg-gradient-to-br from-slate-900 to-slate-950 border border-slate-800 space-y-4 flex flex-col justify-between">
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <Zap className="w-4 h-4 text-amber-400" />
              <h3 className="text-sm font-bold text-white font-sans">Recommended Next Recovery Move</h3>
            </div>
            
            <div className="p-3.5 rounded-xl bg-sky-950/30 border border-sky-800/40 text-xs text-slate-200 space-y-2">
              <div className="font-semibold text-sky-300 flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-sky-400" />
                Serve 14-Day Supplemental Demand Package
              </div>
              <p className="text-[11px] text-slate-300 leading-relaxed">
                Attach the Apex PE structural affidavit proving the 25% building code roof mandate, along with the 4-trade Xactimate estimate invoking 10/10 GCO&P.
              </p>
            </div>
          </div>

          <div className="space-y-2 pt-2">
            <button
              onClick={() => onNavigateTab('legal_letters')}
              className="w-full py-2.5 px-3 rounded-xl bg-sky-500 hover:bg-sky-400 text-white text-xs font-semibold shadow-md shadow-sky-500/20 transition-all flex items-center justify-center gap-2"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Draft Pre-Settlement Demand</span>
            </button>
            <button
              onClick={onOpenAdvisorChat}
              className="w-full py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-medium transition-colors flex items-center justify-center gap-2"
            >
              <Sparkles className="w-3.5 h-3.5 text-sky-400" />
              <span>Ask AI Claim Advisor</span>
            </button>
          </div>
        </div>

      </div>

      {/* Active Tensions & Carrier Denial Contradictions */}
      <div className="p-6 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-400" />
              <span>Active Claim Tensions & Carrier Contradictions</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Specific points where the carrier's denial or lowball directly conflicts with validated evidence.
            </p>
          </div>
          <span className="text-xs font-mono px-2.5 py-1 rounded-md bg-rose-950/60 text-rose-300 border border-rose-800/60">
            {claim.tensions?.length || 0} Critical Contradictions
          </span>
        </div>

        <div className="space-y-3">
          {claim.tensions?.map((tension) => (
            <div
              key={tension.id}
              className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 hover:border-slate-700 transition-all space-y-3"
            >
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-xs font-bold text-white">{tension.title}</span>
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-slate-800 text-slate-300">
                    {tension.category}
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-xs font-bold font-mono text-emerald-400">
                    +${tension.monetaryExposure.toLocaleString()}
                  </span>
                  <span className="text-[10px] text-slate-400 block font-mono">Disputed Exposure</span>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                <div className="p-3 rounded-lg bg-rose-950/20 border border-rose-800/30 space-y-1">
                  <div className="flex items-center justify-between text-[11px] font-mono text-rose-400 font-semibold">
                    <span>CARRIER POSITION</span>
                    <span>[{tension.carrierBracket}]</span>
                  </div>
                  <p className="text-slate-300 text-[11px]">{tension.carrierPosition}</p>
                </div>

                <div className="p-3 rounded-lg bg-emerald-950/20 border border-emerald-800/30 space-y-1">
                  <div className="flex items-center justify-between text-[11px] font-mono text-emerald-400 font-semibold">
                    <span>POLICYHOLDER VALIDATED PROOF</span>
                    <span>[[[{tension.policyholderBracket}]]]</span>
                  </div>
                  <p className="text-slate-300 text-[11px]">{tension.policyholderEvidence}</p>
                </div>
              </div>

              <div className="p-2.5 rounded-lg bg-sky-950/30 border border-sky-800/30 text-[11px] text-sky-200 flex items-start gap-2">
                <ArrowUpRight className="w-3.5 h-3.5 text-sky-400 shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold">Resolution Strategy: </span>
                  <span>{tension.resolutionStrategy}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Canonical PAi Epistemic Legend */}
      <EpistemicLegend />

    </div>
  );
};
