import type { EpistemicBracket } from '../types';

/**
 * Policy coverage terms as bracketed facts.
 *
 * Every value carries the bracket it earned and the place it came from.
 * Nothing in this module invents a policy term. A term that was not read
 * from a document is UNVERIFIED and says so.
 */

/** Where a value was read from. */
export interface PolicySource {
  evidenceId: string;
  formNumber?: string;      // e.g. 'HO-00-03 04 91'
  page?: number;
  line?: number;
  ocrConfidence?: number;   // 0..1, drives bracket ceiling
}

/** A single policy term with its epistemic status. */
export interface PolicyValue<T = number> {
  value: T | null;
  bracket: EpistemicBracket;
  /** Every place this value was found. Two agreeing sources => VALIDATED. */
  sources: PolicySource[];
  /** Formula, when the value was computed rather than read. */
  derivation?: string;
  /** Why the bracket is what it is — shown in the UI, not inferred at render. */
  note?: string;
}

export interface BracketedPolicyLimits {
  dwelling_covA: PolicyValue;
  otherStructures_covB: PolicyValue;
  personalProperty_covC: PolicyValue;
  lossOfUse_covD: PolicyValue;
  ordinanceAndLaw_percent: PolicyValue;
  ordinanceAndLaw_amount: PolicyValue;
  moldRemediationLimit: PolicyValue;
  debrisRemovalPercent: PolicyValue;
  deductible: PolicyValue;
  deductibleType: PolicyValue<'flat_dollar' | 'percentage_named_storm'>;
  /** Settlement basis governs whether depreciation is recoverable. */
  settlementBasis: PolicyValue<'RCV' | 'ACV'>;
  policyPeriodStart: PolicyValue<string>;
  policyPeriodEnd: PolicyValue<string>;
  suitLimitationMonths: PolicyValue;
  proofOfLossDays: PolicyValue;
}

/**
 * Two reads of the same term that disagreed and could not be settled against
 * the document. Held on the record rather than resolved away: the software
 * does not pick a winner, and neither value is used in any figure until the
 * user confirms one against the policy.
 */
export interface PolicyConflict {
  id: string;
  /** Which term disagreed, in plain language. */
  label: string;
  /** Field on BracketedPolicyLimits, when the conflict maps to one. */
  term?: keyof BracketedPolicyLimits;
  page: number | null;
  candidates: Array<{
    value: string;
    method: string;
    confidence?: number | null;
    occurrences?: number;
  }>;
  /** What was tried before giving up. */
  reason: string;
  /** What the user has to do. */
  userAction: string;
  /** Set once the user confirms a value against the document. */
  resolvedValue?: string | null;
  resolvedAt?: string | null;
}

/** Endorsement listed on the dec page, and whether its form was actually supplied. */
export interface EndorsementEntry {
  formNumber: string;
  title?: string;
  listedOnDecPage: boolean;
  formPresentInUpload: boolean;
  evidenceId?: string;
}

export interface PolicyRecord {
  claimId: string;
  limits: BracketedPolicyLimits;
  endorsements: EndorsementEntry[];
  /** Disagreements between reads that the document could not settle. */
  conflicts: PolicyConflict[];
  /** Set when the insured explicitly declined to supply the policy. */
  declined: boolean;
}

/* ------------------------------------------------------------------ */
/* Bracket algebra                                                     */
/* ------------------------------------------------------------------ */

const RANK: Record<Exclude<EpistemicBracket, 'CONTRADICTED'>, number> = {
  UNVERIFIED: 0,
  SPECULATIVE: 1,
  EXPLAINED: 2,
  VALIDATED: 3,
};

/**
 * A result is never more confident than its weakest input.
 * A contradicted input poisons the result outright — a conflict is not
 * a weak fact, it is a live disagreement and must surface as one.
 */
export function weakestBracket(...brackets: EpistemicBracket[]): EpistemicBracket {
  if (brackets.length === 0) return 'UNVERIFIED';
  if (brackets.includes('CONTRADICTED')) return 'CONTRADICTED';
  let lowest: Exclude<EpistemicBracket, 'CONTRADICTED'> = 'VALIDATED';
  for (const b of brackets) {
    const cur = b as Exclude<EpistemicBracket, 'CONTRADICTED'>;
    if (RANK[cur] < RANK[lowest]) lowest = cur;
  }
  return lowest;
}

/** An absent term. This is the default for every field. */
export function unverified<T>(note: string): PolicyValue<T> {
  return { value: null, bracket: 'UNVERIFIED', sources: [], note };
}

/**
 * A term read from the policy.
 * Two independent agreeing sources earn VALIDATED; one earns EXPLAINED.
 * Poor OCR caps the result regardless of source count.
 */
export function transcribed<T>(
  value: T,
  sources: PolicySource[],
  note?: string,
): PolicyValue<T> {
  const worstOcr = Math.min(...sources.map((s) => s.ocrConfidence ?? 1));
  let bracket: EpistemicBracket = sources.length >= 2 ? 'VALIDATED' : 'EXPLAINED';
  if (worstOcr < 0.75) bracket = 'UNVERIFIED';
  else if (worstOcr < 0.9) bracket = weakestBracket(bracket, 'SPECULATIVE');
  return { value, bracket, sources, note };
}

/**
 * A term computed from other terms. Cannot exceed SPECULATIVE, and cannot
 * exceed its weakest input — arithmetic on a guess is still a guess.
 */
export function derived<T>(
  value: T,
  derivation: string,
  inputs: PolicyValue<any>[],
  note?: string,
): PolicyValue<T> {
  const inherited = weakestBracket(...inputs.map((i) => i.bracket));
  return {
    value,
    bracket: weakestBracket(inherited, 'SPECULATIVE'),
    sources: inputs.flatMap((i) => i.sources),
    derivation,
    note,
  };
}

/** Same term found twice with different values. */
export function contradicted<T>(
  candidates: Array<{ value: T; source: PolicySource }>,
  note: string,
): PolicyValue<T> {
  return {
    value: null,
    bracket: 'CONTRADICTED',
    sources: candidates.map((c) => c.source),
    note,
  };
}

/* ------------------------------------------------------------------ */
/* Empty record — what a claim starts with                             */
/* ------------------------------------------------------------------ */

const NO_POLICY = 'No policy document on file. Supply the complete policy packet.';

export function emptyPolicyLimits(): BracketedPolicyLimits {
  return {
    dwelling_covA: unverified(NO_POLICY),
    otherStructures_covB: unverified(NO_POLICY),
    personalProperty_covC: unverified(NO_POLICY),
    lossOfUse_covD: unverified(NO_POLICY),
    ordinanceAndLaw_percent: unverified(NO_POLICY),
    ordinanceAndLaw_amount: unverified(NO_POLICY),
    moldRemediationLimit: unverified(NO_POLICY),
    debrisRemovalPercent: unverified(NO_POLICY),
    deductible: unverified(NO_POLICY),
    deductibleType: unverified(NO_POLICY),
    settlementBasis: unverified(NO_POLICY),
    policyPeriodStart: unverified(NO_POLICY),
    policyPeriodEnd: unverified(NO_POLICY),
    suitLimitationMonths: unverified(NO_POLICY),
    proofOfLossDays: unverified(NO_POLICY),
  };
}

/**
 * A figure the insured typed at intake with no document behind it.
 * This is UNVERIFIED by definition and must never be promoted by
 * arithmetic or by appearing in a summary.
 */
export function insuredAsserted<T>(value: T, field: string): PolicyValue<T> {
  return {
    value,
    bracket: 'UNVERIFIED',
    sources: [],
    note: `${field} entered at intake by the insured. Not read from a policy document.`,
  };
}

export function emptyPolicyRecord(claimId: string): PolicyRecord {
  return {
    claimId,
    limits: emptyPolicyLimits(),
    endorsements: [],
    conflicts: [],
    declined: false,
  };
}

/* ------------------------------------------------------------------ */
/* Completeness                                                        */
/* ------------------------------------------------------------------ */

export interface PolicyCompleteness {
  hasPolicyOnFile: boolean;
  /** Forms named on the dec page whose text was never supplied. */
  missingForms: string[];
  /** Terms still unread. */
  unreadTerms: string[];
  /** Terms found twice with conflicting values. */
  conflicts: string[];
  /** Extraction conflicts awaiting the user's confirmation. */
  unresolvedConflicts: PolicyConflict[];
  /** Ceiling any conclusion drawn from this policy can reach. */
  ceiling: EpistemicBracket;
}

export function assessCompleteness(record: PolicyRecord): PolicyCompleteness {
  const missingForms = record.endorsements
    .filter((e) => e.listedOnDecPage && !e.formPresentInUpload)
    .map((e) => e.formNumber);

  const entries = Object.entries(record.limits) as Array<[string, PolicyValue<any>]>;
  const unreadTerms = entries
    .filter(([, v]) => v.bracket === 'UNVERIFIED')
    .map(([k]) => k);
  const conflicts = entries
    .filter(([, v]) => v.bracket === 'CONTRADICTED')
    .map(([k]) => k);

  // Conflicts raised during extraction and not yet confirmed by the user count
  // the same as a contradicted term — the value is disputed either way.
  const unresolved = (record.conflicts ?? []).filter((c) => !c.resolvedValue);
  for (const c of unresolved) {
    const key = c.term ?? c.label;
    if (!conflicts.includes(key as string)) conflicts.push(key as string);
  }

  const hasPolicyOnFile = entries.some(
    ([, v]) => v.bracket === 'EXPLAINED' || v.bracket === 'VALIDATED',
  );

  let ceiling = weakestBracket(...entries.map(([, v]) => v.bracket));
  if (unresolved.length > 0) ceiling = 'CONTRADICTED';
  // A form named on the dec page but never supplied means the governing
  // language is unread, whatever the dec page numbers say.
  if (missingForms.length > 0) ceiling = weakestBracket(ceiling, 'SPECULATIVE');

  return {
    hasPolicyOnFile,
    missingForms,
    unreadTerms,
    conflicts,
    unresolvedConflicts: unresolved,
    ceiling,
  };
}

/* ------------------------------------------------------------------ */
/* Coverage boundary checks                                            */
/* ------------------------------------------------------------------ */

export interface BoundaryCheck {
  id: string;
  label: string;
  /** Null when the governing term is unread — an untestable boundary. */
  passed: boolean | null;
  bracket: EpistemicBracket;
  detail: string;
  citedTerms: string[];
}

/**
 * Deterministic comparisons of claim figures against policy terms.
 * Each result inherits the weakest bracket of its inputs, so a check run
 * against an unread limit reports as untestable rather than as a pass.
 */
export function runBoundaryChecks(
  record: PolicyRecord,
  claim: {
    dateOfLoss: string;
    contractorRCV: number;
    codeUpgrades: number;
    deductibleApplied: number;
  },
): BoundaryCheck[] {
  const L = record.limits;
  const checks: BoundaryCheck[] = [];

  const untestable = (id: string, label: string, term: string): BoundaryCheck => ({
    id,
    label,
    passed: null,
    bracket: 'UNVERIFIED',
    detail: `Cannot be tested: ${term} has not been read from a policy document.`,
    citedTerms: [term],
  });

  // 1. Date of loss inside the policy period.
  if (L.policyPeriodStart.value && L.policyPeriodEnd.value) {
    const dol = new Date(claim.dateOfLoss).getTime();
    const inside =
      dol >= new Date(L.policyPeriodStart.value).getTime() &&
      dol <= new Date(L.policyPeriodEnd.value).getTime();
    checks.push({
      id: 'period',
      label: 'Date of loss within policy period',
      passed: inside,
      bracket: weakestBracket(L.policyPeriodStart.bracket, L.policyPeriodEnd.bracket),
      detail: inside
        ? `Loss ${claim.dateOfLoss} falls inside ${L.policyPeriodStart.value} to ${L.policyPeriodEnd.value}.`
        : `Loss ${claim.dateOfLoss} falls OUTSIDE ${L.policyPeriodStart.value} to ${L.policyPeriodEnd.value}.`,
      citedTerms: ['policyPeriodStart', 'policyPeriodEnd'],
    });
  } else {
    checks.push(untestable('period', 'Date of loss within policy period', 'policy period'));
  }

  // 2. Repair scope against the dwelling limit.
  if (L.dwelling_covA.value !== null) {
    const within = claim.contractorRCV <= L.dwelling_covA.value;
    checks.push({
      id: 'cov_a',
      label: 'Repair scope against Coverage A',
      passed: within,
      bracket: L.dwelling_covA.bracket,
      detail: within
        ? `Scope $${claim.contractorRCV.toLocaleString()} is within the $${L.dwelling_covA.value.toLocaleString()} dwelling limit.`
        : `Scope $${claim.contractorRCV.toLocaleString()} EXCEEDS the $${L.dwelling_covA.value.toLocaleString()} dwelling limit by $${(claim.contractorRCV - L.dwelling_covA.value).toLocaleString()}.`,
      citedTerms: ['dwelling_covA'],
    });
  } else {
    checks.push(untestable('cov_a', 'Repair scope against Coverage A', 'Coverage A limit'));
  }

  // 3. Code upgrades against the ordinance and law allowance.
  if (L.ordinanceAndLaw_amount.value !== null) {
    const within = claim.codeUpgrades <= L.ordinanceAndLaw_amount.value;
    checks.push({
      id: 'ord_law',
      label: 'Code upgrades against ordinance and law allowance',
      passed: within,
      bracket: L.ordinanceAndLaw_amount.bracket,
      detail: within
        ? `Code upgrades $${claim.codeUpgrades.toLocaleString()} are within the $${L.ordinanceAndLaw_amount.value.toLocaleString()} allowance.`
        : `Code upgrades $${claim.codeUpgrades.toLocaleString()} exceed the $${L.ordinanceAndLaw_amount.value.toLocaleString()} allowance. Excess is not recoverable under this term.`,
      citedTerms: ['ordinanceAndLaw_amount'],
    });
  } else {
    checks.push(
      untestable('ord_law', 'Code upgrades against ordinance and law allowance', 'ordinance and law allowance'),
    );
  }

  // 4. Deductible the carrier applied against the deductible the policy states.
  if (L.deductible.value !== null) {
    const match = Math.abs(claim.deductibleApplied - L.deductible.value) < 1;
    checks.push({
      id: 'deductible',
      label: 'Deductible applied against policy deductible',
      passed: match,
      bracket: L.deductible.bracket,
      detail: match
        ? `Carrier applied $${claim.deductibleApplied.toLocaleString()}, matching the policy.`
        : `Carrier applied $${claim.deductibleApplied.toLocaleString()} against a stated $${L.deductible.value.toLocaleString()} — a $${Math.abs(claim.deductibleApplied - L.deductible.value).toLocaleString()} discrepancy.`,
      citedTerms: ['deductible', 'deductibleType'],
    });
  } else {
    checks.push(untestable('deductible', 'Deductible applied against policy deductible', 'deductible'));
  }

  return checks;
}

/* ------------------------------------------------------------------ */
/* Page transcripts on the record                                       */
/* ------------------------------------------------------------------ */

/**
 * Reconciled page readings, kept on the claim so the estimation gate and the
 * UI both work from the same record rather than re-deriving it.
 */
export interface PageReview {
  page: number;
  sources: string[];
  bracket: EpistemicBracket;
  unresolvedCount: number;
  requiresUserVerification: boolean;
  verifiedAt?: string | null;
}

/* ------------------------------------------------------------------ */
/* Outbound-document prerequisites                                     */
/* ------------------------------------------------------------------ */

export interface Prerequisite {
  id: string;
  label: string;
  satisfied: boolean;
  why: string;
}

export interface PrerequisiteResult {
  satisfied: boolean;
  blocking: Prerequisite[];
  all: Prerequisite[];
}

/**
 * Hard gate for anything that leaves the building.
 *
 * A dispute letter is read by an adjuster, and later possibly by opposing
 * counsel. Unlike the workspace — where a warning is enough, because the user
 * can see the caveat alongside the number — an exported letter travels alone.
 * Every figure in it is therefore asserted without its bracket attached.
 *
 * So the letter is not generated at all until the terms it would rely on have
 * actually been read. This is a prerequisite, not a warning.
 */
export function disputeLetterPrerequisites(claim: {
  intakeGaps?: string[];
  policyRecord?: PolicyRecord;
  evidence?: Array<{ type: string; filename: string }>;
  carrierName?: string;
  claimNumber?: string;
  policyNumber?: string;
  dateOfLoss?: string;
}): PrerequisiteResult {
  const rec = claim.policyRecord;
  const comp = rec ? assessCompleteness(rec) : null;

  // The packet must physically be on the case. Terms read from it raise the
  // bracket of what the letter can assert, but the document itself is the
  // prerequisite — an unread packet still means the user has the policy.
  const packetOnFile =
    (claim.evidence ?? []).some(
      (e) => e.type === 'policy_dec' && !!e.filename?.trim(),
    ) || !!comp?.hasPolicyOnFile;

  const all: Prerequisite[] = [
    {
      id: 'policy_on_file',
      label: 'Policy packet supplied',
      satisfied: packetOnFile,
      why: 'A demand quotes coverage terms. The policy has to be on the case before those terms can be relied on.',
    },
    {
      id: 'no_conflicts',
      label: 'No conflicting policy values outstanding',
      satisfied: (comp?.conflicts.length ?? 0) === 0,
      why: 'A term found twice with different values must be resolved before it is quoted.',
    },
    {
      id: 'claim_identity',
      label: 'Carrier, claim number and date of loss entered',
      satisfied:
        !!claim.carrierName?.trim() &&
        !!claim.claimNumber?.trim() &&
        !!claim.dateOfLoss?.trim(),
      why: 'A letter without these cannot be matched to a file by the recipient.',
    },
    {
      id: 'intake_complete',
      label: 'No intake fields left blank',
      satisfied: (claim.intakeGaps?.length ?? 0) === 0,
      why: claim.intakeGaps?.length
        ? `Not entered: ${claim.intakeGaps.join(', ')}.`
        : 'Blank intake fields propagate into the demand total.',
    },
  ];

  const blocking = all.filter((p) => !p.satisfied);
  return { satisfied: blocking.length === 0, blocking, all };
}
