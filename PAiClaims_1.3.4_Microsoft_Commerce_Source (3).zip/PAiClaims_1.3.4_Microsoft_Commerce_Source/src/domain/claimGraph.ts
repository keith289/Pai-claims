import type {
  ClaimGraph,
  ClaimGraphEdge,
  ClaimGraphEdgeKind,
  ClaimGraphHistoryEvent,
  ClaimGraphNode,
  ClaimGraphNodeKind,
  DamageInventoryItem,
  EpistemicBracket,
  EvidenceItem,
  InsuranceClaim,
  RPMChannel,
  XactimateLineItem,
} from '../types';

const rank: Record<Exclude<EpistemicBracket, 'CONTRADICTED'>, number> = {
  UNVERIFIED: 0,
  SPECULATIVE: 1,
  EXPLAINED: 2,
  VALIDATED: 3,
};

const nowIso = () => new Date().toISOString();
const safeId = (value: string) => value.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 80) || 'node';

export function strongerBracket(current: EpistemicBracket, proposed: EpistemicBracket): EpistemicBracket {
  if (proposed === 'CONTRADICTED') return 'CONTRADICTED';
  if (current === 'CONTRADICTED') return proposed;
  return rank[proposed] > rank[current] ? proposed : current;
}

function rootsFor(evidenceIds: string[], evidence: EvidenceItem[]): string[] {
  return [...new Set(evidenceIds.map((id) => evidence.find((item) => item.id === id)?.provenanceRoot?.trim()).filter(Boolean) as string[])];
}

function historyEvent(
  id: string,
  at: string,
  action: ClaimGraphHistoryEvent['action'],
  toBracket: EpistemicBracket,
  reason: string,
  sourceEvidenceId?: string,
  provenanceRoot?: string,
  fromBracket?: EpistemicBracket,
  previousValue?: string | number,
  nextValue?: string | number,
): ClaimGraphHistoryEvent {
  return { id, at, action, fromBracket, toBracket, sourceEvidenceId, provenanceRoot, reason, previousValue, nextValue };
}

function mergeNode(previous: ClaimGraphNode | undefined, next: ClaimGraphNode): ClaimGraphNode {
  if (!previous) {
    return {
      ...next,
      history: [historyEvent(`h-${next.id}-created`, next.createdAt, 'created', next.bracket, next.reason, next.sourceEvidenceIds[0], next.provenanceRoots[0], undefined, undefined, next.amount ?? next.value)],
    };
  }
  const history = [...previous.history];
  let bracket = next.bracket;
  if (previous.bracket !== 'CONTRADICTED' && next.bracket !== 'CONTRADICTED') bracket = strongerBracket(previous.bracket, next.bracket);
  if (bracket !== previous.bracket) {
    history.push(historyEvent(`h-${next.id}-${history.length}-bracket`, next.updatedAt, bracket === 'CONTRADICTED' ? 'contradicted' : 'promoted', bracket, next.reason, next.sourceEvidenceIds[0], next.provenanceRoots[0], previous.bracket));
  }
  const oldValue = previous.amount ?? previous.value;
  const newValue = next.amount ?? next.value;
  if (newValue !== undefined && oldValue !== newValue) {
    history.push(historyEvent(`h-${next.id}-${history.length}-value`, next.updatedAt, 'corrected', bracket, next.reason, next.sourceEvidenceIds[0], next.provenanceRoots[0], previous.bracket, oldValue, newValue));
  }
  return {
    ...previous,
    ...next,
    bracket,
    sourceEvidenceIds: [...new Set([...previous.sourceEvidenceIds, ...next.sourceEvidenceIds])],
    provenanceRoots: [...new Set([...previous.provenanceRoots, ...next.provenanceRoots])],
    createdAt: previous.createdAt,
    history,
  };
}

function mergeEdge(previous: ClaimGraphEdge | undefined, next: ClaimGraphEdge): ClaimGraphEdge {
  if (!previous) {
    return {
      ...next,
      history: [historyEvent(`h-${next.id}-created`, next.createdAt, 'created', next.bracket, next.reason, next.sourceEvidenceIds[0], next.provenanceRoots[0])],
    };
  }
  const bracket = previous.bracket === 'CONTRADICTED' || next.bracket === 'CONTRADICTED'
    ? next.bracket
    : strongerBracket(previous.bracket, next.bracket);
  const history = [...previous.history];
  if (bracket !== previous.bracket) history.push(historyEvent(`h-${next.id}-${history.length}-bracket`, next.updatedAt, bracket === 'CONTRADICTED' ? 'contradicted' : 'promoted', bracket, next.reason, next.sourceEvidenceIds[0], next.provenanceRoots[0], previous.bracket));
  return {
    ...previous,
    ...next,
    bracket,
    sourceEvidenceIds: [...new Set([...previous.sourceEvidenceIds, ...next.sourceEvidenceIds])],
    provenanceRoots: [...new Set([...previous.provenanceRoots, ...next.provenanceRoots])],
    createdAt: previous.createdAt,
    history,
  };
}

function node(
  id: string,
  kind: ClaimGraphNodeKind,
  statement: string,
  bracket: EpistemicBracket,
  channel: RPMChannel,
  reason: string,
  at: string,
  evidenceIds: string[],
  evidence: EvidenceItem[],
  extra: Partial<ClaimGraphNode> = {},
): ClaimGraphNode {
  return {
    id,
    kind,
    statement,
    bracket,
    channel,
    reason,
    sourceEvidenceIds: [...new Set(evidenceIds)],
    provenanceRoots: rootsFor(evidenceIds, evidence),
    createdAt: at,
    updatedAt: at,
    history: [],
    ...extra,
  };
}

function edge(
  fromNodeId: string,
  toNodeId: string,
  kind: ClaimGraphEdgeKind,
  bracket: EpistemicBracket,
  reason: string,
  at: string,
  evidenceIds: string[],
  evidence: EvidenceItem[],
): ClaimGraphEdge {
  return {
    id: `edge:${safeId(fromNodeId)}:${kind}:${safeId(toNodeId)}`,
    fromNodeId,
    toNodeId,
    kind,
    bracket,
    reason,
    sourceEvidenceIds: [...new Set(evidenceIds)],
    provenanceRoots: rootsFor(evidenceIds, evidence),
    createdAt: at,
    updatedAt: at,
    history: [],
  };
}

function addDamageItem(nodes: ClaimGraphNode[], edges: ClaimGraphEdge[], item: DamageInventoryItem, evidence: EvidenceItem[], at: string) {
  // Photo/vision discovery always begins as a provisional proposition.  The
  // graph is promoted only by later independent evidence, never by the AI that
  // created the proposition.
  const initialBracket: EpistemicBracket = item.carrierResolution ? 'EXPLAINED' : 'SPECULATIVE';
  const evidenceIds = item.photoEvidenceIds;
  const damageId = `damage:${item.id}`;
  const damage = node(damageId, 'damage', item.statement, initialBracket, 'matter_k66', 'Observed or inferred from claim photographs; provisional until corroborated.', at, evidenceIds, evidence, { damageInventoryId: item.id });
  nodes.push(damage);

  const locationId = `location:${item.id}`;
  nodes.push(node(locationId, 'location', item.location || 'Location inferred from photo context', initialBracket, 'matter_k66', 'Location supplied by photo analysis or claim metadata.', at, evidenceIds, evidence, { damageInventoryId: item.id, value: item.location || 'unknown' }));
  edges.push(edge(damageId, locationId, 'located_at', initialBracket, 'Damage proposition is located at this area.', at, evidenceIds, evidence));

  const causeId = `cause:${item.id}`;
  nodes.push(node(causeId, 'cause', item.likelyCause || 'Cause not yet independently tested', initialBracket, 'relation_k90', 'Cause is an initial inference from the visible damage pattern.', at, evidenceIds, evidence, { damageInventoryId: item.id, value: item.likelyCause || 'unknown' }));
  edges.push(edge(causeId, damageId, 'causes', initialBracket, 'Photo-analysis causation relationship; remains provisional until corroborated.', at, evidenceIds, evidence));

  const extentId = `extent:${item.id}`;
  nodes.push(node(extentId, 'extent', item.extent || 'Extent requires measurement', initialBracket, 'matter_k66', 'Extent originates from photo analysis or provisional measurement.', at, evidenceIds, evidence, { damageInventoryId: item.id, value: item.extent || 'unknown' }));
  edges.push(edge(damageId, extentId, 'quantified_as', initialBracket, 'Extent describes the provisional size/severity of the damage.', at, evidenceIds, evidence));

  item.repairOperations.forEach((operation, index) => {
    const operationId = `repair:${item.id}:${operation.id || index}`;
    nodes.push(node(operationId, 'repair_operation', operation.description, initialBracket, 'matter_k66', 'Repair operation is inferred from the visible damage and repair relationship.', at, evidenceIds, evidence, { damageInventoryId: item.id, repairOperationId: operation.id, value: operation.description }));
    edges.push(edge(damageId, operationId, 'requires', initialBracket, 'Visible/inferred damage is mapped to this provisional repair operation.', at, evidenceIds, evidence));

    const quantityId = `quantity:${item.id}:${operation.id || index}`;
    nodes.push(node(quantityId, 'quantity', `${operation.quantity} ${operation.unit} for ${operation.description}`, initialBracket, 'matter_k66', 'Quantity is the current photo/takeoff estimate and is not set in stone.', at, evidenceIds, evidence, { damageInventoryId: item.id, repairOperationId: operation.id, value: operation.quantity, unit: operation.unit }));
    edges.push(edge(operationId, quantityId, 'quantified_as', initialBracket, 'Repair operation uses this provisional quantity.', at, evidenceIds, evidence));

    const components = operation.costComponents || [];
    if (!components.length) {
      const laborId = `labor:${item.id}:${operation.id || index}`;
      nodes.push(node(laborId, 'labor', `${operation.laborHours} provisional worker-hour(s) for ${operation.description}`, initialBracket, 'matter_k66', 'Labor hours are a provisional estimating input until regional/Xactimate labor evidence is supplied.', at, evidenceIds, evidence, { damageInventoryId: item.id, repairOperationId: operation.id, value: operation.laborHours, unit: 'worker-hour' }));
      edges.push(edge(operationId, laborId, 'related_to', initialBracket, 'Labor input belongs to this repair operation.', at, evidenceIds, evidence));
    }

    components.forEach((component, componentIndex) => {
      const kind = component.kind === 'material' ? 'material'
        : component.kind === 'labor' ? 'labor'
        : component.kind === 'equipment' ? 'equipment'
        : component.kind === 'disposal' ? 'disposal'
        : component.kind === 'permit' ? 'permit'
        : component.kind === 'tax' ? 'tax'
        : component.kind === 'overhead_profit' ? 'overhead_profit'
        : 'other';
      const componentId = `cost:${item.id}:${operation.id || index}:${component.id || componentIndex}`;
      const bracket = component.bracket || initialBracket;
      const componentEvidence = [...new Set([...(component.sourceEvidenceIds || []), ...evidenceIds])];
      nodes.push(node(
        componentId,
        kind,
        `${component.label}: $${Number(component.amount || 0).toFixed(2)}`,
        bracket,
        kind === 'labor' || kind === 'material' || kind === 'equipment' || kind === 'disposal' ? 'matter_k66' : 'relation_k90',
        component.reason,
        at,
        componentEvidence,
        evidence,
        {
          damageInventoryId: item.id,
          repairOperationId: operation.id,
          costComponentId: component.id,
          amount: Number(component.amount || 0),
          currency: 'USD',
          metadata: {
            sourceMethod: component.sourceMethod,
            costKind: component.kind,
            workerHours: component.workerHours ?? null,
            laborRate: component.laborRate ?? null,
            regionalDifferencePct: component.regionalDifferencePct ?? null,
          },
        },
      ));
      edges.push(edge(operationId, componentId, 'priced_by', bracket, `${component.kind} cost belongs to this repair operation.`, at, componentEvidence, evidence));

      const reasonId = `reason:${item.id}:${operation.id || index}:${component.id || componentIndex}`;
      nodes.push(node(reasonId, 'reason', component.reason, bracket, 'relation_k90', 'Every price reason is itself a bracketed proposition and matures independently.', at, componentEvidence, evidence, { damageInventoryId: item.id, repairOperationId: operation.id, costComponentId: component.id }));
      edges.push(edge(reasonId, componentId, 'reason_for', bracket, 'This bracketed reason explains this cost component.', at, componentEvidence, evidence));
    });
  });

  const amount = Number(item.pass2Valuation?.amount ?? item.valuation?.amount ?? 0);
  const priceId = `price:${item.id}`;
  const priceReason = item.pass2Valuation?.pricingBasis || item.valuation?.pricingBasis || 'Provisional model price from photo-derived scope; later passes replace or refine it with regional/supplier/carrier evidence.';
  const priceBracket: EpistemicBracket = item.pass2Valuation ? item.pass2Valuation.bracket : initialBracket;
  nodes.push(node(priceId, 'price', `$${amount.toFixed(2)} current PSi repair value — ${item.component}`, priceBracket, 'matter_k66', priceReason, at, evidenceIds, evidence, { damageInventoryId: item.id, amount, currency: 'USD', metadata: { pricingBasis: priceReason } }));
  edges.push(edge(damageId, priceId, 'priced_by', priceBracket, 'The initial claim estimate assigns a rough value to every observed/inferred damage item.', at, evidenceIds, evidence));

  const reasonId = `reason:${item.id}:price`;
  nodes.push(node(reasonId, 'reason', priceReason, priceBracket, 'relation_k90', 'The reason/basis for the price is itself a bracketed proposition and must mature independently.', at, evidenceIds, evidence, { damageInventoryId: item.id }));
  edges.push(edge(reasonId, priceId, 'reason_for', priceBracket, 'This bracketed reason explains why the provisional price is present.', at, evidenceIds, evidence));

  (item.valuation?.assumptions || []).forEach((assumption, index) => {
    const assumptionId = `reason:${item.id}:assumption:${index}`;
    nodes.push(node(assumptionId, 'reason', assumption, initialBracket, 'relation_k90', 'Assumption used to complete the initial estimate; it remains provisional until independently confirmed.', at, evidenceIds, evidence, { damageInventoryId: item.id }));
    edges.push(edge(assumptionId, priceId, 'reason_for', initialBracket, 'Assumption contributes to the provisional valuation.', at, evidenceIds, evidence));
  });

  if (item.carrierResolution) {
    const carrierId = `carrier:${item.id}:${item.carrierResolution.sourceEvidenceId}`;
    const carrierEvidence = [item.carrierResolution.sourceEvidenceId];
    nodes.push(node(carrierId, 'carrier_position', `Carrier returned $${item.carrierResolution.amount.toFixed(2)} for ${item.component}`, 'EXPLAINED', 'relation_k90', 'Carrier/adjuster estimate is an independent claim position; it corroborates only the facts it actually addresses.', item.carrierResolution.resolvedAt || at, carrierEvidence, evidence, { damageInventoryId: item.id, amount: item.carrierResolution.amount, currency: 'USD', metadata: { resolutionStatus: item.carrierResolution.status } }));
    edges.push(edge(carrierId, damageId, 'confirmed_by', 'EXPLAINED', 'Carrier line matching this damage item adds one independent corroborating path.', item.carrierResolution.resolvedAt || at, carrierEvidence, evidence));
    edges.push(edge(carrierId, priceId, item.carrierResolution.status === 'corrected' ? 'corrected_by' : 'confirmed_by', 'EXPLAINED', 'Carrier amount confirms or corrects the provisional valuation without erasing the original.', item.carrierResolution.resolvedAt || at, carrierEvidence, evidence));
  }
}

export function buildClaimGraph(claim: InsuranceClaim, at = nowIso()): ClaimGraph {
  const previous = claim.claimGraph;
  const nextNodes: ClaimGraphNode[] = [];
  const nextEdges: ClaimGraphEdge[] = [];

  (claim.damageInventory || []).forEach((item) => addDamageItem(nextNodes, nextEdges, item, claim.evidence, at));

  claim.evidence.forEach((record) => {
    const channel: RPMChannel = record.type === 'policy_dec' || record.type === 'denial_letter'
      ? 'relation_k90'
      : record.type === 'weather_data' || record.type === 'communication'
        ? 'chronology_k120'
        : 'matter_k66';
    (record.keyObservations || []).forEach((observation, index) => {
      const id = `evidence-observation:${record.id}:${index}`;
      nextNodes.push(node(id, 'other', observation, record.bracketState, channel, `Observation extracted from ${record.title}.`, at, [record.id], claim.evidence, { metadata: { evidenceType: record.type } }));
    });
  });

  (claim.actualAuthorities || []).forEach((authority, index) => {
    const ids = authority.sourceEvidenceId ? [authority.sourceEvidenceId] : [];
    nextNodes.push(node(`authority:${index}:${safeId(authority.citation)}`, 'authority', `${authority.citation} — ${authority.title}`, authority.sourceEvidenceId ? 'EXPLAINED' : 'UNVERIFIED', 'relation_k90', 'Authority remains separate from the physical-damage and payment propositions it may support.', at, ids, claim.evidence, { value: authority.citation }));
  });

  (claim.monetaryTruths || []).forEach((truth) => {
    const bracket: EpistemicBracket = truth.kind === 'received' ? 'VALIDATED' : truth.bracket;
    const paymentId = `money:${truth.id}`;
    nextNodes.push(node(paymentId, truth.kind === 'received' ? 'payment' : 'carrier_position', truth.statement, bracket, truth.kind === 'received' ? 'chronology_k120' : 'relation_k90', truth.kind === 'received' ? 'Actual receipt/payment is a direct monetary event.' : 'Monetary claim position is preserved as its own proposition.', truth.recordedAt || at, truth.evidenceIds, claim.evidence, { amount: truth.amount, currency: 'USD', damageInventoryId: truth.damageInventoryId, repairOperationId: truth.repairOperationId, lineItemId: truth.lineItemId, metadata: { monetaryKind: truth.kind } }));
    if (truth.kind === 'received') {
      const targets = nextNodes.filter((candidate) =>
        candidate.kind === 'price' &&
        ((truth.damageInventoryId && candidate.damageInventoryId === truth.damageInventoryId) ||
          (truth.repairOperationId && candidate.repairOperationId === truth.repairOperationId) ||
          (truth.lineItemId && candidate.lineItemId === truth.lineItemId))
      );
      targets.forEach((target) => {
        nextEdges.push(edge(
          target.id,
          paymentId,
          'paid_by',
          truth.finalForLinkedItem ? 'VALIDATED' : 'EXPLAINED',
          truth.finalForLinkedItem
            ? 'Actual final payment closes the linked monetary proposition; unrelated scope facts are not automatically promoted.'
            : 'Actual partial/interim payment is direct monetary evidence but does not close the linked monetary proposition.',
          truth.recordedAt || at,
          truth.evidenceIds,
          claim.evidence,
        ));
      });
    }
  });

  claim.auditTrail.slice(0, 50).forEach((event) => {
    nextNodes.push(node(`timeline:${event.id}`, 'timeline', `${event.action}: ${event.impact}`, event.bracketStatus, 'chronology_k120', 'Audit event records how the claim map changed over time.', event.timestamp || at, [], claim.evidence, { value: event.timestamp }));
  });

  const oldNodes = new Map((previous?.nodes || []).map((item) => [item.id, item]));
  const oldEdges = new Map((previous?.edges || []).map((item) => [item.id, item]));
  const nodes = nextNodes.map((item) => mergeNode(oldNodes.get(item.id), item));
  const edges = nextEdges.map((item) => mergeEdge(oldEdges.get(item.id), item));

  // Preserve superseded/older nodes in history rather than deleting the map's
  // memory when a later pass no longer emits them.
  (previous?.nodes || []).forEach((old) => {
    if (!nodes.some((item) => item.id === old.id)) nodes.push(old);
  });
  (previous?.edges || []).forEach((old) => {
    if (!edges.some((item) => item.id === old.id)) edges.push(old);
  });

  return { version: 1, nodes, edges, rebuiltAt: at };
}

const words = (value: string) => new Set(value.toLowerCase().match(/[a-z0-9]{3,}/g) || []);
const overlap = (left: string, right: string) => {
  const a = words(left); const b = words(right);
  if (!a.size || !b.size) return 0;
  return [...a].filter((word) => b.has(word)).length / Math.min(a.size, b.size);
};

/**
 * A carrier/Xactimate counter is one new independent path, not automatic final
 * proof.  It may promote the particular damage/scope/quantity/price facts it
 * actually confirms from SPECULATIVE to EXPLAINED.  A differing amount is
 * stored as a new carrier node and never overwrites the original PSi value.
 */
export function applyCarrierToClaimGraph(
  graph: ClaimGraph,
  inventory: DamageInventoryItem[],
  carrierItems: XactimateLineItem[],
  sourceEvidenceId: string,
  evidence: EvidenceItem[],
  at = nowIso(),
): ClaimGraph {
  const nodes = graph.nodes.map((item) => ({ ...item, history: [...item.history] }));
  const edges = graph.edges.map((item) => ({ ...item, history: [...item.history] }));
  const byId = new Map(nodes.map((item) => [item.id, item]));
  const source = evidence.find((item) => item.id === sourceEvidenceId);
  const root = source?.provenanceRoot;

  const promote = (id: string, reason: string) => {
    const target = byId.get(id);
    if (!target || target.bracket === 'VALIDATED') return;
    const prior = target.bracket;
    const next = strongerBracket(prior, 'EXPLAINED');
    if (next === prior) return;
    target.bracket = next;
    target.updatedAt = at;
    target.sourceEvidenceIds = [...new Set([...target.sourceEvidenceIds, sourceEvidenceId])];
    if (root) target.provenanceRoots = [...new Set([...target.provenanceRoots, root])];
    target.history.push(historyEvent(`h-${target.id}-${target.history.length}-carrier`, at, 'promoted', next, reason, sourceEvidenceId, root, prior));
  };

  inventory.forEach((damage) => {
    const searchable = [damage.statement, damage.component, damage.damageType, ...damage.repairOperations.map((op) => op.description)].join(' ');
    const ranked = carrierItems.map((carrier) => ({ carrier, score: overlap(searchable, `${carrier.category} ${carrier.description}`) })).sort((a, b) => b.score - a.score);
    const match = ranked[0];
    if (!match || match.score < 0.34) return;

    promote(`damage:${damage.id}`, 'Carrier/adjuster estimate independently addresses this damage/scope proposition.');
    damage.repairOperations.forEach((operation, index) => {
      const operationId = operation.id || String(index);
      if (overlap(operation.description, `${match.carrier.category} ${match.carrier.description}`) >= 0.25) {
        promote(`repair:${damage.id}:${operationId}`, 'Carrier line independently addresses this repair operation.');
        const qtyNode = byId.get(`quantity:${damage.id}:${operationId}`);
        if (qtyNode && match.carrier.carrierQuantity > 0) {
          const currentQty = Number(qtyNode.value || 0);
          const carrierQty = Number(match.carrier.carrierQuantity);
          const close = currentQty > 0 && Math.abs(currentQty - carrierQty) <= Math.max(0.01, currentQty * 0.02);
          if (close) promote(qtyNode.id, 'Carrier quantity independently corroborates the current PSi quantity within 2%.');
          const carrierQtyId = `carrier-quantity:${damage.id}:${match.carrier.id}`;
          if (!byId.has(carrierQtyId)) {
            const carrierQtyNode = node(carrierQtyId, 'quantity', `Carrier quantity: ${carrierQty} ${match.carrier.unit} — ${match.carrier.description}`, 'EXPLAINED', 'relation_k90', 'Imported unchanged from carrier/Xactimate estimate.', at, [sourceEvidenceId], evidence, { value: carrierQty, unit: match.carrier.unit, damageInventoryId: damage.id, carrierLineItemId: match.carrier.id });
            carrierQtyNode.history = [historyEvent(`h-${carrierQtyId}-created`, at, 'created', 'EXPLAINED', carrierQtyNode.reason, sourceEvidenceId, root)];
            nodes.push(carrierQtyNode); byId.set(carrierQtyId, carrierQtyNode);
            edges.push(edge(carrierQtyId, qtyNode.id, close ? 'confirmed_by' : 'corrected_by', 'EXPLAINED', close ? 'Carrier quantity corroborates the PSi quantity.' : 'Carrier quantity differs and is preserved as a competing proposition.', at, [sourceEvidenceId], evidence));
          }
        }

        // Material and labor are separate propositions. The carrier can add one
        // corroborating path to each cost class it actually exposes without
        // validating the rest of the estimate line.
        const costNodes = nodes.filter((candidate) =>
          candidate.damageInventoryId === damage.id
          && candidate.repairOperationId === operation.id
          && candidate.id.startsWith('cost:')
        );

        const addCarrierCost = (
          costKind: 'material' | 'labor' | 'equipment' | 'tax' | 'overhead_profit',
          amount: number,
          detail: string,
        ) => {
          if (!(amount > 0)) return;
          const psiCost = costNodes.find((candidate) => candidate.metadata?.costKind === costKind);
          const carrierCostId = `carrier-${costKind}:${damage.id}:${operationId}:${match.carrier.id}`;
          if (!byId.has(carrierCostId)) {
            const carrierCost = node(
              carrierCostId,
              costKind === 'overhead_profit' ? 'overhead_profit' : costKind,
              `Carrier/Xactimate ${costKind.replace('_', ' ')}: $${amount.toFixed(2)} — ${match.carrier.description}`,
              'EXPLAINED',
              'relation_k90',
              `Imported/derived from the supplied carrier estimate. ${detail}`,
              at,
              [sourceEvidenceId],
              evidence,
              { amount, currency: 'USD', damageInventoryId: damage.id, repairOperationId: operation.id, carrierLineItemId: match.carrier.id, metadata: { costKind, carrierBasis: true } },
            );
            carrierCost.history = [historyEvent(`h-${carrierCostId}-created`, at, 'created', 'EXPLAINED', carrierCost.reason, sourceEvidenceId, root)];
            nodes.push(carrierCost); byId.set(carrierCostId, carrierCost);
            if (psiCost) {
              const psiAmount = Number(psiCost.amount || 0);
              const close = psiAmount > 0 && Math.abs(psiAmount - amount) <= Math.max(1, psiAmount * 0.02);
              if (close) promote(psiCost.id, `Carrier/Xactimate ${costKind.replace('_', ' ')} independently corroborates the current PSi cost within 2%.`);
              edges.push(edge(
                carrierCostId,
                psiCost.id,
                close ? 'confirmed_by' : 'corrected_by',
                'EXPLAINED',
                close
                  ? `Carrier ${costKind.replace('_', ' ')} corroborates the PSi proposition.`
                  : `Carrier ${costKind.replace('_', ' ')} differs and is retained as a competing proposition; it does not erase PSi.`,
                at,
                [sourceEvidenceId],
                evidence,
              ));
            }
          }
        };

        addCarrierCost('material', Number(match.carrier.materialAmount || 0), 'Material amount was exposed by the carrier/Xactimate line.');
        const carrierLabor = Number(match.carrier.workerHours || 0) > 0 && Number(match.carrier.laborRate || 0) > 0
          ? Number(match.carrier.workerHours) * Number(match.carrier.laborRate)
          : Number(match.carrier.laborAmount || 0);
        addCarrierCost('labor', carrierLabor, Number(match.carrier.workerHours || 0) > 0 && Number(match.carrier.laborRate || 0) > 0
          ? `${Number(match.carrier.workerHours).toFixed(2)} worker-hours × $${Number(match.carrier.laborRate).toFixed(2)}/hr.`
          : 'Labor amount was exposed by the carrier/Xactimate line.');
        addCarrierCost('equipment', Number(match.carrier.equipmentAmount || 0), 'Equipment amount was exposed by the carrier/Xactimate line.');
        addCarrierCost('tax', Number(match.carrier.tax || 0), 'Tax amount was exposed by the carrier/Xactimate line.');
        addCarrierCost('overhead_profit', Number(match.carrier.overheadAndProfit || 0), 'O&P amount was exposed by the carrier/Xactimate line; entitlement remains a separate policy/rule question.');
      }
    });

    const carrierAmount = match.carrier.carrierRCV ?? match.carrier.carrierTotal;
    const priceNode = byId.get(`price:${damage.id}`);
    if (priceNode && carrierAmount > 0) {
      const current = Number(priceNode.amount || 0);
      const close = current > 0 && Math.abs(current - carrierAmount) <= Math.max(1, current * 0.02);
      if (close) promote(priceNode.id, 'Carrier/Xactimate amount independently corroborates the current PSi value within 2%.');
      const carrierPriceId = `carrier-price:${damage.id}:${match.carrier.id}`;
      if (!byId.has(carrierPriceId)) {
        const carrierPrice = node(carrierPriceId, 'price', `Carrier/Xactimate value $${carrierAmount.toFixed(2)} — ${match.carrier.description}`, 'EXPLAINED', 'relation_k90', 'Carrier value is imported unchanged and compared against, not substituted for, the original PSi estimate.', at, [sourceEvidenceId], evidence, { amount: carrierAmount, currency: 'USD', damageInventoryId: damage.id, carrierLineItemId: match.carrier.id });
        carrierPrice.history = [historyEvent(`h-${carrierPriceId}-created`, at, 'created', 'EXPLAINED', carrierPrice.reason, sourceEvidenceId, root)];
        nodes.push(carrierPrice); byId.set(carrierPriceId, carrierPrice);
        edges.push(edge(carrierPriceId, priceNode.id, close ? 'confirmed_by' : 'corrected_by', 'EXPLAINED', close ? 'Carrier amount corroborates the PSi amount.' : 'Carrier amount differs; both values remain visible for Parliament.', at, [sourceEvidenceId], evidence));
      }
    }
  });

  return { ...graph, nodes, edges, rebuiltAt: at };
}

export function graphStats(graph: ClaimGraph) {
  const counts: Record<EpistemicBracket, number> = { UNVERIFIED: 0, SPECULATIVE: 0, EXPLAINED: 0, VALIDATED: 0, CONTRADICTED: 0 };
  graph.nodes.forEach((item) => counts[item.bracket]++);
  return {
    nodeCount: graph.nodes.length,
    edgeCount: graph.edges.length,
    counts,
    amountByBracket: graph.nodes.reduce((acc, item) => {
      if (typeof item.amount === 'number') acc[item.bracket] = (acc[item.bracket] || 0) + item.amount;
      return acc;
    }, {} as Partial<Record<EpistemicBracket, number>>),
  };
}

const normalize = (value: string) => value.toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();

/**
 * Attach an independently ingested evidence record to the atomic propositions
 * it explicitly names.  The evidence record must point at a graph node id or
 * repeat the proposition text through assertionIds; merely uploading a file is
 * not enough to promote unrelated nodes.
 */
export function applyEvidenceToClaimGraph(graph: ClaimGraph, record: EvidenceItem, at = nowIso()): ClaimGraph {
  const assertions = new Set((record.assertionIds || []).map(normalize));
  if (!assertions.size) return graph;
  const nodes = graph.nodes.map((item) => ({ ...item, history: [...item.history] }));
  const root = record.provenanceRoot?.trim();

  nodes.forEach((target) => {
    const matched = assertions.has(normalize(target.id)) || assertions.has(normalize(target.statement));
    if (!matched) return;
    const prior = target.bracket;
    let next = prior;
    let action: ClaimGraphHistoryEvent['action'] = 'promoted';

    if (record.stance === 'contradicts') {
      next = 'CONTRADICTED';
      action = 'contradicted';
    } else if (record.stance === 'supports' && !record.compromised) {
      if (record.evidenceLevel === 'direct') {
        const roots = new Set(target.provenanceRoots.map((item) => item.toLowerCase()));
        if (root) roots.add(root.toLowerCase());
        next = prior === 'EXPLAINED' && roots.size >= 2 ? 'VALIDATED' : strongerBracket(prior, 'EXPLAINED');
      } else if (record.evidenceLevel === 'structural') {
        next = strongerBracket(prior, 'EXPLAINED');
      }
    }

    target.sourceEvidenceIds = [...new Set([...target.sourceEvidenceIds, record.id])];
    if (root) target.provenanceRoots = [...new Set([...target.provenanceRoots, root])];
    target.updatedAt = at;
    if (next !== prior) {
      target.bracket = next;
      target.history.push(historyEvent(
        `h-${target.id}-${target.history.length}-evidence`,
        at,
        action,
        next,
        `${record.title} ${action === 'contradicted' ? 'contradicts' : 'independently supports'} this proposition.`,
        record.id,
        root,
        prior,
      ));
    }
  });

  return { ...graph, nodes, rebuiltAt: at };
}

/**
 * A received payment validates the payment event and promotes only the linked
 * monetary price proposition to VALIDATED. Damage/cause/scope remain at their
 * own evidentiary level unless independently proven.
 */
export function applyPaymentToClaimGraph(
  graph: ClaimGraph,
  payment: { id: string; amount: number; evidenceIds: string[]; recordedAt: string; damageInventoryId?: string; repairOperationId?: string; lineItemId?: string; statement: string; finalForLinkedItem?: boolean },
  evidence: EvidenceItem[],
): ClaimGraph {
  const nodes = graph.nodes.map((item) => ({ ...item, history: [...item.history] }));
  const edges = graph.edges.map((item) => ({ ...item, history: [...item.history] }));
  const at = payment.recordedAt || nowIso();
  const paymentId = `money:${payment.id}`;
  const root = payment.evidenceIds.map((id) => evidence.find((e) => e.id === id)?.provenanceRoot).filter(Boolean)[0] as string | undefined;

  let payNode = nodes.find((n) => n.id === paymentId);
  if (!payNode) {
    payNode = node(paymentId, 'payment', payment.statement, 'VALIDATED', 'chronology_k120', 'Actual received payment is a direct monetary event.', at, payment.evidenceIds, evidence, { amount: payment.amount, currency: 'USD', damageInventoryId: payment.damageInventoryId, repairOperationId: payment.repairOperationId, lineItemId: payment.lineItemId });
    payNode.history = [historyEvent(`h-${paymentId}-created`, at, 'paid', 'VALIDATED', payNode.reason, payment.evidenceIds[0], root)];
    nodes.push(payNode);
  }

  nodes.forEach((target) => {
    if (target.kind !== 'price') return;
    const linked = (payment.damageInventoryId && target.damageInventoryId === payment.damageInventoryId)
      || (payment.repairOperationId && target.repairOperationId === payment.repairOperationId)
      || (payment.lineItemId && target.lineItemId === payment.lineItemId);
    if (!linked) return;

    // Every received payment is a validated monetary event, but only a payment
    // explicitly recorded as final for the linked item closes/promotes that
    // item's PSi monetary proposition. Partial payments remain connected proof
    // without pretending the repair price itself is finally established.
    if (payment.finalForLinkedItem) {
      const prior = target.bracket;
      if (prior !== 'VALIDATED') {
        target.bracket = 'VALIDATED';
        target.updatedAt = at;
        target.sourceEvidenceIds = [...new Set([...target.sourceEvidenceIds, ...payment.evidenceIds])];
        if (root) target.provenanceRoots = [...new Set([...target.provenanceRoots, root])];
        target.history.push(historyEvent(`h-${target.id}-${target.history.length}-paid`, at, 'paid', 'VALIDATED', 'Linked amount was actually paid as the final resolution for this item; this closes the monetary proposition.', payment.evidenceIds[0], root, prior, target.amount, payment.amount));
      }
      edges.push(edge(target.id, paymentId, 'paid_by', 'VALIDATED', 'Final actual payment validates the linked monetary proposition only.', at, payment.evidenceIds, evidence));
    } else {
      edges.push(edge(target.id, paymentId, 'paid_by', 'EXPLAINED', 'A received partial/interim payment is direct monetary evidence but does not close the linked PSi price proposition.', at, payment.evidenceIds, evidence));
    }
  });

  return { ...graph, nodes, edges, rebuiltAt: at };
}
