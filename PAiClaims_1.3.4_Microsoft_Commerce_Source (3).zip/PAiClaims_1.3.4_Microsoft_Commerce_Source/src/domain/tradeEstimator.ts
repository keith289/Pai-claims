import type {
  ContractorRateObservation,
  EvidenceItem,
  LowesMaterialPrice,
  TradeCategory,
  TradeEstimateResult,
} from '../types.ts';

const round = (value: number) => Math.round((Number.isFinite(value) ? value : 0) * 100) / 100;

export const TRADE_MATERIAL_SLOTS: Record<TradeCategory, string[]> = {
  Roofing: ['Field roofing', 'Underlayment', 'Starter course', 'Ridge/hip cap', 'Drip edge', 'Fasteners', 'Flashing/sealant'],
  'Drywall & Framing': ['Drywall panels', 'Joint compound', 'Joint tape', 'Drywall fasteners', 'Corner bead', 'Framing lumber'],
  'Paint & Finishes': ['Finish paint', 'Primer/sealer', 'Caulk', 'Masking/protection', 'Roller/brush consumables'],
  Flooring: ['Finish flooring', 'Underlayment', 'Adhesive/fasteners', 'Transitions', 'Moisture barrier'],
  Siding: ['Siding panels', 'House wrap', 'Starter/trim', 'Fasteners', 'Sealant/flashing'],
  Framing: ['Dimensional lumber', 'Structural panels', 'Connectors', 'Fasteners', 'Construction adhesive'],
  Insulation: ['Insulation', 'Vapor retarder', 'Tape/sealant', 'Fasteners/supports'],
  Plumbing: ['Pipe/tubing', 'Fittings', 'Valves', 'Hangers', 'Consumables'],
  'Electrical & HVAC': ['Cable/conduit', 'Boxes/connectors', 'Devices/equipment', 'Fasteners/supports', 'Consumables'],
  'Water Mitigation': ['Containment materials', 'Antimicrobial product', 'Air filters', 'Extraction consumables', 'Protective materials'],
};

export function uniqueProvenanceRoots(items: EvidenceItem[]): string[] {
  const seenHashes = new Set<string>();
  const roots = new Set<string>();
  for (const item of items) {
    const hash = item.contentHash?.trim().toLowerCase();
    if (hash && seenHashes.has(hash)) continue;
    if (hash) seenHashes.add(hash);
    const root = item.provenanceRoot?.trim().toLowerCase();
    if (root) roots.add(root);
  }
  return [...roots];
}

export function median(values: number[]): number | null {
  const finite = values.filter(Number.isFinite).sort((a, b) => a - b);
  if (!finite.length) return null;
  const middle = Math.floor(finite.length / 2);
  return finite.length % 2 ? finite[middle] : (finite[middle - 1] + finite[middle]) / 2;
}

/**
 * Derive the local contractor direct-cost delta from actual contractor estimates
 * for equivalent scope. Three independent provenance roots are required before
 * the result can be used as SUPPORTED. Repeated copies of one estimate never
 * increase independence.
 */
export function deriveContractorMedian(
  trade: TradeCategory,
  observations: ContractorRateObservation[],
  evidence: EvidenceItem[]
) {
  const evidenceById = new Map(evidence.map((item) => [item.id, item]));
  const eligible = observations.filter(
    (item) =>
      item.trade === trade &&
      item.lowesMaterialSubtotal > 0 &&
      item.contractorDirectCost >= item.lowesMaterialSubtotal &&
      evidenceById.has(item.evidenceId)
  );

  // One observation per independent provenance root. Content-hash duplicates
  // are discarded first, then the remaining observations are grouped by root.
  // This prevents one contractor/source from overweighting the median by
  // submitting several different files or repeated exports.
  const byRoot = new Map<string, ContractorRateObservation>();
  const seenHashes = new Set<string>();
  for (const item of eligible) {
    const ev = evidenceById.get(item.evidenceId)!;
    const hash = ev.contentHash?.trim().toLowerCase();
    if (hash && seenHashes.has(hash)) continue;
    if (hash) seenHashes.add(hash);
    const root = (ev.provenanceRoot || hash || item.evidenceId).trim().toLowerCase();
    if (!byRoot.has(root)) byRoot.set(root, item);
  }
  const independent = [...byRoot.values()];
  const percentages = independent.map(
    (item) => ((item.contractorDirectCost - item.lowesMaterialSubtotal) / item.lowesMaterialSubtotal) * 100
  );

  return {
    medianPercent: median(percentages),
    observationIds: independent.map((item) => item.id),
    independentRoots: byRoot.size,
    status: byRoot.size >= 3 ? ('SUPPORTED' as const) : ('REQUIRES_DATA' as const),
  };
}

export function calculateTradeEstimate(input: {
  trade: TradeCategory;
  measuredQuantity: number;
  measuredUnit: string;
  materials: LowesMaterialPrice[];
  observations: ContractorRateObservation[];
  evidence: EvidenceItem[];
  taxRate: number;
  userAdjustmentPercent?: number;
  now?: Date;
}): TradeEstimateResult {
  const missingInputs: string[] = [];
  const now = input.now || new Date();

  if (!(input.measuredQuantity > 0)) missingInputs.push('measured repair quantity');
  if (!input.measuredUnit.trim()) missingInputs.push('measurement unit');
  if (!input.materials.length) missingInputs.push('source-traced material selections');

  for (const material of input.materials) {
    if (!(material.sellingPrice > 0) || !(material.purchaseUnits > 0)) {
      missingInputs.push(`${material.description}: price and purchase units`);
    }
    if (!material.storeId || !material.zipCode) {
      missingInputs.push(`${material.description}: store and ZIP`);
    }
    if (material.sourceMethod === 'lowes_quote' && !material.sourceEvidenceId) {
      missingInputs.push(`${material.description}: attach the Lowe's quote/price evidence`);
    }
    const ageDays = (now.getTime() - new Date(material.fetchedAt).getTime()) / 86_400_000;
    if (!Number.isFinite(ageDays) || ageDays > 30) {
      missingInputs.push(`${material.description}: refresh price (older than 30 days)`);
    }
  }

  const derived = deriveContractorMedian(input.trade, input.observations, input.evidence);
  const userAdjustment =
    Number.isFinite(input.userAdjustmentPercent) && input.userAdjustmentPercent! >= 0
      ? input.userAdjustmentPercent!
      : null;
  const adjustment = derived.medianPercent ?? userAdjustment;

  if (adjustment === null) {
    missingInputs.push('contractor direct-cost delta or evidence-backed contractor observations');
  }
  if (derived.medianPercent === null && userAdjustment !== null) {
    missingInputs.push('evidence-backed contractor median; typed percentage is scenario-only');
  }
  if (derived.medianPercent !== null && derived.status !== 'SUPPORTED') {
    missingInputs.push('three independent contractor provenance roots for a supported median');
  }

  const materialSubtotal = round(
    input.materials.reduce((sum, item) => sum + item.sellingPrice * item.purchaseUnits, 0)
  );
  const contractorAdjustmentAmount = round(materialSubtotal * ((adjustment || 0) / 100));
  const materialTax = round(materialSubtotal * Math.max(0, input.taxRate));

  return {
    status: missingInputs.length ? 'REQUIRES_DATA' : 'SUPPORTED',
    trade: input.trade,
    measuredQuantity: input.measuredQuantity,
    measuredUnit: input.measuredUnit,
    materialSubtotal,
    contractorAdjustmentPercent: adjustment === null ? null : round(adjustment),
    contractorAdjustmentAmount,
    materialTax,
    documentedTradeCost: round(materialSubtotal + contractorAdjustmentAmount + materialTax),
    missingInputs: [...new Set(missingInputs)],
    materialSources: input.materials,
    observationIds: derived.observationIds,
  };
}
