import assert from 'node:assert/strict';
import test from 'node:test';
import { calculateTradeEstimate, deriveContractorMedian, median } from './tradeEstimator.ts';
import type { ContractorRateObservation, EvidenceItem, LowesMaterialPrice } from '../types.ts';

const evidence = (id: string, root: string): EvidenceItem => ({
  id, title: id, type: 'contractor_estimate', filename: `${id}.pdf`, date: '2026-08-01', source: root,
  provenanceRoot: root, evidenceLevel: 'structural', stance: 'supports', bracketState: 'EXPLAINED', excerpt: '', rawText: '',
  floatPoints: 0, mixPoints: 0, stirPoints: 0, totalPressure: 0, keyObservations: [], contentHash: `hash-${id}`,
});
const observations: ContractorRateObservation[] = [
  { id: 'o1', trade: 'Roofing', lowesMaterialSubtotal: 100, contractorDirectCost: 150, evidenceId: 'e1', observedAt: '2026-08-01' },
  { id: 'o2', trade: 'Roofing', lowesMaterialSubtotal: 100, contractorDirectCost: 160, evidenceId: 'e2', observedAt: '2026-08-01' },
  { id: 'o3', trade: 'Roofing', lowesMaterialSubtotal: 100, contractorDirectCost: 170, evidenceId: 'e3', observedAt: '2026-08-01' },
];

test('median contractor delta is deterministic', () => assert.equal(median([70, 50, 60]), 60));

test('supported median requires three independent roots', () => {
  const records = [evidence('e1', 'A'), evidence('e2', 'B'), evidence('e3', 'C')];
  assert.equal(deriveContractorMedian('Roofing', observations, records).status, 'SUPPORTED');
  const repeated = records.map((record) => ({ ...record, provenanceRoot: 'same', contentHash: undefined }));
  assert.equal(deriveContractorMedian('Roofing', observations, repeated).status, 'REQUIRES_DATA');
});

test('fresh local prices plus supported contractor delta produce a supported cost', () => {
  const material: LowesMaterialPrice = {
    productId: '123', description: 'Shingles', storeId: '100', zipCode: '31639', sellingPrice: 40,
    fetchedAt: '2026-08-20T00:00:00Z', sourceUrl: 'feed', sourceMethod: 'lowes_store_feed', purchaseUnits: 10,
  };
  const result = calculateTradeEstimate({
    trade: 'Roofing', measuredQuantity: 10, measuredUnit: 'SQ', materials: [material], observations,
    evidence: [evidence('e1', 'A'), evidence('e2', 'B'), evidence('e3', 'C')], taxRate: 0.07,
    now: new Date('2026-08-29T00:00:00Z'),
  });
  assert.equal(result.status, 'SUPPORTED');
  assert.equal(result.materialSubtotal, 400);
  assert.equal(result.contractorAdjustmentAmount, 240);
  assert.equal(result.materialTax, 28);
  assert.equal(result.documentedTradeCost, 668);
});
