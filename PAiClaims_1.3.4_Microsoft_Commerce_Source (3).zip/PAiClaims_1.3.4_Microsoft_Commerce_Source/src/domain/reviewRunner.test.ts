import assert from 'node:assert/strict';
import test from 'node:test';
import { splitPages, sourceForMethod, requestModelReread, buildPageReviews } from './reviewRunner.ts';
import { confirmDiscrepancy } from './transcriptReview.ts';

const DOC = {
  evidenceId: 'ev-1',
  filename: 'dec.pdf',
  text: '<<<PAGE 1>>>\nCoverage A $312,000\n\n<<<PAGE 2>>>\nDeductible $6,240',
  method: 'pdf-text',
  confidence: null,
};

const fetcherReturning = (pages: any[], ok = true, verified = true): any =>
  async () => ({ ok, json: async () => ({ verified, pages }) });

const failingFetcher: any = async () => { throw new Error('offline'); };

test('page markers split back into pages', () => {
  const pages = splitPages(DOC.text);
  assert.equal(pages.length, 2);
  assert.equal(pages[0].page, 1);
  assert.match(pages[0].text, /Coverage A \$312,000/);
  assert.equal(pages[1].page, 2);
});

test('text with no markers is a single page', () => {
  assert.deepEqual(splitPages('plain text'), [{ page: 1, text: 'plain text' }]);
  assert.deepEqual(splitPages('   '), []);
});

test('the extraction method decides which reader produced the text', () => {
  assert.equal(sourceForMethod('pdf-text'), 'pdf-text');
  assert.equal(sourceForMethod('tesseract-ocr'), 'tesseract-ocr');
  assert.equal(sourceForMethod('vision-model'), 'vision-model');
  assert.equal(sourceForMethod('anything-else'), 'pdf-text');
});

test('a model agreeing with the ingest validates the page', async () => {
  const reviews = await buildPageReviews(DOC, {
    fetcher: fetcherReturning([
      { page: 1, text: 'Coverage A $312,000' },
      { page: 2, text: 'Deductible $6,240' },
    ]),
  });
  assert.equal(reviews.length, 2);
  assert.equal(reviews[0].bracket, 'VALIDATED');
  assert.equal(reviews[0].unresolved.length, 0);
});

test('a model disagreeing on a figure raises it for the user', async () => {
  const reviews = await buildPageReviews(DOC, {
    fetcher: fetcherReturning([
      { page: 1, text: 'Coverage A $312,000' },
      { page: 2, text: 'Deductible $8,240' },
    ]),
  });
  assert.equal(reviews[1].unresolved.length, 1);
  assert.equal(reviews[1].bracket, 'CONTRADICTED');
  assert.equal(reviews[1].unresolved[0].numeric, true);
});

test('no provider configured still reconciles, it does not error', async () => {
  const reviews = await buildPageReviews(DOC, {
    fetcher: fetcherReturning([], true, false),
  });
  assert.equal(reviews.length, 2);
  assert.equal(reviews[0].sources.length, 1);
  assert.equal(reviews[0].bracket, 'EXPLAINED');
});

test('a failed model call degrades quietly rather than losing the document', async () => {
  const reviews = await buildPageReviews(DOC, { fetcher: failingFetcher });
  assert.equal(reviews.length, 2);
  assert.equal(reviews[0].requiresUserVerification, false);
  assert.equal((await requestModelReread([{ page: 1, text: 'x' }], failingFetcher)).length, 0);
});

test('a confirmation the user already made survives a re-run', async () => {
  const first = await buildPageReviews(DOC, {
    fetcher: fetcherReturning([
      { page: 1, text: 'Coverage A $312,000' },
      { page: 2, text: 'Deductible $8,240' },
    ]),
  });
  const settled = confirmDiscrepancy(first[1], first[1].unresolved[0].id, '$6,240');
  assert.equal(settled.unresolved.length, 0);

  const rerun = await buildPageReviews(DOC, {
    fetcher: fetcherReturning([
      { page: 1, text: 'Coverage A $312,000' },
      { page: 2, text: 'Deductible $8,240' },
    ]),
    existing: [first[0], settled],
  });
  assert.equal(rerun[1].unresolved.length, 0, 'the user should not be asked twice');
  assert.equal(rerun[1].discrepancies[0].resolvedBy, 'user');
});

test('a page verified by the user stays verified across a re-run', async () => {
  const doc = { ...DOC, text: '<<<PAGE 1>>>\nCoverage A $312,000', method: 'vision-model' };
  const first = await buildPageReviews(doc, { fetcher: fetcherReturning([], true, false) });
  assert.equal(first[0].requiresUserVerification, true);

  const rerun = await buildPageReviews(doc, {
    fetcher: fetcherReturning([], true, false),
    existing: [{ ...first[0], requiresUserVerification: false, verifiedAt: '2026-09-02T00:00:00Z' }],
  });
  assert.equal(rerun[0].requiresUserVerification, false);
});

test('image transcripts join the page they belong to', async () => {
  const reviews = await buildPageReviews(
    { ...DOC, text: '<<<PAGE 1>>>\nCoverage A $312,000' },
    {
      fetcher: fetcherReturning([], true, false),
      imageTranscripts: [{ page: 1, source: 'vision-model', text: 'Coverage A $312,000', confidence: null }],
    },
  );
  assert.equal(reviews[0].sources.length, 2);
  assert.equal(reviews[0].bracket, 'VALIDATED');
});
