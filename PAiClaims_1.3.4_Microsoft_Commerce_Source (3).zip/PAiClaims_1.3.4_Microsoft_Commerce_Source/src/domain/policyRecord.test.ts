import assert from 'node:assert/strict';
import test from 'node:test';
import { emptyPolicyRecord, transcribed, derived, insuredAsserted, weakestBracket, runBoundaryChecks, assessCompleteness, disputeLetterPrerequisites, contradicted } from './policyRecord.ts';

test('an unread policy makes every boundary check untestable, never a pass', () => {
  const rec = emptyPolicyRecord('c1');
  const checks = runBoundaryChecks(rec, { dateOfLoss: '2026-08-01', contractorRCV: 250000, codeUpgrades: 40000, deductibleApplied: 6240 });
  assert.equal(checks.length, 4);
  assert.ok(checks.every((c) => c.passed === null));
  assert.ok(!checks.some((c) => c.passed === true));
});

test('a figure typed by the insured never gains confidence through arithmetic', () => {
  const typed = insuredAsserted(312000, 'Coverage A');
  assert.equal(typed.bracket, 'UNVERIFIED');
  assert.equal(derived(78000, '0.25 * covA', [typed]).bracket, 'UNVERIFIED');
});

test('two agreeing sources validate; one explains; bad OCR does neither', () => {
  assert.equal(transcribed(312000, [{ evidenceId: 'a', ocrConfidence: 0.98 }]).bracket, 'EXPLAINED');
  assert.equal(transcribed(312000, [{ evidenceId: 'a', ocrConfidence: 0.98 }, { evidenceId: 'b', ocrConfidence: 0.97 }]).bracket, 'VALIDATED');
  assert.equal(transcribed(312000, [{ evidenceId: 'a', ocrConfidence: 0.6 }]).bracket, 'UNVERIFIED');
});

test('a derived term cannot exceed SPECULATIVE', () => {
  const validated = transcribed(312000, [{ evidenceId: 'a' }, { evidenceId: 'b' }]);
  assert.equal(validated.bracket, 'VALIDATED');
  assert.equal(derived(78000, '0.25 * covA', [validated]).bracket, 'SPECULATIVE');
});

test('a contradicted input poisons the result', () => {
  assert.equal(weakestBracket('VALIDATED', 'CONTRADICTED'), 'CONTRADICTED');
});

test('a form listed on the dec page but not supplied is named and caps the ceiling', () => {
  const rec = emptyPolicyRecord('c1');
  rec.limits.dwelling_covA = transcribed(312000, [{ evidenceId: 'dec' }, { evidenceId: 'sched' }]);
  rec.endorsements = [{ formNumber: 'HO-04-90 04 91', listedOnDecPage: true, formPresentInUpload: false }];
  const comp = assessCompleteness(rec);
  assert.deepEqual(comp.missingForms, ['HO-04-90 04 91']);
  assert.equal(comp.hasPolicyOnFile, true);
});

test('a read policy produces real verdicts that cite the term', () => {
  const rec = emptyPolicyRecord('c1');
  rec.limits.dwelling_covA = transcribed(312000, [{ evidenceId: 'dec', page: 1, line: 8 }]);
  rec.limits.deductible = transcribed(6240, [{ evidenceId: 'dec', page: 1, line: 11 }]);
  const checks = runBoundaryChecks(rec, { dateOfLoss: '2026-08-01', contractorRCV: 400000, codeUpgrades: 0, deductibleApplied: 9000 });
  const covA = checks.find((c) => c.id === 'cov_a')!;
  const ded = checks.find((c) => c.id === 'deductible')!;
  assert.equal(covA.passed, false);
  assert.equal(covA.bracket, 'EXPLAINED');
  assert.deepEqual(covA.citedTerms, ['dwelling_covA']);
  assert.equal(ded.passed, false);
});

const PACKET = [{ type: 'policy_dec', filename: 'policy.pdf' }];

test('a dispute letter is blocked when no policy packet is on the case', () => {
  const r = disputeLetterPrerequisites({
    intakeGaps: [], policyRecord: emptyPolicyRecord('c1'), evidence: [],
    carrierName: 'EverGuard', claimNumber: 'CLM-1', dateOfLoss: '2026-08-01',
  });
  assert.equal(r.satisfied, false);
  assert.ok(r.blocking.some((p) => p.id === 'policy_on_file'));
});

test('an empty filename does not count as a supplied packet', () => {
  const r = disputeLetterPrerequisites({
    intakeGaps: [], policyRecord: emptyPolicyRecord('c1'),
    evidence: [{ type: 'policy_dec', filename: '' }],
    carrierName: 'EverGuard', claimNumber: 'CLM-1', dateOfLoss: '2026-08-01',
  });
  assert.equal(r.satisfied, false);
  assert.ok(r.blocking.some((p) => p.id === 'policy_on_file'));
});

test('blank intake fields still block the letter', () => {
  const r = disputeLetterPrerequisites({
    intakeGaps: ['deductible'], policyRecord: emptyPolicyRecord('c1'), evidence: PACKET,
    carrierName: 'EverGuard', claimNumber: 'CLM-1', dateOfLoss: '2026-08-01',
  });
  assert.equal(r.satisfied, false);
  assert.ok(r.blocking.some((p) => p.id === 'intake_complete'));
});

test('a supplied packet plus complete intake clears the gate', () => {
  const r = disputeLetterPrerequisites({
    intakeGaps: [], policyRecord: emptyPolicyRecord('c1'), evidence: PACKET,
    carrierName: 'EverGuard', claimNumber: 'CLM-1', dateOfLoss: '2026-08-01',
  });
  assert.equal(r.satisfied, true, JSON.stringify(r.blocking.map((b) => b.id)));
});

test('conflicting policy values block the letter even with the packet on file', () => {
  const rec = emptyPolicyRecord('c1');
  rec.limits.dwelling_covA = contradicted(
    [{ value: 312000, source: { evidenceId: 'dec' } }, { value: 350000, source: { evidenceId: 'sched' } }],
    'Coverage A stated twice with different values',
  );
  const r = disputeLetterPrerequisites({
    intakeGaps: [], policyRecord: rec, evidence: PACKET,
    carrierName: 'EverGuard', claimNumber: 'CLM-1', dateOfLoss: '2026-08-01',
  });
  assert.equal(r.satisfied, false);
  assert.ok(r.blocking.some((p) => p.id === 'no_conflicts'));
});

const CONFLICT = {
  id: 'cf-1',
  label: 'Coverage A dwelling limit',
  term: 'dwelling_covA' as const,
  page: 1,
  candidates: [
    { value: '$312,000', method: 'pdf-text', occurrences: 1 },
    { value: '$412,000', method: 'tesseract-ocr', confidence: 0.96, occurrences: 1 },
  ],
  reason: 'Two readings disagree and nothing in the document settles it.',
  userAction: 'Open page 1 and confirm the dwelling limit.',
};

test('an unresolved extraction conflict drags the whole record to CONTRADICTED', () => {
  const rec = emptyPolicyRecord('c1');
  rec.limits.dwelling_covA = transcribed(312000, [{ evidenceId: 'dec', page: 1 }]);
  rec.conflicts = [{ ...CONFLICT }];
  const comp = assessCompleteness(rec);
  assert.equal(comp.ceiling, 'CONTRADICTED');
  assert.equal(comp.unresolvedConflicts.length, 1);
  assert.ok(comp.conflicts.includes('dwelling_covA'));
});

test('confirming a value clears the conflict', () => {
  const rec = emptyPolicyRecord('c1');
  rec.limits.dwelling_covA = transcribed(312000, [{ evidenceId: 'dec', page: 1 }]);
  rec.conflicts = [{ ...CONFLICT, resolvedValue: '$312,000', resolvedAt: '2026-09-02' }];
  const comp = assessCompleteness(rec);
  assert.equal(comp.unresolvedConflicts.length, 0);
  assert.notEqual(comp.ceiling, 'CONTRADICTED');
});

test('an unresolved conflict blocks a dispute letter even with the packet on file', () => {
  const rec = emptyPolicyRecord('c1');
  rec.conflicts = [{ ...CONFLICT }];
  const r = disputeLetterPrerequisites({
    intakeGaps: [], policyRecord: rec,
    evidence: [{ type: 'policy_dec', filename: 'policy.pdf' }],
    carrierName: 'EverGuard', claimNumber: 'CLM-1', dateOfLoss: '2026-08-01',
  });
  assert.equal(r.satisfied, false);
  assert.ok(r.blocking.some((p) => p.id === 'no_conflicts'));
});

test('both candidate values survive on the record so the user can choose', () => {
  const rec = emptyPolicyRecord('c1');
  rec.conflicts = [{ ...CONFLICT }];
  const [c] = assessCompleteness(rec).unresolvedConflicts;
  assert.equal(c.candidates.length, 2);
  assert.equal(c.candidates[0].value, '$312,000');
  assert.equal(c.candidates[1].value, '$412,000');
  assert.match(c.userAction, /confirm/i);
});
