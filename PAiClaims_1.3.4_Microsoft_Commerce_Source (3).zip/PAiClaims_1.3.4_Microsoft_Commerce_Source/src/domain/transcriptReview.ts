import type { EpistemicBracket } from '../types';

/**
 * Word-for-word reconciliation of the same page read by different means.
 *
 * Extraction produces characters. This decides whether those characters can be
 * trusted, by comparing every reader that saw the page and refusing to guess
 * when they disagree about something that matters.
 *
 * Three readers, in descending order of how directly they saw the page:
 *
 *   pdf-text       the publisher's own embedded text
 *   tesseract-ocr  a reconstruction from pixels, with per-word confidence
 *   vision-model   a model transcribing what it sees
 *
 * No reader is authoritative on its own. A scanner that embeds its own bad OCR
 * as a text layer is common enough that "the text layer wins" is not a safe
 * rule, so agreement between any two independent readers outranks any one.
 */

export type TranscriptSource = 'pdf-text' | 'tesseract-ocr' | 'vision-model';

export interface PageTranscript {
  page: number;
  source: TranscriptSource;
  text: string;
  /** 0..1 where the reader reports one. */
  confidence?: number | null;
}

export interface TranscriptDiscrepancy {
  id: string;
  page: number;
  /** Position in the reconciled word sequence. */
  index: number;
  /** Words either side, so the user can find it on the page. */
  context: string;
  /** True when the disputed word carries a number — money, dates, limits. */
  numeric: boolean;
  readings: Array<{
    source: TranscriptSource;
    value: string;
    confidence?: number | null;
  }>;
  resolved: boolean;
  /** Agreed or user-confirmed reading. Null while disputed. */
  value: string | null;
  bracket: EpistemicBracket;
  reason: string;
  userAction: string | null;
  resolvedBy?: 'agreement' | 'majority' | 'user' | null;
  resolvedAt?: string | null;
}

export interface ReconciliationResult {
  page: number;
  /** Best available text: agreed words, and a marker where they disagree. */
  text: string;
  discrepancies: TranscriptDiscrepancy[];
  unresolved: TranscriptDiscrepancy[];
  /** Ceiling for anything read off this page. */
  bracket: EpistemicBracket;
  /** Readers that contributed. */
  sources: TranscriptSource[];
  /** True when a human must confirm the text before figures may use it. */
  requiresUserVerification: boolean;
  verifiedAt?: string | null;
}

const RANK: Record<Exclude<EpistemicBracket, 'CONTRADICTED'>, number> = {
  UNVERIFIED: 0,
  SPECULATIVE: 1,
  EXPLAINED: 2,
  VALIDATED: 3,
};

function weakest(...brackets: EpistemicBracket[]): EpistemicBracket {
  if (brackets.length === 0) return 'UNVERIFIED';
  if (brackets.includes('CONTRADICTED')) return 'CONTRADICTED';
  let low: Exclude<EpistemicBracket, 'CONTRADICTED'> = 'VALIDATED';
  for (const b of brackets) {
    const cur = b as Exclude<EpistemicBracket, 'CONTRADICTED'>;
    if (RANK[cur] < RANK[low]) low = cur;
  }
  return low;
}

/**
 * Compare on content, not on spacing or sentence punctuation.
 *
 * Punctuation inside a word carrying digits is never stripped: "$6.240" and
 * "$6,240" are different amounts, and treating a decimal point as a thousands
 * separator would silently merge readings that differ by three orders of
 * magnitude. Only leading and trailing punctuation is removed from those.
 */
export function normalise(word: string): string {
  const raw = String(word ?? '').toLowerCase().trim();
  const trimmed = raw.replace(/^[.,;:!?"'`([\]]+/, '').replace(/[.,;:!?"'`)\]]+$/, '');
  if (/\d/.test(trimmed)) return trimmed;
  return trimmed.replace(/[.,;:!?"'`()[\]]/g, '');
}

export function words(text: string): string[] {
  return String(text ?? '')
    .replace(/<<<PAGE \d+>>>/g, ' ')
    .split(/\s+/)
    .filter(Boolean);
}

/** A word carrying digits is money, a date, a limit or a form number. */
export function isNumeric(word: string): boolean {
  return /\d/.test(word);
}

/* ------------------------------------------------------------------ */
/* Alignment                                                            */
/* ------------------------------------------------------------------ */

/**
 * Align word sequences from two or more readers.
 *
 * Readers drop and add words, so index-for-index comparison drifts and then
 * reports every remaining word as a discrepancy. This walks the sequences
 * together and resynchronises on the next run of words they agree on.
 */
export function alignSequences(sequences: string[][], lookahead = 6): string[][] {
  const cursors = sequences.map(() => 0);
  const rows: string[][] = [];

  const remaining = () => sequences.some((s, i) => cursors[i] < s.length);

  while (remaining()) {
    const current = sequences.map((s, i) => (cursors[i] < s.length ? s[cursors[i]] : ''));
    const normalised = current.map(normalise);
    const allAgree = normalised.every((w) => w === normalised[0]);

    if (allAgree) {
      rows.push(current);
      cursors.forEach((_, i) => {
        if (cursors[i] < sequences[i].length) cursors[i] += 1;
      });
      continue;
    }

    // Try to resynchronise: find the nearest word ahead that every reader has.
    let resynced = false;
    for (let offset = 1; offset <= lookahead && !resynced; offset += 1) {
      const candidate = normalise(sequences[0][cursors[0] + offset] ?? '');
      if (!candidate) continue;
      const positions = sequences.map((s, i) => {
        for (let k = 0; k <= lookahead; k += 1) {
          if (normalise(s[cursors[i] + k] ?? '') === candidate) return k;
        }
        return -1;
      });
      if (positions.every((pos) => pos >= 0)) {
        // Everything before the sync point is one disputed span per reader.
        const span = sequences.map((s, i) =>
          s.slice(cursors[i], cursors[i] + positions[i]).join(' '),
        );
        if (span.some((piece) => piece.length > 0)) rows.push(span);
        cursors.forEach((_, i) => {
          cursors[i] += positions[i];
        });
        resynced = true;
      }
    }

    if (!resynced) {
      rows.push(current);
      cursors.forEach((_, i) => {
        if (cursors[i] < sequences[i].length) cursors[i] += 1;
      });
    }
  }
  return rows;
}

/* ------------------------------------------------------------------ */
/* Reconciliation                                                       */
/* ------------------------------------------------------------------ */

/**
 * Reconcile every reading of one page.
 *
 * Resolution is by agreement only. Two readers that saw the page
 * independently and produced the same word corroborate each other; a single
 * reader does not. Nothing here picks the more plausible word, and a
 * disagreement over a number is never resolved by preferring a source.
 */
export function reconcilePage(
  transcripts: PageTranscript[],
  options: { verifiedAt?: string | null } = {},
): ReconciliationResult {
  const usable = transcripts.filter((t) => (t.text ?? '').trim().length > 0);
  const page = transcripts[0]?.page ?? 0;
  const sources = usable.map((t) => t.source);

  if (usable.length === 0) {
    return {
      page,
      text: '',
      discrepancies: [],
      unresolved: [],
      bracket: 'UNVERIFIED',
      sources: [],
      requiresUserVerification: false,
      verifiedAt: null,
    };
  }

  const visionOnly = usable.length === 1 && usable[0].source === 'vision-model';

  if (usable.length === 1) {
    const only = usable[0];
    // One reader is never corroboration. A lone model transcription of an
    // image must be confirmed by a person before any figure may rest on it.
    const bracket: EpistemicBracket =
      only.source === 'pdf-text'
        ? 'EXPLAINED'
        : only.source === 'tesseract-ocr'
          ? 'SPECULATIVE'
          : 'SPECULATIVE';
    return {
      page,
      text: only.text,
      discrepancies: [],
      unresolved: [],
      bracket: options.verifiedAt && visionOnly ? 'EXPLAINED' : bracket,
      sources,
      requiresUserVerification: visionOnly && !options.verifiedAt,
      verifiedAt: options.verifiedAt ?? null,
    };
  }

  const rows = alignSequences(usable.map((t) => words(t.text)));
  const merged: string[] = [];
  const discrepancies: TranscriptDiscrepancy[] = [];

  rows.forEach((row, index) => {
    const normalised = row.map(normalise);
    const present = normalised.filter(Boolean);
    const agreed = present.length > 0 && present.every((w) => w === present[0]);

    if (agreed) {
      merged.push(row.find((w) => w) ?? '');
      return;
    }

    // Majority: two independent readers producing the same word outrank a
    // third that did not, whichever readers they happen to be.
    const tally = new Map<string, number>();
    for (const w of present) tally.set(w, (tally.get(w) ?? 0) + 1);
    const best = [...tally.entries()].sort((a, b) => b[1] - a[1])[0];
    const majority = best && best[1] >= 2 && best[1] > present.length - best[1];

    const readings = row.map((value, i) => ({
      source: usable[i].source,
      value,
      confidence: usable[i].confidence ?? null,
    }));
    const numeric = row.some((w) => isNumeric(w));
    const before = merged.slice(-4).join(' ');
    const after = rows
      .slice(index + 1, index + 5)
      .map((r) => r.find((w) => w) ?? '')
      .join(' ');

    if (majority) {
      const winner = row.find((w) => normalise(w) === best[0]) ?? best[0];
      merged.push(winner);
      discrepancies.push({
        id: `disc-p${page}-${index}`,
        page,
        index,
        context: `${before} [${winner}] ${after}`.trim(),
        numeric,
        readings,
        resolved: true,
        value: winner,
        // Corroborated by two readers, but a third disagreed. That is one
        // rung below clean agreement across the board.
        bracket: 'EXPLAINED',
        reason: `${best[1]} of ${present.length} readers read "${winner}"; the others differed.`,
        userAction: null,
        resolvedBy: 'majority',
        resolvedAt: null,
      });
      return;
    }

    merged.push(`[?${row.filter(Boolean).join(' | ')}]`);
    discrepancies.push({
      id: `disc-p${page}-${index}`,
      page,
      index,
      context: `${before} [?] ${after}`.trim(),
      numeric,
      readings,
      resolved: false,
      value: null,
      bracket: 'CONTRADICTED',
      reason: numeric
        ? 'The readers disagree on a value containing digits, and no two of them agree.'
        : 'The readers disagree and no two of them agree.',
      userAction: `Open page ${page} and confirm this${numeric ? ' figure' : ' word'} against the document.`,
      resolvedBy: null,
      resolvedAt: null,
    });
  });

  const unresolved = discrepancies.filter((d) => !d.resolved);

  let bracket: EpistemicBracket;
  if (unresolved.length > 0) {
    bracket = 'CONTRADICTED';
  } else if (discrepancies.length > 0) {
    bracket = 'EXPLAINED';
  } else {
    bracket = 'VALIDATED';
  }

  // Model-only pages still need eyes on them even when readers agree, because
  // two models reading the same image can be wrong the same way.
  const modelOnly = sources.every((s) => s === 'vision-model');
  const requiresUserVerification = modelOnly && !options.verifiedAt;
  if (requiresUserVerification) bracket = weakest(bracket, 'SPECULATIVE');

  return {
    page,
    text: merged.join(' '),
    discrepancies,
    unresolved,
    bracket,
    sources,
    requiresUserVerification,
    verifiedAt: options.verifiedAt ?? null,
  };
}

/* ------------------------------------------------------------------ */
/* Estimation gate                                                      */
/* ------------------------------------------------------------------ */

export interface EstimationReadiness {
  ready: boolean;
  unresolvedCount: number;
  awaitingVerification: number[];
  blockingPages: number[];
  reasons: string[];
}

/**
 * Whether the estimation flow may run.
 *
 * Two conditions stop it. A word the readers could not agree on is a value
 * nobody has confirmed, and an estimate built over it would be arithmetic on
 * a guess. A page transcribed only by a model has been read by no one — it is
 * shown to the user first and used afterwards, never the other way round.
 */
export function assessEstimationReadiness(pages: ReconciliationResult[]): EstimationReadiness {
  const unresolvedCount = pages.reduce((sum, p) => sum + p.unresolved.length, 0);
  const awaitingVerification = pages
    .filter((p) => p.requiresUserVerification)
    .map((p) => p.page);
  const conflictPages = pages.filter((p) => p.unresolved.length > 0).map((p) => p.page);

  const reasons: string[] = [];
  if (unresolvedCount > 0) {
    reasons.push(
      `${unresolvedCount} word${unresolvedCount === 1 ? '' : 's'} could not be read consistently on page${conflictPages.length === 1 ? '' : 's'} ${conflictPages.join(', ')}. Confirm each against the document.`,
    );
  }
  if (awaitingVerification.length > 0) {
    reasons.push(
      `Page${awaitingVerification.length === 1 ? '' : 's'} ${awaitingVerification.join(', ')} were transcribed from images by a model and have not been checked. Review the transcription before any figure uses it.`,
    );
  }

  const blockingPages = [...new Set([...conflictPages, ...awaitingVerification])].sort(
    (a, b) => a - b,
  );

  return {
    ready: unresolvedCount === 0 && awaitingVerification.length === 0,
    unresolvedCount,
    awaitingVerification,
    blockingPages,
    reasons,
  };
}

/** Record the user's confirmation of one disputed word. */
export function confirmDiscrepancy(
  result: ReconciliationResult,
  discrepancyId: string,
  value: string,
  at: string = new Date().toISOString(),
): ReconciliationResult {
  const discrepancies = result.discrepancies.map((d) =>
    d.id === discrepancyId
      ? {
          ...d,
          resolved: true,
          value,
          // A person reading the document is a direct reading, not a
          // corroborated one. EXPLAINED, never VALIDATED.
          bracket: 'EXPLAINED' as EpistemicBracket,
          reason: `${d.reason} Confirmed against the document by the user.`,
          userAction: null,
          resolvedBy: 'user' as const,
          resolvedAt: at,
        }
      : d,
  );
  const unresolved = discrepancies.filter((d) => !d.resolved);
  return {
    ...result,
    discrepancies,
    unresolved,
    text: result.text.replace(
      /\[\?[^\]]*\]/,
      unresolved.length === result.unresolved.length ? '$&' : value,
    ),
    bracket: unresolved.length > 0 ? 'CONTRADICTED' : 'EXPLAINED',
  };
}

/** Record that the user has reviewed a model transcription of an image. */
export function markVerified(
  result: ReconciliationResult,
  at: string = new Date().toISOString(),
): ReconciliationResult {
  return {
    ...result,
    requiresUserVerification: false,
    verifiedAt: at,
    bracket: result.unresolved.length > 0 ? 'CONTRADICTED' : 'EXPLAINED',
  };
}
