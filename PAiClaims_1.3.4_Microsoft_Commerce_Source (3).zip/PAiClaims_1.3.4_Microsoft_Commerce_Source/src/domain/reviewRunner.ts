import {
  reconcilePage,
  type PageTranscript,
  type ReconciliationResult,
  type TranscriptSource,
} from './transcriptReview.ts';

/**
 * Drives the full read of a document: split what extraction produced into
 * pages, ask the model to read the same text back, and reconcile the two.
 *
 * The model call is optional by design. With no provider configured the
 * ingested readings still reconcile against each other, so verification
 * degrades rather than disappearing.
 */

export interface ExtractedDocument {
  /** Evidence record this text came from. */
  evidenceId: string;
  filename: string;
  /** Extraction output, with <<<PAGE n>>> markers. */
  text: string;
  method: string;
  confidence?: number | null;
  /** Pages the text pipeline could not read at all. */
  needsVision?: boolean;
}

/** Split extraction output back into pages on its markers. */
export function splitPages(text: string): Array<{ page: number; text: string }> {
  const source = String(text ?? '');
  if (!source.trim()) return [];
  const matches = [...source.matchAll(/<<<PAGE (\d+)>>>/g)];
  if (matches.length === 0) return [{ page: 1, text: source.trim() }];

  const pages: Array<{ page: number; text: string }> = [];
  matches.forEach((match, i) => {
    const start = (match.index ?? 0) + match[0].length;
    const end = i + 1 < matches.length ? matches[i + 1].index ?? source.length : source.length;
    pages.push({ page: Number(match[1]), text: source.slice(start, end).trim() });
  });
  return pages;
}

/**
 * Which reader produced this text. The extraction method decides it; a page
 * that needed OCR is an OCR reading even when the rest of the file had a text
 * layer.
 */
export function sourceForMethod(method: string): TranscriptSource {
  if (method === 'tesseract-ocr') return 'tesseract-ocr';
  if (method === 'vision-model') return 'vision-model';
  return 'pdf-text';
}

type Fetcher = typeof fetch;

/**
 * Ask the model to read the extracted text back verbatim.
 * Returns an empty array when no provider is configured or the call fails —
 * a missing second reader is a weaker check, not an error.
 */
export async function requestModelReread(
  pages: Array<{ page: number; text: string }>,
  fetcher: Fetcher = fetch,
): Promise<PageTranscript[]> {
  if (pages.length === 0) return [];
  try {
    const response = await fetcher('/api/verify-transcript', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ pages }),
    });
    if (!response.ok) return [];
    const data = await response.json();
    if (!data?.verified || !Array.isArray(data.pages)) return [];
    return data.pages.map((p: any) => ({
      page: Number(p.page),
      source: 'vision-model' as const,
      text: String(p.text ?? ''),
      confidence: null,
    }));
  } catch {
    return [];
  }
}

/** Ask the model to transcribe page images the text pipeline could not read. */
export async function requestImageTranscription(
  images: Array<{ page: number; dataUrl: string; filename?: string }>,
  fetcher: Fetcher = fetch,
): Promise<PageTranscript[]> {
  if (images.length === 0) return [];
  try {
    const response = await fetcher('/api/transcribe-images', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ images }),
    });
    if (!response.ok) return [];
    const data = await response.json();
    if (!data?.transcribed || !Array.isArray(data.pages)) return [];
    return data.pages.map((p: any) => ({
      page: Number(p.page),
      source: 'vision-model' as const,
      text: String(p.text ?? ''),
      confidence: null,
    }));
  } catch {
    return [];
  }
}

/**
 * Reconcile one document into per-page reviews.
 *
 * Existing reviews are carried forward so a confirmation the user has already
 * made is not thrown away by a re-run.
 */
export async function buildPageReviews(
  document: ExtractedDocument,
  options: {
    fetcher?: Fetcher;
    existing?: ReconciliationResult[];
    imageTranscripts?: PageTranscript[];
  } = {},
): Promise<ReconciliationResult[]> {
  const extracted = splitPages(document.text);
  const ingestSource = sourceForMethod(document.method);

  const modelPages = await requestModelReread(extracted, options.fetcher ?? fetch);
  const byPage = new Map<number, PageTranscript[]>();

  for (const page of extracted) {
    byPage.set(page.page, [
      {
        page: page.page,
        source: ingestSource,
        text: page.text,
        confidence: document.confidence ?? null,
      },
    ]);
  }
  for (const transcript of [...modelPages, ...(options.imageTranscripts ?? [])]) {
    const list = byPage.get(transcript.page) ?? [];
    list.push(transcript);
    byPage.set(transcript.page, list);
  }

  const results: ReconciliationResult[] = [];
  for (const [page, transcripts] of [...byPage.entries()].sort((a, b) => a[0] - b[0])) {
    const prior = options.existing?.find((r) => r.page === page);
    const result = reconcilePage(transcripts, { verifiedAt: prior?.verifiedAt ?? null });

    // Carry forward anything the user already settled.
    if (prior) {
      const confirmed = new Map(
        prior.discrepancies
          .filter((d) => d.resolvedBy === 'user' && d.value)
          .map((d) => [d.index, d]),
      );
      if (confirmed.size > 0) {
        const discrepancies = result.discrepancies.map((d) => {
          const previous = confirmed.get(d.index);
          return previous && !d.resolved ? { ...previous } : d;
        });
        const unresolved = discrepancies.filter((d) => !d.resolved);
        results.push({
          ...result,
          discrepancies,
          unresolved,
          bracket: unresolved.length > 0 ? 'CONTRADICTED' : 'EXPLAINED',
        });
        continue;
      }
    }
    results.push(result);
  }
  return results;
}
