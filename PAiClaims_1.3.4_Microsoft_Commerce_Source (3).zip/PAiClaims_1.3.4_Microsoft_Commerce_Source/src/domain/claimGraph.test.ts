import assert from 'node:assert/strict';
import test from 'node:test';
import { applyCarrierToClaimGraph, applyEvidenceToClaimGraph, buildClaimGraph } from './claimGraph.ts';
import type { DamageInventoryItem, EvidenceItem, InsuranceClaim, XactimateLineItem } from '../types.ts';
import { emptyPolicyRecord } from './policyRecord.ts';

const evidence = (id: string, root: string, level: EvidenceItem['evidenceLevel'] = 'direct'): EvidenceItem => ({
  id, title: id, type: 'engineer_report', filename: `${id}.pdf`, date: '2026-08-29', source: root,
  provenanceRoot: root, evidenceLevel: level, stance: 'supports', bracketState: 'EXPLAINED', excerpt: '', rawText: '',
  floatPoints: 1, mixPoints: 0, stirPoints: 0, totalPressure: 1, keyObservations: [], contentHash: `hash-${id}`,
});

const inventory = (): DamageInventoryItem[] => [{
  id: 'd1', statement: 'Roof shingles show wind damage', component: 'roof shingles', location: 'north slope',
  damageType: 'wind crease', likelyCause: 'wind', extent: '24 SQ estimated', photoEvidenceIds: [], imageRegions: [], damageBracket: 'SPECULATIVE',
  repairOperations: [{
    id: 'r1', trade: 'Roofing', description: 'Replace architectural shingles', quantity: 24, unit: 'SQ',
    materialSearchTerms: ['architectural shingles'], laborHours: 50, equipmentAndDisposal: 900,
    costComponents: [
      { id: 'mat1', kind: 'material', label: 'Shingles', amount: 4000, reason: 'Photo rough material value', bracket: 'SPECULATIVE', sourceMethod: 'photo_ai' },
      { id: 'lab1', kind: 'labor', label: 'Labor', amount: 3000, reason: 'Photo rough labor value', bracket: 'SPECULATIVE', sourceMethod: 'photo_ai', workerHours: 50 },
    ],
  }],
  valuation: { amount: 7000, currency: 'USD', assumptions: ['Full slope replacement assumed'], bracket: 'SPECULATIVE', pricedAt: '2026-08-29', pricingBasis: 'Photo analysis rough price' },
}];

const claim = (): InsuranceClaim => ({
  id: 'c1', claimNumber: 'C-1', policyNumber: 'P-1', policyholderName: 'A', carrierName: 'B', policyType: 'homeowners_ho3',
  dateOfLoss: '2026-08-01', dateReported: '2026-08-02', peril: 'wind_hail', propertyAddress: 'X', status: 'intake',
  intakeGaps: [],
  pageReviews: [],
  policyRecord: emptyPolicyRecord('test'),
  policyLimits: { dwelling_covA: 100000, otherStructures_covB: 0, personalProperty_covC: 0, lossOfUse_covD: 0, ordinanceAndLaw_percent: 0, ordinanceAndLaw_amount: 0, moldRemediationLimit: 0, debrisRemovalPercent: 0, deductible: 1000, deductibleType: 'flat_dollar' },
  carrierOffer: { initialOfferACV: 0, initialOfferRCV: 0, depreciationWithheld: 0, deductibleDeducted: 0, netCarrierCheckIssued: 0, carrierSummary: '' },
  auditedTrueValuation: { contractorRCV: 0, contractorACV: 0, recoverableDepreciation: 0, eligibleCodeUpgrades: 0, eligibleOverheadAndProfit: 0, eligibleALE: 0, trueGrossRecovery: 0, netPayoutOwed: 0, totalRecoveryGap: 0, bracket: 'UNVERIFIED', unreadTerms: ['ordinanceAndLaw_amount', 'deductible'] },
  evidence: [], damageInventory: inventory(), lineItems: [], tensions: [], statutoryDeadlines: [], auditTrail: [], caseNotes: [],
});

test('claim graph is built from atomic damage, cost and reason propositions', () => {
  const graph = buildClaimGraph(claim(), '2026-08-29T12:00:00Z');
  assert.equal(graph.nodes.find((n) => n.id === 'damage:d1')?.bracket, 'SPECULATIVE');
  assert.equal(graph.nodes.find((n) => n.id === 'quantity:d1:r1')?.bracket, 'SPECULATIVE');
  assert.ok(graph.nodes.some((n) => n.kind === 'material' && n.amount === 4000));
  assert.ok(graph.nodes.some((n) => n.kind === 'reason' && /material/i.test(n.statement)));
  assert.ok(graph.edges.some((e) => e.kind === 'reason_for'));
});

test('carrier counter adds competing values and corroborates only matched propositions', () => {
  const c = claim();
  const carrierEvidence = { ...evidence('carrier-e1', 'Carrier Xactimate', 'structural'), type: 'carrier_estimate' as const };
  c.evidence = [carrierEvidence];
  const initial = buildClaimGraph(c, '2026-08-29T12:00:00Z');
  const carrier: XactimateLineItem[] = [{
    id: 'x1', xactCode: 'RFG 300', description: 'Replace architectural shingles', category: 'Roofing', tradeCategory: 'Roofing', unit: 'SQ',
    carrierQuantity: 24, carrierUnitPrice: 280, carrierTotal: 6720, carrierRCV: 6720,
    contractorQuantity: 24, contractorUnitPrice: 280, contractorTotal: 6720, gapAmount: 0,
    status: 'carrier_imported', reason: 'carrier supplied', codeCitation: '', selected: true,
    workerHours: 50, laborRate: 60, laborAmount: 3000, materialAmount: 3720, epistemicBracket: 'EXPLAINED',
  }];
  const next = applyCarrierToClaimGraph(initial, c.damageInventory!, carrier, carrierEvidence.id, c.evidence, '2026-08-30T12:00:00Z');
  assert.equal(next.nodes.find((n) => n.id === 'damage:d1')?.bracket, 'EXPLAINED');
  assert.equal(next.nodes.find((n) => n.id === 'price:d1')?.amount, 7000);
  assert.equal(next.nodes.find((n) => n.id === 'carrier-price:d1:x1')?.amount, 6720);
  assert.ok(next.nodes.some((n) => n.id.startsWith('carrier-labor:') && n.amount === 3000));
});

test('adjuster/company evidence promotes only the atomic proposition it explicitly addresses', () => {
  const c = claim();
  const initial = buildClaimGraph(c, '2026-08-29T12:00:00Z');
  const adjuster = { ...evidence('adjuster', 'Independent Adjuster', 'structural'), assertionIds: ['damage:d1'] };
  const afterAdjuster = applyEvidenceToClaimGraph(initial, adjuster, '2026-08-30T12:00:00Z');
  assert.equal(afterAdjuster.nodes.find((n) => n.id === 'damage:d1')?.bracket, 'EXPLAINED');
  assert.equal(afterAdjuster.nodes.find((n) => n.id === 'price:d1')?.bracket, 'SPECULATIVE');
  const companyTest = { ...evidence('test', 'Independent Test Lab', 'direct'), assertionIds: ['damage:d1'] };
  const afterTest = applyEvidenceToClaimGraph(afterAdjuster, companyTest, '2026-08-31T12:00:00Z');
  assert.equal(afterTest.nodes.find((n) => n.id === 'damage:d1')?.bracket, 'VALIDATED');
  assert.equal(afterTest.nodes.find((n) => n.id === 'price:d1')?.bracket, 'SPECULATIVE');
});
