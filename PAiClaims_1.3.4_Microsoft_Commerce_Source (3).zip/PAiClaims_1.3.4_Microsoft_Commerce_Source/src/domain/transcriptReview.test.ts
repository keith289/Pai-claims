import assert from 'node:assert/strict';
import test from 'node:test';
import {
  reconcilePage, assessEstimationReadiness, confirmDiscrepancy, markVerified,
  alignSequences, isNumeric, words,
} from './transcriptReview.ts';

const T = (source: any, text: string, confidence: number | null = null, page = 1) =>
  ({ page, source, text, confidence });

test('readers that agree word for word corroborate each other', () => {
  const r = reconcilePage([
    T('pdf-text', 'Coverage A Dwelling $312,000'),
    T('tesseract-ocr', 'Coverage A Dwelling $312,000', 0.96),
  ]);
  assert.equal(r.discrepancies.length, 0);
  assert.equal(r.bracket, 'VALIDATED');
  assert.equal(r.unresolved.length, 0);
});

test('a disagreement on a figure with no majority stops and asks the user', () => {
  const r = reconcilePage([
    T('pdf-text', 'Coverage A Dwelling $312,000'),
    T('tesseract-ocr', 'Coverage A Dwelling $412,000', 0.96),
  ]);
  assert.equal(r.unresolved.length, 1);
  assert.equal(r.bracket, 'CONTRADICTED');
  const [d] = r.unresolved;
  assert.equal(d.numeric, true);
  assert.equal(d.value, null);
  assert.equal(d.readings.length, 2);
  assert.match(d.userAction!, /confirm this figure/i);
});

test('the disputed word is surrounded by context so it can be found on the page', () => {
  const r = reconcilePage([
    T('pdf-text', 'the total dwelling limit is $312,000 under this policy'),
    T('tesseract-ocr', 'the total dwelling limit is $412,000 under this policy', 0.9),
  ]);
  const [d] = r.unresolved;
  assert.match(d.context, /dwelling limit is/);
  assert.match(d.context, /under this policy/);
});

test('two readers agreeing outrank a third that does not', () => {
  const r = reconcilePage([
    T('pdf-text', 'Deductible $6,240'),
    T('tesseract-ocr', 'Deductible $6,240', 0.95),
    T('vision-model', 'Deductible $6.240'),
  ]);
  assert.equal(r.unresolved.length, 0);
  assert.equal(r.bracket, 'EXPLAINED');
  const [d] = r.discrepancies;
  assert.equal(d.resolvedBy, 'majority');
  assert.equal(d.value, '$6,240');
});

test('three readers all differing on a number is never auto-resolved', () => {
  const r = reconcilePage([
    T('pdf-text', 'Deductible $6,240'),
    T('tesseract-ocr', 'Deductible $5,240', 0.95),
    T('vision-model', 'Deductible $8,240'),
  ]);
  assert.equal(r.unresolved.length, 1);
  assert.equal(r.unresolved[0].value, null);
  assert.equal(r.bracket, 'CONTRADICTED');
});

test('a dropped word resynchronises instead of cascading', () => {
  const r = reconcilePage([
    T('pdf-text', 'Coverage A the Dwelling limit is $312,000 per occurrence'),
    T('tesseract-ocr', 'Coverage A Dwelling limit is $312,000 per occurrence', 0.9),
  ]);
  // One disputed span, not every word after the drop.
  assert.ok(r.unresolved.length <= 1, `got ${r.unresolved.length} discrepancies`);
  assert.match(r.text, /\$312,000/);
  assert.match(r.text, /per occurrence/);
});

test('a model-only page must be seen by a person before it is used', () => {
  const r = reconcilePage([T('vision-model', 'Coverage A Dwelling $312,000')]);
  assert.equal(r.requiresUserVerification, true);
  assert.equal(r.bracket, 'SPECULATIVE');
});

test('a text layer alone does not need verification', () => {
  const r = reconcilePage([T('pdf-text', 'Coverage A Dwelling $312,000')]);
  assert.equal(r.requiresUserVerification, false);
  assert.equal(r.bracket, 'EXPLAINED');
});

test('estimation is blocked while any word is unresolved', () => {
  const page = reconcilePage([
    T('pdf-text', 'Deductible $6,240'),
    T('tesseract-ocr', 'Deductible $9,240', 0.95),
  ]);
  const gate = assessEstimationReadiness([page]);
  assert.equal(gate.ready, false);
  assert.equal(gate.unresolvedCount, 1);
  assert.deepEqual(gate.blockingPages, [1]);
  assert.match(gate.reasons[0], /could not be read consistently/);
});

test('estimation is blocked while a model transcription is unreviewed', () => {
  const page = reconcilePage([T('vision-model', 'Coverage A $312,000')]);
  const gate = assessEstimationReadiness([page]);
  assert.equal(gate.ready, false);
  assert.deepEqual(gate.awaitingVerification, [1]);
  assert.match(gate.reasons[0], /transcribed from images/);
});

test('estimation runs once everything is confirmed and reviewed', () => {
  const clean = reconcilePage([
    T('pdf-text', 'Coverage A $312,000'),
    T('tesseract-ocr', 'Coverage A $312,000', 0.97),
  ]);
  assert.equal(assessEstimationReadiness([clean]).ready, true);
});

test('user confirmation clears a disputed word but only earns EXPLAINED', () => {
  const page = reconcilePage([
    T('pdf-text', 'Deductible $6,240'),
    T('tesseract-ocr', 'Deductible $9,240', 0.95),
  ]);
  const after = confirmDiscrepancy(page, page.unresolved[0].id, '$6,240', '2026-09-02T00:00:00Z');
  assert.equal(after.unresolved.length, 0);
  assert.equal(after.bracket, 'EXPLAINED');
  assert.equal(after.discrepancies[0].resolvedBy, 'user');
  assert.equal(after.discrepancies[0].resolvedAt, '2026-09-02T00:00:00Z');
  assert.equal(assessEstimationReadiness([after]).ready, true);
});

test('reviewing a model transcription unblocks it without inventing confidence', () => {
  const page = reconcilePage([T('vision-model', 'Coverage A $312,000')]);
  const after = markVerified(page, '2026-09-02T00:00:00Z');
  assert.equal(after.requiresUserVerification, false);
  assert.equal(after.bracket, 'EXPLAINED');
  assert.notEqual(after.bracket, 'VALIDATED');
  assert.equal(assessEstimationReadiness([after]).ready, true);
});

test('both readings survive on the record so the user chooses, not the software', () => {
  const page = reconcilePage([
    T('pdf-text', 'limit $312,000'),
    T('tesseract-ocr', 'limit $412,000', 0.96),
  ]);
  const [d] = page.unresolved;
  assert.deepEqual(d.readings.map((r) => r.value), ['$312,000', '$412,000']);
  assert.ok(!/362|350/.test(JSON.stringify(d)));
});

test('punctuation differences are not disagreements', () => {
  const r = reconcilePage([
    T('pdf-text', 'Coverage A, Dwelling.'),
    T('tesseract-ocr', 'Coverage A Dwelling', 0.9),
  ]);
  assert.equal(r.unresolved.length, 0);
});

test('helpers behave', () => {
  assert.equal(isNumeric('$312,000'), true);
  assert.equal(isNumeric('Dwelling'), false);
  assert.deepEqual(words('<<<PAGE 1>>>\nA  B'), ['A', 'B']);
  assert.deepEqual(alignSequences([['a', 'b'], ['a', 'b']]), [['a', 'a'], ['b', 'b']]);
});

test('a decimal point is never treated as a thousands separator', () => {
  const r = reconcilePage([
    T('pdf-text', 'Deductible $6,240'),
    T('tesseract-ocr', 'Deductible $6.240', 0.95),
  ]);
  assert.equal(r.unresolved.length, 1, '$6.240 and $6,240 are different amounts');
  assert.equal(r.bracket, 'CONTRADICTED');
});

test('trailing sentence punctuation on a figure is still ignored', () => {
  const r = reconcilePage([
    T('pdf-text', 'limit is $312,000.'),
    T('tesseract-ocr', 'limit is $312,000', 0.95),
  ]);
  assert.equal(r.unresolved.length, 0);
});

test('a small decimal is not confused with a whole number', () => {
  const r = reconcilePage([
    T('pdf-text', 'factor 1.5 applied'),
    T('tesseract-ocr', 'factor 15 applied', 0.9),
  ]);
  assert.equal(r.unresolved.length, 1);
});

test('the panel contract: unresolved words expose every reading and no default', () => {
  const page = reconcilePage([
    T('pdf-text', 'Deductible $6,240'),
    T('tesseract-ocr', 'Deductible $9,240', 0.95),
  ]);
  const [d] = page.unresolved;
  // Nothing on the discrepancy marks one reading as preferred.
  assert.equal(d.value, null);
  assert.ok(!('recommended' in d));
  assert.ok(!('preferred' in d));
  assert.equal(d.readings.length, 2);
  assert.ok(d.readings.every((r) => typeof r.value === 'string'));
});

test('confirming one word does not silently clear the others', () => {
  const page = reconcilePage([
    T('pdf-text', 'limit $312,000 deductible $6,240'),
    T('tesseract-ocr', 'limit $412,000 deductible $9,240', 0.95),
  ]);
  assert.equal(page.unresolved.length, 2);
  const after = confirmDiscrepancy(page, page.unresolved[0].id, '$312,000');
  assert.equal(after.unresolved.length, 1);
  assert.equal(assessEstimationReadiness([after]).ready, false);
});

test('a page needing verification and a page with a dispute both block', () => {
  const a = reconcilePage([T('vision-model', 'Coverage A $312,000')], {});
  const b = reconcilePage([
    T('pdf-text', 'Deductible $6,240', null, 2),
    T('tesseract-ocr', 'Deductible $9,240', 0.95, 2),
  ]);
  const gate = assessEstimationReadiness([a, b]);
  assert.equal(gate.ready, false);
  assert.deepEqual(gate.blockingPages, [1, 2]);
  assert.equal(gate.reasons.length, 2);
});
