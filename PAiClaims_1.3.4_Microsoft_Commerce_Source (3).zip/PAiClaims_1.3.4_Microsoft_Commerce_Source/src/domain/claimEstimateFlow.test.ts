import assert from 'node:assert/strict';
import test from 'node:test';
import { applyRegionalPass2, ensureCompletePhotoEstimate, inventoryTotals } from './claimEstimateFlow.ts';
import { applyPaymentToClaimGraph } from './claimGraph.ts';
import type { ClaimGraph, DamageInventoryItem, EvidenceItem, LowesMaterialPrice, XactimateLineItem } from '../types.ts';

const photoItem = (rough = 1000): DamageInventoryItem => ({
  id: 'd1',
  statement: 'Roof covering appears damaged',
  component: 'Architectural shingles',
  location: 'Main roof',
  damageType: 'wind damage',
  likelyCause: 'wind',
  extent: 'approximately 10 SQ',
  photoEvidenceIds: ['photo-1'],
  imageRegions: [],
  damageBracket: 'SPECULATIVE',
  repairOperations: [{
    id: 'op1', trade: 'Roofing', description: 'Architectural shingle replacement', quantity: 10, unit: 'SQ',
    materialSearchTerms: ['architectural shingles'], laborHours: 10, equipmentAndDisposal: 0,
  }],
  valuation: {
    amount: rough, currency: 'USD', assumptions: ['photo pass'], bracket: 'SPECULATIVE',
    pricedAt: '2026-08-29T00:00:00Z', pricingBasis: 'photo rough estimate',
  },
});

const carrierLine = (overrides: Partial<XactimateLineItem> = {}): XactimateLineItem => ({
  id: 'x1', xactCode: 'RFG 300', category: 'Roofing', description: 'Architectural shingle replacement', unit: 'SQ',
  carrierQuantity: 10, carrierUnitPrice: 100, carrierTotal: 1000,
  contractorQuantity: 10, contractorUnitPrice: 100, contractorTotal: 1000,
  gapAmount: 0, status: 'carrier_imported', reason: 'carrier supplied', codeCitation: '', tradeCategory: 'Roofing', selected: true,
  epistemicBracket: 'EXPLAINED', ...overrides,
});

test('photo pass fills every required cost class with a price and reason at one bracket', () => {
  const [item] = ensureCompletePhotoEstimate([photoItem()]);
  const costs = item.repairOperations[0].costComponents || [];
  const kinds = new Set(costs.map((c) => c.kind));
  for (const kind of ['material', 'labor', 'equipment', 'disposal', 'permit', 'tax', 'overhead_profit', 'mobilization', 'protection']) {
    assert.equal(kinds.has(kind as any), true, `missing ${kind}`);
  }
  assert.equal(costs.every((c) => c.amount > 0 && c.reason.trim().length > 0 && c.bracket === 'SPECULATIVE'), true);
  assert.equal(item.valuation?.amount, 1000);
});

test('Pass 2 uses local material data and raises labor when Xactimate hours x rate is higher', () => {
  const source: LowesMaterialPrice = {
    productId: 'sku1', description: 'architectural shingles', storeId: '100', zipCode: '31639',
    sellingPrice: 40, purchaseUnits: 10, fetchedAt: '2026-08-29T00:00:00Z', sourceUrl: 'authorized-feed',
    sourceMethod: 'lowes_store_feed',
  };
  const [item] = applyRegionalPass2([photoItem()], {
    materialSources: [source], carrierItems: [carrierLine({ workerHours: 10, laborRate: 50 })], contingencyPct: 5,
  });
  const costs = item.repairOperations[0].costComponents || [];
  const material = costs.find((c) => c.kind === 'material')!;
  const labor = costs.find((c) => c.kind === 'labor')!;
  assert.equal(material.amount, 400);
  assert.equal(material.bracket, 'EXPLAINED');
  assert.equal(labor.amount, 500);
  assert.match(labor.reason, /MAX\(PSi, Xactimate\)/);
  assert.equal(item.pass2Valuation?.contingencyPct, 5);
  assert.equal(item.pass2Valuation?.contingencyAmount, Number((item.pass2Valuation!.baseAmount * 0.05).toFixed(2)));
});

test('Pass 2 extends the observed material unit price across the full required quantity', () => {
  const required = photoItem();
  required.repairOperations[0].quantity = 24;
  required.extent = 'approximately 24 SQ';
  const source: LowesMaterialPrice = {
    productId: 'sku-24sq', description: 'architectural shingles', storeId: '100', zipCode: '31639',
    sellingPrice: 118, purchaseUnits: 1, fetchedAt: '2026-08-29T00:00:00Z', sourceUrl: 'authorized-feed',
    sourceMethod: 'lowes_store_feed',
  };

  const [item] = applyRegionalPass2([required], { materialSources: [source], contingencyPct: 5 });
  const material = item.repairOperations[0].costComponents!.find((c) => c.kind === 'material')!;

  assert.equal(material.amount, 2832);
  assert.match(material.reason, /\$2832\.00/);
});

test('complete Pass 2 pricing cannot collapse the Pass 1 total by substituting sample purchase units', () => {
  const required = photoItem(8000);
  required.repairOperations[0].quantity = 24;
  required.extent = 'approximately 24 SQ';
  const source: LowesMaterialPrice = {
    productId: 'sku-no-collapse', description: 'architectural shingles', storeId: '100', zipCode: '31639',
    sellingPrice: 118, purchaseUnits: 1, fetchedAt: '2026-08-29T00:00:00Z', sourceUrl: 'authorized-feed',
    sourceMethod: 'lowes_store_feed',
  };

  const [item] = applyRegionalPass2([required], {
    materialSources: [source],
    carrierItems: [carrierLine({ carrierQuantity: 24, workerHours: 60, laborRate: 52 })],
    contingencyPct: 5,
  });
  const totals = inventoryTotals([item]);

  assert.equal(totals.initial, 8000);
  assert.equal(totals.pass2 >= totals.initial, true);
});

test('Pass 2 never lowers PSi labor when supplied Xactimate labor is lower', () => {
  const completed = ensureCompletePhotoEstimate([photoItem()]);
  const labor = completed[0].repairOperations[0].costComponents!.find((c) => c.kind === 'labor')!;
  labor.amount = 700;
  const [item] = applyRegionalPass2(completed, {
    materialSources: [], carrierItems: [carrierLine({ workerHours: 10, laborRate: 50 })], contingencyPct: 5,
  });
  const pass2Labor = item.repairOperations[0].costComponents!.find((c) => c.kind === 'labor')!;
  assert.equal(pass2Labor.amount, 700);
  assert.match(pass2Labor.reason, /holds at \$700\.00/);
});

test('missing retailer material price can be extrapolated from supplied Xactimate material basis', () => {
  const [item] = applyRegionalPass2([photoItem()], {
    materialSources: [], carrierItems: [carrierLine({ materialAmount: 450, carrierQuantity: 10 })], contingencyPct: 5,
  });
  const material = item.repairOperations[0].costComponents!.find((c) => c.kind === 'material')!;
  assert.equal(material.amount, 450);
  assert.equal(material.sourceMethod, 'xactimate_derived');
  assert.equal(material.bracket, 'EXPLAINED');
});

test('inventory totals preserve initial estimate separately from later Pass 2', () => {
  const initial = ensureCompletePhotoEstimate([photoItem(1000)]);
  const later = applyRegionalPass2(initial, { materialSources: [], carrierItems: [], contingencyPct: 5 });
  const totals = inventoryTotals(later);
  assert.equal(totals.initial, 1000);
  assert.equal(totals.pass2 > totals.pass2Base, true);
  assert.equal(totals.contingency, Number((totals.pass2Base * 0.05).toFixed(2)));
});

const paymentEvidence: EvidenceItem = {
  id: 'pay-proof', title: 'Paid check', type: 'communication', filename: 'paid.pdf', date: '2026-08-29', source: 'Carrier',
  provenanceRoot: 'carrier:payment:1', evidenceLevel: 'direct', stance: 'supports', bracketState: 'VALIDATED', excerpt: '', rawText: '',
  floatPoints: 1, mixPoints: 0, stirPoints: 0, totalPressure: 1, keyObservations: ['payment received'],
};
const baseGraph = (): ClaimGraph => ({
  version: 1, rebuiltAt: '2026-08-29T00:00:00Z', edges: [], nodes: [{
    id: 'price:d1', kind: 'price', statement: '$1000 current PSi repair value', bracket: 'EXPLAINED', channel: 'matter_k66',
    amount: 1000, currency: 'USD', reason: 'supported estimate', sourceEvidenceIds: [], provenanceRoots: [],
    createdAt: '2026-08-29T00:00:00Z', updatedAt: '2026-08-29T00:00:00Z', history: [], damageInventoryId: 'd1',
  }],
});

test('partial payment is validated evidence but does not close the linked PSi price', () => {
  const graph = applyPaymentToClaimGraph(baseGraph(), {
    id: 'p1', amount: 500, evidenceIds: ['pay-proof'], recordedAt: '2026-08-29T01:00:00Z', damageInventoryId: 'd1',
    statement: 'Partial payment $500', finalForLinkedItem: false,
  }, [paymentEvidence]);
  assert.equal(graph.nodes.find((n) => n.id === 'price:d1')?.bracket, 'EXPLAINED');
  assert.equal(graph.nodes.find((n) => n.id === 'money:p1')?.bracket, 'VALIDATED');
});

test('final actual payment promotes only the linked monetary proposition', () => {
  const graph = applyPaymentToClaimGraph(baseGraph(), {
    id: 'p2', amount: 1000, evidenceIds: ['pay-proof'], recordedAt: '2026-08-29T01:00:00Z', damageInventoryId: 'd1',
    statement: 'Final payment $1000', finalForLinkedItem: true,
  }, [paymentEvidence]);
  assert.equal(graph.nodes.find((n) => n.id === 'price:d1')?.bracket, 'VALIDATED');
  assert.equal(graph.edges.some((e) => e.kind === 'paid_by' && e.bracket === 'VALIDATED'), true);
});
