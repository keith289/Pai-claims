import type {
  DamageCostComponent,
  DamageInventoryItem,
  DamageRepairOperation,
  EpistemicBracket,
  LowesMaterialPrice,
  XactimateLineItem,
} from '../types';

const money = (value: number) => Math.round((Number.isFinite(value) ? value : 0) * 100) / 100;
const pct = (value: number) => (Number.isFinite(value) ? value : 0) / 100;

const REQUIRED_COSTS: Array<{
  kind: DamageCostComponent['kind'];
  label: string;
  share: number;
  reason: string;
}> = [
  { kind: 'material', label: 'Materials', share: 0.38, reason: 'Provisional material allowance inferred from the visible repair assembly.' },
  { kind: 'labor', label: 'Labor', share: 0.34, reason: 'Provisional worker effort inferred from visible scope, access, and trade complexity.' },
  { kind: 'equipment', label: 'Equipment / access', share: 0.05, reason: 'Provisional equipment/access allowance inferred from height, pitch, access and work method visible in the photos.' },
  { kind: 'disposal', label: 'Debris / disposal', share: 0.05, reason: 'Provisional debris handling and disposal allowance based on the apparent demolition volume.' },
  { kind: 'permit', label: 'Permit allowance', share: 0.02, reason: 'Provisional permit allowance based on the job type and location; exact jurisdiction fee has not yet been verified.' },
  { kind: 'tax', label: 'Tax allowance', share: 0.03, reason: 'Provisional tax allowance used only to keep the initial estimate complete until local tax treatment is confirmed.' },
  { kind: 'overhead_profit', label: 'Overhead & profit allowance', share: 0.08, reason: 'Provisional coordination/overhead/profit allowance. Coverage entitlement is a separate claim question.' },
  { kind: 'mobilization', label: 'Mobilization / delivery', share: 0.03, reason: 'Provisional mobilization and delivery allowance inferred from the repair scope.' },
  { kind: 'protection', label: 'Protection / cleanup', share: 0.02, reason: 'Provisional protection, setup and final cleanup allowance inferred from the repair environment.' },
];

const words = (value: string) => new Set(value.toLowerCase().match(/[a-z0-9]{3,}/g) || []);
function similarity(a: string, b: string) {
  const left = words(a); const right = words(b);
  if (!left.size || !right.size) return 0;
  const common = [...left].filter((w) => right.has(w)).length;
  return common / Math.min(left.size, right.size);
}

function bestCarrierMatch(operation: DamageRepairOperation, items: XactimateLineItem[]) {
  const query = [operation.trade, operation.description, ...(operation.materialSearchTerms || [])].join(' ');
  return items
    .map((item) => ({ item, score: similarity(query, `${item.category} ${item.tradeCategory} ${item.description} ${item.xactCode}`) }))
    .sort((a, b) => b.score - a.score)[0];
}

function sourceMatchesOperation(source: LowesMaterialPrice, operation: DamageRepairOperation) {
  const query = [operation.description, ...(operation.materialSearchTerms || [])].join(' ');
  return similarity(source.description || source.productId, query) >= 0.22;
}

/**
 * Nothing in the initial photo estimate is allowed to be blank. If the vision
 * model omits a cost category, this function allocates part of the model's
 * rough total to that category and keeps it SPECULATIVE with an explicit reason.
 */
export function ensureCompletePhotoEstimate(items: DamageInventoryItem[], at = new Date().toISOString()): DamageInventoryItem[] {
  return items.map((item) => {
    const operations = (item.repairOperations || []).length ? item.repairOperations : [{
      id: `repair-${item.id}-1`, trade: 'General', description: `Repair ${item.component || item.statement}`,
      quantity: 1, unit: 'EA', materialSearchTerms: [item.component || item.statement], laborHours: 1,
      equipmentAndDisposal: 0, costComponents: [],
    }];

    const roughTotal = Math.max(50, Number(item.valuation?.amount || 0) || 1000);
    const perOperation = roughTotal / operations.length;
    const normalizedOps = operations.map((operation, opIndex) => {
      const existing = new Map((operation.costComponents || []).map((c) => [c.kind, c]));
      const complete: DamageCostComponent[] = REQUIRED_COSTS.map((spec, idx) => {
        const current = existing.get(spec.kind);
        const amount = current && current.amount > 0 ? current.amount : money(perOperation * spec.share);
        return {
          id: current?.id || `cost:${item.id}:${operation.id || opIndex}:${spec.kind}`,
          kind: spec.kind,
          label: current?.label || spec.label,
          amount: Math.max(0.01, money(amount)),
          reason: current?.reason?.trim() || `${spec.reason} This is a one-bracket rough value and is not set in stone.`,
          bracket: 'SPECULATIVE' as const,
          sourceMethod: current?.sourceMethod || 'photo_ai',
          sourceEvidenceIds: current?.sourceEvidenceIds?.length ? current.sourceEvidenceIds : item.photoEvidenceIds,
          unitPrice: current?.unitPrice,
          quantity: current?.quantity,
          unit: current?.unit,
          workerHours: current?.workerHours ?? (spec.kind === 'labor' ? Math.max(0.25, Number(operation.laborHours) || 0.25) : undefined),
          laborRate: current?.laborRate,
          regionalDifferencePct: current?.regionalDifferencePct,
        };
      });
      const componentTotal = money(complete.reduce((sum, c) => sum + c.amount, 0));
      return {
        ...operation,
        id: operation.id || `repair-${item.id}-${opIndex}`,
        quantity: Math.max(0.01, Number(operation.quantity) || 1),
        unit: operation.unit || 'EA',
        laborHours: Math.max(0.25, Number(operation.laborHours) || 0.25),
        equipmentAndDisposal: money(complete.filter((c) => c.kind === 'equipment' || c.kind === 'disposal').reduce((sum, c) => sum + c.amount, 0)),
        costComponents: complete,
        _componentTotal: componentTotal,
      } as DamageRepairOperation & { _componentTotal: number };
    });

    const normalizedTotal = money(normalizedOps.reduce((sum, op) => sum + op._componentTotal, 0));
    return {
      ...item,
      damageBracket: 'SPECULATIVE',
      repairOperations: normalizedOps.map(({ _componentTotal, ...op }) => op),
      valuation: {
        amount: normalizedTotal,
        currency: 'USD',
        assumptions: item.valuation?.assumptions?.length ? item.valuation.assumptions : ['Initial photo-driven estimate; every included dollar remains provisional until corroborated.'],
        bracket: 'SPECULATIVE',
        pricedAt: item.valuation?.pricedAt || at,
        pricingBasis: item.valuation?.pricingBasis || 'Photo-analysis rough estimate. Every cost category has a provisional price and an explicit reason.',
      },
    };
  });
}

export interface Pass2Options {
  materialSources: LowesMaterialPrice[];
  carrierItems?: XactimateLineItem[];
  regionalMaterialDifferencePct?: number;
  regionalLaborDifferencePct?: number;
  contingencyPct?: number;
  at?: string;
}

/**
 * PASS 2 rule:
 *  - current local retailer data replaces/refines rough material dollars;
 *  - if direct material pricing is unavailable, supplied Xactimate pricing is
 *    extrapolated where possible; otherwise the photo/LLM rough amount stays;
 *  - labor is split out and compared to supplied Xactimate worker-hours × rate;
 *    if PSi is under, raise it; if PSi is already over, hold it;
 *  - all other photo-derived components remain explicit;
 *  - a separate 5% (configurable) estimate contingency is added at the end.
 */
export function applyRegionalPass2(items: DamageInventoryItem[], options: Pass2Options): DamageInventoryItem[] {
  const at = options.at || new Date().toISOString();
  const carrierItems = options.carrierItems || [];
  const materialPct = Number(options.regionalMaterialDifferencePct || 0);
  const laborPct = Number(options.regionalLaborDifferencePct || 0);
  const contingencyPct = Number.isFinite(options.contingencyPct) ? Math.max(0, Number(options.contingencyPct)) : 5;

  return ensureCompletePhotoEstimate(items, at).map((item) => {
    let base = 0;
    const nextOps = item.repairOperations.map((operation) => {
      const match = bestCarrierMatch(operation, carrierItems);
      const carrier = match && match.score >= 0.24 ? match.item : undefined;
      const directMaterials = options.materialSources.filter((source) => source.sellingPrice > 0 && source.purchaseUnits > 0 && sourceMatchesOperation(source, operation));
      const requiredQty = Math.max(0.01, Number(operation.quantity) || 1);
      const current = operation.costComponents || [];

      const nextComponents = current.map((component): DamageCostComponent => {
        if (component.kind === 'material') {
          if (directMaterials.length) {
            // Retail observations establish the material price for one repair
            // unit. Extend that unit price across the operation's full required
            // quantity; purchaseUnits describes the sampled retail package and
            // must not replace the claim quantity.
            const observed = directMaterials.reduce((sum, source) => sum + source.sellingPrice * requiredQty, 0);
            const adjusted = money(observed * (1 + pct(materialPct)));
            const speculativeSource = directMaterials.some((source) =>
              source.bracket === 'SPECULATIVE' || String(source.sourceMethod).includes('llm') || String(source.sourceUrl || '').includes('speculative')
            );
            const xactimateDerived = !speculativeSource && directMaterials.some((source) => String(source.sourceMethod) === 'xactimate_derived');
            return {
              ...component,
              amount: adjusted,
              bracket: speculativeSource ? 'SPECULATIVE' : 'EXPLAINED',
              sourceMethod: speculativeSource
                ? 'llm_fallback'
                : xactimateDerived
                  ? 'xactimate_derived'
                  : directMaterials.some((source) => source.sourceMethod === 'lowes_partner_api')
                    ? 'lowes_partner_api'
                    : directMaterials[0].sourceMethod as any,
              sourceEvidenceIds: [...new Set(directMaterials.flatMap((source) => source.sourceEvidenceId ? [source.sourceEvidenceId] : []))],
              regionalDifferencePct: materialPct,
              reason: speculativeSource
                ? `No direct regional material observation was available. PAi retained a complete one-bracket speculative material value of $${adjusted.toFixed(2)} after the ${materialPct >= 0 ? '+' : ''}${materialPct.toFixed(2)}% regional factor. The source reason remains attached and this value must be superseded by stronger evidence when available.`
                : xactimateDerived
                  ? `Material value of $${money(observed).toFixed(2)} is derived from the supplied Xactimate basis. Regional material difference ${materialPct >= 0 ? '+' : ''}${materialPct.toFixed(2)}% yields $${adjusted.toFixed(2)}.`
                  : `Current local retailer material observations total $${money(observed).toFixed(2)}. Regional material difference ${materialPct >= 0 ? '+' : ''}${materialPct.toFixed(2)}% yields $${adjusted.toFixed(2)}.`,
            };
          }
          if (carrier) {
            const directCarrierMaterial = Number(carrier.materialAmount || 0);
            const carrierUnit = Number(carrier.carrierUnitPrice || 0);
            const carrierQty = Math.max(0.01, Number(carrier.carrierQuantity) || requiredQty);
            // If Xactimate did not expose a separate material amount, preserve
            // the photo material share and scale it by the related carrier unit
            // price rather than pretending the whole carrier line is material.
            const initialShare = Math.max(0.05, component.amount / Math.max(1, item.valuation?.amount || component.amount));
            const extrapolated = directCarrierMaterial > 0
              ? directCarrierMaterial * (requiredQty / carrierQty)
              : carrierUnit > 0
                ? carrierUnit * requiredQty * Math.min(0.8, Math.max(0.2, initialShare * 2.2))
                : 0;
            if (extrapolated > 0) {
              const adjusted = money(extrapolated * (1 + pct(materialPct)));
              return {
                ...component,
                amount: adjusted,
                bracket: 'EXPLAINED',
                sourceMethod: 'xactimate_derived',
                regionalDifferencePct: materialPct,
                reason: `Direct retailer price was unavailable. Material cost was extrapolated from the supplied carrier/Xactimate line "${carrier.description}" and preserved as a derived value; regional difference ${materialPct >= 0 ? '+' : ''}${materialPct.toFixed(2)}% applied.`,
              };
            }
          }
          return { ...component, bracket: 'SPECULATIVE', sourceMethod: component.sourceMethod || 'llm_fallback', reason: `${component.reason} No stronger regional material source was available, so this rough one-bracket amount is retained.` };
        }

        if (component.kind === 'labor') {
          const psiLabor = money(component.amount * (1 + pct(laborPct)));
          const hours = Number(carrier?.workerHours || 0);
          const rate = Number(carrier?.laborRate || 0);
          const explicitLabor = Number(carrier?.laborAmount || 0);
          const xactLabor = hours > 0 && rate > 0 ? money(hours * rate) : explicitLabor > 0 ? money(explicitLabor) : 0;
          const finalLabor = money(Math.max(psiLabor, xactLabor));
          const usedXact = xactLabor > psiLabor;
          return {
            ...component,
            amount: finalLabor,
            bracket: xactLabor > 0 ? 'EXPLAINED' : component.bracket,
            sourceMethod: xactLabor > 0 ? 'xactimate_direct' : (laborPct ? 'regional_factor' : component.sourceMethod),
            workerHours: hours || component.workerHours,
            laborRate: rate || component.laborRate,
            regionalDifferencePct: laborPct,
            reason: xactLabor > 0
              ? `PSi labor after regional difference (${laborPct >= 0 ? '+' : ''}${laborPct.toFixed(2)}%) is $${psiLabor.toFixed(2)}. Supplied Xactimate labor basis is $${xactLabor.toFixed(2)}${hours > 0 && rate > 0 ? ` (${hours.toFixed(2)} worker-hours × $${rate.toFixed(2)}/hr)` : ''}. Pass-2 rule uses MAX(PSi, Xactimate), so labor ${usedXact ? 'increases to' : 'holds at'} $${finalLabor.toFixed(2)}.`
              : `No usable Xactimate labor hours/rate were supplied for this operation. PSi labor holds at $${finalLabor.toFixed(2)} after regional difference ${laborPct >= 0 ? '+' : ''}${laborPct.toFixed(2)}%.`,
          };
        }

        // Picture-derived equipment, disposal, permit, tax, O&P, protection
        // and mobilization remain in the estimate. A carrier amount may add
        // support but never silently reduce the PSi amount.
        let carrierAmount = 0;
        if (carrier) {
          if (component.kind === 'equipment') carrierAmount = Number(carrier.equipmentAmount || 0);
          if (component.kind === 'tax') carrierAmount = Number(carrier.tax || 0);
          if (component.kind === 'overhead_profit') carrierAmount = Number(carrier.overheadAndProfit || 0);
        }
        if (carrierAmount > 0) {
          const held = money(Math.max(component.amount, carrierAmount));
          return {
            ...component,
            amount: held,
            bracket: 'EXPLAINED',
            sourceMethod: 'xactimate_direct',
            reason: `${component.reason} The supplied carrier/Xactimate estimate independently shows $${carrierAmount.toFixed(2)} for this cost class; PSi does not reduce its existing amount and holds the higher supported value of $${held.toFixed(2)}.`,
          };
        }
        return component;
      });

      base += nextComponents.reduce((sum, component) => sum + component.amount, 0);
      return { ...operation, costComponents: nextComponents };
    });

    base = money(base);
    const contingencyAmount = money(base * pct(contingencyPct));
    const finalAmount = money(base + contingencyAmount);
    // The contingency has a reason and remains explicit; it is never buried in
    // the other line prices.
    if (nextOps.length) {
      const last = nextOps[nextOps.length - 1];
      const existing = (last.costComponents || []).filter((c) => c.kind !== 'contingency');
      last.costComponents = [...existing, {
        id: `cost:${item.id}:contingency`,
        kind: 'contingency',
        label: `${contingencyPct.toFixed(1)}% estimate contingency`,
        amount: contingencyAmount,
        reason: `Explicit ${contingencyPct.toFixed(1)}% high-side estimating contingency applied to the Pass-2 base amount. It is shown separately and may be refined later.`,
        bracket: 'EXPLAINED',
        sourceMethod: 'regional_factor',
        regionalDifferencePct: contingencyPct,
      }];
    }

    return {
      ...item,
      repairOperations: nextOps,
      pass2Valuation: {
        baseAmount: base,
        contingencyPct,
        contingencyAmount,
        amount: finalAmount,
        bracket: 'EXPLAINED',
        pricedAt: at,
        pricingBasis: `Pass 2: regional material pricing, regional differences, supplied Xactimate labor comparison where available, retained photo-derived non-material costs, plus explicit ${contingencyPct.toFixed(1)}% contingency.`,
      },
    };
  });
}

export function inventoryTotals(items: DamageInventoryItem[]) {
  const initial = money(items.reduce((sum, item) => sum + Number(item.valuation?.amount || 0), 0));
  const pass2Base = money(items.reduce((sum, item) => sum + Number(item.pass2Valuation?.baseAmount || 0), 0));
  const contingency = money(items.reduce((sum, item) => sum + Number(item.pass2Valuation?.contingencyAmount || 0), 0));
  const pass2 = money(items.reduce((sum, item) => sum + Number(item.pass2Valuation?.amount || 0), 0));
  return { initial, pass2Base, contingency, pass2 };
}
