import assert from 'node:assert/strict';
import test from 'node:test';
import { buildRoofingMaterialTakeoff, purchaseUnits } from './psiEstimator.ts';

test('24 SQ roof with 10% waste requires 26.4 SQ field shingles', () => {
  const rows = buildRoofingMaterialTakeoff({
    roofSquares: 24, wastePct: 10, tearoffLayers: 1,
    eaveLf: 180, rakeLf: 96, ridgeLf: 64, hipLf: 0, valleyLf: 42,
    pipeBootCount: 2, roofVentCount: 4, ridgeVentLf: 0,
    deckReplacementSf: 64, iceWaterSf: 0, fastenerLbPerSq: 2.5,
  });
  const shingles = rows.find((row) => row.psiCode === 'PSI_RFG_SHINGLE_ARCH');
  assert.equal(shingles?.requiredQuantity, 26.4);
});

test('package rounding never under-buys', () => {
  assert.equal(purchaseUnits(67.2, 15), 5);
  assert.equal(purchaseUnits(768, 32), 24);
});

test('fasteners require an explicit verified rate', () => {
  const rows = buildRoofingMaterialTakeoff({
    roofSquares: 10, wastePct: 10, tearoffLayers: 1,
    eaveLf: 0, rakeLf: 0, ridgeLf: 0, hipLf: 0, valleyLf: 0,
    pipeBootCount: 0, roofVentCount: 0, ridgeVentLf: 0,
    deckReplacementSf: 0, iceWaterSf: 0, fastenerLbPerSq: 0,
  });
  const nails = rows.find((row) => row.psiCode === 'PSI_RFG_FASTENER');
  assert.equal(nails?.status, 'REQUIRES_DATA');
});
