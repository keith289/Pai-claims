export interface RoofingMeasurements {
  roofSquares: number;
  wastePct: number;
  tearoffLayers: number;
  eaveLf: number;
  rakeLf: number;
  ridgeLf: number;
  hipLf: number;
  valleyLf: number;
  pipeBootCount: number;
  roofVentCount: number;
  ridgeVentLf: number;
  deckReplacementSf: number;
  iceWaterSf: number;
  fastenerLbPerSq: number;
}

export type RoofingScopeStatus = 'MEASURED' | 'DERIVED' | 'REQUIRES_DATA';

export interface RoofingMaterialRequirement {
  psiCode: string;
  description: string;
  requiredQuantity: number;
  requiredUnit: string;
  status: RoofingScopeStatus;
  formula: string;
  optional?: boolean;
}

const round4 = (value: number) => Math.round(Math.max(0, value) * 10000) / 10000;

/**
 * Deterministic roofing material takeoff. No price source and no AI is used.
 * Derived quantities are shown with their formula so the user can defend the
 * physical scope independently of the dollars.
 */
export function buildRoofingMaterialTakeoff(m: RoofingMeasurements): RoofingMaterialRequirement[] {
  const wasteFactor = 1 + Math.max(0, m.wastePct) / 100;
  const fieldSquares = round4(m.roofSquares * wasteFactor);
  const roofSf = round4(m.roofSquares * 100);
  const edgeLf = round4(m.eaveLf + m.rakeLf);
  const ridgeHipLf = round4(m.ridgeLf + m.hipLf);

  const rows: RoofingMaterialRequirement[] = [];
  const add = (row: RoofingMaterialRequirement) => {
    if (row.requiredQuantity > 0) rows.push({ ...row, requiredQuantity: round4(row.requiredQuantity) });
  };

  add({
    psiCode: 'PSI_RFG_SHINGLE_ARCH',
    description: 'Architectural asphalt shingles',
    requiredQuantity: fieldSquares,
    requiredUnit: 'SQ',
    status: m.roofSquares > 0 ? 'DERIVED' : 'REQUIRES_DATA',
    formula: `roof squares × (1 + waste %) = ${m.roofSquares} × ${wasteFactor.toFixed(4)}`,
  });
  add({
    psiCode: 'PSI_RFG_UNDERLAYMENT',
    description: 'Roof underlayment',
    requiredQuantity: roofSf,
    requiredUnit: 'SF',
    status: m.roofSquares > 0 ? 'DERIVED' : 'REQUIRES_DATA',
    formula: `roof squares × 100 SF = ${m.roofSquares} × 100`,
  });
  add({
    psiCode: 'PSI_RFG_STARTER',
    description: 'Starter course',
    requiredQuantity: edgeLf,
    requiredUnit: 'LF',
    status: edgeLf > 0 ? 'DERIVED' : 'REQUIRES_DATA',
    formula: `eave LF + rake LF = ${m.eaveLf} + ${m.rakeLf}`,
  });
  add({
    psiCode: 'PSI_RFG_RIDGE_CAP',
    description: 'Hip / ridge cap shingles',
    requiredQuantity: ridgeHipLf,
    requiredUnit: 'LF',
    status: ridgeHipLf > 0 ? 'DERIVED' : 'REQUIRES_DATA',
    formula: `ridge LF + hip LF = ${m.ridgeLf} + ${m.hipLf}`,
  });
  add({
    psiCode: 'PSI_RFG_DRIP_EDGE',
    description: 'Metal drip edge',
    requiredQuantity: edgeLf,
    requiredUnit: 'LF',
    status: edgeLf > 0 ? 'DERIVED' : 'REQUIRES_DATA',
    formula: `eave LF + rake LF = ${m.eaveLf} + ${m.rakeLf}`,
  });
  add({
    psiCode: 'PSI_RFG_VALLEY',
    description: 'Valley flashing / treatment',
    requiredQuantity: m.valleyLf,
    requiredUnit: 'LF',
    status: 'MEASURED',
    formula: 'direct valley measurement',
    optional: true,
  });
  add({
    psiCode: 'PSI_RFG_PIPE_BOOT',
    description: 'Pipe jack / roof boot',
    requiredQuantity: m.pipeBootCount,
    requiredUnit: 'EA',
    status: 'MEASURED',
    formula: 'count of affected roof penetrations',
    optional: true,
  });
  add({
    psiCode: 'PSI_RFG_ROOF_VENT',
    description: 'Roof vent',
    requiredQuantity: m.roofVentCount,
    requiredUnit: 'EA',
    status: 'MEASURED',
    formula: 'count of affected roof vents',
    optional: true,
  });
  add({
    psiCode: 'PSI_RFG_RIDGE_VENT',
    description: 'Ridge vent',
    requiredQuantity: m.ridgeVentLf,
    requiredUnit: 'LF',
    status: 'MEASURED',
    formula: 'direct ridge vent measurement',
    optional: true,
  });
  add({
    psiCode: 'PSI_RFG_DECK_OSB',
    description: 'Roof sheathing / decking',
    requiredQuantity: m.deckReplacementSf,
    requiredUnit: 'SF',
    status: 'MEASURED',
    formula: 'documented damaged deck area',
    optional: true,
  });
  add({
    psiCode: 'PSI_RFG_ICE_WATER',
    description: 'Ice & water membrane',
    requiredQuantity: m.iceWaterSf,
    requiredUnit: 'SF',
    status: 'MEASURED',
    formula: 'direct measured/applicable membrane area; no code assumption is injected',
    optional: true,
  });

  if (m.fastenerLbPerSq > 0 && fieldSquares > 0) {
    add({
      psiCode: 'PSI_RFG_FASTENER',
      description: 'Roofing fasteners / nails',
      requiredQuantity: fieldSquares * m.fastenerLbPerSq,
      requiredUnit: 'LB',
      status: 'DERIVED',
      formula: `field roofing ${fieldSquares} SQ × verified fastener rate ${m.fastenerLbPerSq} LB/SQ`,
    });
  } else if (fieldSquares > 0) {
    rows.push({
      psiCode: 'PSI_RFG_FASTENER',
      description: 'Roofing fasteners / nails',
      requiredQuantity: 0,
      requiredUnit: 'LB',
      status: 'REQUIRES_DATA',
      formula: 'enter a manufacturer/specification-supported fastener rate; PSi does not invent one',
    });
  }

  return rows;
}

export function purchaseUnits(requiredQuantity: number, packageCoverage: number): number {
  if (!(requiredQuantity > 0) || !(packageCoverage > 0)) return 0;
  return Math.ceil(requiredQuantity / packageCoverage);
}
