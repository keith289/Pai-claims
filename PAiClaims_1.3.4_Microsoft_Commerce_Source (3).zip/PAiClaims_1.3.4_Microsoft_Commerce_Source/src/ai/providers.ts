/**
 * AI provider layer.
 *
 * One interface, several backends. Every provider is reached over plain REST
 * with global fetch, so adding one costs no new dependency and nothing has to
 * be rebuilt when a vendor ships a new SDK.
 *
 * Boundaries this layer keeps (they are the product's, not the vendor's):
 *  - Keys come from the user's own settings, never from the package.
 *  - No provider is contacted unless a key for it is configured.
 *  - `local` sends nothing off the machine, which is the right default for
 *    claim files. It is listed first for that reason.
 *  - AI output is narrative. Quantities, prices and rates come from the
 *    deterministic engine, never from here.
 */

export type ProviderId = 'local' | 'gemini' | 'anthropic' | 'openai' | 'openai-compatible';

export interface GenerateOptions {
  prompt: string;
  /** Ask for strict JSON back. Providers enforce this differently. */
  json?: boolean;
  system?: string;
  maxTokens?: number;
  temperature?: number;
  /** Optional image data URLs for user-initiated vision analysis. */
  images?: Array<{ dataUrl: string; label?: string }>;
}

export interface GenerateResult {
  text: string;
  provider: ProviderId;
  model: string;
}

export interface ProviderConfig {
  id: ProviderId;
  apiKey?: string;
  model?: string;
  /** For local/openai-compatible: e.g. http://localhost:11434 */
  baseUrl?: string;
}

export interface ProviderInfo {
  id: ProviderId;
  label: string;
  /** Shown in settings so the choice is informed rather than a guess. */
  note: string;
  needsKey: boolean;
  defaultModel: string;
  keyUrl?: string;
  sendsDataOffDevice: boolean;
}

export const PROVIDERS: ProviderInfo[] = [
  {
    id: 'local',
    label: 'Private (runs on this device)',
    note: 'llama.cpp, included with the app. No claim content leaves the device.',
    needsKey: false,
    defaultModel: 'local-gguf',
    sendsDataOffDevice: false,
  },
  {
    id: 'gemini',
    label: 'Google Gemini',
    note: 'Cloud. Claim content you submit is sent to Google.',
    needsKey: true,
    defaultModel: 'gemini-2.0-flash',
    keyUrl: 'https://aistudio.google.com/apikey',
    sendsDataOffDevice: true,
  },
  {
    id: 'anthropic',
    label: 'Anthropic Claude',
    note: 'Cloud. Claim content you submit is sent to Anthropic.',
    needsKey: true,
    defaultModel: 'claude-sonnet-4-5',
    keyUrl: 'https://console.anthropic.com/settings/keys',
    sendsDataOffDevice: true,
  },
  {
    id: 'openai',
    label: 'OpenAI',
    note: 'Cloud. Claim content you submit is sent to OpenAI.',
    needsKey: true,
    defaultModel: 'gpt-4o',
    keyUrl: 'https://platform.openai.com/api-keys',
    sendsDataOffDevice: true,
  },
  {
    id: 'openai-compatible',
    label: 'Other OpenAI-compatible endpoint',
    note: 'Groq, OpenRouter, Together, or a self-hosted gateway. You supply the base URL.',
    needsKey: true,
    defaultModel: 'llama-3.3-70b-versatile',
    sendsDataOffDevice: true,
  },
];

export class AINotConfigured extends Error {
  constructor(msg: string) {
    super(msg);
    this.name = 'AINotConfigured';
  }
}

const TIMEOUT_MS = 120000;

async function postJSON(url: string, headers: Record<string, string>, body: unknown) {
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), TIMEOUT_MS);
  try {
    const r = await fetch(url, {
      method: 'POST',
      headers: { 'content-type': 'application/json', ...headers },
      body: JSON.stringify(body),
      signal: ctl.signal,
    });
    const raw = await r.text();
    if (!r.ok) {
      // Surface the provider's own message: "invalid key" and "out of quota"
      // need different fixes and must not collapse into one error.
      let detail = raw.slice(0, 400);
      try {
        const j = JSON.parse(raw);
        detail = j?.error?.message || j?.message || detail;
      } catch {
        /* keep raw */
      }
      throw new Error(`${r.status} ${detail}`);
    }
    return JSON.parse(raw);
  } finally {
    clearTimeout(timer);
  }
}

/** Models often wrap JSON in ``` fences even when told not to. */
export function stripFences(s: string): string {
  const t = (s || '').trim();
  const m = t.match(/^```(?:json)?\s*([\s\S]*?)\s*```$/);
  return (m ? m[1] : t).trim();
}

/* ------------------------------------------------------------------ */

async function callGemini(cfg: ProviderConfig, o: GenerateOptions): Promise<string> {
  const model = cfg.model || 'gemini-2.0-flash';
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${cfg.apiKey}`;
  const geminiParts: any[] = [{ text: o.prompt }];
  for (const image of o.images || []) {
    const match = image.dataUrl.match(/^data:([^;]+);base64,(.+)$/);
    if (match) geminiParts.push({ inlineData: { mimeType: match[1], data: match[2] } });
  }
  const body: any = {
    contents: [{ role: 'user', parts: geminiParts }],
    generationConfig: {
      temperature: o.temperature ?? 0.7,
      maxOutputTokens: o.maxTokens ?? 8192,
      ...(o.json ? { responseMimeType: 'application/json' } : {}),
    },
  };
  if (o.system) body.systemInstruction = { parts: [{ text: o.system }] };
  const j = await postJSON(url, {}, body);
  const parts = j?.candidates?.[0]?.content?.parts || [];
  return parts.map((p: any) => p.text || '').join('');
}

async function callAnthropic(cfg: ProviderConfig, o: GenerateOptions): Promise<string> {
  const model = cfg.model || 'claude-sonnet-4-5';
  const system = o.json
    ? `${o.system || ''}\nRespond with valid JSON only. No prose, no code fences.`.trim()
    : o.system;
  const j = await postJSON(
    'https://api.anthropic.com/v1/messages',
    {
      'x-api-key': cfg.apiKey || '',
      'anthropic-version': '2023-06-01',
    },
    {
      model,
      max_tokens: o.maxTokens ?? 8192,
      temperature: o.temperature ?? 0.7,
      ...(system ? { system } : {}),
      messages: [{
        role: 'user',
        content: (o.images && o.images.length)
          ? [
              { type: 'text', text: o.prompt },
              ...o.images.flatMap((image) => {
                const match = image.dataUrl.match(/^data:([^;]+);base64,(.+)$/);
                return match ? [{ type: 'image', source: { type: 'base64', media_type: match[1], data: match[2] } }] : [];
              }),
            ]
          : o.prompt,
      }],
    }
  );
  return (j?.content || []).map((b: any) => (b.type === 'text' ? b.text : '')).join('');
}

async function callOpenAILike(
  cfg: ProviderConfig,
  o: GenerateOptions,
  baseUrl: string,
  defaultModel: string
): Promise<string> {
  const model = cfg.model || defaultModel;
  const messages: any[] = [];
  if (o.system) messages.push({ role: 'system', content: o.system });
  const userContent: any = (o.images && o.images.length)
    ? [
        { type: 'text', text: o.prompt },
        ...o.images.map((image) => ({ type: 'image_url', image_url: { url: image.dataUrl } })),
      ]
    : o.prompt;
  messages.push({ role: 'user', content: userContent });
  const j = await postJSON(
    `${baseUrl.replace(/\/+$/, '')}/chat/completions`,
    cfg.apiKey ? { authorization: `Bearer ${cfg.apiKey}` } : {},
    {
      model,
      messages,
      temperature: o.temperature ?? 0.7,
      max_tokens: o.maxTokens ?? 8192,
      ...(o.json ? { response_format: { type: 'json_object' } } : {}),
    }
  );
  return j?.choices?.[0]?.message?.content || '';
}

async function callLocal(cfg: ProviderConfig, o: GenerateOptions): Promise<string> {
  // llama-server is started by the app on a loopback port and speaks the
  // OpenAI chat-completions API, so the same client path serves it.
  const base = (cfg.baseUrl || process.env.LLAMA_BASE_URL || 'http://127.0.0.1:8080')
    .replace(/\/+$/, '');
  return callOpenAILike({ ...cfg, apiKey: 'local' }, o, `${base}/v1`,
                        cfg.model || 'local-gguf');
}

/* ------------------------------------------------------------------ */

export function activeConfig(env: NodeJS.ProcessEnv = process.env): ProviderConfig {
  const id = (env.AI_PROVIDER as ProviderId) || (env.GEMINI_API_KEY ? 'gemini' : 'local');
  const keyByProvider: Record<string, string | undefined> = {
    gemini: env.GEMINI_API_KEY,
    anthropic: env.ANTHROPIC_API_KEY,
    openai: env.OPENAI_API_KEY,
    'openai-compatible': env.AI_API_KEY,
    local: undefined,
  };
  return {
    id,
    apiKey: keyByProvider[id],
    model: env.AI_MODEL || undefined,
    // Bundled local AI is usable only when llama.cpp has actually started.
    // Never inherit a stale cloud/openai-compatible base URL when switching
    // back to local.
    baseUrl: id === 'local' ? (env.LLAMA_BASE_URL || undefined) : (env.AI_BASE_URL || undefined),
  };
}

export function isConfigured(cfg = activeConfig()): boolean {
  const info = PROVIDERS.find((p) => p.id === cfg.id);
  if (!info) return false;
  if (info.needsKey && !cfg.apiKey) return false;
  if (cfg.id === 'openai-compatible' && !cfg.baseUrl) return false;
  // The local runtime counts as configured only when the server is actually
  // up; a stopped runtime must not look ready.
  if (cfg.id === 'local' && !(cfg.baseUrl || process.env.LLAMA_BASE_URL)) return false;
  return true;
}

export async function generate(o: GenerateOptions, cfg = activeConfig()): Promise<GenerateResult> {
  if (!isConfigured(cfg)) {
    throw new AINotConfigured(
      `No AI provider is configured. Open Settings and choose a provider. ` +
        `Deterministic features continue to work without one.`
    );
  }
  let text: string;
  switch (cfg.id) {
    case 'gemini':
      text = await callGemini(cfg, o);
      break;
    case 'anthropic':
      text = await callAnthropic(cfg, o);
      break;
    case 'openai':
      text = await callOpenAILike(cfg, o, 'https://api.openai.com/v1', 'gpt-4o');
      break;
    case 'openai-compatible':
      text = await callOpenAILike(cfg, o, cfg.baseUrl as string, 'llama-3.3-70b-versatile');
      break;
    case 'local':
    default:
      text = await callLocal(cfg, o);
      break;
  }
  return {
    text: o.json ? stripFences(text) : text,
    provider: cfg.id,
    model: cfg.model || PROVIDERS.find((p) => p.id === cfg.id)?.defaultModel || 'unknown',
  };
}

/** Cheap round trip so Settings can verify a key before the user relies on it. */
export async function testConnection(cfg: ProviderConfig): Promise<{ ok: boolean; detail: string }> {
  try {
    const r = await generate(
      { prompt: 'Reply with the single word: ready', maxTokens: 16, temperature: 0 },
      cfg
    );
    return { ok: true, detail: `${r.provider} / ${r.model} responded` };
  } catch (e: any) {
    return { ok: false, detail: e?.message || String(e) };
  }
}
