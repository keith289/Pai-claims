/**
 * Private AI runtime: llama.cpp.
 *
 * llama-server ships inside the package (llama.cpp is MIT licensed), so there
 * is no separate install step and no daemon running outside the app. The
 * server is a child process this app starts and stops, bound to loopback.
 *
 * llama-server exposes an OpenAI-compatible /v1/chat/completions surface, so
 * the provider layer talks to it exactly as it talks to a hosted endpoint.
 * Only the base URL differs.
 *
 * Model weights are NOT bundled: they are large and carry their own licences
 * (Llama community licence, Qwen's Apache-2.0, and so on). The user downloads
 * the one they want, with the licence named before the download starts.
 */
import { spawn, ChildProcess } from 'child_process';
import { once } from 'events';
import fs from 'fs';
import os from 'os';
import path from 'path';

export interface RuntimeStatus {
  binaryPresent: boolean;
  binaryPath: string;
  running: boolean;
  baseUrl: string;
  loadedModel: string | null;
  models: LocalModelFile[];
  modelsDir: string;
  error?: string;
  nextStep: string;
}

export interface LocalModelFile {
  file: string;
  path: string;
  sizeBytes: number;
  catalogId?: string;
  label?: string;
}

export interface CatalogModel {
  id: string;
  label: string;
  file: string;
  url: string;
  downloadGB: number;
  minRamGB: number;
  contextTokens: number;
  licence: string;
  note: string;
}

/**
 * Short by design. Every entry is a Q4_K_M GGUF, which is the quality/size
 * balance that makes local inference practical on ordinary hardware.
 */
export const MODEL_CATALOG: CatalogModel[] = [
  {
    id: 'llama-3.2-3b',
    label: 'Llama 3.2 3B Instruct',
    file: 'Llama-3.2-3B-Instruct-Q4_K_M.gguf',
    url: 'https://huggingface.co/bartowski/Llama-3.2-3B-Instruct-GGUF/resolve/main/Llama-3.2-3B-Instruct-Q4_K_M.gguf',
    downloadGB: 2.0,
    minRamGB: 8,
    contextTokens: 8192,
    licence: 'Llama 3.2 Community License',
    note: 'Smallest workable option. Good for summaries and drafting; weaker on long policy documents.',
  },
  {
    id: 'llama-3.1-8b',
    label: 'Llama 3.1 8B Instruct',
    file: 'Meta-Llama-3.1-8B-Instruct-Q4_K_M.gguf',
    url: 'https://huggingface.co/bartowski/Meta-Llama-3.1-8B-Instruct-GGUF/resolve/main/Meta-Llama-3.1-8B-Instruct-Q4_K_M.gguf',
    downloadGB: 4.9,
    minRamGB: 16,
    contextTokens: 8192,
    licence: 'Llama 3.1 Community License',
    note: 'Balanced default. Handles claim narratives and structured JSON reliably.',
  },
  {
    id: 'qwen2.5-14b',
    label: 'Qwen 2.5 14B Instruct',
    file: 'Qwen2.5-14B-Instruct-Q4_K_M.gguf',
    url: 'https://huggingface.co/bartowski/Qwen2.5-14B-Instruct-GGUF/resolve/main/Qwen2.5-14B-Instruct-Q4_K_M.gguf',
    downloadGB: 9.0,
    minRamGB: 32,
    contextTokens: 16384,
    licence: 'Apache 2.0',
    note: 'Stronger reasoning over long documents. Noticeably slower on CPU only.',
  },
];

/* ------------------------------------------------------------------ paths */

/** Where the bundled llama-server lives inside the packaged app. */
export function binaryPath(resourcesDir?: string): string {
  const dir = resourcesDir || process.env.LLAMA_BIN_DIR || path.join(process.cwd(), 'runtime');
  return path.join(dir, process.platform === 'win32' ? 'llama-server.exe' : 'llama-server');
}

/** Model files live in user data, never inside the read-only package. */
export function modelsDir(userDataDir?: string): string {
  const dir =
    userDataDir ||
    process.env.LLAMA_MODELS_DIR ||
    path.join(os.homedir(), '.pai-claims', 'models');
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

export function listModels(dir?: string): LocalModelFile[] {
  const d = modelsDir(dir);
  return fs
    .readdirSync(d)
    .filter((f) => f.toLowerCase().endsWith('.gguf'))
    .map((f) => {
      const full = path.join(d, f);
      const cat = MODEL_CATALOG.find((c) => c.file === f);
      return {
        file: f,
        path: full,
        sizeBytes: fs.statSync(full).size,
        catalogId: cat?.id,
        label: cat?.label,
      };
    });
}

/* ------------------------------------------------------------- lifecycle */

let proc: ChildProcess | null = null;
let currentModel: string | null = null;
let currentPort = 0;

export function isRunning() {
  return Boolean(proc && !proc.killed);
}

export function baseUrl() {
  return `http://127.0.0.1:${currentPort}`;
}

/**
 * Start llama-server on a loopback port with a chosen model file.
 * Resolves once the server answers /health, so callers never race it.
 */
export async function start(opts: {
  modelPath: string;
  port: number;
  binDir?: string;
  contextTokens?: number;
  threads?: number;
  gpuLayers?: number;
}): Promise<{ ok: boolean; baseUrl?: string; error?: string }> {
  if (isRunning()) await stop();

  const bin = binaryPath(opts.binDir);
  if (!fs.existsSync(bin)) {
    return { ok: false, error: `llama-server not found at ${bin}` };
  }
  if (!fs.existsSync(opts.modelPath)) {
    return { ok: false, error: `Model file not found: ${opts.modelPath}` };
  }

  const args = [
    '-m', opts.modelPath,
    '--host', '127.0.0.1',            // loopback only: claim text never hits the network
    '--port', String(opts.port),
    '-c', String(opts.contextTokens ?? 8192),
    '-t', String(opts.threads ?? Math.max(2, Math.min(8, os.cpus().length - 1))),
    '-ngl', String(opts.gpuLayers ?? 0),
    '--no-webui',
  ];

  proc = spawn(bin, args, { windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
  currentPort = opts.port;
  currentModel = opts.modelPath;

  let stderrTail = '';
  proc.stderr?.on('data', (d) => {
    stderrTail = (stderrTail + d.toString()).slice(-2000);
  });
  const exited = new Promise<string>((resolve) => {
    proc?.on('exit', (code) => resolve(`llama-server exited (code ${code}). ${stderrTail.slice(-400)}`));
  });

  // Poll /health rather than guessing with a fixed sleep: load time varies
  // from seconds to a minute depending on model size and disk.
  const deadline = Date.now() + 120000;
  while (Date.now() < deadline) {
    if (!proc || proc.killed) return { ok: false, error: await exited };
    try {
      const r = await fetch(`${baseUrl()}/health`);
      if (r.ok) return { ok: true, baseUrl: baseUrl() };
    } catch {
      /* not up yet */
    }
    await new Promise((r) => setTimeout(r, 500));
  }
  await stop();
  return { ok: false, error: 'llama-server did not become ready within 2 minutes.' };
}

export async function stop(): Promise<void> {
  if (!proc) return;
  const p = proc;
  proc = null;
  currentModel = null;
  await new Promise<void>((resolve) => {
    const done = setTimeout(() => {
      try {
        p.kill('SIGKILL');
      } catch {
        /* already gone */
      }
      resolve();
    }, 5000);
    p.once('exit', () => {
      clearTimeout(done);
      resolve();
    });
    try {
      p.kill();
    } catch {
      clearTimeout(done);
      resolve();
    }
  });
}

export async function status(binDir?: string, dir?: string): Promise<RuntimeStatus> {
  const bin = binaryPath(binDir);
  const present = fs.existsSync(bin);
  const models = listModels(dir);
  const running = isRunning();

  let nextStep: string;
  if (!present) nextStep = 'The local AI runtime is missing from this installation. Reinstall the app.';
  else if (!models.length) nextStep = 'No model installed yet. Download one below to run AI on this device.';
  else if (!running) nextStep = 'Model ready. Start the local runtime to use it.';
  else nextStep = 'Running on this device. Nothing is sent to any external service.';

  return {
    binaryPresent: present,
    binaryPath: bin,
    running,
    baseUrl: running ? baseUrl() : '',
    loadedModel: currentModel,
    models,
    modelsDir: modelsDir(dir),
    nextStep,
  };
}

/* ------------------------------------------------------------- downloads */

export interface DownloadProgress {
  status: string;
  completed?: number;
  total?: number;
  percent?: number;
  done?: boolean;
  error?: string;
  path?: string;
}

/**
 * Download a catalog model with progress, resuming is not attempted but a
 * partial file is always cleaned up so a failed download cannot masquerade
 * as an installed model.
 */
export async function* download(
  catalogId: string,
  dir?: string
): AsyncGenerator<DownloadProgress> {
  const model = MODEL_CATALOG.find((m) => m.id === catalogId);
  if (!model) {
    // Whitelist only: a typo cannot start a multi-gigabyte download.
    yield { status: 'refused', error: `'${catalogId}' is not in the model catalog.`, done: true };
    return;
  }

  const destDir = modelsDir(dir);
  const dest = path.join(destDir, model.file);
  const partial = dest + '.part';

  if (fs.existsSync(dest)) {
    yield { status: 'already installed', percent: 100, done: true, path: dest };
    return;
  }

  const free = await freeSpaceBytes(destDir);
  const needed = model.downloadGB * 1024 ** 3 * 1.05;
  if (free !== null && free < needed) {
    yield {
      status: 'refused',
      error: `Not enough disk space: ${model.label} needs about ${model.downloadGB} GB, ` +
             `${(free / 1024 ** 3).toFixed(1)} GB free.`,
      done: true,
    };
    return;
  }

  let res: Response;
  try {
    res = await fetch(model.url, { redirect: 'follow' });
  } catch (e: any) {
    yield { status: 'error', error: `Download failed: ${e?.message || e}`, done: true };
    return;
  }
  if (!res.ok || !res.body) {
    yield { status: 'error', error: `Download failed: ${res.status}`, done: true };
    return;
  }

  const total = Number(res.headers.get('content-length')) || model.downloadGB * 1024 ** 3;
  const out = fs.createWriteStream(partial);
  const reader = res.body.getReader();
  let completed = 0;
  let lastEmit = 0;

  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      if (!out.write(Buffer.from(value))) {
        await once(out, 'drain');
      }
      completed += value.length;
      const pct = Math.round((completed / total) * 100);
      if (pct !== lastEmit) {
        lastEmit = pct;
        yield { status: 'downloading', completed, total, percent: pct };
      }
    }
    await new Promise<void>((r) => out.end(r));
    fs.renameSync(partial, dest);
    yield { status: 'success', percent: 100, done: true, path: dest };
  } catch (e: any) {
    try {
      out.destroy();
      if (fs.existsSync(partial)) fs.unlinkSync(partial);
    } catch {
      /* best effort */
    }
    yield { status: 'error', error: `Download interrupted: ${e?.message || e}`, done: true };
  }
}

export function removeModel(file: string, dir?: string) {
  const full = path.join(modelsDir(dir), path.basename(file));
  if (!full.endsWith('.gguf') || !fs.existsSync(full)) {
    throw new Error(`Not a model file: ${file}`);
  }
  fs.unlinkSync(full);
  return { ok: true, removed: path.basename(full) };
}

async function freeSpaceBytes(dir: string): Promise<number | null> {
  try {
    const s: any = await fs.promises.statfs(dir);
    return s.bavail * s.bsize;
  } catch {
    return null;
  }
}

/** Recommendations ranked against the machine's real memory. */
export function recommend(totalRamGB: number) {
  const fits = MODEL_CATALOG.filter((m) => m.minRamGB <= totalRamGB);
  const best = fits.length ? fits[fits.length - 1] : null;
  return {
    totalRamGB,
    recommended: best?.id || null,
    options: MODEL_CATALOG.map((m) => ({
      ...m,
      fits: m.minRamGB <= totalRamGB,
      reason:
        m.minRamGB <= totalRamGB
          ? ''
          : `Needs about ${m.minRamGB} GB RAM; this machine reports ${totalRamGB} GB.`,
    })),
    note: best
      ? `${best.label} is the largest model this machine can run comfortably.`
      : 'This machine is below the minimum for every model listed. A cloud provider may be the practical choice.',
  };
}
