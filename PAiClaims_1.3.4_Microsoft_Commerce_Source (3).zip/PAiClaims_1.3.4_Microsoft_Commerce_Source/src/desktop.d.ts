import type { LowesMaterialPrice } from './types';

declare global {
  interface Window {
    paiDesktop?: {
      isDesktop: boolean;
      chooseLocation(): Promise<{ path: string; writable: boolean } | null>;
      createClaim(
        location: string,
        name: string,
        claimData: unknown,
        documents: Array<{ kind: string; filename: string; dataBase64: string }>,
      ): Promise<{ root: string; meta: unknown; manifest: unknown; access: CommerceAccess; attachments: unknown[] }>;
      getCommerceOffer(location: string, name: string): Promise<CommerceOffer>;
      acquireMicrosoftCase(location: string, name: string): Promise<{ ok: boolean; productId: string | null; access: CommerceAccess }>;
      acquireMicrosoftAnnual(location: string, name: string): Promise<{ ok: boolean; productId: string; access: CommerceAccess }>;
      redeemPurchaseCode(request: { code: string; location: string; name: string; expectedProductId: string }): Promise<{ ok: boolean; productId: string; access: CommerceAccess }>;
      /**
       * Copy a document into the case folder, hash it, and extract what is
       * readable. `bracketCeiling` is the highest bracket a value read from
       * this document may reach; `needsVision` marks a file only a model can
       * describe.
       */
      attachDocument(request: {
        root: string;
        kind: string;
        filename: string;
        dataBase64: string;
      }): Promise<{
        storedPath: string;
        filename: string;
        kind: string;
        bytes: number;
        contentHash: string;
        duplicateOf: string | null;
        text: string;
        method: string;
        pages: number;
        ocrPages: number;
        confidence: number | null;
        bracketCeiling: 'UNVERIFIED' | 'SPECULATIVE' | 'EXPLAINED' | 'VALIDATED' | 'CONTRADICTED';
        needsVision: boolean;
        note: string;
      }>;
      getSettings(): Promise<unknown>;
      setGeminiKey(key: string): Promise<unknown>;
      getAIConfig(): Promise<unknown>;
      setAIConfig(config: unknown): Promise<unknown>;
      machineInfo(): Promise<unknown>;
      revealClaim(root: string): Promise<string>;
      getLowesConfig(): Promise<{
        clientId: string;
        scope: string;
        tokenUrl: string;
        productUrlTemplate: string;
        searchUrlTemplate: string;
        hasSecret: boolean;
        secretProtected: boolean;
        hasStoreFeed: boolean;
        storeFeedRows: number;
      }>;
      setLowesConfig(config: {
        clientId: string;
        clientSecret?: string;
        scope?: string;
        tokenUrl?: string;
        productUrlTemplate?: string;
        searchUrlTemplate?: string;
      }): Promise<{
        ok: boolean;
        clientId: string;
        scope: string;
        tokenUrl: string;
        productUrlTemplate: string;
        searchUrlTemplate: string;
        hasSecret: boolean;
        secretProtected: boolean;
      }>;
      lookupLowesProduct(request: { productId: string; storeId: string; zipCode: string }): Promise<LowesMaterialPrice>;
      searchLowesProduct(request: { query: string; storeId: string; zipCode: string }): Promise<LowesMaterialPrice>;
      importLowesStoreFeed(): Promise<null | { rowCount: number; hash: string; importedAt: string }>;
    };
  }
}

interface CommerceAccess {
  allowed: boolean;
  mode: 'annual' | 'case' | 'annual-expired' | 'locked';
  readOnly: boolean;
  expiresAt: string | null;
  complimentaryPaiLegalCase: null | {
    included: true;
    caseCount: 1;
    grantedAt: string;
    sourceProductId: 'pai-claims-first-case';
    features: ['pai-case-file-creator', 'psi-legal-data'];
  };
}

interface CommerceOffer {
  access: CommerceAccess;
  firstCaseUsed: boolean;
  store: { available: boolean; error: string; lastSyncAt: string };
  caseOffer: {
    productId: string;
    priceUsd: number;
    checkoutUrl: string;
    storeId: string;
    formattedPrice: string;
    owned: boolean;
    balance: number;
    purchasable: boolean;
  };
  annualOffer: {
    productId: string;
    priceUsd: number;
    checkoutUrl: string;
    storeId: string;
    formattedPrice: string;
    active: boolean;
    expiresAt: string;
    purchasable: boolean;
  };
  singleCaseBalance: number;
}


export {};
