import { weakestBracket } from '../domain/policyRecord.ts';
import { EpistemicBracket, EvidenceItem, LineItemDispute, InsuranceClaim } from '../types';

export const BRACKET_WRAPPERS: Record<EpistemicBracket, [string, string]> = {
  UNVERIFIED: ['[{', '}]'],
  SPECULATIVE: ['[[', ']]'],
  EXPLAINED: ['{[', ']}'],
  VALIDATED: ['[[[', ']]]'],
  CONTRADICTED: ['[!', '!@]'],
};

export const BRACKET_COLORS: Record<EpistemicBracket, {
  border: string;
  bg: string;
  text: string;
  badgeBg: string;
  badgeText: string;
  glow: string;
  label: string;
}> = {
  UNVERIFIED: {
    border: 'border-slate-600',
    bg: 'bg-slate-900/60',
    text: 'text-slate-300',
    badgeBg: 'bg-slate-800 text-slate-300 border border-slate-700',
    badgeText: 'text-slate-300',
    glow: 'rgba(100, 116, 139, 0.2)',
    label: 'Unverified / Raw Assertion',
  },
  SPECULATIVE: {
    border: 'border-purple-500/50',
    bg: 'bg-purple-950/40',
    text: 'text-purple-200',
    badgeBg: 'bg-purple-900/60 text-purple-200 border border-purple-700/60',
    badgeText: 'text-purple-200',
    glow: 'rgba(168, 85, 247, 0.2)',
    label: 'Speculative / Adjuster Opinion',
  },
  EXPLAINED: {
    border: 'border-amber-500/50',
    bg: 'bg-amber-950/40',
    text: 'text-amber-200',
    badgeBg: 'bg-amber-900/60 text-amber-200 border border-amber-700/60',
    badgeText: 'text-amber-200',
    glow: 'rgba(245, 158, 11, 0.2)',
    label: 'Explained / Structural Proof',
  },
  VALIDATED: {
    border: 'border-emerald-500/60',
    bg: 'bg-emerald-950/40',
    text: 'text-emerald-200',
    badgeBg: 'bg-emerald-900/60 text-emerald-200 border border-emerald-700/60',
    badgeText: 'text-emerald-200',
    glow: 'rgba(16, 185, 129, 0.25)',
    label: 'Independently Validated',
  },
  CONTRADICTED: {
    border: 'border-rose-500/60',
    bg: 'bg-rose-950/40',
    text: 'text-rose-200',
    badgeBg: 'bg-rose-900/60 text-rose-200 border border-rose-700/60',
    badgeText: 'text-rose-200',
    glow: 'rgba(244, 63, 94, 0.25)',
    label: 'Tension / Denial Contradiction',
  },
};

/**
 * Format string with canonical bracket notation
 */
export function wrapBracket(text: string, bracket: EpistemicBracket): string {
  const [open, close] = BRACKET_WRAPPERS[bracket] || ['[{', '}]'];
  return `${open}${text}${close}`;
}

/**
 * Parses bracketed text in strings and returns formatted chunks for JSX rendering
 */
export function parseEpistemicText(rawText: string): Array<{ text: string; bracket?: EpistemicBracket }> {
  if (!rawText) return [];
  const results: Array<{ text: string; bracket?: EpistemicBracket }> = [];
  
  // Regex to match [[[...]]], {[...]}, [[...]], [{...}], [!...!]
  const regex = /(\[\[\[[\s\S]*?\]\]\]|\{\[[\s\S]*?\]\}|\[\[[\s\S]*?\]\]|\[\{[\s\S]*?\}\]|\[![\s\S]*?!@\])/g;
  
  let lastIndex = 0;
  let match;
  
  while ((match = regex.exec(rawText)) !== null) {
    if (match.index > lastIndex) {
      results.push({ text: rawText.substring(lastIndex, match.index) });
    }
    
    const matchedStr = match[0];
    let bracket: EpistemicBracket = 'UNVERIFIED';
    let innerContent = matchedStr;
    
    if (matchedStr.startsWith('[[[') && matchedStr.endsWith(']]]')) {
      bracket = 'VALIDATED';
      innerContent = matchedStr.slice(3, -3);
    } else if (matchedStr.startsWith('{[') && matchedStr.endsWith(']}')) {
      bracket = 'EXPLAINED';
      innerContent = matchedStr.slice(2, -2);
    } else if (matchedStr.startsWith('[[') && matchedStr.endsWith(']]')) {
      bracket = 'SPECULATIVE';
      innerContent = matchedStr.slice(2, -2);
    } else if (matchedStr.startsWith('[{') && matchedStr.endsWith('}]')) {
      bracket = 'UNVERIFIED';
      innerContent = matchedStr.slice(2, -2);
    } else if (matchedStr.startsWith('[!') && matchedStr.endsWith('!@]')) {
      bracket = 'CONTRADICTED';
      innerContent = matchedStr.slice(2, -3);
    }
    
    results.push({ text: innerContent, bracket });
    lastIndex = regex.lastIndex;
  }
  
  if (lastIndex < rawText.length) {
    results.push({ text: rawText.substring(lastIndex) });
  }
  
  return results;
}

/**
 * Calculates mathematical Relational Pressure Mapping (RPM)
 */
export function calculateClaimRPM(evidence: EvidenceItem[]) {
  let floatTotal = 0;
  let mixTotal = 0;
  let stirTotal = 0;
  
  let matterK66Pressure = 0;
  let relationK90Pressure = 0;
  let chronologyK120Pressure = 0;

  evidence.forEach((item) => {
    floatTotal += item.floatPoints;
    mixTotal += item.mixPoints;
    stirTotal += item.stirPoints;
    
    // Categorize by Klein channel
    if (item.type === 'contractor_estimate' || item.type === 'carrier_estimate' || item.type === 'receipts_ale') {
      matterK66Pressure += item.totalPressure;
    } else if (item.type === 'policy_dec' || item.type === 'denial_letter' || item.type === 'engineer_report') {
      relationK90Pressure += item.totalPressure;
    } else {
      chronologyK120Pressure += item.totalPressure;
    }
  });

  const totalPressure = floatTotal + mixTotal + stirTotal;
  
  return {
    floatTotal,
    mixTotal,
    stirTotal,
    totalPressure,
    channels: {
      matter_k66: Math.round(matterK66Pressure),
      relation_k90: Math.round(relationK90Pressure),
      chronology_k120: Math.round(chronologyK120Pressure),
    },
  };
}

/**
 * Audits Multi-Trade General Contractor Overhead & Profit (GCO&P 10 & 10)
 * Standard Insurance Rule: If 3 or more distinct trades are required (e.g. Roofing + Drywall + Electrical),
 * the carrier must apply 10% Overhead and 10% Profit to the entire scope!
 */
export function auditOverheadAndProfit(lineItems: LineItemDispute[]): {
  qualifiesForOP: boolean;
  distinctTradeCount: number;
  trades: string[];
  eligibleBaseRCV: number;
  overheadAmount: number;
  profitAmount: number;
  totalOPAddition: number;
  legalJustification: string;
} {
  const activeTrades = new Set<string>();
  let eligibleBaseRCV = 0;
  let explicitOP = 0;

  lineItems.forEach((item) => {
    if (item.category === 'General Conditions / O&P') {
      explicitOP += Math.max(0, Number(item.contractorBenchmarkRCV || 0));
      return;
    }
    if (item.category !== 'Contents / ALE') {
      activeTrades.add(item.category);
      eligibleBaseRCV += Math.max(0, Number(item.contractorBenchmarkRCV || 0));
    }
  });

  const trades = Array.from(activeTrades);
  const distinctTradeCount = trades.length;
  // Trade count is context, not a legal entitlement switch. Only an explicit
  // source-traced O&P allowance is included here; the policy/rule basis is
  // evaluated separately in the claim map and Parliament.
  const qualifiesForOP = explicitOP > 0;
  const overheadAmount = explicitOP / 2;
  const profitAmount = explicitOP / 2;
  const totalOPAddition = explicitOP;

  return {
    qualifiesForOP,
    distinctTradeCount,
    trades,
    eligibleBaseRCV,
    overheadAmount,
    profitAmount,
    totalOPAddition,
    legalJustification: qualifiesForOP
      ? `A $${explicitOP.toFixed(2)} O&P allowance is explicitly present in the source-traced estimate. Whether it is covered/owed remains dependent on the policy, jurisdiction, facts, and supporting evidence.`
      : `${distinctTradeCount} trade(s) are present, but trade count alone does not establish O&P entitlement. Keep any photo-derived O&P allowance bracketed until the policy/rule/evidence basis is added.`,
  };
}

/**
 * Calculates True Audited Valuation & Recovery Gap Breakdown
 */
export function recalculateClaimValuation(claim: InsuranceClaim) {
  let contractorRCV = 0;
  let contractorACV = 0;
  let recoverableDepreciation = 0;
  let codeUpgrades = 0;

  claim.lineItems.forEach((item) => {
    contractorRCV += item.contractorBenchmarkRCV;
    const itemDeprec = item.contractorBenchmarkRCV - item.carrierAllowedACV;
    if (itemDeprec > 0 && item.isRecoverableDepreciation) {
      recoverableDepreciation += itemDeprec;
    }
    if (item.codeUpgradeRequired) {
      codeUpgrades += (item.contractorBenchmarkRCV - item.carrierAllowedRCV);
    }
  });

  contractorACV = contractorRCV - recoverableDepreciation;

  const opAudit = auditOverheadAndProfit(claim.lineItems);
  const eligibleOverheadAndProfit = opAudit.totalOPAddition;

  // Ordinance & Law cap check against the policy limit.
  // The cap is applied only when the allowance was actually read from a
  // policy document. An unread allowance must not be treated as zero (which
  // silently deletes recoverable upgrades) nor as an assumed percentage
  // (which invents a policy term). It is left uncapped and bracketed.
  const ordLaw = claim.policyRecord?.limits.ordinanceAndLaw_amount;
  const ordLawRead =
    !!ordLaw && ordLaw.value !== null &&
    (ordLaw.bracket === 'EXPLAINED' || ordLaw.bracket === 'VALIDATED' || ordLaw.bracket === 'SPECULATIVE');
  const eligibleCodeUpgrades = ordLawRead
    ? Math.min(codeUpgrades, ordLaw!.value as number)
    : codeUpgrades;

  const eligibleALE = claim.evidence
    .filter((record) => record.type === 'receipts_ale')
    .reduce((sum, record) => sum + Math.max(0, Number(record.amountAssociated || 0)), 0); // only documented ALE amounts

  const trueGrossRecovery = contractorRCV + eligibleOverheadAndProfit + eligibleCodeUpgrades;

  // The deductible is subtracted only when it was read from the policy.
  const ded = claim.policyRecord?.limits.deductible;
  const dedRead = !!ded && ded.value !== null && ded.bracket !== 'UNVERIFIED' && ded.bracket !== 'CONTRADICTED';
  const netPayoutOwed = dedRead
    ? trueGrossRecovery - (ded!.value as number)
    : trueGrossRecovery;
  const totalRecoveryGap = Math.max(0, netPayoutOwed - claim.carrierOffer.netCarrierCheckIssued);

  // A valuation is never more confident than the policy terms it rests on.
  const unreadTerms: string[] = [];
  if (!ordLawRead) unreadTerms.push('ordinanceAndLaw_amount');
  if (!dedRead) unreadTerms.push('deductible');
  const bracket: EpistemicBracket = weakestBracket(
    ordLaw?.bracket ?? 'UNVERIFIED',
    ded?.bracket ?? 'UNVERIFIED',
  );

  return {
    contractorRCV,
    contractorACV,
    recoverableDepreciation,
    eligibleCodeUpgrades,
    eligibleOverheadAndProfit,
    eligibleALE,
    trueGrossRecovery,
    netPayoutOwed,
    totalRecoveryGap,
    bracket,
    unreadTerms,
    opAudit,
  };
}
