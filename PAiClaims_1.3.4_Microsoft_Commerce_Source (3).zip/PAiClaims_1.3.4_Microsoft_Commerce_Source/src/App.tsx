import React, { useState, useEffect } from 'react';
import { INITIAL_CLAIMS } from './data/sampleClaims';
import { InsuranceClaim } from './types';
import { Header } from './components/Header';
import { Sidebar, TabType } from './components/Sidebar';
import { DashboardView } from './components/DashboardView';
import { XactimateOptimizerView } from './components/XactimateOptimizerView';
import { PayoutOptimizerView } from './components/PayoutOptimizerView';
import { EvidenceVaultView } from './components/EvidenceVaultView';
import { PrecognitiveClaimMapView } from './components/PrecognitiveClaimMapView';
import { ParliamentView } from './components/ParliamentView';
import { DisputeLettersStudioView } from './components/DisputeLettersStudioView';
import { StatutoryTimelineView } from './components/StatutoryTimelineView';
import { AISetupView } from './components/AISetupView';
import { ClaimAdvisorChatModal } from './components/ClaimAdvisorChatModal';
import { PSiEstimatorView } from './components/PSiEstimatorView';
import { ShieldAlert, Plus, Building2, Home, Shield, DollarSign, X } from 'lucide-react';
import { emptyPolicyRecord, emptyPolicyLimits, insuredAsserted } from './domain/policyRecord.ts';
import { assessEstimationReadiness } from './domain/transcriptReview.ts';
import { buildPageReviews } from './domain/reviewRunner.ts';
import { AccuracyWarningBanner } from './components/AccuracyWarningBanner.tsx';

export default function App() {
  const [claims, setClaims] = useState<InsuranceClaim[]>(INITIAL_CLAIMS);
  const [activeClaimId, setActiveClaimId] = useState<string>(INITIAL_CLAIMS[0].id);
  const [activeTab, setActiveTab] = useState<TabType>('dashboard');
  const [isAdvisorOpen, setIsAdvisorOpen] = useState<boolean>(false);
  const [showNewClaimModal, setShowNewClaimModal] = useState<boolean>(false);
  const [paymentGate, setPaymentGate] = useState<null | {
    location: string;
    offer: {
      access: { allowed: boolean; mode: string; readOnly: boolean; expiresAt: string | null };
      store: { available: boolean; error: string; lastSyncAt: string };
      caseOffer: {
        productId: string; priceUsd: number; checkoutUrl: string; storeId: string;
        formattedPrice: string; owned: boolean; balance: number; purchasable: boolean;
      };
      annualOffer: {
        productId: string; priceUsd: number; checkoutUrl: string; storeId: string;
        formattedPrice: string; active: boolean; expiresAt: string; purchasable: boolean;
      };
      singleCaseBalance: number;
    };
  }>(null);
  const [purchaseCode, setPurchaseCode] = useState('');
  // Wizard order: choose location -> pay -> fill the form. The form is part of
  // the paid workspace, so it is not shown until access is granted.
  const [wizardStep, setWizardStep] = useState<'gate' | 'form'>('gate');
  const [policyFiles, setPolicyFiles] = useState<File[]>([]);
  const [claimMessage, setClaimMessage] = useState('');
  const [isCreatingClaim, setIsCreatingClaim] = useState(false);

  // First run: ask how AI should work before the workspace opens. Answered
  // once, then remembered. Skipping is allowed - the app works without AI.
  const [setupChecked, setSetupChecked] = useState(false);
  const [needsSetup, setNeedsSetup] = useState(false);
  useEffect(() => {
    (async () => {
      // Check the running backend every launch. If no provider is actually
      // usable, show the local/API chooser. A previous "skip" must not hide
      // setup forever when AI is still unconfigured.
      try {
        const r = await fetch('/api/ai/providers').then((x) => {
          if (!x.ok) throw new Error(`AI status ${x.status}`);
          return x.json();
        });
        setNeedsSetup(!r.configured);
      } catch {
        setNeedsSetup(true);
      }
      setSetupChecked(true);
    })();
  }, []);
  const finishSetup = () => {
    setNeedsSetup(false);
  };

  // New Claim Form State
  const [newClaimTitle, setNewClaimTitle] = useState('');
  const [newPolicyholder, setNewPolicyholder] = useState('');
  const [newCarrierName, setNewCarrierName] = useState('');
  const [newClaimNumber, setNewClaimNumber] = useState('');
  const [newPolicyNumber, setNewPolicyNumber] = useState('');
  const [newPropertyAddress, setNewPropertyAddress] = useState('');
  const [newPeril, setNewPeril] = useState<InsuranceClaim['peril']>('hurricane');
  const [newDwellingLimit, setNewDwellingLimit] = useState<number | null>(null);
  const [newDeductible, setNewDeductible] = useState<number | null>(null);
  const [newInitialCheck, setNewInitialCheck] = useState<number | null>(null);
  const [newContractorEstimate, setNewContractorEstimate] = useState<number | null>(null);

  const activeClaim = claims.find((c) => c.id === activeClaimId) || claims[0];

  const handleUpdateClaim = (updated: InsuranceClaim) => {
    setClaims((prev) => prev.map((c) => (c.id === updated.id ? updated : c)));
  };

  /**
   * Step 1: pick a folder and settle access. Runs before the form is shown, so
   * the customer is not asked to fill anything in before they know the price.
   */
  const beginNewClaim = async () => {
    const desktop = window.paiDesktop;
    setClaimMessage('');
    if (!desktop) {
      // Browser/dev build has no commerce layer; go straight to the form.
      setWizardStep('form');
      return;
    }
    const selected = await desktop.chooseLocation();
    if (!selected) return;
    if (!selected.writable) {
      setClaimMessage('That folder is not writable. Choose a folder you own and try again.');
      return;
    }
    const offer = await desktop.getCommerceOffer(selected.path, newClaimTitle || 'New claim');
    if (!offer.access.allowed) {
      setPaymentGate({ location: selected.path, offer });
      setWizardStep('gate');
      return;
    }
    setPaymentGate({ location: selected.path, offer });
    setWizardStep('form');
  };

  const handleCreateNewClaim = async (preauthorizedLocation?: string) => {
    if (!newClaimTitle || !newPolicyholder) return;
    // The policy packet is required. Nothing is created without it.
    if (policyFiles.length === 0) return;

    const desktopLocation = preauthorizedLocation ?? paymentGate?.location;

    setIsCreatingClaim(true);
    setClaimMessage('');

    // Blank inputs are treated as absent, never as zero-with-confidence.
    const dwelling = newDwellingLimit ?? 0;
    const deductible = newDeductible ?? 0;
    const initialCheck = newInitialCheck ?? 0;
    const contractorEstimate = newContractorEstimate ?? 0;

    const intakeGaps: string[] = [];
    if (!newPolicyholder.trim()) intakeGaps.push('policyholder name');
    if (!newCarrierName.trim()) intakeGaps.push('carrier');
    if (!newPropertyAddress.trim()) intakeGaps.push('property address');
    if (newDwellingLimit === null) intakeGaps.push('dwelling limit');
    if (newDeductible === null) intakeGaps.push('deductible');
    if (newInitialCheck === null) intakeGaps.push('initial carrier check');
    if (newContractorEstimate === null) intakeGaps.push('contractor estimate');

    const opAddition = Math.round(contractorEstimate * 0.2);
    const codeAddition = Math.round(contractorEstimate * 0.15);
    const gross = contractorEstimate + opAddition + codeAddition;
    const netOwed = Math.max(0, gross - deductible);
    const gap = Math.max(0, netOwed - initialCheck);

    const created: InsuranceClaim = {
      id: `claim-${Date.now()}`,
      claimNumber: newClaimNumber || `CLM-${Math.floor(100000 + Math.random() * 900000)}`,
      policyNumber: newPolicyNumber || `POL-2024-${Math.floor(1000 + Math.random() * 9000)}`,
      policyholderName: newPolicyholder,
      carrierName: newCarrierName,
      assignedAdjuster: 'Staff Field Adjuster',
      policyType: 'homeowners_ho3',
      dateOfLoss: new Date().toISOString().split('T')[0],
      dateReported: new Date().toISOString().split('T')[0],
      peril: newPeril,
      propertyAddress: newPropertyAddress || '123 Coastal Ridge Way, Naples, FL',
      status: 'carrier_lowball',
      // Only the two figures the insured actually typed are carried.
      // Coverage B/C/D, ordinance & law, mold and debris limits are NOT
      // guessed from percentages — an unread term stays 0 here and
      // UNVERIFIED in policyRecord until a policy document is supplied.
      policyLimits: {
        dwelling_covA: dwelling,
        otherStructures_covB: 0,
        personalProperty_covC: 0,
        lossOfUse_covD: 0,
        ordinanceAndLaw_percent: 0,
        ordinanceAndLaw_amount: 0,
        moldRemediationLimit: 0,
        debrisRemovalPercent: 0,
        deductible: deductible,
        deductibleType: 'flat_dollar',
      },
      intakeGaps,
      pageReviews: [],
      policyRecord: {
        ...emptyPolicyRecord(`claim-${Date.now()}`),
        limits: {
          ...emptyPolicyLimits(),
          dwelling_covA: insuredAsserted(dwelling, 'Coverage A dwelling limit'),
          deductible: insuredAsserted(deductible, 'Deductible'),
        },
      },
      carrierOffer: {
        initialOfferACV: initialCheck,
        initialOfferRCV: initialCheck + 8000,
        depreciationWithheld: 8000,
        deductibleDeducted: deductible,
        netCarrierCheckIssued: initialCheck,
        carrierSummary: 'Carrier approved initial spot repairs only. Missing multi-trade GCO&P and code upgrades.',
      },
      auditedTrueValuation: {
        contractorRCV: contractorEstimate,
        contractorACV: contractorEstimate - 4000,
        recoverableDepreciation: 8000,
        eligibleCodeUpgrades: codeAddition,
        eligibleOverheadAndProfit: opAddition,
        eligibleALE: 4500,
        trueGrossRecovery: gross,
        netPayoutOwed: netOwed,
        totalRecoveryGap: gap,
        // No policy has been read at creation, so this valuation rests on
        // figures the insured typed. It is UNVERIFIED until the packet lands.
        bracket: 'UNVERIFIED',
        unreadTerms: ['ordinanceAndLaw_amount', 'deductible'],
      },
      evidence: [
        ...policyFiles.map((f, i) => ({
          // The packet the customer supplied. No terms have been read from it
          // yet, so it asserts the document exists and nothing more.
          id: `ev-${Date.now()}-policy-${i}`,
          title: i === 0 ? 'Policy packet (as supplied)' : `Policy packet — part ${i + 1}`,
          type: 'policy_dec' as const,
          filename: f.name,
          date: new Date().toISOString().split('T')[0],
          source: 'Supplied by insured at intake',
          provenanceRoot: 'Insured upload',
          evidenceLevel: 'direct' as const,
          stance: 'context' as const,
          bracketState: 'UNVERIFIED' as const,
          excerpt: '',
          rawText: '',
          floatPoints: 0,
          mixPoints: 0,
          stirPoints: 0,
          totalPressure: 0,
          keyObservations: [
            'Document on file. Coverage terms have not been read from it yet.',
          ],
        })),
        {
          id: `ev-${Date.now()}-2`,
          title: 'Initial Carrier Estimate & Explanation of Benefits',
          type: 'denial_letter',
          filename: 'Carrier_Scope.pdf',
          date: new Date().toISOString().split('T')[0],
          source: `${newCarrierName} Claims Dept`,
          provenanceRoot: 'Carrier Field Adjuster System',
          evidenceLevel: 'structural',
          stance: 'contradicts',
          bracketState: 'CONTRADICTED',
          excerpt: `Carrier issued ACV payment of $${newInitialCheck.toLocaleString()} after withholding depreciation and deductible. Omitted general contractor overhead and profit.`,
          rawText: 'Payment represents undisputed actual cash value per initial field inspection.',
          amountAssociated: initialCheck,
          floatPoints: 12,
          mixPoints: 8,
          stirPoints: 2,
          totalPressure: 22.0,
          keyObservations: ['Omits mandatory multi-trade overhead and profit (10 & 10)'],
        },
      ],
      tensions: [
        {
          id: `ten-${Date.now()}-1`,
          category: 'Overhead & Profit (10/10)',
          title: 'Carrier Omission of GCO&P (10/10)',
          carrierPosition: 'Carrier adjuster omitted General Contractor Overhead & Profit.',
          carrierBracket: 'CONTRADICTED',
          policyholderEvidence: 'Multiple licensed trades required for repair.',
          policyholderBracket: 'VALIDATED',
          monetaryExposure: opAddition,
          severity: 'critical',
          resolutionStrategy: 'Serve formal supplemental demand package with contractor trade breakdown.',
        },
      ],
      lineItems: [
        {
          id: `li-${Date.now()}-1`,
          category: 'Roofing',
          description: 'Tear off & Replace Architectural Shingle Roof',
          unit: 'SQ',
          quantity: 32,
          carrierAllowedACV: initialCheck,
          carrierAllowedRCV: initialCheck + 4000,
          contractorBenchmarkRCV: contractorEstimate * 0.6,
          depreciationWithheld: 4000,
          isRecoverableDepreciation: true,
          overheadProfitApplies: true,
          codeUpgradeRequired: true,
          disputeReason: 'Carrier field adjuster under-scoped quantity and omitted code upgrades.',
          status: 'underpaid',
        },
      ],
      statutoryDeadlines: [
        {
          id: `dl-${Date.now()}-1`,
          title: 'Carrier 14-Day Mandatory Supplement Response Window',
          statuteCode: 'State Insurance Code Prompt Payment Provision',
          deadlineDate: new Date(Date.now() + 14 * 86400000).toISOString().split('T')[0],
          daysRemaining: 14,
          status: 'critical_pending',
          description: 'Carrier must acknowledge and act upon formal proof within 14 days.',
          penaltyForCarrierDefault: 'Statutory interest and potential bad faith civil liability.',
        },
      ],
      auditTrail: [
        {
          id: `at-${Date.now()}-1`,
          timestamp: new Date().toISOString().split('T')[0],
          action: 'Claim Case Ingested into PAi Claim Handler',
          impact: `Mapped Initial Check ($${newInitialCheck.toLocaleString()}) vs Benchmark Scope ($${newContractorEstimate.toLocaleString()}).`,
          bracketStatus: 'VALIDATED',
        },
      ],
      caseNotes: [
        {
          id: `cn-${Date.now()}-1`,
          timestamp: new Date().toISOString().split('T')[0],
          content: 'Claim ingested and audited against state building codes and multi-trade GCO&P guidelines.',
          bracket: 'VALIDATED',
          pinned: true,
          sourceRef: 'Initial Ingestion',
        },
      ],
    };

    try {
      const desktop = window.paiDesktop;
      if (desktop && desktopLocation) {
        // Read the packet into memory so the main process can copy it into
        // the case folder. Creation fails if any of this fails, so a case
        // never exists without the policy that was required to make it.
        const documents = await Promise.all(
          policyFiles.map(
            (file) =>
              new Promise<{ kind: string; filename: string; dataBase64: string }>(
                (resolve, reject) => {
                  const reader = new FileReader();
                  reader.onerror = () =>
                    reject(new Error(`Could not read ${file.name} from disk.`));
                  reader.onload = () =>
                    resolve({
                      kind: 'policy_dec',
                      filename: file.name,
                      dataBase64: String(reader.result || '').split(',')[1] || '',
                    });
                  reader.readAsDataURL(file);
                },
              ),
          ),
        );
        const result = await desktop.createClaim(
          desktopLocation,
          newClaimTitle,
          created,
          documents,
        );

        // Everything the attachment step managed to read now gets a second
        // reader. This happens after creation so a slow or absent model never
        // costs the customer the case they just paid for.
        const attachments = (result?.attachments ?? []) as Array<{
          filename: string;
          text: string;
          method: string;
          confidence: number | null;
        }>;
        const reviews = [];
        for (const attachment of attachments) {
          if (!attachment.text?.trim()) continue;
          reviews.push(
            ...(await buildPageReviews({
              evidenceId: attachment.filename,
              filename: attachment.filename,
              text: attachment.text,
              method: attachment.method,
              confidence: attachment.confidence,
            })),
          );
        }
        created.pageReviews = reviews;
      }
      setClaims([created, ...claims]);
      setActiveClaimId(created.id);
      setShowNewClaimModal(false);
      setPaymentGate(null);
      setPurchaseCode('');
      setPolicyFiles([]);
      setWizardStep('gate');
      setActiveTab('dashboard');
    } catch (error: any) {
      setClaimMessage(error?.message || 'The claim workspace could not be created.');
    } finally {
      setIsCreatingClaim(false);
    }
  };

  const handleAcquireMicrosoftCase = async () => {
    if (!paymentGate || !window.paiDesktop) return;
    setIsCreatingClaim(true);
    setClaimMessage('');
    try {
      await window.paiDesktop.acquireMicrosoftCase(paymentGate.location, newClaimTitle || 'New claim');
      // Paid. Now collect the case details and the policy packet.
      setWizardStep('form');
      setIsCreatingClaim(false);
    } catch (error: any) {
      setClaimMessage(error?.message || 'Microsoft Store could not unlock this case.');
      setIsCreatingClaim(false);
    }
  };

  const handleAcquireMicrosoftAnnual = async () => {
    if (!paymentGate || !window.paiDesktop) return;
    setIsCreatingClaim(true);
    setClaimMessage('');
    try {
      await window.paiDesktop.acquireMicrosoftAnnual(paymentGate.location, newClaimTitle || 'New claim');
      // Paid. Now collect the case details and the policy packet.
      setWizardStep('form');
      setIsCreatingClaim(false);
    } catch (error: any) {
      setClaimMessage(error?.message || 'Microsoft Store could not activate annual access.');
      setIsCreatingClaim(false);
    }
  };

  const handleRedeemPurchaseCode = async () => {
    if (!paymentGate || !window.paiDesktop) return;
    setIsCreatingClaim(true);
    setClaimMessage('');
    try {
      await window.paiDesktop.redeemPurchaseCode({
        code: purchaseCode,
        location: paymentGate.location,
        name: newClaimTitle,
        expectedProductId: paymentGate.offer.caseOffer.productId,
      });
      setWizardStep('form');
      setIsCreatingClaim(false);
    } catch (error: any) {
      setClaimMessage(error?.message || 'The support/recovery code could not be verified.');
      setIsCreatingClaim(false);
    }
  };

  if (!setupChecked) return <div className="min-h-screen bg-[#070a0f]" />;

  if (needsSetup) {
    return (
      <div className="min-h-screen bg-[#070a0f] text-slate-100 flex items-center justify-center p-6">
        <div className="w-full max-w-4xl">
          <AISetupView firstRun onDone={finishSetup} />
        </div>
      </div>
    );
  }


  // Estimation must not run over text nobody has confirmed. This is the same
  // rule as the dispute-letter gate: a figure that leaves this screen carries
  // none of the qualifications shown on it.
  const estimationReadiness = assessEstimationReadiness(activeClaim?.pageReviews ?? []);

  const EstimationBlocked = ({ what }: { what: string }) => (
    <div className="max-w-3xl mx-auto space-y-4 pb-12">
      <div className="rounded-2xl border border-amber-500/40 bg-amber-950/25 p-6 space-y-3">
        <div className="flex items-center gap-3">
          <ShieldAlert className="w-6 h-6 text-amber-400" />
          <h2 className="text-lg font-bold text-white">{what} is paused</h2>
        </div>
        <p className="text-sm text-amber-100/80">
          The document has not been read consistently yet. Estimating over text
          nobody has confirmed would put unverified figures into a number you
          may later have to defend.
        </p>
        {estimationReadiness.reasons.map((reason, i) => (
          <p key={i} className="text-xs text-slate-300">{reason}</p>
        ))}
        <button
          onClick={() => setActiveTab('evidence')}
          className="mt-1 rounded-lg border border-amber-500/50 px-3 py-1.5 text-xs font-semibold text-amber-200 hover:bg-amber-500/10"
        >
          Review the document
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-[#070a0f] text-slate-100 flex flex-col font-sans selection:bg-sky-500 selection:text-white">
      
      {/* Top Universal Header */}
      <Header
        claims={claims}
        activeClaim={activeClaim}
        onSelectClaim={(claim) => setActiveClaimId(claim.id)}
        onOpenNewClaimModal={() => {
          setWizardStep('gate');
          setPolicyFiles([]);
          setPaymentGate(null);
          setClaimMessage('');
          setShowNewClaimModal(true);
          void beginNewClaim();
        }}
        onOpenAdvisorChat={() => setIsAdvisorOpen(true)}
        onExportBrief={() => window.print()}
      />

      {/* Main Layout: Sidebar + View Content */}
      <div className="flex-1 flex flex-col lg:flex-row min-h-0">
        
        {/* Navigation Sidebar */}
        <Sidebar
          activeTab={activeTab}
          onTabChange={setActiveTab}
          activeClaim={activeClaim}
        />

        {/* Dynamic Main Workspace Container */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 bg-gradient-to-b from-[#080c14] to-[#05070a]">
          {/* Persistent across every tab for as long as inputs are missing. */}
          <AccuracyWarningBanner
            claim={activeClaim}
            onSupplyPolicy={() => setActiveTab('evidence')}
            onResolveConflict={(conflictId, value) => {
              // The user confirmed one reading against the document. Record
              // which one and when; the losing candidate stays on the record.
              setClaims((previous) =>
                previous.map((c) =>
                  c.id !== activeClaimId
                    ? c
                    : {
                        ...c,
                        policyRecord: {
                          ...c.policyRecord,
                          conflicts: (c.policyRecord.conflicts ?? []).map((cf) =>
                            cf.id === conflictId
                              ? { ...cf, resolvedValue: value, resolvedAt: new Date().toISOString() }
                              : cf,
                          ),
                        },
                      },
                ),
              );
            }}
          />
          {activeTab === 'dashboard' && (
            <DashboardView
              claim={activeClaim}
              onNavigateTab={setActiveTab}
              onOpenAdvisorChat={() => setIsAdvisorOpen(true)}
            />
          )}

          {activeTab === 'psi_estimator' && !estimationReadiness.ready && (
            <EstimationBlocked what="Estimating" />
          )}

          {activeTab === 'psi_estimator' && estimationReadiness.ready && (
            <PSiEstimatorView
              claim={activeClaim}
              onUpdateClaim={handleUpdateClaim}
              onNavigateTab={setActiveTab}
            />
          )}

          {activeTab === 'xactimate_optimizer' && !estimationReadiness.ready && (
            <EstimationBlocked what="The estimate audit" />
          )}

          {activeTab === 'xactimate_optimizer' && estimationReadiness.ready && (
            <XactimateOptimizerView
              claim={activeClaim}
              onUpdateClaim={handleUpdateClaim}
              onNavigateTab={setActiveTab}
            />
          )}

          {activeTab === 'payout_optimizer' && !estimationReadiness.ready && (
            <EstimationBlocked what="Payout analysis" />
          )}

          {activeTab === 'payout_optimizer' && estimationReadiness.ready && (
            <PayoutOptimizerView
              claim={activeClaim}
              onUpdateClaim={handleUpdateClaim}
              onNavigateTab={setActiveTab}
            />
          )}

          {activeTab === 'evidence' && (
            <EvidenceVaultView
              claim={activeClaim}
              onUpdateClaim={handleUpdateClaim}
            />
          )}

          {activeTab === 'precognitive_map' && (
            <PrecognitiveClaimMapView claim={activeClaim} />
          )}

          {activeTab === 'parliament' && (
            <ParliamentView
              claim={activeClaim}
              onNavigateTab={setActiveTab}
            />
          )}

          {activeTab === 'legal_letters' && (
            <DisputeLettersStudioView claim={activeClaim} />
          )}

          {activeTab === 'timeline' && (
            <StatutoryTimelineView
              claim={activeClaim}
              onNavigateTab={setActiveTab}
            />
          )}
          {activeTab === 'ai_setup' && <AISetupView />}
        </main>
      </div>

      {/* AI Claim Advisor Slide-out Modal */}
      <ClaimAdvisorChatModal
        isOpen={isAdvisorOpen}
        onClose={() => setIsAdvisorOpen(false)}
        claim={activeClaim}
      />

      {/* Ingest New Claim Modal */}
      {showNewClaimModal && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-xl rounded-2xl bg-slate-900 border border-slate-700 shadow-2xl p-6 space-y-5 max-h-[90vh] overflow-y-auto">
            
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Shield className="w-5 h-5 text-sky-400" />
                <h3 className="text-base font-bold text-white">Create / Audit Insurance Claim</h3>
              </div>
              <button
                onClick={() => setShowNewClaimModal(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {wizardStep === 'gate' && !paymentGate && (
              <div className="py-8 text-center text-xs text-slate-400">
                Choose a folder for this case to continue.
              </div>
            )}

            {wizardStep === 'gate' && paymentGate && (
              <div className="space-y-4 text-xs">
                <div className="rounded-xl border border-sky-700/50 bg-sky-950/30 p-4">
                  <div className="flex items-center gap-2 text-sky-200 font-bold text-sm">
                    <DollarSign className="w-4 h-4" /> Unlock this case workspace
                  </div>
                  <p className="mt-2 text-slate-300 leading-5">
                    Microsoft Store handles payment and the purchase entitlement. PAi Claims does not collect your card information. Your claim files remain in the folder you selected.
                  </p>
                  {!paymentGate.offer.store.available && (
                    <div className="mt-3 rounded-lg border border-amber-500/40 bg-amber-950/30 p-3 text-amber-200">
                      Microsoft Store commerce is not available right now: {paymentGate.offer.store.error || 'Install the Microsoft Store build and try again.'}
                    </div>
                  )}
                </div>

                <div className="grid sm:grid-cols-2 gap-3">
                  <div className="rounded-xl border border-slate-700 bg-slate-950 p-4">
                    <div className="text-white font-bold">
                      {paymentGate.offer.caseOffer.productId === 'pai-claims-first-case' ? 'First case' : 'Additional case'}
                    </div>
                    <div className="text-2xl text-emerald-300 font-bold mt-1">
                      {paymentGate.offer.caseOffer.formattedPrice || `$${paymentGate.offer.caseOffer.priceUsd}`}
                    </div>
                    <div className="text-slate-400 mt-1">Permanent access for this workspace on this installation.</div>
                    {paymentGate.offer.caseOffer.productId === 'pai-claims-first-case' && (
                      <div className="mt-2 rounded-lg border border-violet-500/40 bg-violet-950/30 p-2 text-violet-200">
                        Introductory bonus: one complimentary PAi Legal case, including the PAi Case File Creator and PSi Legal Data.
                      </div>
                    )}
                    {paymentGate.offer.caseOffer.productId === 'pai-claims-single-case' && paymentGate.offer.caseOffer.balance > 0 && (
                      <div className="mt-2 text-emerald-200">Microsoft Store case credits available: {paymentGate.offer.caseOffer.balance}</div>
                    )}
                    <button
                      disabled={isCreatingClaim || !paymentGate.offer.store.available}
                      onClick={() => void handleAcquireMicrosoftCase()}
                      className="mt-3 w-full px-3 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white font-bold"
                    >
                      {isCreatingClaim ? 'Working with Microsoft Store…'
                        : paymentGate.offer.caseOffer.productId === 'pai-claims-first-case' && paymentGate.offer.caseOffer.owned
                          ? 'Use my purchased first case'
                          : paymentGate.offer.caseOffer.productId === 'pai-claims-single-case' && paymentGate.offer.caseOffer.balance > 0
                            ? 'Use 1 Microsoft case credit'
                            : 'Buy with Microsoft Store'}
                    </button>
                  </div>

                  <div className="rounded-xl border border-slate-700 bg-slate-950 p-4">
                    <div className="text-white font-bold">Annual access</div>
                    <div className="text-2xl text-sky-300 font-bold mt-1">
                      {paymentGate.offer.annualOffer.formattedPrice || `$${paymentGate.offer.annualOffer.priceUsd.toLocaleString()} / year`}
                    </div>
                    <div className="text-slate-300 mt-2">Use PAi Claims across opened cases while the Microsoft subscription is active.</div>
                    <div className="text-slate-400 mt-1">Expired cases stay viewable in read-only mode.</div>
                    <button
                      disabled={isCreatingClaim || !paymentGate.offer.store.available}
                      onClick={() => void handleAcquireMicrosoftAnnual()}
                      className="mt-3 w-full px-3 py-2 rounded-lg bg-sky-600 hover:bg-sky-500 disabled:opacity-40 text-white font-bold"
                    >
                      {isCreatingClaim ? 'Working with Microsoft Store…' : 'Buy annual access with Microsoft Store'}
                    </button>
                  </div>
                </div>

                <div className="flex justify-start pt-1">
                  <button onClick={() => { setPaymentGate(null); setClaimMessage(''); }} className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium">
                    Choose another folder
                  </button>
                </div>

                <details className="rounded-xl border border-slate-800 bg-slate-950/60 p-3">
                  <summary className="cursor-pointer text-slate-500 hover:text-slate-300 select-none">Support / recovery code</summary>
                  <div className="mt-3 space-y-3">
                    <p className="text-slate-500">Use this only if PAi support issued a recovery code. Normal customer purchases are handled by Microsoft Store.</p>
                    <input
                      type="text"
                      autoComplete="off"
                      placeholder="PAI-1234-5678"
                      value={purchaseCode}
                      onChange={(e) => setPurchaseCode(e.target.value.toUpperCase())}
                      className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white font-mono tracking-wider focus:outline-none focus:border-sky-500"
                    />
                    <button
                      disabled={isCreatingClaim || purchaseCode.trim().length < 8}
                      onClick={() => void handleRedeemPurchaseCode()}
                      className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-300 font-bold"
                    >
                      Redeem recovery code
                    </button>
                  </div>
                </details>
              </div>
            )}

            <div className={`space-y-4 text-xs ${wizardStep === 'form' ? '' : 'hidden'}`}>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 mb-1 font-medium">Policyholder Full Name</label>
                  <input
                    type="text"
                    placeholder="e.g. John & Sarah Reynolds"
                    value={newPolicyholder}
                    onChange={(e) => {
                      setNewPolicyholder(e.target.value);
                      if (!newClaimTitle) setNewClaimTitle(`${e.target.value} - Roof Damage Claim`);
                    }}
                    className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 focus:outline-none focus:border-sky-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 mb-1 font-medium">Insurance Carrier Name</label>
                  <input
                    type="text"
                    placeholder="e.g. State Farm, Allstate, Citizens"
                    value={newCarrierName}
                    onChange={(e) => setNewCarrierName(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 focus:outline-none focus:border-sky-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 mb-1 font-medium">Claim # (or Pending)</label>
                  <input
                    type="text"
                    placeholder="e.g. CLM-892401"
                    value={newClaimNumber}
                    onChange={(e) => setNewClaimNumber(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 focus:outline-none focus:border-sky-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 mb-1 font-medium">Peril / Damage Type</label>
                  <select
                    value={newPeril}
                    onChange={(e) => setNewPeril(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 focus:outline-none focus:border-sky-500"
                  >
                    <option value="hurricane">Hurricane / Severe Windstorm</option>
                    <option value="wind_hail">Hailstorm & Tornado</option>
                    <option value="water_pipe">Plumbing / Pipe Burst Water Loss</option>
                    <option value="fire_smoke">Fire & Smoke Damage</option>
                    <option value="freeze_collapse">Freeze & Collapse Loss</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-300 mb-1 font-medium">Insured Property Address</label>
                <input
                  type="text"
                  placeholder="e.g. 742 Evergreen Terrace, Orlando, FL"
                  value={newPropertyAddress}
                  onChange={(e) => setNewPropertyAddress(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 focus:outline-none focus:border-sky-500"
                />
              </div>

              {/* Policy packet — required before a case can be created */}
              <div className="p-4 rounded-xl bg-slate-950 border border-amber-600/40 space-y-2">
                <span className="text-[11px] font-mono uppercase text-amber-400 font-bold block">
                  Policy packet — required
                </span>
                <p className="text-[11px] text-slate-400">
                  The complete policy as issued: declarations page plus all forms
                  and endorsements. Usually 30&ndash;60 pages. Without it, coverage
                  limits, deductible basis, sublimits and deadlines are unknown and
                  no figure on this case can be checked against the policy.
                </p>
                <input
                  type="file"
                  multiple
                  accept=".pdf,.png,.jpg,.jpeg,.tif,.tiff"
                  onChange={(e) =>
                    setPolicyFiles(Array.from((e.target as HTMLInputElement).files || []))
                  }
                  className="w-full text-xs text-slate-300 file:mr-3 file:rounded-lg file:border-0 file:bg-sky-600 file:px-3 file:py-1.5 file:text-xs file:font-semibold file:text-white hover:file:bg-sky-500"
                />
                {policyFiles.length > 0 ? (
                  <div className="text-[11px] text-emerald-300">
                    {policyFiles.length} file{policyFiles.length === 1 ? '' : 's'} attached:{' '}
                    {policyFiles.map((f) => f.name).join(', ')}
                  </div>
                ) : (
                  <div className="text-[11px] text-amber-300">
                    No policy attached. The case cannot be created until it is.
                  </div>
                )}
              </div>

              {/* Financial Snapshot */}
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
                <span className="text-[11px] font-mono uppercase text-sky-400 font-bold block">
                  Financial Valuation Benchmarks
                </span>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-400 text-[11px] mb-1">Dwelling Policy Limit ($)</label>
                    <input
                      type="number"
                      value={newDwellingLimit ?? ''}
                      placeholder="not supplied"
                      onChange={(e) => setNewDwellingLimit(e.target.value === '' ? null : Number(e.target.value))}
                      className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-white font-mono focus:outline-none focus:border-sky-500"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-400 text-[11px] mb-1">Policy Deductible ($)</label>
                    <input
                      type="number"
                      value={newDeductible ?? ''}
                      placeholder="not supplied"
                      onChange={(e) => setNewDeductible(e.target.value === '' ? null : Number(e.target.value))}
                      className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-white font-mono focus:outline-none focus:border-sky-500"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-400 text-[11px] mb-1">Initial Check Issued ($)</label>
                    <input
                      type="number"
                      value={newInitialCheck ?? ''}
                      placeholder="not supplied"
                      onChange={(e) => setNewInitialCheck(e.target.value === '' ? null : Number(e.target.value))}
                      className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-rose-300 font-mono focus:outline-none focus:border-sky-500"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-400 text-[11px] mb-1">Contractor Benchmark RCV ($)</label>
                    <input
                      type="number"
                      value={newContractorEstimate ?? ''}
                      placeholder="not supplied"
                      onChange={(e) => setNewContractorEstimate(e.target.value === '' ? null : Number(e.target.value))}
                      className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-emerald-400 font-mono font-bold focus:outline-none focus:border-sky-500"
                    />
                  </div>
                </div>
              </div>

            </div>

            {claimMessage && <div className="rounded-lg border border-rose-700/50 bg-rose-950/30 px-3 py-2 text-xs text-rose-200">{claimMessage}</div>}

            <div className={`items-center justify-end gap-3 pt-3 border-t border-slate-800 ${wizardStep === 'form' ? 'flex' : 'hidden'}`}>
              {policyFiles.length === 0 && (
                <span className="mr-auto text-[11px] text-amber-300">
                  Attach the policy packet to continue.
                </span>
              )}
              <button
                onClick={() => setShowNewClaimModal(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium"
              >
                Cancel
              </button>
              <button
                onClick={() => void handleCreateNewClaim()}
                disabled={
                  isCreatingClaim ||
                  policyFiles.length === 0 ||
                  !newClaimTitle.trim() ||
                  !newPolicyholder.trim()
                }
                className="px-5 py-2 rounded-xl bg-sky-500 hover:bg-sky-400 disabled:opacity-40 disabled:cursor-not-allowed text-white text-xs font-bold shadow-md shadow-sky-500/20"
              >
                {isCreatingClaim ? 'Creating…' : 'Create case'}
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
