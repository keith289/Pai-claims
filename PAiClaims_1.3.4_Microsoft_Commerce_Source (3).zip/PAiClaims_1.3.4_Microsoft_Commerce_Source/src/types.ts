import type { PolicyRecord } from './domain/policyRecord.ts';
import type { ReconciliationResult } from './domain/transcriptReview.ts';

export type EpistemicBracket = 'UNVERIFIED' | 'SPECULATIVE' | 'EXPLAINED' | 'VALIDATED' | 'CONTRADICTED';

export type EvidenceLevel = 'raw' | 'structural' | 'direct';
export type Stance = 'supports' | 'contradicts' | 'context';

export type RPMChannel = 'matter_k66' | 'relation_k90' | 'chronology_k120';

export interface ObservationPoint {
  id: string;
  kind: 'CLAIM' | 'POLICY_CLAUSE' | 'DAMAGE_MEASURE' | 'STATUTORY_DUTY' | 'DENIAL_BASIS' | 'LINE_ITEM' | 'OBS';
  value: string;
  weight: number;
  channel: RPMChannel;
  provenance: string;
}

export interface RelationalMix {
  id: string;
  fromKind: string;
  fromValue: string;
  toKind: string;
  toValue: string;
  channel: RPMChannel;
  strength: number;
}

export interface RecurrenceStir {
  id: string;
  pattern: string;
  occurrences: number;
  isBadFaithIndicator?: boolean;
}

export interface CasePhotoItem {
  id: string;
  title: string;
  category:
    | 'Roof & Slopes'
    | 'Attic & Sheathing'
    | 'Interior & Ceilings'
    | 'Water Line & Moisture'
    | 'Exterior Elevations'
    | 'HVAC & Electrical'
    | 'Contents & Personal Property'
    | 'Code & Municipal';
  url?: string;
  thumbnail?: string;
  dateTaken: string;
  caption: string;
  damageTags: string[];
  source: string;
  cameraAngle?: string;
  aiDetectedGaps?: string[];
  isVerified: boolean;
  gpsLocation?: string;
  elevation?: string;
  /** Backing evidence record used by the atomic claim graph. */
  evidenceId?: string;
  /** In-memory preview used for user-initiated vision analysis. */
  dataUrl?: string;
  contentHash?: string;
}


export type ClaimCostKind =
  | 'material'
  | 'labor'
  | 'equipment'
  | 'disposal'
  | 'permit'
  | 'tax'
  | 'overhead_profit'
  | 'mobilization'
  | 'protection'
  | 'other'
  | 'contingency';

export type ClaimCostSource =
  | 'photo_ai'
  | 'llm_fallback'
  | 'lowes_partner_api'
  | 'lowes_store_feed'
  | 'lowes_quote'
  | 'supplier_quote'
  | 'invoice'
  | 'xactimate_direct'
  | 'xactimate_derived'
  | 'regional_factor'
  | 'manual'
  | 'payment';

export interface DamageCostComponent {
  id: string;
  kind: ClaimCostKind;
  label: string;
  amount: number;
  reason: string;
  bracket: EpistemicBracket;
  sourceMethod: ClaimCostSource;
  sourceEvidenceIds?: string[];
  unitPrice?: number;
  quantity?: number;
  unit?: string;
  workerHours?: number;
  laborRate?: number;
  regionalDifferencePct?: number;
  supersedesComponentId?: string;
}

export interface DamageRepairOperation {
  id: string;
  trade: string;
  description: string;
  quantity: number;
  unit: string;
  materialSearchTerms: string[];
  laborHours: number;
  /** Kept for backward compatibility; new code uses costComponents. */
  equipmentAndDisposal: number;
  /** Every included dollar has its own reason and bracket. */
  costComponents?: DamageCostComponent[];
}

export interface DamageInventoryItem {
  id: string;
  statement: string;
  component: string;
  location: string;
  damageType: string;
  likelyCause: string;
  extent: string;
  photoEvidenceIds: string[];
  imageRegions: Array<{ evidenceId: string; label: string; x: number; y: number; width: number; height: number }>;
  duplicateGroup?: string;
  damageBracket: EpistemicBracket;
  repairOperations: DamageRepairOperation[];
  valuation?: {
    amount: number;
    currency: 'USD';
    assumptions: string[];
    bracket: EpistemicBracket;
    pricedAt: string;
    pricingBasis: string;
  };
  pass2Valuation?: {
    baseAmount: number;
    contingencyPct: number;
    contingencyAmount: number;
    amount: number;
    bracket: EpistemicBracket;
    pricedAt: string;
    pricingBasis: string;
  };
  carrierResolution?: {
    status: 'accepted' | 'corrected' | 'omitted';
    amount: number;
    sourceEvidenceId: string;
    sourcePage?: number;
    resolvedAt: string;
  };
}

export type ClaimGraphNodeKind =
  | 'damage' | 'cause' | 'location' | 'extent' | 'repair_operation' | 'quantity'
  | 'material' | 'labor' | 'equipment' | 'disposal' | 'permit' | 'tax'
  | 'overhead_profit' | 'price' | 'reason' | 'policy' | 'authority'
  | 'timeline' | 'carrier_position' | 'payment' | 'other';

export type ClaimGraphEdgeKind =
  | 'supports' | 'contradicts' | 'causes' | 'located_at' | 'requires'
  | 'measured_by' | 'quantified_as' | 'priced_by' | 'reason_for'
  | 'confirmed_by' | 'corrected_by' | 'supersedes' | 'paid_by' | 'related_to';

export interface ClaimGraphHistoryEvent {
  id: string;
  at: string;
  action: 'created' | 'promoted' | 'corrected' | 'contradicted' | 'superseded' | 'paid';
  fromBracket?: EpistemicBracket;
  toBracket: EpistemicBracket;
  sourceEvidenceId?: string;
  provenanceRoot?: string;
  reason: string;
  previousValue?: string | number;
  nextValue?: string | number;
}

export interface ClaimGraphNode {
  id: string;
  kind: ClaimGraphNodeKind;
  statement: string;
  bracket: EpistemicBracket;
  channel: RPMChannel;
  value?: string | number;
  unit?: string;
  amount?: number;
  currency?: 'USD';
  reason: string;
  sourceEvidenceIds: string[];
  provenanceRoots: string[];
  createdAt: string;
  updatedAt: string;
  history: ClaimGraphHistoryEvent[];
  damageInventoryId?: string;
  repairOperationId?: string;
  lineItemId?: string;
  carrierLineItemId?: string;
  costComponentId?: string;
  metadata?: Record<string, string | number | boolean | null>;
}

export interface ClaimGraphEdge {
  id: string;
  fromNodeId: string;
  toNodeId: string;
  kind: ClaimGraphEdgeKind;
  bracket: EpistemicBracket;
  reason: string;
  sourceEvidenceIds: string[];
  provenanceRoots: string[];
  createdAt: string;
  updatedAt: string;
  history: ClaimGraphHistoryEvent[];
}

export interface ClaimGraph {
  version: 1;
  nodes: ClaimGraphNode[];
  edges: ClaimGraphEdge[];
  rebuiltAt: string;
}

export interface MonetaryTruth {
  id: string;
  kind: 'submitted' | 'offered' | 'approved' | 'issued' | 'received' | 'withheld' | 'remaining';
  statement: string;
  amount: number;
  bracket: EpistemicBracket;
  evidenceIds: string[];
  recordedAt: string;
  damageInventoryId?: string;
  repairOperationId?: string;
  lineItemId?: string;
  /** True only when this received payment finally resolves the linked monetary item. Partial payments remain validated events but do not close the linked PSi price proposition. */
  finalForLinkedItem?: boolean;
}

export interface MissingEvidenceChecklistItem {
  id: string;
  category:
    | 'Photographic Proof'
    | 'Policy & Endorsements'
    | 'Engineering & Causation'
    | 'Weather & NOAA Data'
    | 'Contractor Benchmark / Xactimate'
    | 'Code & Ordinance (Law)'
    | 'Mitigation & Living Expenses (ALE)';
  itemTitle: string;
  urgency: 'critical' | 'high' | 'medium';
  whyNeeded: string;
  carrierTrapToAvoid: string;
  suggestedAction: string;
  questionPrompt: string;
  quickAnswers: string[];
  actionType: 'upload_doc' | 'upload_photo' | 'generate_letter' | 'confirm_fact';
  isResolved: boolean;
  userResponse?: string;
  attachedDocId?: string;
  attachedPhotoId?: string;
}

export interface ProactiveQuestionItem {
  id: string;
  question: string;
  context: string;
  pillar: string;
  impactOnSettlement: string;
  options: Array<{
    label: string;
    value: string;
    triggersRecommendation?: string;
    suggestedDocOrPhoto?: string;
  }>;
  answered?: boolean;
  selectedAnswer?: string;
}

export interface CaseCompletenessAudit {
  overallScore: number; // 0 - 100
  completenessStatus: 'CRITICAL_GAPS' | 'MODERATE_GAPS' | 'READY_FOR_DEMAND' | 'BULLETPROOF';
  readinessForAppraisalOrDemand: number;
  totalDocumentsLoaded: number;
  totalPhotosLoaded: number;
  pillars: Array<{
    name: string;
    status: 'complete' | 'partial' | 'missing';
    score: number;
    description: string;
    presentItems: string[];
    missingItems: string[];
  }>;
  missingChecklist: MissingEvidenceChecklistItem[];
  proactiveQuestions: ProactiveQuestionItem[];
  expertRecommendations: string[];
}

export interface EvidenceItem {
  id: string;
  title: string;
  type: 'policy_dec' | 'carrier_estimate' | 'contractor_estimate' | 'denial_letter' | 'proof_of_loss' | 'engineer_report' | 'photo_log' | 'receipts_ale' | 'weather_data' | 'communication';
  filename: string;
  date: string;
  source: string;
  provenanceRoot: string;
  evidenceLevel: EvidenceLevel;
  stance: Stance;
  bracketState: EpistemicBracket;
  compromised?: boolean;
  /** SHA-256 or equivalent content identity when available. Duplicate hashes do not create independent evidence roots. */
  contentHash?: string;
  assertionIds?: string[];
  excerpt: string;
  rawText: string;
  amountAssociated?: number;
  floatPoints: number;
  mixPoints: number;
  stirPoints: number;
  totalPressure: number;
  keyObservations: string[];
}

export interface LineItemDispute {
  id: string;
  category: 'Roofing' | 'Drywall & Framing' | 'Water Mitigation' | 'Electrical & HVAC' | 'Flooring' | 'Paint & Finishes' | 'Ordinance & Law' | 'General Conditions / O&P' | 'Contents / ALE';
  description: string;
  unit: string;
  quantity: number;
  carrierAllowedACV: number;
  carrierAllowedRCV: number;
  contractorBenchmarkRCV: number;
  depreciationWithheld: number;
  isRecoverableDepreciation: boolean;
  overheadProfitApplies: boolean;
  codeUpgradeRequired: boolean;
  disputeReason: string;
  policyEndorsementRef?: string;
  status: 'omitted_by_carrier' | 'underpaid' | 'depreciation_disputed' | 'settled' | 'valid_carrier_allowance';
  /** PSi deterministic/source-traced calculation metadata. AI must not mutate these values. */
  psi?: PsiLineMetadata;
}

export interface ClaimTension {
  id: string;
  title: string;
  category: 'Scope & Quantity' | 'Wear-and-Tear Defense' | 'Overhead & Profit (10/10)' | 'Code Upgrades' | 'Depreciation Schedule' | 'Statutory Bad Faith';
  carrierPosition: string;
  carrierBracket: EpistemicBracket;
  policyholderEvidence: string;
  policyholderBracket: EpistemicBracket;
  monetaryExposure: number;
  severity: 'critical' | 'high' | 'moderate';
  resolutionStrategy: string;
}

export interface StatutoryDeadline {
  id: string;
  title: string;
  statuteCode: string;
  deadlineDate: string;
  daysRemaining: number;
  status: 'passed' | 'critical_pending' | 'on_track' | 'carrier_defaulted';
  description: string;
  penaltyForCarrierDefault: string;
}

/**
 * Legacy flat limits. Retained so existing views keep compiling.
 * A value of 0 here means "not read from a policy document" — it does NOT
 * mean the policy states zero. Read `policyRecord` for the bracketed truth.
 * @deprecated Use InsuranceClaim.policyRecord.
 */
export interface PolicyCoverageLimits {
  dwelling_covA: number;
  otherStructures_covB: number;
  personalProperty_covC: number;
  lossOfUse_covD: number;
  ordinanceAndLaw_percent: number; // e.g. 10%, 25%, 50%
  ordinanceAndLaw_amount: number;
  moldRemediationLimit: number;
  debrisRemovalPercent: number; // e.g. 5% additional
  deductible: number;
  deductibleType: 'flat_dollar' | 'percentage_named_storm';
}

export interface InsuranceClaim {
  id: string;
  claimNumber: string;
  policyNumber: string;
  policyholderName: string;
  carrierName: string;
  assignedAdjuster?: string;
  policyType: 'homeowners_ho3' | 'homeowners_ho5' | 'commercial_property' | 'auto_collision' | 'renters_ho4' | 'business_interruption';
  dateOfLoss: string;
  dateReported: string;
  peril: 'wind_hail' | 'water_pipe' | 'hurricane' | 'fire_smoke' | 'theft' | 'freeze_collapse';
  propertyAddress: string;
  status: 'intake' | 'carrier_lowball' | 'denial_rebuttal' | 'appraisal_demanded' | 'settled_maximized';
  jurisdictionState?: string;
  actualAuthorities?: Array<{ citation: string; title: string; effectiveDate?: string; sourceEvidenceId?: string }>;
  
  /** @deprecated Display-only mirror. Authoritative terms live in policyRecord. */
  policyLimits: PolicyCoverageLimits;

  /**
   * Policy terms as bracketed facts with provenance. Every term defaults to
   * UNVERIFIED until it is read from a supplied policy document.
   */
  policyRecord: PolicyRecord;

  /**
   * Intake fields the user left blank, in plain language. Drives the
   * persistent accuracy warning. Empty means every intake field was supplied.
   */
  intakeGaps: string[];

  /**
   * Per-page reconciliation of every reader that saw each document. Drives the
   * transcript review panel and the estimation gate.
   */
  pageReviews: ReconciliationResult[];
  
  carrierOffer: {
    initialOfferACV: number;
    initialOfferRCV: number;
    depreciationWithheld: number;
    deductibleDeducted: number;
    netCarrierCheckIssued: number;
    carrierSummary: string;
  };
  
  auditedTrueValuation: {
    contractorRCV: number;
    contractorACV: number;
    recoverableDepreciation: number;
    eligibleCodeUpgrades: number;
    eligibleOverheadAndProfit: number; // General Contractor 10 & 10
    eligibleALE: number;
    trueGrossRecovery: number;
    netPayoutOwed: number;
    totalRecoveryGap: number; // trueGrossRecovery - initialCarrierCheck
    /** Weakest bracket among the policy terms this valuation depended on. */
    bracket: EpistemicBracket;
    /** Policy terms that could not be read, and what that cost the result. */
    unreadTerms: string[];
  };

  evidence: EvidenceItem[];
  photos?: CasePhotoItem[];
  /** Photo-first atomic repair propositions and their evolving estimate state. */
  damageInventory?: DamageInventoryItem[];
  claimGraph?: ClaimGraph;
  monetaryTruths?: MonetaryTruth[];
  /** Most recently imported carrier/Xactimate estimate; original values remain unchanged. */
  carrierAudit?: XactimateAuditResult;
  completenessAudit?: CaseCompletenessAudit;
  lineItems: LineItemDispute[];
  tensions: ClaimTension[];
  statutoryDeadlines: StatutoryDeadline[];

  /** PSi estimator pricing evidence kept separately from carrier values. */
  pricingModel?: {
    lowesStoreId?: string;
    zipCode?: string;
    contractorRateObservations: ContractorRateObservation[];
    estimateSnapshots?: PsiEstimateSnapshot[];
    latestMaterialSources?: LowesMaterialPrice[];
    regionalMaterialDifferencePct?: number;
    regionalLaborDifferencePct?: number;
    contingencyPct?: number;
  };
  
  auditTrail: Array<{
    id: string;
    timestamp: string;
    action: string;
    impact: string;
    bracketStatus: EpistemicBracket;
  }>;
  
  caseNotes: Array<{
    id: string;
    timestamp: string;
    content: string;
    bracket: EpistemicBracket;
    pinned: boolean;
    sourceRef?: string;
  }>;
}

export type TabType =
  | 'ai_setup'
  | 'dashboard'
  | 'psi_estimator'
  | 'xactimate_optimizer'
  | 'payout_optimizer'
  | 'evidence'
  | 'precognitive_map'
  | 'parliament'
  | 'legal_letters'
  | 'timeline';

export interface XactimateLineItem {
  id: string;
  xactCode: string;
  category: string;
  description: string;
  unit: string;
  carrierQuantity: number;
  carrierUnitPrice: number;
  carrierTotal: number;
  contractorQuantity: number;
  contractorUnitPrice: number;
  contractorTotal: number;
  gapAmount: number;
  status:
    | 'completely_missing'
    | 'shorted_quantity'
    | 'lowballed_pricing'
    | 'unjustified_depreciation'
    | 'omitted_code_upgrade'
    | 'omitted_gcop'
    | 'carrier_imported';
  reason: string;
  codeCitation?: string;
  tradeCategory:
    | 'Roofing'
    | 'Drywall & Ceiling'
    | 'Water Mitigation'
    | 'Paint & Finishes'
    | 'Flooring'
    | 'HVAC & Electrical'
    | 'General Contractor O&P (10/10)'
    | 'Code Upgrades & Permits'
    | 'Contents & Protection';
  selected: boolean;
  epistemicBracket: EpistemicBracket;
  originalPage?: number;
  carrierRCV?: number;
  depreciation?: number;
  carrierACV?: number;
  tax?: number;
  overheadAndProfit?: number;
  /** Labor decomposition when supplied/extracted from the carrier estimate. */
  workerHours?: number;
  laborRate?: number;
  laborAmount?: number;
  materialAmount?: number;
  equipmentAmount?: number;
  sourceHash?: string;
}

export interface XactimateAuditResult {
  carrierName: string;
  claimNumber: string;
  carrierXactimateTotal: number;
  optimizedContractorTotal: number;
  totalOmittedValue: number;
  omittedCount: number;
  multiTradeGCOPQualified: boolean;
  gcopValue: number;
  codeUpgradesTotal: number;
  identifiedTrades: string[];
  items: XactimateLineItem[];
  summaryNotes: string;
  auditScore: number;
  rebuttalArguments: string[];
}

export type ParliamentPerspective = 'advocate' | 'opposition' | 'precedent' | 'forecaster' | 'recorder' | 'settlement';

export interface ParliamentAnalysisResult {
  perspective: ParliamentPerspective;
  title: string;
  coreFindingBracket: EpistemicBracket;
  structuralForecast: string;
  keyLeveragePoints: string[];
  vulnerabilities: string[];
  recommendedAction: string;
  confidenceScore: number;
  matterWeight_k66: number;
  relationWeight_k90: number;
  chronologyWeight_k120: number;
}


/** ---------------- PSi Estimators: deterministic insurance reconstruction layer ---------------- */
export type TradeCategory =
  | 'Roofing'
  | 'Drywall & Framing'
  | 'Paint & Finishes'
  | 'Flooring'
  | 'Siding'
  | 'Framing'
  | 'Insulation'
  | 'Plumbing'
  | 'Electrical & HVAC'
  | 'Water Mitigation';

export type PriceSourceMethod =
  | 'lowes_partner_api'
  | 'lowes_store_feed'
  | 'lowes_quote'
  | 'supplier_quote'
  | 'invoice'
  | 'manual'
  | 'llm_speculation'
  | 'xactimate_derived';

export interface LowesMaterialPrice {
  productId: string;
  description: string;
  storeId: string;
  zipCode: string;
  sellingPrice: number;
  fetchedAt: string;
  sourceUrl: string;
  sourceMethod: PriceSourceMethod;
  sourceEvidenceId?: string;
  stock?: number | string;
  /** Number of retail packages/units purchased. */
  purchaseUnits: number;
  /** Repair quantity covered by one retail package, when known. */
  packageCoverage?: number;
  packageCoverageUnit?: string;
  packageDescription?: string;
  sourceHash?: string;
  bracket?: EpistemicBracket;
  priceReason?: string;
  regionalDifferencePct?: number;
}

export interface ContractorRateObservation {
  id: string;
  trade: TradeCategory;
  /** Current local materials for the same supported scope. */
  lowesMaterialSubtotal: number;
  /** Contractor direct repair cost for the same scope, excluding policy payments and claim conclusions. */
  contractorDirectCost: number;
  evidenceId: string;
  observedAt: string;
}

export interface PsiLineMetadata {
  materialUnitCost: number;
  laborUnitCost: number;
  equipmentCost: number;
  disposalCost: number;
  taxRate: number;
  region: string;
  priceDate: string;
  pricingSource: string;
  damageEvidenceIds: string[];
  lowesMaterialSources?: LowesMaterialPrice[];
  contractorAdjustmentPercent?: number;
  contractorAdjustmentBasis?: 'claim_median' | 'documented_rate' | 'none';
  contractorObservationIds?: string[];
}

export interface TradeEstimateResult {
  status: 'SUPPORTED' | 'REQUIRES_DATA';
  trade: TradeCategory;
  measuredQuantity: number;
  measuredUnit: string;
  materialSubtotal: number;
  contractorAdjustmentPercent: number | null;
  contractorAdjustmentAmount: number;
  materialTax: number;
  documentedTradeCost: number;
  missingInputs: string[];
  materialSources: LowesMaterialPrice[];
  observationIds: string[];
}

export interface PsiEstimateSnapshot {
  id: string;
  trade: TradeCategory;
  createdAt: string;
  status: 'SUPPORTED' | 'REQUIRES_DATA';
  measuredQuantity: number;
  measuredUnit: string;
  materialSubtotal: number;
  contractorAdjustmentPercent: number | null;
  contractorAdjustmentAmount: number;
  materialTax: number;
  documentedTradeCost: number;
  damageEvidenceIds: string[];
  materialSources: LowesMaterialPrice[];
  contractorObservationIds: string[];
  measurements?: Record<string, number | string | boolean>;
  stage?: 'initial_photo' | 'regional_pass2' | 'carrier_compared' | 'final_paid';
  bracket?: EpistemicBracket;
  baseCost?: number;
  contingencyPct?: number;
  contingencyAmount?: number;
  reason?: string;
}
