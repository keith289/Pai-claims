<#
  Post-build check for a Store submission.

  electron-builder does not fail when an extraResources entry is missing --
  it logs one line and produces a package anyway. A build that quietly omits
  the commerce bridge or the local AI runtime installs fine and is broken for
  the customer, so the package itself is checked rather than the build log.
#>
param(
  [string]$Version = "1.3.4"
)
$ErrorActionPreference = "Stop"

$appx = Join-Path $PSScriptRoot "release\PAiClaims-$Version-x64.appx"
if (-not (Test-Path $appx)) { throw "No package at $appx" }

$check = Join-Path $PSScriptRoot "release\_check"
if (Test-Path $check) { Remove-Item $check -Recurse -Force }
$zip = [System.IO.Path]::ChangeExtension($appx, ".zip")
Copy-Item $appx $zip -Force
Expand-Archive $zip -DestinationPath $check -Force
Remove-Item $zip -Force

$failures = @()
function Require($relative, $why) {
  $path = Join-Path $check $relative
  if (Test-Path $path) {
    "PASS  {0}" -f $relative
  } else {
    $script:failures += "$relative -- $why"
    "FAIL  {0}" -f $relative
  }
}

"=== required payload ==="
Require "app\resources\storebridge\PAiClaims.StoreBridge.exe" "no commerce bridge: the app cannot take payment"
Require "app\resources\runtime\llama-server.exe"              "no local AI runtime: local provider tells the user to reinstall"
Require "app\resources\app.asar"                               "no application payload"
Require "AppxManifest.xml"                                       "no manifest"

"`n=== must NOT be present ==="
$junk = Get-ChildItem $check -Recurse -Include esbuild.exe, *.node -ErrorAction SilentlyContinue
if ($junk) {
  $junk | ForEach-Object { $failures += "$($_.Name) -- build tooling in a customer package" }
  $junk | Select-Object Name, @{n="MB";e={[math]::Round($_.Length/1MB,1)}}
} else {
  "PASS  no build tooling"
}

"`n=== manifest ==="
Select-String -Path (Join-Path $check "AppxManifest.xml") -Pattern 'Version=|Identity Name|Publisher=|DisplayName' |
  ForEach-Object { $_.Line.Trim() }

"`n=== size ==="
"{0:N0} MB" -f ((Get-Item $appx).Length / 1MB)

Remove-Item $check -Recurse -Force
if ($failures.Count) {
  "`nDO NOT SUBMIT:"
  $failures | ForEach-Object { "  - $_" }
  exit 1
}
"`nPackage looks complete."
