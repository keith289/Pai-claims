$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

if (-not (Test-Path ".\node_modules")) {
    Write-Host "Installing project dependencies..." -ForegroundColor Cyan
    npm install
}

Write-Host "Running PSi deterministic tests..." -ForegroundColor Cyan
npm run test:psi

Write-Host "Running TypeScript check..." -ForegroundColor Cyan
npm run lint

Write-Host "Starting PAi Claims 1.2.0 — photo-to-paid claim flow..." -ForegroundColor Green
npm run electron:dev
