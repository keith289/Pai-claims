// Legacy entrypoint kept for compatibility. The canonical desktop main process
// lives in electron/main.cjs and is the file referenced by package.json.
require('./electron/main.cjs');
