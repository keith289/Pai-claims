# PAi Claims AI installer fix

## Confirmed root causes

1. `AISetupView.tsx` and `App.tsx` hard-coded `http://127.0.0.1:3100`.
   The packaged Electron app deliberately chooses a random free loopback port, so the
   local-model status and recommendation requests were sent to the wrong port.

2. The production SPA wildcard (`app.get('*')`) was registered before the local-AI GET
   routes. Requests such as `/api/ai/local/status` and `/api/ai/local/recommend` could
   receive `index.html` instead of JSON.

3. The active Electron files are `electron/main.cjs` and `electron/preload.cjs`, but the
   newer multi-provider AI handlers existed only in unused root copies
   (`electron-main.cjs` / `electron-preload.cjs`). The packaged app therefore had no
   `getAIConfig`, `setAIConfig`, or `machineInfo` bridge.

4. The packaged main process did not configure `LLAMA_BIN_DIR` / `LLAMA_MODELS_DIR` for
   the bundled llama.cpp runtime, so local runtime discovery could point at the wrong
   location.

5. The model-download SSE route used `req.on('close')` as its cancellation signal. On
   modern Node versions that can fire when the request side completes, causing a long
   download to be treated as aborted. It now uses request abort / response close logic.

6. First-run setup was permanently suppressed by `localStorage` after "Skip for now".
   It now checks the real backend state at each launch and shows the chooser whenever no
   AI provider is actually usable.

7. In `electron:dev`, Electron and Express are separate processes. Saving a key through
   IPC did not update the server process. A loopback `/api/ai/config` runtime route now
   applies the current selection to the running server as well as persisting it in the
   desktop settings.

8. Local-provider configuration could inherit a stale cloud base URL. Local now uses
   `LLAMA_BASE_URL` only after llama.cpp has actually started.

## Expected first-run behavior after patch

- Launch PAi Claims.
- If no working AI is configured, the AI Setup screen appears.
- Choose **Private — on this device** or **Use an API key**.
- Private mode shows machine RAM/CPU, model choices, download progress, installed model,
  and Start/Stop controls.
- API mode saves/tests the selected provider.
- Once a local runtime is running or a cloud provider is active, the bottom action reads
  **Continue to PAi Claims**.
- The rest of the deterministic app still works if the user skips AI for the current
  session.

## Validation completed here

- `npm run lint` / `tsc --noEmit`: PASS
- `node --check electron/main.cjs`: PASS
- `node --check electron/preload.cjs`: PASS

A complete Vite build could not be run in the Linux inspection container because the
uploaded `node_modules` is a Windows installation and does not contain Rollup's Linux
native optional package. Build again on the original Windows development machine after
applying the patch.
