# PAi Claims 1.3.1 — Microsoft Store Commerce

## What changed

PAi Claims 1.3.1 moves normal customer purchases from PAi purchase codes to Microsoft Store add-ons. The existing code verifier remains available only under the collapsed **Support / recovery code** section.

The app discovers Microsoft-generated Store IDs at runtime by matching the Partner Center Product ID exposed as `InAppOfferToken`. No generated Store IDs are hard-coded. The first-case matcher explicitly accepts both the canonical PAi ID and the GUID shown on the already-submitted first-case Partner Center screen.

### Partner Center Product IDs

- first-case Durable, forever — canonical PAi ID `pai-claims-first-case`; also accepts the already-submitted Partner Center identifier `daa1e8b9-d3d8-4d66-aaae-4fdc5fcedd53`
- `pai-claims-single-case` — Store-managed consumable, quantity 1 — additional case
- `pai-claims-annual` — Subscription — annual access

## Customer flow

### First case

1. The user chooses a workspace folder.
2. PAi Claims checks Microsoft Store state and the local entitlement ledger.
3. Before opening purchase UI, PAi Claims records a pending first-case marker tied to that exact workspace.
4. Microsoft Store purchase UI opens for `pai-claims-first-case` if the account does not already own it.
5. When Microsoft reports the Durable license, PAi Claims binds the introductory entitlement to the pending workspace and clears the marker.
6. The first-case PAi Legal bonus is preserved.

### Durable first-case behavior across reinstalls/devices

The first-case add-on is a **Durable**, so Microsoft treats it as a permanent account-level license rather than a consumable balance. PAi Claims therefore uses it as an account-level marker that the introductory offer has already been purchased.

- During the actual first purchase, the persisted pending-workspace marker allows that Durable to unlock the selected first workspace even if the app restarts around the purchase.
- On a fresh installation where Microsoft already reports the Durable and there is no matching pending first-case purchase, PAi Claims treats the introductory offer as already used and offers `pai-claims-single-case` instead of granting another $20 introductory case.
- The selected first workspace also records its local entitlement/provenance in the case manifest and ledger.

This prevents the simple reinstall/new-device path from repeatedly receiving the introductory offer. It does not create a cloud database of workspace identities; the Microsoft account license is the cross-device marker, while exact workspace bindings remain user-owned/local records.

### Additional case

1. PAi Claims reads Microsoft's Store-managed balance for `pai-claims-single-case`.
2. If the balance is zero, Microsoft Store purchase UI opens.
3. PAi Claims persists a unique fulfillment tracking ID before consuming one unit, so a retry reuses the same tracking ID.
4. PAi Claims calls Microsoft consumable fulfillment for one unit.
5. Only after Microsoft reports fulfillment success is the selected workspace permanently unlocked locally.

### Annual

PAi Claims reads the subscription license from Microsoft Store and caches the observed expiration. While active, new/opened cases are fully usable. After expiration, workspaces that relied on annual access fall back to read-only, preserving the existing ownership rule: PAi never locks the user out of their own files.

## Recovery codes

The pre-1.3.1 PAi verification endpoint remains available behind **Support / recovery code**. This is intended for support/admin recovery, promotional grants, or exceptional cases. It is not shown as the normal purchase path.

## Desktop Store bridge

Electron cannot directly use the Windows Runtime Store APIs from ordinary JavaScript in this package. `store-bridge/PAiClaims.StoreBridge.exe` is a small Windows helper that:

- obtains `StoreContext`,
- associates Store UI with an initialized Windows owner window,
- enumerates associated products and licenses,
- requests purchases, and
- reports Store-managed consumable fulfillment.

The bridge is included as an APPX resource and inherits the installed PAi Claims package identity when launched from the packaged app.

## Build

On the Windows build machine, from the source root:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\BUILD_PSI_STORE.ps1
```

The build script:

1. compiles `store-bridge/PAiClaims.StoreBridge.exe` against the installed Windows SDK,
2. runs the domain tests plus Microsoft commerce tests,
3. runs TypeScript checking, and
4. creates `release\PAiClaims-1.3.1-x64.appx`.

The live Store calls require package identity. Therefore the Microsoft purchase UI and real licenses are tested from an installed Store/MSIX build, not by double-clicking the helper or running ordinary Electron development mode.
