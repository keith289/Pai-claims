# PAi Claims 1.3.4

PAi Claims is a Windows desktop workspace for organizing property-insurance claim evidence, comparing repair estimates, and maintaining a source-traced case graph.

Version 1.3.1 keeps the 1.3.0 estimator, evidence graph, workspace, and entitlement rules and moves normal customer purchases to Microsoft Store add-ons.

## Microsoft Store commerce

The customer-facing purchase flow uses these Partner Center Product IDs:

- first-case Durable, forever — canonical PAi ID `pai-claims-first-case`; the already-submitted Partner Center add-on shown as `daa1e8b9-d3d8-4d66-aaae-4fdc5fcedd53` is also recognized
- `pai-claims-single-case` — Store-managed consumable, quantity 1 — one additional case credit
- `pai-claims-annual` — Subscription — annual access

PAi Claims discovers Microsoft's generated Store IDs at runtime by matching those Product IDs against each Store product's `InAppOfferToken`. No generated Store ID is hard-coded into the app.

The existing PAi purchase-code verifier remains available only in the collapsed **Support / recovery code** area for support/admin recovery. It is no longer the normal customer purchase path.

The introductory Durable is treated as a permanent Microsoft-account marker that the first-case offer has already been purchased. A pending-purchase marker ties the initial purchase to the selected workspace; on a later installation where the Durable already exists, PAi Claims offers the normal additional-case credit instead of another introductory case.

The app never receives or stores the customer's Microsoft payment-card details.

## Run locally

Requirements: Node.js 20 or later on Windows.

```powershell
npm install
npm test
npm run lint
npm run electron:dev
```

The estimator and evidence workflow work without AI. Users can optionally run the bundled local-AI runtime with their own model or explicitly consent to a hosted provider and supply their own API key.

Microsoft Store purchase UI itself requires package identity, so live purchase testing must be done from an installed Store/MSIX package rather than ordinary `electron:dev`.

## Build the Microsoft Store package

From the source root on the Windows build machine:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\BUILD_PSI_STORE.ps1
```

That script compiles the Windows Store bridge, runs the domain and commerce tests, runs TypeScript checking, and builds the Store APPX.

Expected output:

`release\PAiClaims-1.3.4-x64.appx`

Upload that APPX as a new submission for the **existing PAi Claims product** in Partner Center. Do not create a second app identity.

The reserved package identity remains `PAiLuton.PAiClaims`.

## First-case bonus

Only the introductory `pai-claims-first-case` entitlement includes the complimentary PAi Legal case/shared-workspace bonus. Additional-case consumables and annual access do not create additional introductory bonuses.

## Verification

For a pre-build check on Windows:

```powershell
.\VERIFY_FINAL_FLOW.ps1
```

See `PAiClaims_1.3.1_MICROSOFT_COMMERCE.md` for the commerce architecture and `NEXT_STEPS_1.3.1.txt` for the release procedure.
