/**
 * Electron main process for PAi Claims.
 *
 * The packaged app runs the existing Express server on a loopback port and
 * loads it in a BrowserWindow. Nothing about the web app changes.
 *
 * Two things this file exists to get right:
 *
 *  1. Claim storage location. An MSIX-packaged app is sandboxed, but a folder
 *     the user picks through the system dialog is granted to the app. That is
 *     how "build this claim on D:\ or an external drive" works WITHOUT the
 *     broadFileSystemAccess restricted capability, which requires separate
 *     Store approval and would be rejected for a first submission.
 *
 *  2. The Gemini key is never packaged. It is read from the user's own
 *     settings file in %LOCALAPPDATA%, entered through the app's settings
 *     screen. A key baked into the MSIX would be extractable by anyone who
 *     downloads it.
 */
const { app, BrowserWindow, dialog, ipcMain, shell, safeStorage } = require('electron');
const path = require('path');
const fs = require('fs');
const net = require('net');
const crypto = require('crypto');
const {
  PRODUCTS,
  storeProductAliases,
  VERIFY_URL,
  CODE_PATTERN,
  normalizeCode,
  workspaceKey,
  emptyLedger,
  sanitizeLedger,
  accessFor,
  offerFor,
  recordRedemption,
} = require('./commerce.cjs');
const storeBridge = require('./store-bridge.cjs');
const {
  syncAnnualFromStore,
  recordStoreCaseUnlock,
  ensurePendingFulfillment,
  clearPendingFulfillment,
  markPendingFirstCase,
  clearPendingFirstCase,
  microsoftOffer,
} = require('./microsoft-store.cjs');

const isDev = !app.isPackaged;
let mainWindow = null;
let server = null;
const aiSessionKeys = {};

/** Per-user settings, outside the read-only package directory. */
const settingsDir = app.getPath('userData');
const settingsFile = path.join(settingsDir, 'settings.json');

function readSettings() {
  try {
    return JSON.parse(fs.readFileSync(settingsFile, 'utf8'));
  } catch {
    return {};
  }
}

function writeSettings(next) {
  fs.mkdirSync(settingsDir, { recursive: true });
  fs.writeFileSync(settingsFile, JSON.stringify(next, null, 2), 'utf8');
  return next;
}

/* ---------------------------------------------------------- paid access */
const commerceLedgerFile = path.join(settingsDir, 'commerce-ledger.json');

function readCommerceLedger() {
  try {
    return sanitizeLedger(JSON.parse(fs.readFileSync(commerceLedgerFile, 'utf8')));
  } catch {
    return emptyLedger();
  }
}

function writeCommerceLedger(next) {
  fs.mkdirSync(settingsDir, { recursive: true });
  fs.writeFileSync(commerceLedgerFile, JSON.stringify(sanitizeLedger(next), null, 2), 'utf8');
  return next;
}

function verificationUrl() {
  return process.env.PAI_CLAIMS_VERIFY_URL || readSettings().commerce?.verificationUrl || VERIFY_URL;
}

async function verifyPurchaseCode(rawCode) {
  const code = normalizeCode(rawCode);
  if (!CODE_PATTERN.test(code)) {
    throw new Error('That code does not look right. It should look like PAI-1234-5678.');
  }

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 12000);
  let response;
  try {
    response = await fetch(verificationUrl(), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify({ code }),
      signal: controller.signal,
    });
  } catch (error) {
    const message = error?.name === 'AbortError'
      ? 'The activation service timed out. Check your internet connection and try again.'
      : 'The activation service could not be reached. Check your internet connection and try again.';
    throw new Error(message);
  } finally {
    clearTimeout(timer);
  }

  let payload = null;
  try { payload = await response.json(); } catch {}
  if (!payload || payload.valid !== true) {
    throw new Error(String(payload?.error || payload?.message || 'That code was not accepted.'));
  }
  return { code, payload };
}


function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function microsoftStoreState() {
  try {
    const state = await storeBridge.getState(mainWindow);
    if (!state || state.ok === false) {
      return {
        ok: false,
        available: false,
        error: String(state?.error || 'Microsoft Store commerce is unavailable.'),
        products: [],
        licenses: [],
      };
    }
    return { ...state, available: true };
  } catch (error) {
    return {
      ok: false,
      available: false,
      error: String(error?.message || 'Microsoft Store commerce is unavailable.'),
      products: [],
      licenses: [],
    };
  }
}

async function commerceSnapshot(location, name) {
  const key = workspaceKey(location, name);
  let ledger = readCommerceLedger();
  const state = await microsoftStoreState();
  if (state.available) {
    ledger = syncAnnualFromStore(ledger, state);
    writeCommerceLedger(ledger);
  }
  return microsoftOffer(ledger, key, state);
}

async function refreshStoreLedger() {
  let ledger = readCommerceLedger();
  const state = await microsoftStoreState();
  if (state.available) {
    ledger = syncAnnualFromStore(ledger, state);
    writeCommerceLedger(ledger);
  }
  return { ledger, state };
}

function productRow(state, productId) {
  const aliases = new Set(storeProductAliases(productId));
  return (Array.isArray(state?.products) ? state.products : [])
    .find((row) => aliases.has(String(row?.productId || '').trim().toLowerCase())) || null;
}

function licenseRow(state, productId) {
  const aliases = new Set(storeProductAliases(productId));
  return (Array.isArray(state?.licenses) ? state.licenses : [])
    .find((row) => aliases.has(String(row?.productId || '').trim().toLowerCase())) || null;
}

async function purchaseStoreProduct(productId, state = null) {
  const currentState = state || await microsoftStoreState();
  // Pass the exact Product ID returned by Partner Center/Store to the native
  // bridge. This matters for the already-submitted first-case GUID add-on.
  const actualProductId = String(productRow(currentState, productId)?.productId || productId).trim().toLowerCase();
  const result = await storeBridge.purchase(mainWindow, actualProductId);
  if (!result || result.ok === false) {
    const status = String(result?.status || '');
    if (status === 'NotPurchased') throw new Error('The Microsoft Store purchase was canceled or not completed.');
    if (status === 'NetworkError') throw new Error('Microsoft Store could not complete the purchase because of a network error.');
    if (status === 'ServerError') throw new Error('Microsoft Store could not complete the purchase because of a Store service error.');
    throw new Error(String(result?.error || result?.extendedError || 'Microsoft Store did not complete the purchase.'));
  }
  return result;
}

/* --------------------------------------------------------- Lowe's pricing */
const lowesFeedFile = path.join(settingsDir, 'lowes-store-price-feed.json');
let lowesAccessToken = null;
let lowesAccessTokenExpiresAt = 0;

function encryptSettingSecret(value) {
  if (!value) return { encrypted: '', plain: '', protected: false };
  try {
    if (safeStorage && safeStorage.isEncryptionAvailable()) {
      return {
        encrypted: safeStorage.encryptString(String(value)).toString('base64'),
        plain: '',
        protected: true,
      };
    }
  } catch {}
  // Fallback keeps functionality if OS secure storage is unavailable. The UI
  // is told that this value is not protected; never package this file.
  return { encrypted: '', plain: String(value), protected: false };
}

function decryptSettingSecret(config) {
  try {
    if (config?.clientSecretEncrypted && safeStorage && safeStorage.isEncryptionAvailable()) {
      return safeStorage.decryptString(Buffer.from(config.clientSecretEncrypted, 'base64'));
    }
  } catch {}
  return config?.clientSecretPlain || '';
}

function readAIKey(settings, provider) {
  if (aiSessionKeys[provider]) return aiSessionKeys[provider];
  const stored = settings?.ai?.keys?.[provider];
  // Read pre-1.3 string values for migration compatibility. New writes use
  // Windows secure storage and never create another plain-text key.
  if (typeof stored === 'string') return stored;
  if (stored?.encrypted && safeStorage && safeStorage.isEncryptionAvailable()) {
    try { return safeStorage.decryptString(Buffer.from(stored.encrypted, 'base64')); } catch {}
  }
  return '';
}

function writeAIKey(settings, provider, value) {
  settings.ai = settings.ai || {};
  settings.ai.keys = settings.ai.keys || {};
  delete aiSessionKeys[provider];
  if (!value) {
    delete settings.ai.keys[provider];
    return { saved: false, protected: false };
  }
  const protectedSecret = encryptSettingSecret(String(value));
  if (protectedSecret.protected) {
    settings.ai.keys[provider] = { encrypted: protectedSecret.encrypted, protected: true };
    return { saved: true, protected: true };
  }
  // Do not persist an API credential in clear text. Keep it for this app
  // session only on systems where Windows secure storage is unavailable.
  delete settings.ai.keys[provider];
  aiSessionKeys[provider] = String(value);
  return { saved: true, protected: false };
}

function migrateLegacyAIKeys(settings) {
  let changed = false;
  for (const provider of ['gemini', 'anthropic', 'openai', 'openai-compatible']) {
    const legacy = settings?.ai?.keys?.[provider];
    if (typeof legacy === 'string' && legacy) {
      writeAIKey(settings, provider, legacy);
      changed = true;
    }
  }
  if (typeof settings.GEMINI_API_KEY === 'string' && settings.GEMINI_API_KEY) {
    writeAIKey(settings, 'gemini', settings.GEMINI_API_KEY);
    delete settings.GEMINI_API_KEY;
    changed = true;
  }
  if (changed) writeSettings(settings);
  return settings;
}

function readLowesFeed() {
  try {
    return JSON.parse(fs.readFileSync(lowesFeedFile, 'utf8'));
  } catch {
    return { rows: [], hash: '', importedAt: '' };
  }
}

function parseCsv(text) {
  const rows = [];
  let row = [];
  let field = '';
  let quoted = false;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (quoted) {
      if (ch === '"' && text[i + 1] === '"') { field += '"'; i++; }
      else if (ch === '"') quoted = false;
      else field += ch;
      continue;
    }
    if (ch === '"') quoted = true;
    else if (ch === ',') { row.push(field); field = ''; }
    else if (ch === '\n') { row.push(field.replace(/\r$/, '')); rows.push(row); row = []; field = ''; }
    else field += ch;
  }
  if (field.length || row.length) { row.push(field.replace(/\r$/, '')); rows.push(row); }
  return rows.filter((r) => r.some((cell) => String(cell).trim()));
}

const normHeader = (value) => String(value || '').trim().toLowerCase().replace(/[^a-z0-9]/g, '');
function cell(record, aliases) {
  for (const alias of aliases) {
    const v = record[normHeader(alias)];
    if (v !== undefined && String(v).trim() !== '') return String(v).trim();
  }
  return '';
}
function numberCell(record, aliases) {
  const raw = cell(record, aliases).replace(/[$,%]/g, '').replace(/,/g, '');
  const value = Number(raw);
  return Number.isFinite(value) ? value : 0;
}

function normalizeLowesCsv(text, sourcePath) {
  const table = parseCsv(text);
  if (table.length < 2) throw new Error('The selected CSV has no data rows.');
  const headers = table[0].map(normHeader);
  const rows = [];
  for (const values of table.slice(1)) {
    const record = {};
    headers.forEach((h, i) => { if (h) record[h] = values[i] ?? ''; });
    const productId = cell(record, ['productId', 'product_id', 'itemNumber', 'item_number', 'item', 'sku', 'skuNumber', 'modelNumber']);
    const storeId = cell(record, ['storeId', 'store_id', 'storeNumber', 'store_number', 'store']);
    const zipCode = cell(record, ['zipCode', 'zip_code', 'postalCode', 'postal_code', 'zip']);
    const sellingPrice = numberCell(record, ['sellingPrice', 'selling_price', 'currentPrice', 'current_price', 'retailPrice', 'retail_price', 'price']);
    if (!productId || !(sellingPrice > 0)) continue;
    rows.push({
      productId,
      storeId,
      zipCode,
      sellingPrice,
      description: cell(record, ['description', 'productDescription', 'product_description', 'name', 'title']),
      stock: cell(record, ['stock', 'inventory', 'quantityAvailable', 'quantity_available', 'availableQuantity']),
      packageCoverage: numberCell(record, ['packageCoverage', 'package_coverage', 'coverage', 'coveragePerPackage', 'coverage_per_package']),
      packageCoverageUnit: cell(record, ['packageCoverageUnit', 'package_coverage_unit', 'coverageUnit', 'coverage_unit', 'unit']),
      packageDescription: cell(record, ['packageDescription', 'package_description', 'package', 'packSize', 'pack_size']),
      sourcePath: path.basename(sourcePath),
    });
  }
  if (!rows.length) {
    throw new Error('No product/price rows were recognized. Include a product/SKU column and a selling/current price column.');
  }
  return rows;
}

function fillTemplate(template, request) {
  return String(template || '')
    .replaceAll('{productId}', encodeURIComponent(request.productId))
    .replaceAll('{storeId}', encodeURIComponent(request.storeId))
    .replaceAll('{zipCode}', encodeURIComponent(request.zipCode))
    .replaceAll('{query}', encodeURIComponent(request.query || ''));
}

function walkObjects(value, out = []) {
  if (!value || typeof value !== 'object') return out;
  if (Array.isArray(value)) { value.forEach((item) => walkObjects(item, out)); return out; }
  out.push(value);
  Object.values(value).forEach((item) => walkObjects(item, out));
  return out;
}

function firstValue(obj, keys) {
  for (const key of keys) {
    if (obj && obj[key] !== undefined && obj[key] !== null && obj[key] !== '') return obj[key];
  }
  return undefined;
}

function extractLowesApiPrice(payload, request) {
  const objects = walkObjects(payload);
  const idKeys = ['productId', 'productID', 'itemNumber', 'itemId', 'sku', 'skuNumber', 'id'];
  const priceKeys = ['sellingPrice', 'currentPrice', 'retailPrice', 'price', 'unitPrice'];
  const storeKeys = ['storeId', 'storeNumber', 'store'];
  const candidates = objects.filter((obj) => {
    const rawPrice = Number(String(firstValue(obj, priceKeys) ?? '').replace(/[$,]/g, ''));
    if (!(rawPrice > 0)) return false;
    const id = String(firstValue(obj, idKeys) ?? '');
    return !id || id === String(request.productId);
  });
  const chosen = candidates.find((obj) => String(firstValue(obj, storeKeys) ?? '') === String(request.storeId)) || candidates[0];
  if (!chosen) throw new Error('The partner response did not contain a recognizable selling price. Map the authorized endpoint response before using it for a claim.');
  const sellingPrice = Number(String(firstValue(chosen, priceKeys)).replace(/[$,]/g, ''));
  const packageCoverage = Number(firstValue(chosen, ['packageCoverage', 'coverage', 'coveragePerPackage']) || 0);
  return {
    sellingPrice,
    description: String(firstValue(chosen, ['description', 'productDescription', 'name', 'title']) || ''),
    stock: firstValue(chosen, ['stock', 'inventory', 'quantityAvailable', 'availableQuantity']),
    packageCoverage: Number.isFinite(packageCoverage) ? packageCoverage : 0,
    packageCoverageUnit: String(firstValue(chosen, ['packageCoverageUnit', 'coverageUnit', 'unit']) || ''),
    packageDescription: String(firstValue(chosen, ['packageDescription', 'packSize', 'package']) || ''),
  };
}

function searchTerms(value) {
  return new Set(String(value || '').toLowerCase().match(/[a-z0-9]{2,}/g) || []);
}

function searchScore(query, description) {
  const q = searchTerms(query);
  const d = searchTerms(description);
  if (!q.size || !d.size) return 0;
  const overlap = [...q].filter((term) => d.has(term)).length;
  return overlap / q.size;
}

function extractLowesApiSearch(payload, request) {
  const objects = walkObjects(payload);
  const idKeys = ['productId', 'productID', 'itemNumber', 'itemId', 'sku', 'skuNumber', 'id'];
  const priceKeys = ['sellingPrice', 'currentPrice', 'retailPrice', 'price', 'unitPrice'];
  const storeKeys = ['storeId', 'storeNumber', 'store'];
  const descriptionKeys = ['description', 'productDescription', 'name', 'title'];
  const candidates = objects.map((obj) => {
    const sellingPrice = Number(String(firstValue(obj, priceKeys) ?? '').replace(/[$,]/g, ''));
    const productId = String(firstValue(obj, idKeys) ?? '');
    const description = String(firstValue(obj, descriptionKeys) ?? '');
    const responseStore = String(firstValue(obj, storeKeys) ?? '');
    const score = searchScore(request.query, description) + (responseStore && responseStore === String(request.storeId) ? 0.15 : 0);
    return { obj, sellingPrice, productId, description, score };
  }).filter((entry) => entry.sellingPrice > 0 && entry.productId && entry.score > 0);
  candidates.sort((a, b) => b.score - a.score);
  const chosen = candidates[0];
  if (!chosen) throw new Error('The Lowe\'s partner search response did not contain a recognizable matching product with a selling price.');
  const coverage = Number(firstValue(chosen.obj, ['packageCoverage', 'coverage', 'coveragePerPackage']) || 0);
  return {
    productId: chosen.productId,
    description: chosen.description || `Lowe's product ${chosen.productId}`,
    sellingPrice: chosen.sellingPrice,
    stock: firstValue(chosen.obj, ['stock', 'inventory', 'quantityAvailable', 'availableQuantity']),
    packageCoverage: Number.isFinite(coverage) ? coverage : 0,
    packageCoverageUnit: String(firstValue(chosen.obj, ['packageCoverageUnit', 'coverageUnit', 'unit']) || ''),
    packageDescription: String(firstValue(chosen.obj, ['packageDescription', 'packSize', 'package']) || ''),
    score: chosen.score,
  };
}

async function lowesPartnerToken(config) {
  if (lowesAccessToken && Date.now() < lowesAccessTokenExpiresAt - 30_000) return lowesAccessToken;
  const secret = decryptSettingSecret(config);
  if (!config.clientId || !secret || !config.tokenUrl) throw new Error('Partner API is not fully configured. Import an authorized store-price CSV or enter the endpoint details supplied with your Lowe\'s access.');
  const body = new URLSearchParams({ grant_type: 'client_credentials' });
  if (config.scope) body.set('scope', config.scope);
  const auth = Buffer.from(`${config.clientId}:${secret}`).toString('base64');
  const response = await fetch(config.tokenUrl, {
    method: 'POST',
    headers: { Authorization: `Basic ${auth}`, 'Content-Type': 'application/x-www-form-urlencoded' },
    body,
  });
  if (!response.ok) throw new Error(`Lowe's OAuth token request failed (${response.status}).`);
  const json = await response.json();
  const token = json.access_token || json.accessToken || json.token;
  if (!token) throw new Error('Lowe\'s OAuth response did not contain an access token.');
  lowesAccessToken = token;
  lowesAccessTokenExpiresAt = Date.now() + Math.max(60, Number(json.expires_in || json.expiresIn || 3600)) * 1000;
  return token;
}

function freePort() {
  return new Promise((resolve, reject) => {
    const s = net.createServer();
    s.unref();
    s.on('error', reject);
    s.listen(0, '127.0.0.1', () => {
      const { port } = s.address();
      s.close(() => resolve(port));
    });
  });
}

async function startServer() {
  const port = await freePort();
  const settings = migrateLegacyAIKeys(readSettings());

  // Supply configuration the bundled server expects, from user settings only.
  process.env.PORT = String(port);
  process.env.HOST = '127.0.0.1';
  process.env.APP_URL = `http://127.0.0.1:${port}`;
  process.env.NODE_ENV = 'production';
  process.env.PAI_DIST_DIR = path.join(__dirname, '..', 'dist');
  applyAISettings(settings);

  // dist/server.cjs is produced by the existing `npm run build` script.
  require(path.join(__dirname, '..', 'dist', 'server.cjs'));
  return port;
}

async function createWindow() {
  const port = isDev ? 3100 : await startServer();

  mainWindow = new BrowserWindow({
    width: 1480,
    height: 940,
    minWidth: 1040,
    minHeight: 680,
    backgroundColor: '#0E1F26',
    show: false,
    title: 'PAi Claims',
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
    },
  });

  mainWindow.once('ready-to-show', () => mainWindow.show());
  mainWindow.loadURL(`http://127.0.0.1:${port}`);

  // External links open in the user's browser, never in the app frame.
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    try {
      const parsed = new URL(url);
      if (parsed.protocol === 'https:') void shell.openExternal(parsed.toString());
    } catch {}
    return { action: 'deny' };
  });
}

/* ---------------------------------------------------------------- IPC */

/** Let the user choose any drive or folder for a new claim workspace. */
ipcMain.handle('claim:chooseLocation', async () => {
  const res = await dialog.showOpenDialog(mainWindow, {
    title: 'Choose where to build this claim',
    buttonLabel: 'Use this folder',
    properties: ['openDirectory', 'createDirectory'],
  });
  if (res.canceled || !res.filePaths.length) return null;

  const dir = res.filePaths[0];
  let writable = true;
  try {
    fs.accessSync(dir, fs.constants.W_OK);
  } catch {
    writable = false;
  }
  return { path: dir, writable };
});

ipcMain.handle('commerce:getOffer', async (_e, { location, name }) => {
  return commerceSnapshot(location, name);
});

/** Microsoft Store: buy/use the currently applicable case entitlement. */
ipcMain.handle('commerce:acquireCase', async (_e, { location, name }) => {
  const key = workspaceKey(location, name);
  let snapshot = await commerceSnapshot(location, name);
  if (snapshot.access.allowed) return { ok: true, access: snapshot.access, productId: null };
  if (!snapshot.store.available) {
    throw new Error(snapshot.store.error || 'Microsoft Store commerce is unavailable in this build.');
  }

  const productId = snapshot.caseOffer.productId;
  let ledger = snapshot.ledger;
  let state = await microsoftStoreState();

  if (productId === PRODUCTS.firstCase) {
    let license = licenseRow(state, PRODUCTS.firstCase);
    if (!license?.active) {
      ledger = markPendingFirstCase(ledger, key);
      writeCommerceLedger(ledger);
      await purchaseStoreProduct(PRODUCTS.firstCase, state);
      // Give the Store a moment to publish the durable license to this process.
      for (let attempt = 0; attempt < 3; attempt++) {
        await sleep(attempt ? 650 : 150);
        state = await microsoftStoreState();
        license = licenseRow(state, PRODUCTS.firstCase);
        if (license?.active) break;
      }
    }
    if (!license?.active) {
      throw new Error('Microsoft confirmed the purchase but the first-case license is not visible yet. Close and reopen PAi Claims, then choose this case again.');
    }
    const product = productRow(state, PRODUCTS.firstCase);
    ledger = recordStoreCaseUnlock(ledger, {
      productId: PRODUCTS.firstCase,
      workspaceHash: key,
      storeId: String(product?.storeId || license?.storeId || ''),
    });
    ledger = clearPendingFirstCase(ledger, key);
    writeCommerceLedger(ledger);
    return { ok: true, productId: PRODUCTS.firstCase, access: accessFor(ledger, key) };
  }

  if (productId !== PRODUCTS.singleCase) throw new Error('The selected case offer is not recognized.');
  let product = productRow(state, PRODUCTS.singleCase);
  let balance = Number(product?.balance || 0);
  if (balance < 1) {
    await purchaseStoreProduct(PRODUCTS.singleCase, state);
    for (let attempt = 0; attempt < 3; attempt++) {
      await sleep(attempt ? 650 : 150);
      state = await microsoftStoreState();
      product = productRow(state, PRODUCTS.singleCase);
      balance = Number(product?.balance || 0);
      if (balance >= 1) break;
    }
  }
  if (balance < 1) {
    throw new Error('Microsoft confirmed the purchase but the case credit balance has not updated yet. Close and reopen PAi Claims, then choose this case again.');
  }

  // Store-managed consumables require a unique tracking id. Persist it before
  // fulfillment so a retry after a network interruption reuses the same id.
  const pending = ensurePendingFulfillment(ledger, key, PRODUCTS.singleCase);
  ledger = pending.ledger;
  writeCommerceLedger(ledger);
  const fulfilled = await storeBridge.consume(mainWindow, String(product?.productId || PRODUCTS.singleCase), pending.trackingId, 1);
  if (!fulfilled || fulfilled.ok === false || String(fulfilled.status) !== 'Succeeded') {
    const status = String(fulfilled?.status || '');
    if (status === 'InsufficentQuantity') throw new Error('Microsoft Store reports that no unused case credit is available.');
    throw new Error(String(fulfilled?.error || fulfilled?.extendedError || 'Microsoft Store could not consume the case credit. Try again; PAi Claims will reuse the same fulfillment ID.'));
  }

  ledger = recordStoreCaseUnlock(ledger, {
    productId: PRODUCTS.singleCase,
    workspaceHash: key,
    storeId: String(fulfilled.storeId || product?.storeId || ''),
    trackingId: pending.trackingId,
  });
  ledger = clearPendingFulfillment(ledger, pending.trackingId);
  writeCommerceLedger(ledger);
  return { ok: true, productId: PRODUCTS.singleCase, access: accessFor(ledger, key) };
});

/** Microsoft Store: purchase/refresh annual subscription entitlement. */
ipcMain.handle('commerce:acquireAnnual', async (_e, { location, name }) => {
  let snapshot = await commerceSnapshot(location, name);
  if (snapshot.access.mode === 'annual' && snapshot.access.allowed) {
    return { ok: true, access: snapshot.access, productId: PRODUCTS.annual };
  }
  if (!snapshot.store.available) throw new Error(snapshot.store.error || 'Microsoft Store commerce is unavailable in this build.');

  let state = await microsoftStoreState();
  let license = licenseRow(state, PRODUCTS.annual);
  if (!license?.active) {
    await purchaseStoreProduct(PRODUCTS.annual, state);
    for (let attempt = 0; attempt < 4; attempt++) {
      await sleep(attempt ? 750 : 200);
      state = await microsoftStoreState();
      license = licenseRow(state, PRODUCTS.annual);
      if (license?.active) break;
    }
  }
  if (!license?.active) {
    throw new Error('Microsoft confirmed the purchase but the annual subscription is not visible yet. Close and reopen PAi Claims and it will refresh automatically.');
  }

  let ledger = syncAnnualFromStore(readCommerceLedger(), state);
  writeCommerceLedger(ledger);
  const key = workspaceKey(location, name);
  return { ok: true, productId: PRODUCTS.annual, access: accessFor(ledger, key) };
});

/** Hidden recovery/admin path retained from 1.3.0. */
ipcMain.handle('commerce:redeem', async (_e, { code, location, name, expectedProductId }) => {
  const ledger = readCommerceLedger();
  const key = workspaceKey(location, name);
  const offer = offerFor(ledger, key);
  const allowedProducts = [offer.caseOffer.productId, PRODUCTS.annual];
  if (expectedProductId && !allowedProducts.includes(expectedProductId)) {
    throw new Error('The selected offer is no longer available. Refresh the payment screen and try again.');
  }

  const verified = await verifyPurchaseCode(code);
  const productId = String(verified.payload.product_id || '').trim().toLowerCase();
  if (!allowedProducts.includes(productId)) {
    throw new Error(`This code is for ${productId || 'an unknown product'}, not the selected PAi Claims access offer.`);
  }

  const next = recordRedemption(ledger, {
    code: verified.code,
    productId,
    workspaceHash: key,
    verification: verified.payload,
  });
  writeCommerceLedger(next);
  return { ok: true, productId, access: accessFor(next, key) };
});

/** Create the claim folder structure at the chosen location. */
ipcMain.handle('claim:create', async (_e, { location, name, claimData, documents }) => {
  // The policy packet is a precondition of the case, not an afterthought.
  // Creation is atomic: the documents land inside the workspace before the
  // claim file is written, or no workspace is left behind at all.
  const incoming = Array.isArray(documents) ? documents : [];
  if (!incoming.some((d) => (d?.kind || 'policy_dec') === 'policy_dec' && d?.dataBase64)) {
    throw new Error(
      'A policy packet is required. Attach the declarations page plus all forms and endorsements before creating the case.'
    );
  }

  const safe = String(name || '')
    .replace(/[^A-Za-z0-9 ._-]/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 120);
  if (!safe) throw new Error('Claim name must contain at least one letter or number.');

  const root = path.join(location, safe);
  const key = workspaceKey(location, safe);
  const refreshed = await refreshStoreLedger();
  const access = accessFor(refreshed.ledger, key);
  if (!access.allowed) {
    throw new Error('Paid access is required before PAi Claims can create or analyze this workspace.');
  }
  if (fs.existsSync(root) && fs.readdirSync(root).length) {
    throw new Error(
      `A claim folder named "${safe}" already exists here and is not empty. ` +
        'Choose a different name or location.'
    );
  }
  const folders = {
    uploads: 'uploads',
    evidence: 'evidence',
    photos: 'photos',
    estimates: 'estimates',
    carrierRecords: 'carrier_records',
    correspondence: 'correspondence',
    payments: 'payments',
    reports: 'reports',
    exports: 'exports',
    audit: 'audit',
    paiLegal: 'pai_legal',
  };
  for (const d of Object.values(folders)) {
    fs.mkdirSync(path.join(root, d), { recursive: true });
  }
  // Copy every supplied document into the workspace and read what is
  // readable. A failure here removes the folder we just made rather than
  // leaving a paid case with no policy in it.
  let attachments;
  try {
    attachments = [];
    for (const doc of incoming) {
      attachments.push(
        await attachDocumentToCase({
          root,
          kind: doc.kind || 'policy_dec',
          filename: doc.filename,
          dataBase64: doc.dataBase64,
        })
      );
    }
  } catch (err) {
    try {
      fs.rmSync(root, { recursive: true, force: true });
    } catch {
      /* leave what we cannot remove */
    }
    throw new Error(`The case was not created because a document could not be stored: ${err.message}`);
  }

  const attachedEvidence = attachments.map((a, i) => evidenceFromAttachment(a, i));

  const meta = {
    claim_id: safe.toLowerCase().replace(/\s+/g, '-'),
    name: safe,
    created_at: new Date().toISOString(),
    schema_version: 2,
    ...(claimData && typeof claimData === 'object' ? claimData : {}),
    // Placeholder evidence from the renderer is replaced by records that
    // point at files actually on disk.
    evidence: [
      ...attachedEvidence,
      ...((claimData?.evidence || []).filter((e) => e.type !== 'policy_dec')),
    ],
  };
  const manifest = {
    schema: 'pai.shared-case-workspace',
    schema_version: 1,
    workspace_id: crypto.randomUUID(),
    created_at: meta.created_at,
    owner: 'user',
    products: ['pai-claims', 'pai-legal'],
    entitlements: {
      pai_claims: {
        mode: access.mode,
        read_only: access.readOnly,
        expires_at: access.expiresAt,
        source: access.source || null,
        source_product_id: access.sourceProductId || null,
      },
      pai_legal: access.complimentaryPaiLegalCase ? {
        complimentary_case_count: 1,
        source_product_id: PRODUCTS.firstCase,
        granted_at: access.complimentaryPaiLegalCase.grantedAt,
        included_features: ['pai-case-file-creator', 'psi-legal-data'],
      } : {
        complimentary_case_count: 0,
      },
    },
    files: {
      claim: 'claim.json',
      case_graph: 'case_graph.json',
      audit_ledger: 'audit/ledger.jsonl',
    },
    folders,
  };
  const caseGraph = {
    schema: 'pai.case-graph',
    schema_version: 1,
    claim_id: meta.claim_id,
    updated_at: meta.created_at,
    propositions: [],
    relationships: [],
  };
  fs.writeFileSync(path.join(root, 'pai_case_manifest.json'), JSON.stringify(manifest, null, 2), 'utf8');
  fs.writeFileSync(path.join(root, 'claim.json'), JSON.stringify(meta, null, 2), 'utf8');
  fs.writeFileSync(path.join(root, 'case_graph.json'), JSON.stringify(caseGraph, null, 2), 'utf8');
  if (access.complimentaryPaiLegalCase) {
    fs.writeFileSync(
      path.join(root, folders.paiLegal, 'complimentary_case_entitlement.json'),
      JSON.stringify(manifest.entitlements.pai_legal, null, 2),
      'utf8'
    );
  }
  fs.appendFileSync(
    path.join(root, 'audit', 'ledger.jsonl'),
    JSON.stringify({
      at: meta.created_at,
      event: 'claim.created',
      actor: 'user',
      detail: { location, name: safe },
    }) + '\n',
    'utf8'
  );

  // Remember recent locations so the picker can offer them next time.
  const s = readSettings();
  s.recentLocations = [location, ...(s.recentLocations || []).filter((l) => l !== location)].slice(0, 8);
  writeSettings(s);

  return { root, meta, manifest, access, attachments };
});

/**
 * Push the user's AI choice into the environment the server reads.
 * Keys live only in %LOCALAPPDATA%; none is compiled into the package.
 */
function applyAISettings(s) {
  const ai = s.ai || {};
  process.env.AI_PROVIDER = ai.provider || 'local';
  process.env.AI_MODEL = ai.model || '';
  process.env.AI_BASE_URL = ai.baseUrl || '';
  // Bundled llama.cpp runtime and the user's model folder. The binary ships
  // read-only inside the package; models live in user data.
  process.env.LLAMA_BIN_DIR = path.join(process.resourcesPath || __dirname, 'runtime');
  process.env.LLAMA_MODELS_DIR = path.join(app.getPath('userData'), 'models');
  process.env.LLAMA_PORT = String(ai.llamaPort || 8080);
  const cloudAllowed = ai.cloudConsent === true;
  process.env.GEMINI_API_KEY = cloudAllowed ? (readAIKey(s, 'gemini') || s.GEMINI_API_KEY || '') : '';
  process.env.ANTHROPIC_API_KEY = cloudAllowed ? readAIKey(s, 'anthropic') : '';
  process.env.OPENAI_API_KEY = cloudAllowed ? readAIKey(s, 'openai') : '';
  process.env.AI_API_KEY = cloudAllowed ? readAIKey(s, 'openai-compatible') : '';
}

/** Which providers hold a saved key. Never returns the keys themselves. */

/**
 * Attach a document to a case: copy it into the workspace, hash it, and read
 * what can be read from it. The bytes live with the case from here on, so an
 * evidence record always points at a file that travels with the claim.
 *
 * Extraction never fabricates. A file that yields nothing comes back with
 * needsVision so a local model can transcribe it, capped below a real reading.
 */
async function attachDocumentToCase({ root, kind, filename, dataBase64 }) {
  const { TextExtractor, sha256 } = require('./ingestion.cjs');

  if (!root || !fs.existsSync(root)) throw new Error('Case folder not found.');
  const safeName = String(filename || 'document')
    .replace(/[\\/:*?"<>|]/g, '_')
    .slice(0, 180);
  if (!safeName.trim()) throw new Error('That file has no usable name.');

  const uploads = path.join(root, 'uploads');
  fs.mkdirSync(uploads, { recursive: true });

  let target = path.join(uploads, safeName);
  let counter = 1;
  while (fs.existsSync(target)) {
    const ext = path.extname(safeName);
    target = path.join(uploads, `${path.basename(safeName, ext)} (${counter})${ext}`);
    counter += 1;
  }
  fs.writeFileSync(target, Buffer.from(String(dataBase64 || ''), 'base64'));

  const contentHash = sha256(target);

  // A file already on the case under a different name is not a second
  // independent source. The caller needs to know before it counts as one.
  let duplicateOf = null;
  for (const existing of fs.readdirSync(uploads)) {
    const candidate = path.join(uploads, existing);
    if (candidate === target) continue;
    try {
      if (fs.statSync(candidate).isFile() && sha256(candidate) === contentHash) {
        duplicateOf = existing;
        break;
      }
    } catch { /* unreadable entry */ }
  }

  let extraction;
  try {
    extraction = await new TextExtractor().extract(target);
  } catch (err) {
    extraction = {
      text: '',
      method: 'none',
      pages: 0,
      ocrPages: 0,
      confidence: null,
      bracketCeiling: 'UNVERIFIED',
      needsVision: true,
      note: `Extraction failed: ${err.message}`,
    };
  }

  return {
    storedPath: target,
    filename: path.basename(target),
    kind: kind || 'policy_dec',
    bytes: fs.statSync(target).size,
    contentHash,
    duplicateOf,
    ...extraction,
  };
}

ipcMain.handle('claim:attachDocument', async (_e, request) => attachDocumentToCase(request));

/**
 * Turn an attachment result into an evidence record.
 *
 * The record states what the document is and how well it was read, and
 * nothing else. No excerpt is invented, no observation is asserted that the
 * extraction did not support.
 */
function evidenceFromAttachment(attachment, index) {
  const readable = attachment.text && attachment.text.trim().length > 0;
  const observations = [];
  if (readable) {
    observations.push(
      `Text read by ${attachment.method}${attachment.pages ? ` across ${attachment.pages} page(s)` : ''}.`,
    );
    if (attachment.ocrPages) observations.push(`${attachment.ocrPages} page(s) required OCR.`);
    if (typeof attachment.confidence === 'number') {
      observations.push(`Mean OCR confidence ${(attachment.confidence * 100).toFixed(0)}%.`);
    }
  } else {
    observations.push('No text could be read from this document yet.');
  }
  if (attachment.needsVision) {
    observations.push('Parts of this document need a model to describe them; nothing read that way is treated as transcribed.');
  }
  if (attachment.duplicateOf) {
    observations.push(`Identical content to ${attachment.duplicateOf} already on this case; not an independent source.`);
  }
  if (attachment.note) observations.push(attachment.note);

  return {
    id: `ev-${Date.now()}-doc-${index}`,
    title: attachment.kind === 'policy_dec'
      ? (index === 0 ? 'Policy packet (as supplied)' : `Policy packet - part ${index + 1}`)
      : attachment.filename,
    type: attachment.kind,
    filename: attachment.filename,
    date: new Date().toISOString().split('T')[0],
    source: 'Supplied by insured at intake',
    provenanceRoot: 'Insured upload',
    evidenceLevel: 'direct',
    stance: 'context',
    // The document exists; its contents have not been read into policy terms.
    bracketState: 'UNVERIFIED',
    contentHash: attachment.contentHash,
    excerpt: '',
    rawText: attachment.text || '',
    floatPoints: 0,
    mixPoints: 0,
    stirPoints: 0,
    totalPressure: 0,
    keyObservations: observations,
    extraction: {
      method: attachment.method,
      pages: attachment.pages,
      ocrPages: attachment.ocrPages,
      confidence: attachment.confidence,
      bracketCeiling: attachment.bracketCeiling,
      needsVision: attachment.needsVision,
      storedPath: attachment.storedPath,
    },
  };
}

ipcMain.handle('ai:getConfig', () => {
  const ai = readSettings().ai || {};
  return {
    provider: ai.provider || 'local',
    model: ai.model || '',
    baseUrl: ai.baseUrl || '',
    cloudConsent: ai.cloudConsent === true,
    hasKey: Object.fromEntries(
      ['gemini', 'anthropic', 'openai', 'openai-compatible'].map((id) => [
        id,
        Boolean(readAIKey(readSettings(), id) || (id === 'gemini' && readSettings().GEMINI_API_KEY)),
      ])
    ),
  };
});

/** Save provider choice and, optionally, a key for it. */
ipcMain.handle('ai:setConfig', (_e, { provider, model, baseUrl, apiKey, cloudConsent, clearCloudKeys }) => {
  const s = readSettings();
  s.ai = s.ai || { keys: {} };
  s.ai.keys = s.ai.keys || {};
  if (cloudConsent !== undefined) s.ai.cloudConsent = cloudConsent === true;
  if (clearCloudKeys === true) {
    for (const id of ['gemini', 'anthropic', 'openai', 'openai-compatible']) writeAIKey(s, id, '');
  }
  if (provider && provider !== 'local' && s.ai.cloudConsent !== true) {
    throw new Error('Consent is required before claim content can be sent to a hosted AI provider.');
  }
  if (provider) {
    s.ai.provider = provider;
    if (provider === 'local') s.ai.baseUrl = '';
  }
  if (model !== undefined) s.ai.model = model;
  if (baseUrl !== undefined && provider !== 'local') s.ai.baseUrl = baseUrl;
  let keyStatus = null;
  if (apiKey !== undefined && provider) {
    keyStatus = writeAIKey(s, provider, apiKey);
  }
  writeSettings(s);
  applyAISettings(s);
  return { ok: true, provider: s.ai.provider, keyStatus };
});

ipcMain.handle('settings:get', () => {
  const s = readSettings();
  // Never hand the key itself back to the renderer; only whether one is set.
  const ai = s.ai || {};
  return {
    aiProvider: ai.provider || 'local',
    hasGeminiKey: Boolean(readAIKey(s, 'gemini') || s.GEMINI_API_KEY),
    recentLocations: s.recentLocations || [],
  };
});

// Kept for compatibility with any existing caller; routes into the
// multi-provider store so there is only one place keys are held.
ipcMain.handle('settings:setGeminiKey', (_e, key) => {
  const s = readSettings();
  s.ai = s.ai || {};
  const keyStatus = writeAIKey(s, 'gemini', key);
  if (key) s.ai.provider = 'gemini';
  writeSettings(s);
  applyAISettings(s);
  return { hasGeminiKey: Boolean(readAIKey(s, 'gemini')), keyStatus };
});

ipcMain.handle('lowes:getConfig', () => {
  const config = readSettings().lowes || {};
  const feed = readLowesFeed();
  return {
    clientId: config.clientId || '',
    scope: config.scope || '',
    tokenUrl: config.tokenUrl || '',
    productUrlTemplate: config.productUrlTemplate || '',
    searchUrlTemplate: config.searchUrlTemplate || '',
    hasSecret: Boolean(config.clientSecretEncrypted || config.clientSecretPlain),
    secretProtected: Boolean(config.clientSecretEncrypted),
    hasStoreFeed: Boolean(feed.rows?.length),
    storeFeedRows: feed.rows?.length || 0,
  };
});

ipcMain.handle('lowes:setConfig', (_e, next) => {
  const settings = readSettings();
  const existing = settings.lowes || {};
  const config = {
    ...existing,
    clientId: String(next?.clientId || '').trim(),
    scope: String(next?.scope || '').trim(),
    tokenUrl: String(next?.tokenUrl || '').trim(),
    productUrlTemplate: String(next?.productUrlTemplate || '').trim(),
    searchUrlTemplate: String(next?.searchUrlTemplate || '').trim(),
  };
  if (next?.clientSecret !== undefined && String(next.clientSecret).length) {
    const protectedSecret = encryptSettingSecret(String(next.clientSecret));
    config.clientSecretEncrypted = protectedSecret.encrypted;
    config.clientSecretPlain = protectedSecret.plain;
  }
  settings.lowes = config;
  writeSettings(settings);
  lowesAccessToken = null;
  lowesAccessTokenExpiresAt = 0;
  return {
    ok: true,
    clientId: config.clientId,
    scope: config.scope,
    tokenUrl: config.tokenUrl,
    productUrlTemplate: config.productUrlTemplate,
    searchUrlTemplate: config.searchUrlTemplate || '',
    hasSecret: Boolean(config.clientSecretEncrypted || config.clientSecretPlain),
    secretProtected: Boolean(config.clientSecretEncrypted),
  };
});

ipcMain.handle('lowes:importStoreFeed', async () => {
  const picked = await dialog.showOpenDialog(mainWindow, {
    title: 'Import authorized Lowe\'s store-price CSV',
    buttonLabel: 'Import price feed',
    properties: ['openFile'],
    filters: [{ name: 'CSV price feed', extensions: ['csv'] }, { name: 'All files', extensions: ['*'] }],
  });
  if (picked.canceled || !picked.filePaths.length) return null;
  const sourcePath = picked.filePaths[0];
  const raw = fs.readFileSync(sourcePath);
  const hash = crypto.createHash('sha256').update(raw).digest('hex');
  const rows = normalizeLowesCsv(raw.toString('utf8'), sourcePath);
  const importedAt = new Date().toISOString();
  fs.mkdirSync(settingsDir, { recursive: true });
  fs.writeFileSync(lowesFeedFile, JSON.stringify({ hash, importedAt, sourceName: path.basename(sourcePath), rows }, null, 2), 'utf8');
  return { rowCount: rows.length, hash, importedAt };
});

ipcMain.handle('lowes:searchProduct', async (_e, request) => {
  const query = String(request?.query || '').trim();
  const storeId = String(request?.storeId || '').trim();
  const zipCode = String(request?.zipCode || '').trim();
  if (!query || !storeId || !zipCode) throw new Error('Material search text, Lowe\'s store number, and job ZIP are required.');

  // First search the authorized store feed. Prefer the requested store, then
  // ZIP, then unscoped rows, and rank by description-token overlap.
  const feed = readLowesFeed();
  const ranked = (feed.rows || []).map((row) => {
    const locality = String(row.storeId || '') === storeId ? 0.25 : String(row.zipCode || '') === zipCode ? 0.15 : (!row.storeId && !row.zipCode ? 0.05 : 0);
    return { row, score: searchScore(query, row.description || row.productId) + locality };
  }).filter((entry) => entry.score > 0.15).sort((a, b) => b.score - a.score);
  if (ranked.length) {
    const found = ranked[0].row;
    return {
      productId: String(found.productId),
      description: found.description || `Lowe's product ${found.productId}`,
      storeId,
      zipCode,
      sellingPrice: Number(found.sellingPrice),
      stock: found.stock,
      fetchedAt: feed.importedAt || new Date().toISOString(),
      sourceUrl: `Imported Lowe's store-price feed · SHA-256 ${feed.hash || 'unknown'}`,
      sourceMethod: 'lowes_store_feed',
      sourceHash: feed.hash || '',
      purchaseUnits: 0,
      packageCoverage: Number(found.packageCoverage || 0),
      packageCoverageUnit: found.packageCoverageUnit || '',
      packageDescription: found.packageDescription || '',
    };
  }

  const config = readSettings().lowes || {};
  if (!config.searchUrlTemplate) {
    throw new Error(`No matching Lowe's store-feed product was found for "${query}". Configure the authorized partner search URL template or let PAi keep the one-bracket speculative fallback.`);
  }
  const token = await lowesPartnerToken(config);
  const url = fillTemplate(config.searchUrlTemplate, { query, productId: '', storeId, zipCode });
  const response = await fetch(url, { headers: { Authorization: `Bearer ${token}`, Accept: 'application/json' } });
  if (!response.ok) throw new Error(`Lowe's partner search request failed (${response.status}).`);
  const found = extractLowesApiSearch(await response.json(), { query, storeId, zipCode });
  return {
    productId: found.productId,
    description: found.description,
    storeId,
    zipCode,
    sellingPrice: found.sellingPrice,
    stock: found.stock,
    fetchedAt: new Date().toISOString(),
    sourceUrl: url,
    sourceMethod: 'lowes_partner_api',
    purchaseUnits: 0,
    packageCoverage: found.packageCoverage,
    packageCoverageUnit: found.packageCoverageUnit,
    packageDescription: found.packageDescription,
  };
});

ipcMain.handle('lowes:lookupProduct', async (_e, request) => {
  const productId = String(request?.productId || '').trim();
  const storeId = String(request?.storeId || '').trim();
  const zipCode = String(request?.zipCode || '').trim();
  if (!productId || !storeId || !zipCode) throw new Error('Product ID, Lowe\'s store number, and job ZIP are required.');

  const feed = readLowesFeed();
  const productRows = (feed.rows || []).filter((row) => String(row.productId) === productId);
  let found = productRows.find((row) => String(row.storeId || '') === storeId);
  if (!found) found = productRows.find((row) => String(row.zipCode || '') === zipCode);
  if (!found) found = productRows.find((row) => !row.storeId && !row.zipCode);
  if (found) {
    return {
      productId,
      description: found.description || `Lowe's product ${productId}`,
      storeId,
      zipCode,
      sellingPrice: Number(found.sellingPrice),
      stock: found.stock,
      fetchedAt: feed.importedAt || new Date().toISOString(),
      sourceUrl: `Imported Lowe's store-price feed · SHA-256 ${feed.hash || 'unknown'}`,
      sourceMethod: 'lowes_store_feed',
      sourceHash: feed.hash || '',
      purchaseUnits: 0,
      packageCoverage: Number(found.packageCoverage || 0),
      packageCoverageUnit: found.packageCoverageUnit || '',
      packageDescription: found.packageDescription || '',
    };
  }

  const config = readSettings().lowes || {};
  if (!config.productUrlTemplate) {
    throw new Error(`Product ${productId} was not found for Store #${storeId}/ZIP ${zipCode} in the imported feed. Import a current authorized feed or configure the partner endpoint supplied with your Lowe's access.`);
  }
  const token = await lowesPartnerToken(config);
  const url = fillTemplate(config.productUrlTemplate, { productId, storeId, zipCode });
  const response = await fetch(url, { headers: { Authorization: `Bearer ${token}`, Accept: 'application/json' } });
  if (!response.ok) throw new Error(`Lowe's partner product request failed (${response.status}).`);
  const payload = await response.json();
  const price = extractLowesApiPrice(payload, { productId, storeId, zipCode });
  return {
    productId,
    description: price.description || `Lowe's product ${productId}`,
    storeId,
    zipCode,
    sellingPrice: price.sellingPrice,
    stock: price.stock,
    fetchedAt: new Date().toISOString(),
    sourceUrl: url,
    sourceMethod: 'lowes_partner_api',
    purchaseUnits: 0,
    packageCoverage: price.packageCoverage,
    packageCoverageUnit: price.packageCoverageUnit,
    packageDescription: price.packageDescription,
  };
});

ipcMain.handle('shell:revealClaim', (_e, root) => shell.openPath(root));

/** Real machine memory, so model recommendations are not guesses. */
ipcMain.handle('ai:machineInfo', () => {
  const os = require('os');
  return {
    totalRamGB: Math.round(os.totalmem() / 1024 ** 3),
    freeRamGB: Math.round(os.freemem() / 1024 ** 3),
    cpus: os.cpus().length,
    platform: process.platform,
    arch: process.arch,
  };
});

/* ------------------------------------------------------------ lifecycle */

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
});
