const assert = require('node:assert/strict');
const test = require('node:test');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { writeDecPagePdf } = require('./fixtures.cjs');
const DEC_PDF = writeDecPagePdf();
const { TextExtractor, parseTesseractTsv, ceilingFor, sha256, collapse,
        crossMethodBracket, verifyAgainstSource, modelReadBracket } = require('./ingestion.cjs');

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'pai-ingest-test-'));
const write = (name, content) => {
  const p = path.join(tmp, name);
  fs.writeFileSync(p, content);
  return p;
};

test('plain text extracts deterministically and may reach EXPLAINED', async () => {
  const p = write('a.txt', 'Coverage A - Dwelling  $312,000');
  const r = await new TextExtractor().extract(p);
  assert.equal(r.method, 'text');
  assert.match(r.text, /312,000/);
  assert.equal(r.bracketCeiling, 'EXPLAINED');
  assert.equal(r.needsVision, false);
});

test('csv rows are flattened with a separator', async () => {
  const p = write('b.csv', 'term,value\nCoverage A,312000');
  const r = await new TextExtractor().extract(p);
  assert.equal(r.method, 'delimited-text');
  assert.match(r.text, /Coverage A \| 312000/);
});

test('html tags are stripped', async () => {
  const p = write('c.html', '<html><body><p>Deductible &amp; basis</p></body></html>');
  const r = await new TextExtractor().extract(p);
  assert.match(r.text, /Deductible & basis/);
});

test('an unsupported type is handed to vision rather than raising', async () => {
  const p = write('d.heic', 'not really heic');
  const r = await new TextExtractor().extract(p);
  assert.equal(r.method, 'none');
  assert.equal(r.needsVision, true);
  assert.equal(r.bracketCeiling, 'UNVERIFIED');
});

test('an image with no OCR runtime is handed to vision, not failed', async () => {
  const p = write('e.png', Buffer.from([0x89, 0x50, 0x4e, 0x47]));
  const r = await new TextExtractor({ tesseract: null }).extract(p);
  assert.equal(r.needsVision, true);
  assert.equal(r.bracketCeiling, 'UNVERIFIED');
  assert.match(r.note, /local model/);
});

test('a PDF text layer is read per page with page markers', async () => {
  const r = await new TextExtractor().extract(DEC_PDF);
  assert.equal(r.method, 'pdf-text');
  assert.equal(r.pages, 1);
  assert.equal(r.ocrPages, 0);
  assert.match(r.text, /<<<PAGE 1>>>/);
  assert.match(r.text, /Coverage A - Dwelling \$312,000/);
  assert.match(r.text, /HO-04-90 04 91/);
  assert.equal(r.bracketCeiling, 'EXPLAINED');
});

test('tesseract TSV yields text and a mean confidence', () => {
  const tsv = [
    'level\tpage\tblock\tpar\tline\tword\tleft\ttop\twidth\theight\tconf\ttext',
    '5\t1\t1\t1\t1\t1\t0\t0\t10\t10\t96\tCoverage',
    '5\t1\t1\t1\t1\t2\t0\t0\t10\t10\t94\tA',
    '5\t1\t1\t1\t2\t1\t0\t0\t10\t10\t90\t$312,000',
    '4\t1\t1\t1\t2\t0\t0\t0\t0\t0\t-1\t',
  ].join('\n');
  const r = parseTesseractTsv(tsv);
  assert.equal(r.text, 'Coverage A\n$312,000');
  assert.ok(Math.abs(r.confidence - 0.9333) < 0.01);
});

test('the ceiling grades the ingest, not the reader', () => {
  assert.equal(ceilingFor('pdf-text', null), 'EXPLAINED');
  assert.equal(ceilingFor('pdf-text+tesseract', 0.95), 'EXPLAINED');
  assert.equal(ceilingFor('tesseract-ocr', 0.95), 'SPECULATIVE');
  assert.equal(ceilingFor('tesseract-ocr', 0.6), 'UNVERIFIED');
  assert.equal(ceilingFor('tesseract-ocr', 0.85), 'SPECULATIVE');
  assert.equal(ceilingFor('pdf-text', 0.85), 'SPECULATIVE');
});

test('pixels with no OCR beneath them stay speculative', () => {
  for (const c of [0.9, 0.99, null]) {
    assert.equal(ceilingFor('vision-model', c), 'SPECULATIVE');
  }
});

test('a model value found verbatim in the text inherits the ingest ceiling', () => {
  const source = '<<<PAGE 1>>>\nCoverage A - Dwelling $312,000\nDeductible $6,240';
  const r = modelReadBracket({
    reportedValue: '312000', sourceText: source, page: 1, method: 'pdf-text', confidence: null,
  });
  assert.equal(r.verbatim, true);
  assert.equal(r.bracket, 'EXPLAINED');
});

test('a model value absent from the text is derived, never transcribed', () => {
  const source = '<<<PAGE 1>>>\nCoverage A - Dwelling $312,000';
  const r = modelReadBracket({
    reportedValue: '78000', sourceText: source, page: 1, method: 'pdf-text', confidence: null,
  });
  assert.equal(r.verbatim, false);
  assert.equal(r.bracket, 'SPECULATIVE');
  assert.match(r.reason, /derived rather than read/);
});

test('a figure on another page does not pass as a reading of the cited page', () => {
  const source = '<<<PAGE 1>>>\nCoverage A $312,000\n\n<<<PAGE 2>>>\nCoverage B $31,200';
  assert.equal(verifyAgainstSource('31,200', source, 1).verbatim, false);
  assert.equal(verifyAgainstSource('31,200', source, 2).verbatim, true);
});

test('a verbatim value read from OCR text still caps at the OCR ceiling', () => {
  const source = '<<<PAGE 1>>>\nCoverage A $312,000';
  const r = modelReadBracket({
    reportedValue: '$312,000', sourceText: source, page: 1,
    method: 'tesseract-ocr', confidence: 0.95,
  });
  assert.equal(r.verbatim, true);
  assert.equal(r.bracket, 'SPECULATIVE');
});

test('text layer and OCR agreeing on a page is corroboration', () => {
  assert.equal(crossMethodBracket('$312,000', '312000', 0.95), 'VALIDATED');
  assert.equal(crossMethodBracket('$312,000', '$312,000', 0.6), 'EXPLAINED');
});

test('text layer and OCR disagreeing is a conflict, not a weak reading', () => {
  assert.equal(crossMethodBracket('$312,000', '$372,000', 0.95), 'CONTRADICTED');
});

test('formatting differences are not disagreements', () => {
  assert.equal(crossMethodBracket('$312,000', ' 312000 ', 0.99), 'VALIDATED');
});

test('content hashing is stable and distinguishes files', () => {
  const a = write('h1.txt', 'same');
  const b = write('h2.txt', 'same');
  const c = write('h3.txt', 'different');
  assert.equal(sha256(a), sha256(b));
  assert.notEqual(sha256(a), sha256(c));
  assert.equal(sha256(a).length, 64);
});

test('collapse normalises whitespace without eating content', () => {
  assert.equal(collapse('a  \t b\n\n\n\nc  '), 'a b\n\nc');
});

test('a shorter number never verifies against a longer one containing it', () => {
  const source = '<<<PAGE 1>>>\nCoverage A - Dwelling $312,000';
  // 31200 are literally the first digits of 312000.
  assert.equal(verifyAgainstSource('31,200', source, 1).verbatim, false);
  assert.equal(verifyAgainstSource('312,000', source, 1).verbatim, true);
  assert.equal(verifyAgainstSource('12,000', source, 1).verbatim, false);
});

test('multi-token values verify as a run', () => {
  const source = '<<<PAGE 1>>>\nPolicy Period: 01/01/2026 to 01/01/2027';
  assert.equal(verifyAgainstSource('01/01/2026 to 01/01/2027', source, 1).verbatim, true);
  assert.equal(verifyAgainstSource('01/01/2026 to 01/01/2028', source, 1).verbatim, false);
});

test('a real dec page PDF supports verbatim verification end to end', async () => {
  const r = await new TextExtractor().extract(DEC_PDF);
  const covA = modelReadBracket({
    reportedValue: '$312,000', sourceText: r.text, page: 1,
    method: r.method, confidence: r.confidence,
  });
  assert.equal(covA.verbatim, true);
  assert.equal(covA.bracket, 'EXPLAINED');

  // The ordinance & law allowance is nowhere on this page; a model offering
  // one has computed it.
  const ordLaw = modelReadBracket({
    reportedValue: '$78,000', sourceText: r.text, page: 1,
    method: r.method, confidence: r.confidence,
  });
  assert.equal(ordLaw.verbatim, false);
  assert.equal(ordLaw.bracket, 'SPECULATIVE');
});

const { resolveDiscrepancy, differsOnlyByOcrConfusion, occurrenceCount } = require('./ingestion.cjs');

test('agreement resolves as corroboration', () => {
  const r = resolveDiscrepancy({
    label: 'Coverage A', textLayerValue: '$312,000', ocrValue: '312000',
    ocrConfidence: 0.95, fullText: '<<<PAGE 1>>>\nCoverage A $312,000', page: 1,
  });
  assert.equal(r.resolved, true);
  assert.equal(r.bracket, 'VALIDATED');
});

test('corroboration elsewhere in the document settles a disagreement', () => {
  const full = '<<<PAGE 1>>>\nCoverage A $312,000\n\n<<<PAGE 2>>>\nDwelling limit $312,000\n\n<<<PAGE 3>>>\nSchedule: $312,000';
  const r = resolveDiscrepancy({
    label: 'Coverage A', textLayerValue: '$312,000', ocrValue: '$372,000',
    ocrConfidence: 0.95, fullText: full, page: 1,
  });
  assert.equal(r.resolved, true);
  assert.equal(r.value, '$312,000');
  assert.equal(r.bracket, 'EXPLAINED');
  assert.match(r.reason, /appears 3 times/);
});

test('a difference confined to OCR-confusable characters resolves to the text layer', () => {
  const r = resolveDiscrepancy({
    label: 'Policy number', textLayerValue: 'HO3-9941208', ocrValue: 'H03-9941208',
    ocrConfidence: 0.95, fullText: '<<<PAGE 1>>>\nHO3-9941208', page: 1,
  });
  assert.equal(r.resolved, true);
  assert.equal(r.value, 'HO3-9941208');
  assert.match(r.reason, /commonly misreads/);
});

test('low-confidence OCR cannot contradict a clean text layer', () => {
  const r = resolveDiscrepancy({
    label: 'Deductible', textLayerValue: '$6,240', ocrValue: '$9,240',
    ocrConfidence: 0.55, fullText: '<<<PAGE 1>>>\n$6,240', page: 1,
  });
  assert.equal(r.resolved, true);
  assert.equal(r.value, '$6,240');
  assert.match(r.reason, /55%/);
});

test('a genuine unresolvable disagreement goes to the user, not to a figure', () => {
  const r = resolveDiscrepancy({
    label: 'Coverage A', textLayerValue: '$312,000', ocrValue: '$412,000',
    ocrConfidence: 0.96, fullText: '<<<PAGE 1>>>\nCoverage A $312,000', page: 1,
  });
  assert.equal(r.resolved, false);
  assert.equal(r.bracket, 'CONTRADICTED');
  assert.equal(r.value, null);
  assert.match(r.userAction, /page 1/);
  assert.match(r.userAction, /will not be used in any figure/);
  assert.equal(r.candidates.length, 2);
});

test('an unresolved conflict never averages or picks a winner', () => {
  const r = resolveDiscrepancy({
    label: 'Coverage A', textLayerValue: '$300,000', ocrValue: '$400,000',
    ocrConfidence: 0.98, fullText: '<<<PAGE 1>>>\nCoverage A $300,000', page: 1,
  });
  assert.equal(r.value, null);
  assert.ok(!/350,?000/.test(JSON.stringify(r)));
});

test('OCR confusion detection requires same length and known pairs only', () => {
  assert.equal(differsOnlyByOcrConfusion('h03', 'ho3'), true);
  assert.equal(differsOnlyByOcrConfusion('312000', '412000'), false);
  assert.equal(differsOnlyByOcrConfusion('312000', '3120000'), false);
  assert.equal(differsOnlyByOcrConfusion('312000', '312000'), false);
});

test('occurrences are counted per page, not per repetition on a page', () => {
  const full = '<<<PAGE 1>>>\n$312,000 $312,000\n\n<<<PAGE 2>>>\n$312,000';
  assert.equal(occurrenceCount(full, '$312,000'), 2);
  assert.equal(occurrenceCount(full, '$999'), 0);
});

test('a missing read is unresolved, not silently the other one', () => {
  const r = resolveDiscrepancy({
    label: 'Coverage A', textLayerValue: '$312,000', ocrValue: '',
    ocrConfidence: 0.9, fullText: '<<<PAGE 1>>>\nCoverage A $312,000', page: 1,
  });
  assert.equal(r.resolved, false);
  assert.equal(r.bracket, 'UNVERIFIED');
});

test('an explicit null tesseract means no OCR, not "go find one"', () => {
  const withoutOcr = new TextExtractor({ tesseract: null });
  assert.equal(withoutOcr.ocrAvailable, false);
  // Omitting the option still discovers whatever the machine has.
  const discovered = new TextExtractor();
  assert.equal(typeof discovered.ocrAvailable, 'boolean');
});

test('an image on a machine without OCR is handed to vision regardless of what is installed', async () => {
  const fs2 = require('node:fs');
  const os2 = require('node:os');
  const path2 = require('node:path');
  const dir = fs2.mkdtempSync(path2.join(os2.tmpdir(), 'pai-img-'));
  const img = path2.join(dir, 'scan.png');
  fs2.writeFileSync(img, Buffer.from([0x89, 0x50, 0x4e, 0x47]));
  const r = await new TextExtractor({ tesseract: null }).extract(img);
  assert.equal(r.needsVision, true);
  assert.equal(r.bracketCeiling, 'UNVERIFIED');
  assert.match(r.note, /local model/);
});
