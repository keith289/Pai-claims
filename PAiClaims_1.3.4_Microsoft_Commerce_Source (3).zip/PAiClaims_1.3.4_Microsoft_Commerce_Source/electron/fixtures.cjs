'use strict';

/**
 * Test fixtures generated at run time.
 *
 * Nothing here may depend on a path outside the repository: a test that reads
 * from a machine-specific location passes for whoever wrote it and fails for
 * everyone else.
 */

const fs = require('fs');
const os = require('os');
const path = require('path');

/**
 * A minimal single-page PDF with a real text layer, built by hand so no
 * generator dependency is needed. Contents mirror a declarations page.
 */
function decPagePdf() {
  const lines = [
    'HOMEOWNERS DECLARATIONS',
    'Policy Number: HO3-9941208',
    'Coverage A - Dwelling  $312,000',
    'Deductible  $6,240  (2% Named Storm)',
    'Policy Period: 01/01/2026 to 01/01/2027',
    'Forms and Endorsements: HO-00-03 04 91, HO-04-90 04 91',
  ];
  const escape = (s) => s.replace(/([()\\])/g, '\\$1');
  const content =
    'BT\n/F1 12 Tf\n' +
    lines
      .map((line, i) => `1 0 0 1 72 ${760 - i * 20} Tm (${escape(line)}) Tj`)
      .join('\n') +
    '\nET\n';

  const objects = [
    '<< /Type /Catalog /Pages 2 0 R >>',
    '<< /Type /Pages /Kids [3 0 R] /Count 1 >>',
    '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>',
    '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>',
    `<< /Length ${Buffer.byteLength(content)} >>\nstream\n${content}\nendstream`,
  ];

  let pdf = '%PDF-1.4\n';
  const offsets = [];
  objects.forEach((body, i) => {
    offsets.push(Buffer.byteLength(pdf));
    pdf += `${i + 1} 0 obj\n${body}\nendobj\n`;
  });
  const xref = Buffer.byteLength(pdf);
  pdf += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`;
  for (const offset of offsets) pdf += `${String(offset).padStart(10, '0')} 00000 n \n`;
  pdf += `trailer\n<< /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF\n`;
  return Buffer.from(pdf, 'latin1');
}

/** Write the fixture into a fresh temp directory and return its path. */
function writeDecPagePdf() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'pai-fixture-'));
  const file = path.join(dir, 'dec.pdf');
  fs.writeFileSync(file, decPagePdf());
  return file;
}

module.exports = { decPagePdf, writeDecPagePdf };
