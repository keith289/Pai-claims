const { execFile } = require('child_process');
const fs = require('fs');
const path = require('path');

function helperPath() {
  if (process.platform !== 'win32') return '';
  const devPath = path.join(__dirname, '..', 'store-bridge', 'bin', 'PAiClaims.StoreBridge.exe');
  const packagedPath = path.join(process.resourcesPath || '', 'storebridge', 'PAiClaims.StoreBridge.exe');
  return fs.existsSync(packagedPath) ? packagedPath : fs.existsSync(devPath) ? devPath : '';
}

function nativeHwndHex(browserWindow) {
  if (!browserWindow || browserWindow.isDestroyed()) return '0';
  const buffer = browserWindow.getNativeWindowHandle();
  if (!buffer || buffer.length < 4) return '0';
  let value;
  if (buffer.length >= 8 && typeof buffer.readBigUInt64LE === 'function') value = buffer.readBigUInt64LE(0);
  else value = BigInt(buffer.readUInt32LE(0));
  return `0x${value.toString(16)}`;
}

function runBridge(browserWindow, command, options = {}, timeoutMs = 45000) {
  const exe = helperPath();
  if (!exe) {
    return Promise.resolve({
      ok: false,
      available: false,
      error: process.platform === 'win32'
        ? 'Microsoft Store commerce bridge is not built yet.'
        : 'Microsoft Store commerce is available only in the Windows Store build.',
    });
  }

  const args = ['--command', command, '--hwnd', nativeHwndHex(browserWindow)];
  for (const [key, value] of Object.entries(options)) {
    if (value === undefined || value === null || value === '') continue;
    args.push(`--${key}`, String(value));
  }

  return new Promise((resolve, reject) => {
    execFile(exe, args, { windowsHide: true, timeout: timeoutMs, maxBuffer: 1024 * 1024 }, (error, stdout, stderr) => {
      const lines = String(stdout || '').trim().split(/\r?\n/).filter(Boolean);
      let payload = null;
      for (let i = lines.length - 1; i >= 0; i--) {
        try { payload = JSON.parse(lines[i]); break; } catch {}
      }
      if (payload) return resolve(payload);
      if (error) return reject(new Error(String(stderr || error.message || 'Microsoft Store bridge failed.').trim()));
      return reject(new Error('Microsoft Store bridge returned no readable response.'));
    });
  });
}

module.exports = {
  helperPath,
  nativeHwndHex,
  runBridge,
  getState: (window) => runBridge(window, 'state'),
  purchase: (window, productId) => runBridge(window, 'purchase', { product: productId }, 120000),
  consume: (window, productId, trackingId, quantity = 1) => runBridge(window, 'consume', {
    product: productId,
    tracking: trackingId,
    quantity,
  }, 60000),
};
