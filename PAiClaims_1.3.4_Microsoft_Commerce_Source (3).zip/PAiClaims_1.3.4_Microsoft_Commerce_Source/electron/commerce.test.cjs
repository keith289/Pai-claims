const test = require('node:test');
const assert = require('node:assert/strict');

const {
  PRODUCTS,
  emptyLedger,
  offerFor,
  accessFor,
  recordRedemption,
} = require('./commerce.cjs');

const NOW = Date.parse('2026-08-30T12:00:00.000Z');
const WORKSPACE = 'workspace-hash';

test('first locked workspace receives the $20 first-case offer', () => {
  const offer = offerFor(emptyLedger(), WORKSPACE, {}, NOW);
  assert.equal(offer.access.allowed, false);
  assert.equal(offer.caseOffer.productId, PRODUCTS.firstCase);
  assert.equal(offer.caseOffer.priceUsd, 20);
});

test('a case code permanently unlocks only the selected workspace', () => {
  const ledger = recordRedemption(emptyLedger(), {
    code: 'PAI-ABCD-1234',
    productId: PRODUCTS.firstCase,
    workspaceHash: WORKSPACE,
    now: NOW,
  });
  assert.equal(accessFor(ledger, WORKSPACE, NOW).allowed, true);
  assert.equal(accessFor(ledger, 'another-workspace', NOW).allowed, false);
  assert.equal(offerFor(ledger, 'another-workspace', {}, NOW).caseOffer.priceUsd, 179);
  assert.equal(JSON.stringify(ledger).includes('PAI-ABCD-1234'), false);
  assert.equal(accessFor(ledger, WORKSPACE, NOW).complimentaryPaiLegalCase?.caseCount, 1);
  assert.deepEqual(accessFor(ledger, WORKSPACE, NOW).complimentaryPaiLegalCase?.features, ['pai-case-file-creator', 'psi-legal-data']);
});

test('only the $20 first-case purchase includes the complimentary PAi Legal case', () => {
  const firstLedger = recordRedemption(emptyLedger(), {
    code: 'PAI-FREE-0001', productId: PRODUCTS.firstCase, workspaceHash: 'first', now: NOW,
  });
  const laterLedger = recordRedemption(firstLedger, {
    code: 'PAI-PAID-0002', productId: PRODUCTS.singleCase, workspaceHash: 'later', now: NOW,
  });
  const annualLedger = recordRedemption(laterLedger, {
    code: 'PAI-YEAR-0003', productId: PRODUCTS.annual, workspaceHash: 'annual', now: NOW,
  });

  assert.equal(accessFor(annualLedger, 'first', NOW).complimentaryPaiLegalCase?.included, true);
  assert.equal(accessFor(annualLedger, 'later', NOW).complimentaryPaiLegalCase, null);
  assert.equal(accessFor(annualLedger, 'annual', NOW).complimentaryPaiLegalCase, null);
});

test('an annual code defaults to 365 days and then becomes read-only', () => {
  const ledger = recordRedemption(emptyLedger(), {
    code: 'PAI-WXYZ-9876',
    productId: PRODUCTS.annual,
    workspaceHash: WORKSPACE,
    verification: {},
    now: NOW,
  });
  assert.equal(accessFor(ledger, WORKSPACE, NOW + 364 * 86400000).allowed, true);
  const expired = accessFor(ledger, WORKSPACE, NOW + 366 * 86400000);
  assert.equal(expired.allowed, false);
  assert.equal(expired.readOnly, true);
  assert.equal(expired.mode, 'annual-expired');
});

test('a redeemed code hash cannot be reused on the same installation', () => {
  const ledger = recordRedemption(emptyLedger(), {
    code: 'PAI-ABCD-1234',
    productId: PRODUCTS.firstCase,
    workspaceHash: WORKSPACE,
    now: NOW,
  });
  assert.throws(() => recordRedemption(ledger, {
    code: 'pai abcd 1234',
    productId: PRODUCTS.singleCase,
    workspaceHash: 'another-workspace',
    now: NOW,
  }), /already been redeemed/);
});
