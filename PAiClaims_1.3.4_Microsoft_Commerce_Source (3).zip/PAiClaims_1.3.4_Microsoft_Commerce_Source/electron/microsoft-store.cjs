const crypto = require('crypto');
const {
  PRODUCTS,
  canonicalStoreProductId,
  sanitizeLedger,
  accessFor,
  offerFor,
} = require('./commerce.cjs');

function indexStoreState(state) {
  const products = {};
  const licenses = {};
  for (const row of Array.isArray(state?.products) ? state.products : []) {
    const storeProductId = String(row?.productId || '').trim().toLowerCase();
    const id = canonicalStoreProductId(storeProductId);
    if (id) products[id] = { ...row, productId: id, storeProductId };
  }
  for (const row of Array.isArray(state?.licenses) ? state.licenses : []) {
    const storeProductId = String(row?.productId || '').trim().toLowerCase();
    const id = canonicalStoreProductId(storeProductId);
    if (id) licenses[id] = { ...row, productId: id, storeProductId };
  }
  return { products, licenses };
}

function syncAnnualFromStore(ledgerValue, state, now = Date.now()) {
  const ledger = sanitizeLedger(ledgerValue);
  const { products, licenses } = indexStoreState(state);
  const license = licenses[PRODUCTS.annual];
  const product = products[PRODUCTS.annual];
  if (!license) return ledger;

  const expiryMs = Date.parse(String(license.expirationUtc || ''));
  const expiresAt = Number.isFinite(expiryMs)
    ? new Date(expiryMs).toISOString()
    : ledger.annual?.expiresAt || new Date(now + 365 * 86400000).toISOString();

  // Preserve the last Microsoft subscription observation even after expiry so
  // workspaces created under annual access can correctly fall back to read-only.
  ledger.annual = {
    productId: PRODUCTS.annual,
    source: 'microsoft-store',
    storeId: String(license.storeId || product?.storeId || ledger.annual?.storeId || ''),
    activatedAt: ledger.annual?.source === 'microsoft-store'
      ? ledger.annual.activatedAt
      : new Date(now).toISOString(),
    expiresAt,
    lastStoreSyncAt: new Date(now).toISOString(),
    storeActive: Boolean(license.active),
  };
  return ledger;
}

function recordStoreCaseUnlock(ledgerValue, {
  productId,
  workspaceHash,
  storeId = '',
  trackingId = '',
  now = Date.now(),
}) {
  if (![PRODUCTS.firstCase, PRODUCTS.singleCase].includes(productId)) {
    throw new Error('This Microsoft Store product is not a PAi Claims case entitlement.');
  }
  const ledger = sanitizeLedger(ledgerValue);
  ledger.caseUnlocks[workspaceHash] = {
    productId,
    source: 'microsoft-store',
    storeId: String(storeId || ''),
    trackingId: String(trackingId || ''),
    activatedAt: new Date(now).toISOString(),
    ...(productId === PRODUCTS.firstCase ? {
      complimentaryPaiLegalCase: {
        included: true,
        caseCount: 1,
        grantedAt: new Date(now).toISOString(),
        sourceProductId: PRODUCTS.firstCase,
        features: ['pai-case-file-creator', 'psi-legal-data'],
      },
    } : {}),
  };
  return ledger;
}

function ensurePendingFulfillment(ledgerValue, workspaceHash, productId = PRODUCTS.singleCase) {
  const ledger = sanitizeLedger(ledgerValue);
  const current = ledger.store.pendingFulfillment;
  if (current && current.workspaceHash === workspaceHash && current.productId === productId && current.trackingId) {
    return { ledger, trackingId: current.trackingId };
  }
  const trackingId = crypto.randomUUID();
  ledger.store.pendingFulfillment = {
    workspaceHash,
    productId,
    trackingId,
    createdAt: new Date().toISOString(),
  };
  return { ledger, trackingId };
}

function clearPendingFulfillment(ledgerValue, trackingId) {
  const ledger = sanitizeLedger(ledgerValue);
  if (!trackingId || ledger.store.pendingFulfillment?.trackingId === trackingId) {
    ledger.store.pendingFulfillment = null;
  }
  return ledger;
}

function markPendingFirstCase(ledgerValue, workspaceHash) {
  const ledger = sanitizeLedger(ledgerValue);
  ledger.store.pendingFirstCase = {
    workspaceHash,
    createdAt: new Date().toISOString(),
  };
  return ledger;
}

function clearPendingFirstCase(ledgerValue, workspaceHash) {
  const ledger = sanitizeLedger(ledgerValue);
  if (!workspaceHash || ledger.store.pendingFirstCase?.workspaceHash === workspaceHash) {
    ledger.store.pendingFirstCase = null;
  }
  return ledger;
}

function microsoftOffer(ledgerValue, workspaceHash, state, now = Date.now()) {
  const ledger = syncAnnualFromStore(ledgerValue, state, now);
  let base = offerFor(ledger, workspaceHash, {}, now);
  const { products, licenses } = indexStoreState(state);

  // The introductory product is a forever Durable. That makes it a useful
  // Microsoft-account marker: on a fresh installation, an already-owned
  // durable means the introductory purchase has happened before. Do not offer
  // another $20 first case unless this installation recorded the purchase as
  // pending for this exact workspace before the Store UI opened.
  const firstOwned = Boolean(licenses[PRODUCTS.firstCase]?.active || products[PRODUCTS.firstCase]?.inUserCollection);
  const firstBoundLocally = Object.values(ledger.caseUnlocks).some((unlock) => unlock?.productId === PRODUCTS.firstCase);
  const pendingThisWorkspace = ledger.store.pendingFirstCase?.workspaceHash === workspaceHash;
  if (base.caseOffer.productId === PRODUCTS.firstCase && firstOwned && !firstBoundLocally && !pendingThisWorkspace) {
    base = {
      ...base,
      firstCaseUsed: true,
      caseOffer: { productId: PRODUCTS.singleCase, priceUsd: 179, checkoutUrl: '' },
    };
  }

  const caseProduct = products[base.caseOffer.productId] || {};
  const caseLicense = licenses[base.caseOffer.productId] || {};
  const annualProduct = products[PRODUCTS.annual] || {};
  const annualLicense = licenses[PRODUCTS.annual] || {};
  const singleProduct = products[PRODUCTS.singleCase] || {};

  return {
    ...base,
    store: {
      available: state?.available === true && state?.ok !== false,
      error: String(state?.error || ''),
      lastSyncAt: String(state?.timestampUtc || ''),
    },
    caseOffer: {
      ...base.caseOffer,
      storeId: String(caseProduct.storeId || caseLicense.storeId || ''),
      formattedPrice: String(caseProduct.formattedPrice || `$${base.caseOffer.priceUsd}`),
      owned: Boolean(caseLicense.active || caseProduct.inUserCollection),
      balance: Number(caseProduct.balance || 0),
      purchasable: Boolean(caseProduct.storeId),
    },
    annualOffer: {
      ...base.annualOffer,
      storeId: String(annualProduct.storeId || annualLicense.storeId || ''),
      formattedPrice: String(annualProduct.formattedPrice || `$${base.annualOffer.priceUsd.toLocaleString()} / year`),
      active: Boolean(annualLicense.active),
      expiresAt: String(annualLicense.expirationUtc || ''),
      purchasable: Boolean(annualProduct.storeId),
    },
    singleCaseBalance: Number(singleProduct.balance || 0),
    ledger,
  };
}

module.exports = {
  indexStoreState,
  syncAnnualFromStore,
  recordStoreCaseUnlock,
  ensurePendingFulfillment,
  clearPendingFulfillment,
  markPendingFirstCase,
  clearPendingFirstCase,
  microsoftOffer,
};
