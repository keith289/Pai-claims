const test = require('node:test');
const assert = require('node:assert/strict');

const { PRODUCTS, STORE_PRODUCT_ALIASES, emptyLedger, accessFor } = require('./commerce.cjs');
const {
  indexStoreState,
  syncAnnualFromStore,
  recordStoreCaseUnlock,
  ensurePendingFulfillment,
  clearPendingFulfillment,
  markPendingFirstCase,
  microsoftOffer,
} = require('./microsoft-store.cjs');

const NOW = Date.parse('2026-08-30T12:00:00.000Z');

function state({ first = false, singleBalance = 0, annual = false } = {}) {
  return {
    ok: true,
    available: true,
    timestampUtc: new Date(NOW).toISOString(),
    products: [
      { productId: PRODUCTS.firstCase, storeId: 'FIRSTSTORE01', kind: 'Durable', formattedPrice: '$20.00', inUserCollection: first, balance: 0 },
      { productId: PRODUCTS.singleCase, storeId: 'SINGLESTORE1', kind: 'Consumable', formattedPrice: '$179.00', inUserCollection: singleBalance > 0, balance: singleBalance },
      { productId: PRODUCTS.annual, storeId: 'ANNUALSTORE1', kind: 'Durable', formattedPrice: '$2,000.00', inUserCollection: annual, balance: 0 },
    ],
    licenses: [
      ...(first ? [{ productId: PRODUCTS.firstCase, storeId: 'FIRSTSTORE01', active: true, expirationUtc: '9999-12-31T23:59:59.000Z' }] : []),
      ...(annual ? [{ productId: PRODUCTS.annual, storeId: 'ANNUALSTORE1', active: true, expirationUtc: '2027-08-30T12:00:00.000Z' }] : []),
    ],
  };
}


test('submitted first-case GUID is normalized to the canonical PAi first-case entitlement', () => {
  const firstGuid = STORE_PRODUCT_ALIASES[PRODUCTS.firstCase].find((id) => id !== PRODUCTS.firstCase);
  const raw = state();
  raw.products[0] = { ...raw.products[0], productId: firstGuid, inUserCollection: true };
  raw.licenses.push({ productId: firstGuid, storeId: 'FIRSTSTORE01', active: true, expirationUtc: '9999-12-31T23:59:59.000Z' });
  const indexed = indexStoreState(raw);
  assert.equal(indexed.products[PRODUCTS.firstCase].storeProductId, firstGuid);
  assert.equal(indexed.licenses[PRODUCTS.firstCase].storeProductId, firstGuid);
  const offer = microsoftOffer(emptyLedger(), 'fresh-device', raw, NOW);
  assert.equal(offer.caseOffer.productId, PRODUCTS.singleCase);
});

test('Microsoft first-case durable can be bound when this workspace started the purchase', () => {
  const pending = markPendingFirstCase(emptyLedger(), 'w1');
  const offer = microsoftOffer(pending, 'w1', state({ first: true }), NOW);
  assert.equal(offer.caseOffer.productId, PRODUCTS.firstCase);
  assert.equal(offer.caseOffer.owned, true);
  assert.equal(offer.caseOffer.formattedPrice, '$20.00');
});



test('already-owned first-case durable marks intro offer as used on a fresh installation', () => {
  const offer = microsoftOffer(emptyLedger(), 'new-device-workspace', state({ first: true }), NOW);
  assert.equal(offer.caseOffer.productId, PRODUCTS.singleCase);
  assert.equal(offer.caseOffer.formattedPrice, '$179.00');
});

test('pending first-case purchase can still bind its original workspace after Store license appears', () => {
  const pending = markPendingFirstCase(emptyLedger(), 'w-pending');
  const offer = microsoftOffer(pending, 'w-pending', state({ first: true }), NOW);
  assert.equal(offer.caseOffer.productId, PRODUCTS.firstCase);
  assert.equal(offer.caseOffer.owned, true);
});
test('binding Microsoft first case unlocks only that workspace and preserves PAi Legal bonus', () => {
  const ledger = recordStoreCaseUnlock(emptyLedger(), {
    productId: PRODUCTS.firstCase,
    workspaceHash: 'w1',
    storeId: 'FIRSTSTORE01',
    now: NOW,
  });
  assert.equal(accessFor(ledger, 'w1', NOW).allowed, true);
  assert.equal(accessFor(ledger, 'w2', NOW).allowed, false);
  assert.equal(accessFor(ledger, 'w1', NOW).complimentaryPaiLegalCase?.caseCount, 1);
  assert.equal(ledger.caseUnlocks.w1.source, 'microsoft-store');
});

test('additional-case balance is surfaced without storing payment credentials', () => {
  let ledger = recordStoreCaseUnlock(emptyLedger(), {
    productId: PRODUCTS.firstCase,
    workspaceHash: 'w1',
    storeId: 'FIRSTSTORE01',
    now: NOW,
  });
  const offer = microsoftOffer(ledger, 'w2', state({ first: true, singleBalance: 2 }), NOW);
  assert.equal(offer.caseOffer.productId, PRODUCTS.singleCase);
  assert.equal(offer.caseOffer.balance, 2);
  assert.equal(offer.caseOffer.formattedPrice, '$179.00');
});

test('fulfillment tracking id is stable across retries until cleared', () => {
  const first = ensurePendingFulfillment(emptyLedger(), 'w2');
  const second = ensurePendingFulfillment(first.ledger, 'w2');
  assert.equal(first.trackingId, second.trackingId);
  const cleared = clearPendingFulfillment(second.ledger, first.trackingId);
  assert.equal(cleared.store.pendingFulfillment, null);
});

test('active Microsoft annual license opens locked workspace and records expiry', () => {
  const synced = syncAnnualFromStore(emptyLedger(), state({ annual: true }), NOW);
  const access = accessFor(synced, 'new-workspace', NOW);
  assert.equal(access.allowed, true);
  assert.equal(access.mode, 'annual');
  assert.equal(access.expiresAt, '2027-08-30T12:00:00.000Z');
  assert.equal(synced.annual.source, 'microsoft-store');
});
