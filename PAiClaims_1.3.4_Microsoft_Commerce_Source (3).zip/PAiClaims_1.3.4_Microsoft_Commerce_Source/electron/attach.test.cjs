const assert = require('node:assert/strict');
const test = require('node:test');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

// The attach + evidence logic lives inside main.cjs, which pulls in electron.
// Exercise the same contract through ingestion plus a local copy of the
// storage steps, so the guarantees are pinned without launching Electron.
const { writeDecPagePdf } = require('./fixtures.cjs');
const DEC_PDF = writeDecPagePdf();
const { TextExtractor, sha256 } = require('./ingestion.cjs');

async function attach({ root, kind, filename, dataBase64 }) {
  if (!root || !fs.existsSync(root)) throw new Error('Case folder not found.');
  const safeName = String(filename || 'document').replace(/[\\/:*?"<>|]/g, '_').slice(0, 180);
  if (!safeName.trim()) throw new Error('That file has no usable name.');
  const uploads = path.join(root, 'uploads');
  fs.mkdirSync(uploads, { recursive: true });
  let target = path.join(uploads, safeName);
  let counter = 1;
  while (fs.existsSync(target)) {
    const ext = path.extname(safeName);
    target = path.join(uploads, `${path.basename(safeName, ext)} (${counter})${ext}`);
    counter += 1;
  }
  fs.writeFileSync(target, Buffer.from(String(dataBase64 || ''), 'base64'));
  const contentHash = sha256(target);
  let duplicateOf = null;
  for (const existing of fs.readdirSync(uploads)) {
    const candidate = path.join(uploads, existing);
    if (candidate === target) continue;
    if (fs.statSync(candidate).isFile() && sha256(candidate) === contentHash) {
      duplicateOf = existing;
      break;
    }
  }
  // Mirrors main.cjs: a file we cannot read is still a file on the case.
  // Extraction failure degrades the record, it does not reject the document.
  let extraction;
  try {
    extraction = await new TextExtractor().extract(target);
  } catch (err) {
    extraction = {
      text: '', method: 'none', pages: 0, ocrPages: 0, confidence: null,
      bracketCeiling: 'UNVERIFIED', needsVision: true,
      note: `Extraction failed: ${err.message}`,
    };
  }
  return { storedPath: target, filename: path.basename(target), kind, contentHash, duplicateOf, ...extraction };
}

const mkRoot = () => fs.mkdtempSync(path.join(os.tmpdir(), 'pai-case-'));
const b64 = (p) => fs.readFileSync(p).toString('base64');

test('an attached policy is copied into the case uploads folder', async () => {
  const root = mkRoot();
  const r = await attach({ root, kind: 'policy_dec', filename: 'dec.pdf', dataBase64: b64(DEC_PDF) });
  assert.ok(fs.existsSync(r.storedPath));
  assert.equal(path.basename(path.dirname(r.storedPath)), 'uploads');
  assert.equal(fs.readFileSync(r.storedPath).length, fs.statSync(DEC_PDF).size);
});

test('the stored copy is hashed and the text layer is read', async () => {
  const root = mkRoot();
  const r = await attach({ root, kind: 'policy_dec', filename: 'dec.pdf', dataBase64: b64(DEC_PDF) });
  assert.equal(r.contentHash.length, 64);
  assert.equal(r.contentHash, sha256(DEC_PDF));
  assert.equal(r.method, 'pdf-text');
  assert.match(r.text, /Coverage A - Dwelling \$312,000/);
  assert.equal(r.bracketCeiling, 'EXPLAINED');
});

test('the same bytes under a different name are flagged, not counted twice', async () => {
  const root = mkRoot();
  await attach({ root, kind: 'policy_dec', filename: 'dec.pdf', dataBase64: b64(DEC_PDF) });
  const second = await attach({ root, kind: 'policy_dec', filename: 'policy-copy.pdf', dataBase64: b64(DEC_PDF) });
  assert.equal(second.duplicateOf, 'dec.pdf');
});

test('a name collision does not overwrite the earlier file', async () => {
  const root = mkRoot();
  const a = await attach({ root, kind: 'policy_dec', filename: 'dec.pdf', dataBase64: Buffer.from('first').toString('base64') });
  const b = await attach({ root, kind: 'policy_dec', filename: 'dec.pdf', dataBase64: Buffer.from('second').toString('base64') });
  assert.notEqual(a.storedPath, b.storedPath);
  assert.equal(fs.readFileSync(a.storedPath, 'utf8'), 'first');
  assert.equal(fs.readFileSync(b.storedPath, 'utf8'), 'second');
});

test('path separators in a supplied name cannot escape the uploads folder', async () => {
  const root = mkRoot();
  const uploads = path.resolve(root, 'uploads');
  for (const hostile of ['../../evil.pdf', '..\\..\\evil.pdf', 'C:\\Windows\\evil.pdf', '/etc/passwd']) {
    const r = await attach({ root, kind: 'policy_dec', filename: hostile, dataBase64: Buffer.from('x').toString('base64') });
    // Containment is what matters, not whether dots survive in the name.
    assert.ok(
      path.resolve(r.storedPath).startsWith(uploads + path.sep),
      `${hostile} escaped to ${r.storedPath}`,
    );
    assert.equal(path.dirname(path.resolve(r.storedPath)), uploads);
  }
});

test('attaching to a folder that does not exist fails rather than writing elsewhere', async () => {
  await assert.rejects(
    () => attach({ root: '/nonexistent/case', kind: 'policy_dec', filename: 'a.pdf', dataBase64: 'eA==' }),
    /Case folder not found/,
  );
});

test('a file that cannot be parsed is still stored and handed to vision', async () => {
  const root = mkRoot();
  const r = await attach({
    root, kind: 'policy_dec', filename: 'corrupt.pdf',
    dataBase64: Buffer.from('this is not a pdf').toString('base64'),
  });
  assert.ok(fs.existsSync(r.storedPath), 'the document must survive a failed read');
  assert.equal(r.method, 'none');
  assert.equal(r.needsVision, true);
  assert.equal(r.bracketCeiling, 'UNVERIFIED');
  assert.match(r.note, /Extraction failed/);
  assert.equal(r.contentHash.length, 64);
});
