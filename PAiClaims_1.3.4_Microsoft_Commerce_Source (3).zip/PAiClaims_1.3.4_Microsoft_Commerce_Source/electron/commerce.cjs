const crypto = require('crypto');
const path = require('path');

const PRODUCTS = Object.freeze({
  firstCase: 'pai-claims-first-case',
  singleCase: 'pai-claims-single-case',
  annual: 'pai-claims-annual',
});

// The first add-on that is already submitted in Partner Center is shown in the
// user's dashboard with this GUID identifier. Keep the canonical PAi ID for
// ledgers/recovery codes, but accept either identifier from Microsoft Store.
const STORE_PRODUCT_ALIASES = Object.freeze({
  [PRODUCTS.firstCase]: Object.freeze([
    PRODUCTS.firstCase,
    'daa1e8b9-d3d8-4d66-aaae-4fdc5fcedd53',
  ]),
  [PRODUCTS.singleCase]: Object.freeze([PRODUCTS.singleCase]),
  [PRODUCTS.annual]: Object.freeze([PRODUCTS.annual]),
});

function canonicalStoreProductId(value) {
  const id = String(value || '').trim().toLowerCase();
  for (const [canonical, aliases] of Object.entries(STORE_PRODUCT_ALIASES)) {
    if (aliases.includes(id)) return canonical;
  }
  return id;
}

function storeProductAliases(productId) {
  const canonical = canonicalStoreProductId(productId);
  return STORE_PRODUCT_ALIASES[canonical] || Object.freeze([canonical]);
}

const VERIFY_URL = 'https://private-ai-code-server.llmservicemarketplace.workers.dev/verify';
const CODE_PATTERN = /^PAI-[A-Z0-9]{4}-[A-Z0-9]{4}$/;

function normalizeCode(value) {
  const body = String(value || '').toUpperCase().replace(/[^A-Z0-9]/g, '').replace(/^PAI/, '').slice(0, 8);
  return `PAI-${body.slice(0, 4)}-${body.slice(4, 8)}`.replace(/-$/, '');
}

function hashValue(value) {
  return crypto.createHash('sha256').update(String(value), 'utf8').digest('hex');
}

function workspaceKey(location, name) {
  return hashValue(path.resolve(String(location), String(name)).toLowerCase());
}

function emptyLedger() {
  return {
    schemaVersion: 2,
    usedCodeHashes: [],
    caseUnlocks: {},
    annual: null,
    store: { pendingFulfillment: null, pendingFirstCase: null },
  };
}

function sanitizeLedger(value) {
  const ledger = value && typeof value === 'object' ? value : {};
  return {
    schemaVersion: 2,
    usedCodeHashes: Array.isArray(ledger.usedCodeHashes) ? ledger.usedCodeHashes.filter((v) => typeof v === 'string') : [],
    caseUnlocks: ledger.caseUnlocks && typeof ledger.caseUnlocks === 'object' ? ledger.caseUnlocks : {},
    // Honor any pre-release monthly ledger as a legacy timed entitlement while
    // all newly issued access uses the annual product.
    annual: ledger.annual && typeof ledger.annual === 'object'
      ? ledger.annual
      : ledger.monthly && typeof ledger.monthly === 'object'
        ? ledger.monthly
        : null,
    store: {
      pendingFulfillment: ledger.store?.pendingFulfillment && typeof ledger.store.pendingFulfillment === 'object'
        ? ledger.store.pendingFulfillment
        : null,
      pendingFirstCase: ledger.store?.pendingFirstCase && typeof ledger.store.pendingFirstCase === 'object'
        ? ledger.store.pendingFirstCase
        : null,
    },
  };
}

function annualActive(ledger, now = Date.now()) {
  const expiry = Date.parse(ledger?.annual?.expiresAt || '');
  return Number.isFinite(expiry) && expiry > now;
}

function complimentaryLegalCaseFor(ledger, workspaceHash) {
  const unlock = ledger?.caseUnlocks?.[workspaceHash];
  if (!unlock || unlock.productId !== PRODUCTS.firstCase) return null;
  return unlock.complimentaryPaiLegalCase || {
    included: true,
    caseCount: 1,
    grantedAt: unlock.activatedAt,
    sourceProductId: PRODUCTS.firstCase,
    features: ['pai-case-file-creator', 'psi-legal-data'],
  };
}

function accessFor(ledgerValue, workspaceHash, now = Date.now()) {
  const ledger = sanitizeLedger(ledgerValue);
  const complimentaryPaiLegalCase = complimentaryLegalCaseFor(ledger, workspaceHash);
  if (annualActive(ledger, now)) {
    return {
      allowed: true, mode: 'annual', readOnly: false, expiresAt: ledger.annual.expiresAt, complimentaryPaiLegalCase,
      source: ledger.annual?.source || 'pai-code', sourceProductId: PRODUCTS.annual,
    };
  }
  if (ledger.caseUnlocks[workspaceHash]) {
    const unlock = ledger.caseUnlocks[workspaceHash];
    return {
      allowed: true, mode: 'case', readOnly: false, expiresAt: null, complimentaryPaiLegalCase,
      source: unlock.source || 'pai-code', sourceProductId: unlock.productId || null,
    };
  }
  return {
    allowed: false,
    mode: ledger.annual ? 'annual-expired' : 'locked',
    readOnly: Boolean(ledger.annual),
    expiresAt: ledger.annual?.expiresAt || null,
    complimentaryPaiLegalCase,
    source: ledger.annual?.source || null,
    sourceProductId: ledger.annual ? PRODUCTS.annual : null,
  };
}

function offerFor(ledgerValue, workspaceHash, checkoutUrls = {}, now = Date.now()) {
  const ledger = sanitizeLedger(ledgerValue);
  const access = accessFor(ledger, workspaceHash, now);
  const firstCaseUsed = Object.keys(ledger.caseUnlocks).length > 0;
  const caseProductId = firstCaseUsed ? PRODUCTS.singleCase : PRODUCTS.firstCase;
  return {
    access,
    firstCaseUsed,
    caseOffer: {
      productId: caseProductId,
      priceUsd: firstCaseUsed ? 179 : 20,
      checkoutUrl: firstCaseUsed ? checkoutUrls.singleCase || '' : checkoutUrls.firstCase || '',
    },
    annualOffer: {
      productId: PRODUCTS.annual,
      priceUsd: 2000,
      checkoutUrl: checkoutUrls.annual || '',
    },
  };
}

function expiryFromVerification(payload, now = Date.now()) {
  const candidates = [payload?.expiresAt, payload?.expires_at, payload?.expiry, payload?.expires];
  for (const value of candidates) {
    const timestamp = Date.parse(String(value || ''));
    if (Number.isFinite(timestamp) && timestamp > now) return new Date(timestamp).toISOString();
  }
  return new Date(now + 365 * 24 * 60 * 60 * 1000).toISOString();
}

function recordRedemption(ledgerValue, { code, productId, workspaceHash, verification = {}, now = Date.now() }) {
  const ledger = sanitizeLedger(ledgerValue);
  const codeHash = hashValue(normalizeCode(code));
  if (ledger.usedCodeHashes.includes(codeHash)) throw new Error('This purchase code has already been redeemed on this installation.');

  if (productId === PRODUCTS.annual) {
    ledger.annual = {
      productId,
      codeHash,
      activatedAt: new Date(now).toISOString(),
      expiresAt: expiryFromVerification(verification, now),
    };
  } else if (productId === PRODUCTS.firstCase || productId === PRODUCTS.singleCase) {
    ledger.caseUnlocks[workspaceHash] = {
      productId,
      codeHash,
      activatedAt: new Date(now).toISOString(),
      ...(productId === PRODUCTS.firstCase ? {
        complimentaryPaiLegalCase: {
          included: true,
          caseCount: 1,
          grantedAt: new Date(now).toISOString(),
          sourceProductId: PRODUCTS.firstCase,
          features: ['pai-case-file-creator', 'psi-legal-data'],
        },
      } : {}),
    };
  } else {
    throw new Error('This code is not for a PAi Claims access product.');
  }
  ledger.usedCodeHashes.push(codeHash);
  return ledger;
}

module.exports = {
  PRODUCTS,
  STORE_PRODUCT_ALIASES,
  canonicalStoreProductId,
  storeProductAliases,
  VERIFY_URL,
  CODE_PATTERN,
  normalizeCode,
  hashValue,
  workspaceKey,
  emptyLedger,
  sanitizeLedger,
  accessFor,
  offerFor,
  expiryFromVerification,
  recordRedemption,
};
