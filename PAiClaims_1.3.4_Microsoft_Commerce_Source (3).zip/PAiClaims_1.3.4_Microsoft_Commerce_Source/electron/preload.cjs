/**
 * Preload bridge. contextIsolation is on, so the renderer sees only these
 * functions and never the Node API surface.
 */
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('paiDesktop', {
  isDesktop: true,

  /** Opens the system folder picker. Returns {path, writable} or null. */
  chooseLocation: () => ipcRenderer.invoke('claim:chooseLocation'),

  /** Creates the claim folder structure. Returns {root, meta}. */
  createClaim: (location, name, claimData, documents) =>
    ipcRenderer.invoke('claim:create', { location, name, claimData, documents }),

  /** Copy a document into the case, hash it, and extract what is readable. */
  attachDocument: (request) => ipcRenderer.invoke('claim:attachDocument', request),

  /** Returns access status and the currently applicable case/annual offers. */
  getCommerceOffer: (location, name) => ipcRenderer.invoke('commerce:getOffer', { location, name }),

  /** Purchases/uses the Microsoft Store case entitlement for this workspace. */
  acquireMicrosoftCase: (location, name) => ipcRenderer.invoke('commerce:acquireCase', { location, name }),

  /** Purchases or refreshes the Microsoft Store annual subscription. */
  acquireMicrosoftAnnual: (location, name) => ipcRenderer.invoke('commerce:acquireAnnual', { location, name }),

  /** Hidden support/recovery path retained from 1.3.0. */
  redeemPurchaseCode: (request) => ipcRenderer.invoke('commerce:redeem', request),

  /** Returns {hasGeminiKey, recentLocations}. Never returns the key itself. */
  getSettings: () => ipcRenderer.invoke('settings:get'),

  /** Stores the user's own Gemini key in %LOCALAPPDATA%, not in the package. */
  setGeminiKey: (key) => ipcRenderer.invoke('settings:setGeminiKey', key),

  /** Returns {provider, model, baseUrl, hasKey:{...}}. Never returns keys. */
  getAIConfig: () => ipcRenderer.invoke('ai:getConfig'),

  /** Save provider choice and optionally its key. */
  setAIConfig: (cfg) => ipcRenderer.invoke('ai:setConfig', cfg),

  /** Machine memory and CPU count, for model recommendations. */
  machineInfo: () => ipcRenderer.invoke('ai:machineInfo'),

  /** Lowe's/local retail pricing connector. */
  getLowesConfig: () => ipcRenderer.invoke('lowes:getConfig'),
  setLowesConfig: (config) => ipcRenderer.invoke('lowes:setConfig', config),
  lookupLowesProduct: (request) => ipcRenderer.invoke('lowes:lookupProduct', request),
  searchLowesProduct: (request) => ipcRenderer.invoke('lowes:searchProduct', request),
  importLowesStoreFeed: () => ipcRenderer.invoke('lowes:importStoreFeed'),

  /** Opens the claim folder in File Explorer. */
  revealClaim: (root) => ipcRenderer.invoke('shell:revealClaim', root),
});
