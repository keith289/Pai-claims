/**
 * Document extraction for PAi Claims.
 *
 * Ported from PAi Legal's `pai_legal/ingestion.py`, which used PyMuPDF plus a
 * bundled Tesseract. This is the same design in Node: text layer first, OCR
 * only for pages that have no usable text, and nothing invented in between.
 *
 * Three differences from the Legal original, all deliberate:
 *
 *  1. Tesseract is run with TSV output rather than plain stdout, so per-word
 *     confidence comes back with the text. PAi Claims brackets every policy
 *     term by how well it was read, and that needs a number, not a guess.
 *  2. Extraction reports a `bracketCeiling` — the highest epistemic bracket a
 *     value read this way is allowed to reach. A deterministic text layer can
 *     support EXPLAINED; OCR cannot on its own.
 *  3. Anything neither the text layer nor OCR can handle is not an error. It
 *     is returned with `needsVision: true` so a local model can transcribe it,
 *     and that transcription is capped lower still.
 */

'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { spawnSync } = require('child_process');
const zlib = require('zlib');

const TEXT_TYPES = new Set(['.txt', '.md', '.log', '.json', '.xml', '.yaml', '.yml']);
const IMAGE_TYPES = new Set(['.png', '.jpg', '.jpeg', '.tif', '.tiff', '.bmp', '.webp', '.gif']);

/** A page whose text layer holds less than this is treated as scanned. */
const SCANNED_PAGE_THRESHOLD = 40;

class ExtractionError extends Error {}

/* ------------------------------------------------------------------ */
/* Tesseract discovery — mirrors Legal's find_tesseract()              */
/* ------------------------------------------------------------------ */

function applicationRoot() {
  return path.resolve(__dirname, '..');
}

function findTesseract() {
  const candidates = [];
  if (process.env.PAI_CLAIMS_TESSERACT) candidates.push(process.env.PAI_CLAIMS_TESSERACT);
  const root = applicationRoot();
  candidates.push(
    path.join(root, 'resources', 'tesseract', 'tesseract.exe'),
    path.join(root, 'resources', 'tesseract', 'tesseract'),
    path.join(root, 'runtime', 'tesseract', 'tesseract.exe'),
  );
  if (process.env.ProgramFiles) {
    candidates.push(path.join(process.env.ProgramFiles, 'Tesseract-OCR', 'tesseract.exe'));
  }
  if (process.env.LOCALAPPDATA) {
    candidates.push(
      path.join(process.env.LOCALAPPDATA, 'Programs', 'Tesseract-OCR', 'tesseract.exe'),
    );
  }
  for (const candidate of candidates) {
    try {
      if (candidate && fs.statSync(candidate).isFile()) return candidate;
    } catch {
      /* keep looking */
    }
  }
  return null;
}

/* ------------------------------------------------------------------ */
/* Bracket ceilings                                                     */
/* ------------------------------------------------------------------ */

/**
 * The highest bracket a term may reach, by how the underlying TEXT was
 * produced.
 *
 * This grades the ingest, not the reader. Once characters exist as text, a
 * model locating a labelled value inside that text is not guessing at
 * characters — it is reading. What limits such a value is how the text was
 * obtained in the first place, and whether the value it reports actually
 * appears in that text (see `verifyAgainstSource`).
 *
 *  - A publisher's embedded text layer is deterministic. EXPLAINED.
 *  - OCR is a reconstruction, so it caps at SPECULATIVE on its own — but a
 *    reconstruction that AGREES with an independent read of the same page is
 *    corroborated, and corroboration is what VALIDATED means everywhere else
 *    in this product. See `crossMethodBracket`.
 *  - A vision model handed raw pixels with no OCR beneath it produces
 *    characters nobody else has seen. That is a claim about the document
 *    rather than a reading of it, and it stays at SPECULATIVE.
 */
const BRACKET_CEILING = {
  text: 'EXPLAINED',
  html: 'EXPLAINED',
  'delimited-text': 'EXPLAINED',
  docx: 'EXPLAINED',
  odt: 'EXPLAINED',
  'pdf-text': 'EXPLAINED',
  'pdf-text+tesseract': 'EXPLAINED',
  'tesseract-ocr': 'SPECULATIVE',
  'vision-model': 'SPECULATIVE',
  none: 'UNVERIFIED',
};

const RANK = { UNVERIFIED: 0, SPECULATIVE: 1, EXPLAINED: 2, VALIDATED: 3 };

function lower(a, b) {
  if (a === 'CONTRADICTED' || b === 'CONTRADICTED') return 'CONTRADICTED';
  return RANK[a] <= RANK[b] ? a : b;
}

function ceilingFor(method, confidence) {
  const base = BRACKET_CEILING[method] || 'UNVERIFIED';
  if (typeof confidence === 'number') {
    // A poor read is a poor read regardless of method.
    if (confidence < 0.75) return 'UNVERIFIED';
    if (confidence < 0.9) return lower(base, 'SPECULATIVE');
  }
  return base;
}

/**
 * Two independent reads of the same page agreeing on the same string is
 * corroboration, not repetition — the text layer and OCR fail in unrelated
 * ways, so agreement between them is real evidence. Disagreement is not a
 * weak reading; it is a live conflict and must surface as one.
 */
function crossMethodBracket(textLayerValue, ocrValue, ocrConfidence) {
  const a = normaliseForCompare(textLayerValue);
  const b = normaliseForCompare(ocrValue);
  if (!a || !b) return null;
  if (a !== b) return 'CONTRADICTED';
  if (typeof ocrConfidence === 'number' && ocrConfidence < 0.75) return 'EXPLAINED';
  return 'VALIDATED';
}

/**
 * A value a model reports is transcribed only if it actually occurs in the
 * text the model was given. If it does, the value inherits the ingest
 * method's ceiling — the model read it. If it does not, the model produced it
 * by reasoning, and a reasoned value can never exceed SPECULATIVE.
 *
 * `page` scopes the search to the page the model cited, so a figure lifted
 * from a different page does not pass as a reading of this one.
 */
function verifyAgainstSource(reportedValue, sourceText, page) {
  const needle = normaliseForCompare(reportedValue);
  if (!needle) return { verbatim: false, reason: 'No value reported.' };

  let haystack = sourceText || '';
  if (page != null) {
    const marker = new RegExp(`<<<PAGE ${page}>>>([\\s\\S]*?)(?=<<<PAGE |$)`);
    const match = haystack.match(marker);
    if (!match) {
      return { verbatim: false, reason: `Page ${page} is not present in the extracted text.` };
    }
    haystack = match[1];
  }

  // Substring matching is unsafe here: "$312,000" stripped to digits contains
  // "31200", so a Coverage B figure would verify against a Coverage A page.
  // Match whole tokens, and windows of adjacent tokens for multi-word values.
  const verbatim = containsTokenRun(haystack, needle);
  return {
    verbatim,
    reason: verbatim
      ? `Found verbatim${page != null ? ` on page ${page}` : ''}.`
      : `Not present in the extracted text${page != null ? ` for page ${page}` : ''}; the model derived rather than read it.`,
  };
}

/**
 * Final bracket for a value a model reported out of extracted text.
 */
function modelReadBracket({ reportedValue, sourceText, page, method, confidence }) {
  const check = verifyAgainstSource(reportedValue, sourceText, page);
  const ingestCeiling = ceilingFor(method, confidence);
  if (!check.verbatim) {
    return {
      bracket: lower(ingestCeiling, 'SPECULATIVE'),
      verbatim: false,
      reason: check.reason,
    };
  }
  return { bracket: ingestCeiling, verbatim: true, reason: check.reason };
}

/**
 * True when the needle equals a token, or a run of adjacent tokens, in the
 * haystack. Equality rather than containment, so one number cannot verify
 * against a longer number that happens to contain its digits.
 */
function containsTokenRun(haystack, needle, maxRun = 6) {
  const tokens = String(haystack || '')
    .split(/\s+/)
    .map(normaliseForCompare)
    .filter(Boolean);
  for (let i = 0; i < tokens.length; i += 1) {
    let joined = '';
    for (let n = 0; n < maxRun && i + n < tokens.length; n += 1) {
      joined += tokens[i + n];
      if (joined === needle) return true;
      if (joined.length > needle.length) break;
    }
  }
  return false;
}

/** Compare on content, not on how the source happened to space or punctuate it. */
function normaliseForCompare(value) {
  return String(value ?? '')
    .toLowerCase()
    .replace(/[\s,$]/g, '')
    .trim();
}


/* ------------------------------------------------------------------ */
/* Discrepancy resolution                                              */
/* ------------------------------------------------------------------ */

/**
 * Characters Tesseract routinely confuses. Used only to explain a
 * disagreement, never to correct a value silently.
 */
const OCR_CONFUSIONS = [
  ['0', 'o'], ['0', 'd'], ['1', 'l'], ['1', 'i'], ['5', 's'],
  ['8', 'b'], ['6', 'g'], ['2', 'z'], ['9', 'q'], ['3', '8'],
  ['6', '5'], ['7', '1'], ['4', 'a'],
];

/** True when two strings differ only by characters OCR is known to confuse. */
function differsOnlyByOcrConfusion(a, b) {
  if (a.length !== b.length) return false;
  let differences = 0;
  for (let i = 0; i < a.length; i += 1) {
    if (a[i] === b[i]) continue;
    differences += 1;
    const pair = [a[i], b[i]];
    const known = OCR_CONFUSIONS.some(
      ([x, y]) => (pair[0] === x && pair[1] === y) || (pair[0] === y && pair[1] === x),
    );
    if (!known) return false;
  }
  return differences > 0;
}

/** How many times a value occurs as a token run across the whole document. */
function occurrenceCount(fullText, value) {
  const needle = normaliseForCompare(value);
  if (!needle) return 0;
  let count = 0;
  for (const section of String(fullText || '').split(/<<<PAGE \d+>>>/)) {
    if (containsTokenRun(section, needle)) count += 1;
  }
  return count;
}

/**
 * Try to settle a disagreement between two reads of the same value before
 * putting it in front of the user.
 *
 * Resolution is only ever by evidence already in the document. Nothing here
 * picks the "more likely" number, and a resolved value is EXPLAINED rather
 * than VALIDATED — the reads did not agree, so this is one source that
 * survived scrutiny, not two that corroborated.
 *
 * When nothing settles it, the conflict is returned intact for the user to
 * resolve against the document. It is never quietly dropped and never
 * averaged.
 */
function resolveDiscrepancy({
  label,
  textLayerValue,
  ocrValue,
  ocrConfidence,
  fullText,
  page,
}) {
  const a = normaliseForCompare(textLayerValue);
  const b = normaliseForCompare(ocrValue);

  const base = {
    label,
    page: page ?? null,
    candidates: [
      { value: textLayerValue, method: 'pdf-text', occurrences: occurrenceCount(fullText, textLayerValue) },
      { value: ocrValue, method: 'tesseract-ocr', confidence: ocrConfidence ?? null, occurrences: occurrenceCount(fullText, ocrValue) },
    ],
  };

  if (!a || !b) {
    return { ...base, resolved: false, value: null, bracket: 'UNVERIFIED',
      reason: 'One of the two reads produced nothing.',
      userAction: `Open the document and read ${label} directly.` };
  }
  if (a === b) {
    return { ...base, resolved: true, value: textLayerValue, bracket: 'VALIDATED',
      reason: 'Both reads agree.', userAction: null };
  }

  // 1. Corroboration elsewhere in the document settles it outright.
  const [textCandidate, ocrCandidate] = base.candidates;
  if (textCandidate.occurrences > ocrCandidate.occurrences && textCandidate.occurrences > 1) {
    return { ...base, resolved: true, value: textLayerValue, bracket: 'EXPLAINED',
      reason: `The text-layer reading appears ${textCandidate.occurrences} times elsewhere in the document; the OCR reading appears ${ocrCandidate.occurrences}.`,
      userAction: null };
  }
  if (ocrCandidate.occurrences > textCandidate.occurrences && ocrCandidate.occurrences > 1) {
    return { ...base, resolved: true, value: ocrValue, bracket: 'EXPLAINED',
      reason: `The OCR reading appears ${ocrCandidate.occurrences} times elsewhere in the document; the text-layer reading appears ${textCandidate.occurrences}.`,
      userAction: null };
  }

  // 2. A difference confined to characters OCR confuses is an OCR failure,
  //    and the embedded text layer is the authority on its own characters.
  if (differsOnlyByOcrConfusion(a, b)) {
    return { ...base, resolved: true, value: textLayerValue, bracket: 'EXPLAINED',
      reason: 'The two readings differ only by characters OCR commonly misreads, so the embedded text layer governs.',
      userAction: null };
  }

  // 3. OCR that scored badly is not evidence against a clean text layer.
  if (typeof ocrConfidence === 'number' && ocrConfidence < 0.75) {
    return { ...base, resolved: true, value: textLayerValue, bracket: 'EXPLAINED',
      reason: `OCR confidence on this page was ${(ocrConfidence * 100).toFixed(0)}%, below the threshold at which it can contradict the text layer.`,
      userAction: null };
  }

  // Nothing in the document settles it. This goes to the user as-is.
  return {
    ...base,
    resolved: false,
    value: null,
    bracket: 'CONTRADICTED',
    reason: 'Two readings of this value disagree and nothing in the document settles which is correct.',
    userAction: `Open ${page != null ? `page ${page} of ` : ''}the document and confirm ${label} directly. It will not be used in any figure until you do.`,
  };
}

/* ------------------------------------------------------------------ */
/* Extractor                                                            */
/* ------------------------------------------------------------------ */

class TextExtractor {
  constructor(options = {}) {
    this.language = options.language || 'eng';
    // An explicit null means "no OCR available" and must not fall through to
    // discovery — otherwise a caller cannot describe a machine without it,
    // and neither can a test.
    this.tesseract = 'tesseract' in options ? options.tesseract : findTesseract();
  }

  get ocrAvailable() {
    return !!this.tesseract;
  }

  /**
   * @returns {Promise<{text:string, method:string, pages:number, ocrPages:number,
   *                    confidence:number|null, bracketCeiling:string,
   *                    needsVision:boolean, note:string}>}
   */
  async extract(source) {
    const suffix = path.extname(source).toLowerCase();

    if (TEXT_TYPES.has(suffix)) {
      return this.#result(fs.readFileSync(source, 'utf8'), 'text');
    }
    if (suffix === '.html' || suffix === '.htm') {
      const raw = fs.readFileSync(source, 'utf8');
      // Legal used html.unescape here; entities must be decoded or a
      // dollar amount written as &#36;312,000 reads back wrong.
      return this.#result(collapse(decodeXml(stripTags(raw))), 'html');
    }
    if (suffix === '.csv' || suffix === '.tsv') {
      const delimiter = suffix === '.tsv' ? '\t' : ',';
      const rows = fs
        .readFileSync(source, 'utf8')
        .split(/\r?\n/)
        .map((line) => line.split(delimiter).join(' | '));
      return this.#result(rows.join('\n'), 'delimited-text');
    }
    if (suffix === '.pdf') return this.#pdf(source);
    if (IMAGE_TYPES.has(suffix)) return this.#image(source);
    if (suffix === '.docx') return this.#result(this.#docx(source), 'docx');
    if (suffix === '.odt') return this.#result(this.#odt(source), 'odt');

    // Unsupported by both paths. Not an error — hand it to the vision model.
    return {
      text: '',
      method: 'none',
      pages: 0,
      ocrPages: 0,
      confidence: null,
      bracketCeiling: 'UNVERIFIED',
      needsVision: true,
      note: `No text extractor for ${suffix || 'this file type'}. A local model can describe it, but nothing read that way is treated as transcribed.`,
    };
  }

  #result(text, method, extra = {}) {
    const confidence = extra.confidence ?? null;
    return {
      text: collapse(text),
      method,
      pages: extra.pages ?? 0,
      ocrPages: extra.ocrPages ?? 0,
      confidence,
      bracketCeiling: ceilingFor(method, confidence),
      needsVision: extra.needsVision ?? false,
      note: extra.note ?? '',
    };
  }

  async #pdf(source) {
    let mupdf;
    try {
      mupdf = await import('mupdf');
    } catch (err) {
      throw new ExtractionError(`The bundled PDF renderer is not available: ${err.message}`);
    }

    const buffer = fs.readFileSync(source);
    let doc;
    try {
      doc = mupdf.Document.openDocument(buffer, 'application/pdf');
    } catch (err) {
      throw new ExtractionError(`Cannot open PDF: ${err.message}`);
    }

    const pieces = [];
    const confidences = [];
    let ocrPages = 0;
    let visionPages = 0;
    const total = doc.countPages();

    for (let n = 0; n < total; n += 1) {
      const page = doc.loadPage(n);
      let pageText = pageTextOf(page).trim();

      // A page carrying only a stamp or a page number is effectively scanned.
      if (pageText.replace(/\s+/g, '').length < SCANNED_PAGE_THRESHOLD) {
        if (this.ocrAvailable) {
          const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'pai-claims-ocr-'));
          try {
            const image = path.join(tmp, `page-${String(n + 1).padStart(5, '0')}.png`);
            const pixmap = page.toPixmap(
              mupdf.Matrix.scale(2.5, 2.5),
              mupdf.ColorSpace.DeviceRGB,
              false,
              true,
            );
            fs.writeFileSync(image, Buffer.from(pixmap.asPNG()));
            const ocr = this.ocr(image);
            pageText = ocr.text;
            if (ocr.confidence !== null) confidences.push(ocr.confidence);
            ocrPages += 1;
          } finally {
            fs.rmSync(tmp, { recursive: true, force: true });
          }
        } else {
          // Legal raised here. Claims records the gap and moves on, so one
          // scanned page does not reject an otherwise readable packet.
          visionPages += 1;
          pageText = '';
        }
      }
      pieces.push(`<<<PAGE ${n + 1}>>>\n${pageText}`);
    }

    const confidence = confidences.length
      ? confidences.reduce((a, b) => a + b, 0) / confidences.length
      : null;
    const method = ocrPages ? 'pdf-text+tesseract' : 'pdf-text';

    return this.#result(pieces.join('\n\n'), method, {
      pages: total,
      ocrPages,
      confidence,
      needsVision: visionPages > 0,
      note: visionPages
        ? `${visionPages} page(s) have no text layer and OCR is unavailable. Those pages are unread.`
        : '',
    });
  }

  #image(source) {
    if (!this.ocrAvailable) {
      return {
        text: '',
        method: 'none',
        pages: 1,
        ocrPages: 0,
        confidence: null,
        bracketCeiling: 'UNVERIFIED',
        needsVision: true,
        note: 'OCR runtime not found. A local model can transcribe this image, capped at SPECULATIVE.',
      };
    }
    const ocr = this.ocr(source);
    return this.#result(ocr.text, 'tesseract-ocr', {
      pages: 1,
      ocrPages: 1,
      confidence: ocr.confidence,
      // A poor scan is worth a second opinion from the model.
      needsVision: ocr.confidence !== null && ocr.confidence < 0.75,
      note:
        ocr.confidence !== null && ocr.confidence < 0.75
          ? 'OCR confidence is low. Treat every value read from this image as unverified until confirmed against the document.'
          : '',
    });
  }

  /**
   * Run Tesseract in TSV mode so per-word confidence comes back with the text.
   * Legal used plain stdout, which discards it.
   */
  ocr(image) {
    if (!this.ocrAvailable) throw new ExtractionError('The bundled OCR runtime was not found');
    const env = { ...process.env };
    const tessdata = path.join(path.dirname(this.tesseract), 'tessdata');
    try {
      if (fs.statSync(tessdata).isDirectory()) env.TESSDATA_PREFIX = tessdata;
    } catch {
      /* packaged layout may differ */
    }

    const run = spawnSync(
      this.tesseract,
      [image, 'stdout', '-l', this.language, '--oem', '1', '--psm', '3', 'tsv'],
      { encoding: 'utf8', timeout: 600000, env, windowsHide: true },
    );
    if (run.error) throw new ExtractionError(`Tesseract failed to run: ${run.error.message}`);
    if (run.status) {
      throw new ExtractionError(
        (run.stderr || '').trim() || `Tesseract exited with code ${run.status}`,
      );
    }
    return parseTesseractTsv(run.stdout || '');
  }

  #docx(source) {
    const xml = readZipEntry(source, 'word/document.xml');
    const paragraphs = [];
    for (const match of xml.matchAll(/<w:p[ >][\s\S]*?<\/w:p>/g)) {
      const text = [...match[0].matchAll(/<w:t[^>]*>([\s\S]*?)<\/w:t>/g)]
        .map((m) => decodeXml(m[1]))
        .join('');
      if (text.trim()) paragraphs.push(text);
    }
    return paragraphs.join('\n');
  }

  #odt(source) {
    const xml = readZipEntry(source, 'content.xml');
    const paragraphs = [];
    for (const match of xml.matchAll(/<text:(?:p|h)[^>]*>([\s\S]*?)<\/text:(?:p|h)>/g)) {
      const text = decodeXml(stripTags(match[1])).trim();
      if (text) paragraphs.push(text);
    }
    return paragraphs.join('\n');
  }
}

/* ------------------------------------------------------------------ */
/* Helpers                                                              */
/* ------------------------------------------------------------------ */

function pageTextOf(page) {
  const structured = JSON.parse(page.toStructuredText('preserve-whitespace').asJSON());
  const lines = [];
  for (const block of structured.blocks || []) {
    for (const line of block.lines || []) {
      if (typeof line.text === 'string') lines.push(line.text);
    }
  }
  return lines.join('\n');
}

/**
 * Tesseract TSV: level, page, block, par, line, word, left, top, width,
 * height, conf, text. Confidence is -1 for layout rows and 0..100 for words.
 */
function parseTesseractTsv(tsv) {
  const rows = tsv.split(/\r?\n/).slice(1);
  const words = [];
  const scores = [];
  let line = [];
  let lastLineKey = null;

  for (const row of rows) {
    const cols = row.split('\t');
    if (cols.length < 12) continue;
    const conf = Number(cols[10]);
    const text = cols[11];
    if (!text || !text.trim()) continue;
    const lineKey = `${cols[1]}:${cols[2]}:${cols[3]}:${cols[4]}`;
    if (lastLineKey !== null && lineKey !== lastLineKey) {
      words.push(line.join(' '));
      line = [];
    }
    lastLineKey = lineKey;
    line.push(text);
    if (conf >= 0) scores.push(conf);
  }
  if (line.length) words.push(line.join(' '));

  const confidence = scores.length
    ? scores.reduce((a, b) => a + b, 0) / scores.length / 100
    : null;
  return { text: words.join('\n'), confidence };
}

function readZipEntry(archivePath, entryName) {
  const buffer = fs.readFileSync(archivePath);
  // Locate the end-of-central-directory record.
  let eocd = -1;
  for (let i = buffer.length - 22; i >= 0 && i > buffer.length - 65558; i -= 1) {
    if (buffer.readUInt32LE(i) === 0x06054b50) {
      eocd = i;
      break;
    }
  }
  if (eocd < 0) throw new ExtractionError('Not a readable archive');

  let offset = buffer.readUInt32LE(eocd + 16);
  const count = buffer.readUInt16LE(eocd + 10);

  for (let i = 0; i < count; i += 1) {
    if (buffer.readUInt32LE(offset) !== 0x02014b50) break;
    const method = buffer.readUInt16LE(offset + 10);
    const compressedSize = buffer.readUInt32LE(offset + 20);
    const nameLength = buffer.readUInt16LE(offset + 28);
    const extraLength = buffer.readUInt16LE(offset + 30);
    const commentLength = buffer.readUInt16LE(offset + 32);
    const localOffset = buffer.readUInt32LE(offset + 42);
    const name = buffer.subarray(offset + 46, offset + 46 + nameLength).toString('utf8');

    if (name === entryName) {
      const localNameLength = buffer.readUInt16LE(localOffset + 26);
      const localExtraLength = buffer.readUInt16LE(localOffset + 28);
      const start = localOffset + 30 + localNameLength + localExtraLength;
      const raw = buffer.subarray(start, start + compressedSize);
      const data = method === 0 ? raw : zlib.inflateRawSync(raw);
      return data.toString('utf8');
    }
    offset += 46 + nameLength + extraLength + commentLength;
  }
  throw new ExtractionError(`Archive does not contain ${entryName}`);
}

function stripTags(value) {
  return value.replace(/<[^>]+>/g, ' ');
}

function decodeXml(value) {
  return value
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&#(\d+);/g, (_, code) => String.fromCharCode(Number(code)))
    .replace(/&amp;/g, '&');
}

function collapse(text) {
  return String(text)
    .replace(/\r\n/g, '\n')
    .replace(/\n\s*\n\s*\n+/g, '\n\n')
    .replace(/[ \t]+/g, ' ')
    .trim();
}

function sha256(filePath) {
  return crypto.createHash('sha256').update(fs.readFileSync(filePath)).digest('hex');
}

module.exports = {
  TextExtractor,
  ExtractionError,
  findTesseract,
  parseTesseractTsv,
  ceilingFor,
  crossMethodBracket,
  verifyAgainstSource,
  modelReadBracket,
  normaliseForCompare,
  containsTokenRun,
  resolveDiscrepancy,
  differsOnlyByOcrConfusion,
  occurrenceCount,
  sha256,
  collapse,
  BRACKET_CEILING,
  SCANNED_PAGE_THRESHOLD,
};
