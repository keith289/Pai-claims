<#
  Store build for PAi Claims.

  PowerShell's $ErrorActionPreference does not apply to native commands: npm
  returning a non-zero exit code is not a terminating error, so an earlier
  version of this script ran the full build after the tests and the type check
  had both failed, and printed a stale version number at the end. Every step
  now checks $LASTEXITCODE explicitly and the version is read from package.json.
#>
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

$version = (Get-Content .\package.json -Raw | ConvertFrom-Json).version

function Invoke-Step {
    param([string]$Label, [scriptblock]$Action)
    Write-Host $Label -ForegroundColor Cyan
    & $Action
    if ($LASTEXITCODE -ne 0) {
        Write-Host ""
        Write-Host "FAILED: $Label (exit code $LASTEXITCODE)" -ForegroundColor Red
        Write-Host "The package was not built. Fix the failure above and run this again." -ForegroundColor Red
        exit 1
    }
}

Write-Host "Building PAi Claims $version" -ForegroundColor Cyan
Write-Host ""

Write-Host "1/5 Microsoft Store commerce bridge" -ForegroundColor Cyan
& .\store-bridge\Build-StoreBridge.ps1
if (-not (Test-Path ".\store-bridge\bin\PAiClaims.StoreBridge.exe")) {
    Write-Host ""
    Write-Host "FAILED: the commerce bridge did not build." -ForegroundColor Red
    Write-Host "electron-builder would still produce a package, but it could not take payment." -ForegroundColor Red
    exit 1
}

if (-not (Test-Path ".\node_modules")) {
    Invoke-Step "Installing dependencies" { npm install }
}

Invoke-Step "2/5 Domain + commerce tests" { npm test }
Invoke-Step "3/5 TypeScript check" { npm run lint }
Invoke-Step "4/5 Building APPX package" { npm run build:msix }

Write-Host "5/5 Verifying package contents" -ForegroundColor Cyan
& .\verify-package.ps1 -Version $version
if ($LASTEXITCODE -ne 0) { exit 1 }

Write-Host ""
Write-Host "Upload .\release\PAiClaims-$version-x64.appx to the PAi Claims product in Partner Center." -ForegroundColor Green
