# PAi Claims 1.1.0 — PSi Estimators integration

This build merges the working PAi Claims desktop source with the deterministic estimator work.

## Boundary

- **PSi Estimators** calculates source-traced reconstruction cost. AI does not set quantities, material prices, package counts, contractor medians, or the final documented cost.
- **PAi Claims** remains the AI-assisted insurance/evidence layer.
- A PSi estimate is a repair-cost estimate, **not** a coverage or payment determination.

## First production estimator: Roofing

PSi Roofing currently calculates:

- architectural shingles with explicit waste percentage
- underlayment
- starter course
- hip/ridge cap
- drip edge
- valley treatment
- pipe boots
- roof vents
- ridge vent
- damaged roof decking
- measured ice/water membrane
- fasteners only when a verified LB/SQ rate is supplied
- retail package rounding (`ceil(required / package coverage)`)

Every derived quantity shows its formula. Missing fastener rate, prices, packaging coverage, evidence, or contractor roots remains `REQUIRES_DATA`.

## Regional material pricing

The Electron bridge now supports two authorized pricing routes:

1. **Imported Lowe's store-price CSV** — immediately usable. PSi hashes the imported source and keeps the import timestamp. The importer recognizes common columns such as product/SKU, store, ZIP, selling/current price, description, inventory, and package coverage.
2. **Partner API configuration** — PSi accepts the OAuth token URL and product URL template supplied with the user's authorized Lowe's partner access. No undocumented endpoint is guessed and the app does not scrape Lowe's.

The included `examples/lowes_store_price_template.csv` contains headings only and no fake prices.

## Contractor direct-cost median

For a supported regional contractor delta:

- add contractor estimate evidence to the claim,
- record the local material subtotal for the same scope,
- record the contractor direct repair cost for that same scope,
- repeat for at least **three genuinely independent provenance roots**.

Duplicate content hashes or repeated provenance roots do not increase independence.

A typed percentage remains scenario-only and can never produce a `SUPPORTED` PSi estimate.

## Security

Lowe's client secrets are stored with Electron `safeStorage` when the operating system provides it. The UI reports whether the saved secret is protected. No retailer credentials are compiled into the package.

## Tests

`npm run test:psi` checks:

- 24 SQ + 10% waste = 26.4 SQ
- package rounding (67.2 / 15 = 5)
- fasteners require an explicit verified rate
- deterministic contractor median
- independent provenance-root requirement
- supported material + contractor cost calculation

`npm run lint` performs the TypeScript check.
