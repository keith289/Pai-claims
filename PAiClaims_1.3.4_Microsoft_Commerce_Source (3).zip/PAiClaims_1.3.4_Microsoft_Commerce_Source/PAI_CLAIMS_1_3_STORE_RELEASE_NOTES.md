# PAi Claims 1.3.0 — Store Release Notes

## Added

- Shared PAi Claims/PAi Legal workspaces with `pai_case_manifest.json`, `claim.json`, `case_graph.json`, and source folders for evidence, photographs, estimates, carrier records, correspondence, payments, reports, exports, audit history, and PAi Legal.
- Payment enforcement after folder selection and before workspace creation or claim analysis.
- $20 first-case, $179 later single-case, and $2,000 annual entitlement product handling.
- One complimentary PAi Legal case with the $20 introductory purchase only, including the PAi Case File Creator and PSi Legal Data.
- Local one-use protection that stores only SHA-256 purchase-code hashes.
- Permanent per-workspace case unlocks and read-only status after annual expiry.
- Optional external checkout links that remain hidden until configured.
- Explicit consent before hosted-AI claim content is transmitted.
- One-click hosted-AI opt-out and saved-key removal.
- Windows secure-storage protection for saved AI and connector credentials; AI credentials stay session-only when secure storage is unavailable.
- Metallic PAi Store artwork, tile assets, splash image, and Store screenshots.

## Store package

- Identity: `PAiLuton.PAiClaims`
- Publisher: `CN=D7A83BB4-9693-4195-82DE-2A76C46F6F0F`
- Version: `1.3.0.0`
- Architecture: x64
- Minimum OS: Windows 10 version 2004 (`10.0.19041.0`)

## Verification

- 16 PSi/domain tests pass.
- 5 payment/entitlement tests pass.
- TypeScript check passes.
- Electron bridge syntax checks pass.
- Production dependency audit reports zero vulnerabilities.
- Packaged local server starts on loopback and returns a healthy status.
- Final AppX manifest identity, version, architecture, OS target, and artwork references were inspected after packaging.
