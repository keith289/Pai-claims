# PAi Claims 1.3.4 — Release Notes

Correctness release. Policy coverage terms are now bracketed facts with
provenance, and the software no longer manufactures policy terms it has not
read.

## The defect fixed

Through 1.3.1, opening a claim collected two figures from the insured — the
dwelling limit and the deductible — and then generated the remaining policy
terms from fixed ratios:

| Term | 1.3.1 behaviour | Source |
|---|---|---|
| Coverage B other structures | 10% of Coverage A | invented |
| Coverage C personal property | 50% of Coverage A | invented |
| Coverage D loss of use | 20% of Coverage A | invented |
| Ordinance & law | 25% | hardcoded |
| Mold remediation limit | $10,000 | hardcoded |
| Debris removal | 5% | hardcoded |
| Deductible type | percentage / named storm | hardcoded |

Those values were then written into an evidence record of type `policy_dec`
carrying `bracketState: 'VALIDATED'`, a filename of `Policy_Contract.pdf`, and
a `provenanceRoot` naming the carrier's underwriting system — for a document
that had never been supplied.

The invented ordinance & law allowance capped `eligibleCodeUpgrades`, and the
deductible was subtracted from `netPayoutOwed`. `totalRecoveryGap` — the figure
the product exists to produce — therefore rested on fabricated policy terms
presented at the highest confidence tier.

## What changed

**Policy terms are bracketed.** New `src/domain/policyRecord.ts` holds each
coverage term as a `PolicyValue` carrying its epistemic bracket, the document
and page it was read from, and OCR confidence. Terms default to UNVERIFIED.

**Bracket algebra is monotone.** A result never exceeds its weakest input.
Two agreeing sources earn VALIDATED; one earns EXPLAINED; a computed term
cannot exceed SPECULATIVE; poor OCR caps the result regardless of source
count; a contradicted term poisons anything derived from it. A figure typed by
the insured is UNVERIFIED and stays UNVERIFIED through any arithmetic applied
to it.

**Nothing is invented at case creation.** Only the two figures the insured
actually enters are carried, marked `insuredAsserted`. Coverage B/C/D,
ordinance & law, mold and debris limits are no longer guessed.

**The synthetic policy evidence record is gone.** It is replaced by a
placeholder that asserts nothing: no filename, no carrier provenance, no
transcribed excerpt, bracket UNVERIFIED. It keeps the missing policy visible
on the case rather than papering over it.

**The valuation reports what it rested on.** `recalculateClaimValuation` now
returns `bracket` and `unreadTerms`. The ordinance & law cap is applied only
when the allowance was actually read — an unread allowance is neither treated
as zero (which would silently delete recoverable upgrades) nor as an assumed
percentage (which would invent a policy term). The deductible is subtracted
only when read.

**Coverage boundary checks.** `runBoundaryChecks` compares the claim against
policy terms deterministically: date of loss inside the policy period, repair
scope against Coverage A, code upgrades against the ordinance & law allowance,
and the deductible the carrier applied against the deductible the policy
states. A check whose governing term is unread reports `passed: null` —
untestable — rather than a pass.

**Endorsement completeness.** `EndorsementEntry` records which forms the
declarations page lists against which forms were actually supplied, so a
missing form can be named by number rather than discovered later.

**Intake fields no longer ship with prefilled values.** Carrier, dwelling
limit, deductible, initial check and contractor estimate previously defaulted
to `State Farm`, `350000`, `3500`, `18500` and `89000`. A user who clicked
through created a claim against terms they never entered. Fields now render
empty, a blank stays absent rather than collapsing to zero, and whatever is
left blank is recorded in `InsuranceClaim.intakeGaps`.

**Persistent accuracy warning.** `AccuracyWarningBanner` renders above every
tab for as long as the case is missing intake fields, unread policy terms,
endorsement forms listed but not supplied, or conflicting values. It is not
dismissible: a warning cleared on day one would be gone by the time a figure is
exported weeks later.

**Case creation is reordered and the policy packet is required.** The flow is
now: choose a folder, settle access through Microsoft Store, then fill the
form. The form is part of the paid workspace, so the customer is not asked to
enter anything before they know the price. The form requires the complete
policy packet — declarations page plus all forms and endorsements — and the
create button stays disabled until at least one file is attached. Uploaded
files are recorded as `policy_dec` evidence with an UNVERIFIED bracket: the
document is on file, but no terms have been read from it.

**Document ingestion, ported from PAi Legal.** `electron/ingestion.cjs` is a
Node port of Legal's `pai_legal/ingestion.py`: text layer first, OCR only for
pages with no usable text, page markers preserved so a value can cite the page
it came from. PDF handling uses `mupdf` in place of PyMuPDF; OCR shells out to
a bundled Tesseract exactly as Legal does. Also handles txt, csv/tsv, html,
docx and odt.

Three deliberate departures from the Legal original:

- Tesseract runs in TSV mode rather than plain stdout, so per-word confidence
  comes back with the text. Bracketing a term by how well it was read needs a
  number.
- A file neither path can read is not an error. Legal raised on a scanned page
  with no OCR runtime; Claims returns `needsVision: true` so a local model can
  describe it.
- The bracket ceiling grades the ingest, not the reader.

## What the bracket ceiling actually measures

Extraction is the base. OCR or the text layer produces characters; a model then
reads those characters and reports values. Those are different jobs and only
the first is a reconstruction, so only the first limits confidence. A model
locating a labelled figure inside already-extracted text is reading, not
guessing, and is not penalised for it.

What decides whether the model read or reasoned is `verifyAgainstSource`: the
value it reports either occurs in the text for the page it cited, or it does
not. Verbatim means the model transcribed and the value inherits the ingest
ceiling — EXPLAINED off a text layer. Absent means the model derived it, and a
derived value caps at SPECULATIVE no matter how clean the source.

Matching is on whole tokens and runs of adjacent tokens, never substrings.
`$312,000` reduced to digits contains `31200`, so substring matching would let
a Coverage B figure verify against a Coverage A page. There is a regression
test for exactly that.

`crossMethodBracket` handles the corroboration case. The text layer and OCR
fail in unrelated ways, so when both read the same page and agree on a value,
that is two independent sources — VALIDATED, on the same rule used everywhere
else in the product. When they disagree it is CONTRADICTED, because a conflict
between two reads is a live disagreement rather than a weak reading.

Only raw pixels with no OCR beneath them stay capped at SPECULATIVE: those are
characters nobody else has seen, which is a claim about the document rather
than a reading of it.

**Documents are persisted and hashed.** `claim:attachDocument` copies uploads
into the case `uploads/` folder, computes a SHA-256, populates the
`contentHash` field that was previously declared and never written, and reports
`duplicateOf` when the same bytes are already on the case under another name —
the same file twice is not two independent sources.

**Dispute letters are gated, not warned.** A letter leaves the workspace and is
read by the carrier without any of the brackets attached, so every figure in it
is asserted flat. `disputeLetterPrerequisites` blocks generation until four
conditions are met — the policy packet is on the case with a real filename, no
conflicting policy values are outstanding, carrier and claim number and date of
loss are present, and no intake field was left blank. Unread coverage terms do
not block the letter; they surface in the persistent accuracy warning instead.
The studio shows which prerequisites are outstanding and why, rather than
rendering templates behind a disabled button.

## Compatibility

`PolicyCoverageLimits` is retained and deprecated so existing views compile
unchanged. A `0` in that structure now means "not read from a policy
document" — it does not mean the policy states zero. Read `policyRecord` for
the authoritative terms.

`InsuranceClaim.policyRecord`, `InsuranceClaim.intakeGaps` and the two new
`auditedTrueValuation` fields are required. Any claim persisted by 1.3.1 needs a migration pass that attaches
`emptyPolicyRecord()` before it will load.

## Tests

`src/domain/policyRecord.test.ts` — 11 tests covering the bracket algebra,
insured-asserted values resisting promotion, OCR degradation, missing-form
detection, and the guarantee that an unread policy yields untestable checks
rather than passes. Five cover the dispute-letter gate, including the case that matters most: an
evidence record of type `policy_dec` with an empty filename does not count as a
supplied packet. Full domain suite: 66 tests passing. `electron/ingestion.test.cjs` adds 21
more covering extraction, TSV confidence parsing, bracket ceilings, verbatim
verification, the digit-substring regression, cross-method corroboration and
conflict, and content hashing.

## Added in 1.3.4

**Discrepancy resolution.** When the text layer and OCR disagree on a value,
`resolveDiscrepancy` tries to settle it against the document before involving
anyone: corroboration elsewhere in the packet, a difference confined to
characters OCR is known to confuse, or an OCR confidence too low to contradict
a clean text layer. A settled value is EXPLAINED, not VALIDATED — the reads did
not agree, so this is one source that survived scrutiny rather than two that
corroborated.

When nothing in the document settles it, the conflict is not resolved away. It
is recorded on `PolicyRecord.conflicts` with both candidate values, their
methods, OCR confidence, how many times each appears in the packet, what was
tried, and what the user has to do. Nothing is averaged and no winner is
guessed.

**Unresolved conflicts are surfaced and they block.** The persistent banner
shows each conflict with both readings and a confirm button per candidate.
Until the user confirms one against the document, the record's ceiling is
CONTRADICTED and the dispute-letter gate refuses. Confirming records the chosen
value and the timestamp; the losing candidate stays on the record.

**The policy packet is now genuinely mandatory.** In 1.3.3 the form required a
file, but the bytes never left renderer memory: the evidence record named a
document that was not on the case. `claim:create` now takes the documents with
the claim and is atomic — the files are copied into the workspace, hashed and
read before the claim file is written, and if any of that fails the folder just
created is removed rather than leaving a paid case with no policy in it. The
handler rejects outright if no `policy_dec` document is supplied, so the
requirement holds even if the UI is bypassed.

Evidence records for attached documents carry the real filename, the SHA-256,
the extraction method, page count, OCR page count and confidence, and the
bracket ceiling. They assert nothing about the contents: the excerpt is empty
and the observations state only how the document was read.

A document that cannot be parsed is still stored. Extraction failure degrades
the record to `needsVision` rather than rejecting the file — losing the
customer's policy because a PDF was malformed would be worse than holding a
document we cannot yet read.

**Word-for-word reconciliation across readers.** `src/domain/transcriptReview.ts`
compares every reading of the same page — embedded text layer, Tesseract, and
the model reading back the ingested text — word by word, and decides whether
the page can be trusted.

Alignment resynchronises rather than comparing index for index. Readers drop
and add words, so a single dropped article would otherwise report every
following word as a discrepancy; the aligner finds the next run all readers
share and treats only the span between as disputed.

Resolution is by agreement alone. Two readers that saw the page independently
and produced the same word corroborate each other and the page reads VALIDATED.
Where two agree and a third differs, the majority stands at EXPLAINED and the
disagreement is recorded rather than discarded. Where no two agree, nothing is
chosen: every reading is kept, the word is marked in the text, and the user is
asked to confirm it against the document with the surrounding words as context.
No reader is authoritative on its own — a scanner that embeds its own poor OCR
as a text layer is common enough that "the text layer wins" is not safe.

Numbers are compared strictly. Punctuation inside a word carrying digits is
never stripped, because `$6.240` and `$6,240` are different amounts and `1.5`
is not `15`. Sentence punctuation around a figure is still ignored.

**Images are transcribed, shown, and verified before they are used.** A page
read only by the model is marked `requiresUserVerification` and capped at
SPECULATIVE. `assessEstimationReadiness` blocks the estimation flow while any
word is unresolved or any model transcription is unreviewed, and names the
pages responsible. Confirming a word or reviewing a transcription earns
EXPLAINED, never VALIDATED — a person reading the document is a direct reading,
not a corroborated one.

**The model re-read is wired.** `POST /api/verify-transcript` hands the model
the already-extracted text and asks for it back verbatim. The system prompt
forbids correcting spelling, expanding abbreviations, normalising numbers,
adding words or removing them, and instructs it to reproduce garbled passages
as they appear. Temperature is 0. The point is an independent reader whose
mistakes are uncorrelated with Tesseract's — any "improvement" it made would
destroy exactly the property that makes agreement meaningful.

`POST /api/transcribe-images` handles pages the text pipeline cannot read. It
writes `[illegible]` rather than guessing, never completes a partly visible
number, and returns `requiresUserVerification: true`. Both endpoints degrade
quietly when no provider is configured; the ingested readings still reconcile
against each other.

**Review UI.** `TranscriptReviewPanel` shows disputed words with every reading
side by side and a confirm button on each, plus the surrounding words so the
user can find the spot on the page. No reading is marked recommended — a nudge
toward one is the same as choosing it, and there is a test asserting the
discrepancy record carries no preferred value. Image transcriptions are shown
whole with the original one click away, and confirming is a single explicit
action. When everything reconciles the panel says so and gets out of the way.

**The pipeline is connected end to end.** `src/domain/reviewRunner.ts` splits
extraction output back into pages on its markers, asks the model to read each
back, and reconciles the two into `InsuranceClaim.pageReviews`. It runs after
`createClaim` returns, so a slow or unreachable model never costs the customer
the case they just paid for.

Re-running is safe: a word the user has already confirmed and a page they have
already verified are carried forward, so nobody is asked the same question
twice. Both are covered by tests.

`TranscriptReviewPanel` is mounted at the top of the Evidence Vault, and the
PSi estimator, estimate audit and payout analysis tabs are gated on
`assessEstimationReadiness`. A blocked tab explains which pages are responsible
and links to the review rather than presenting a disabled control.

## Packaging fixes in 1.3.4

**Build tooling no longer ships to customers.** `vite`, `@vitejs/plugin-react`
and `@tailwindcss/vite` were listed under `dependencies`, so electron-builder
bundled the whole build chain into 1.3.3 — rollup, esbuild, babel, tailwind
oxide, lightningcss, react-refresh, including an 11 MB `esbuild.exe` and a
9.1 MB `lightningcss` native module in `app.asar.unpacked`. They are now
devDependencies.

**`mupdf` added to `package.electron.json`.** It was in `package.json` only,
which would have left the packaged app without a PDF reader depending on which
manifest the build used. It also ships a `.wasm`, so `asarUnpack` now keeps the
mupdf tree on disk where the loader can resolve a real path.

**Store display name corrected.** `electron-builder.yml` carried
`displayName: PAi Claim's`, which reached the 1.3.3 manifest twice and would
have appeared with the stray apostrophe in the Store listing and Start menu.

## Still outstanding

Estimate-comparison and Xactimate exports are not yet gated or annotated; only
dispute letters are. Case creation continues to seed other figures that were not measured —
`depreciationWithheld`, `eligibleALE`, `initialOfferRCV`, and the O&P and code
percentages used for the opening estimate. Those are the same class of defect
as the policy terms and should be addressed next.

Tesseract is not bundled. `findTesseract()` looks in `resources/tesseract/` and
`runtime/tesseract/`; until the binary and `tessdata` are added to
`extraResources`, scanned pages fall through to `needsVision` and the
`pdf-text+tesseract` path never runs. Text-layer PDFs are unaffected.

Model weights are not bundled by design — they are downloaded on first run,
since the Hugging Face model licences do not permit redistribution.

The policy reader itself (declarations parsing, endorsement schedule
extraction) is not in this release. The interfaces it will populate —
`transcribed()` and `EndorsementEntry` — are in place.
